#!/usr/bin/env bash
# SessionStart health-check: warns if HTTP-backend MCPs (Jira, Confluence, etc.) are not reachable.
# Does NOT start containers — run once after install:
#   docker compose -f ~/.claude/mcp/<kit>/docker-compose.yaml up -d
set -euo pipefail
# shellcheck source=log-helpers.sh
source "$(dirname "${BASH_SOURCE[0]}")/log-helpers.sh" 2>/dev/null || true

_warn_backend_down() {
  local name="$1" port="$2"
  local compose_file
  compose_file="$(find "$HOME/.claude/mcp" -name "docker-compose*.yaml" 2>/dev/null | head -1)"
  local start_hint="${compose_file:+docker compose -f $compose_file up -d}"
  local msg="MCP backend '${name}' not responding on port ${port}."
  [[ -n "$start_hint" ]] && msg+=" Start: ${start_hint}"
  echo "  [mcp-health] ${msg}" >&2
  log_obs "WARN" "ensure-mcp-health" "${msg}" 2>/dev/null || true
}

# curl without -f: exit 0 on any HTTP response, non-zero only on connection failure
_backend_up() {
  curl -s --connect-timeout 2 --max-time 3 -o /dev/null "http://127.0.0.1:${1}/" 2>/dev/null
}

# A headless side call (sr_call_haiku, precompact-handoff.sh: GS_NO_AUTO_HANDOFF=1) has no one to
# warn; every Haiku call logged both WARNs (review-remediation row 34).
[[ -n "${GS_NO_AUTO_HANDOFF:-}" ]] && exit 0

# Skip entirely if no ACME compose file is present (stack not installed/active)
_mcp_compose="$(find "$HOME/.claude/mcp" -name "docker-compose*.yaml" 2>/dev/null | head -1)"
[[ -z "$_mcp_compose" ]] && exit 0

# Warn only while the stack is up. The kit is kept for other clients and instances (ruling
# 2026-09-27), so an idle stack is its normal state, not a fault — and Claude Code already reports
# the MCP connection failure itself. "Up" = a running container of the compose project, which
# docker compose names after the file's directory unless the file sets `name:`. No docker, or a
# daemon that does not answer, means not up (row 34).
_proj=$(sed -n 's/^name:[[:space:]]*//p' "$_mcp_compose" | head -1 | tr -d "\"' ")
_proj=${_proj:-$(basename "$(dirname "$_mcp_compose")")}
# Compose's own name for that project: lowercase, every char outside [a-z0-9_-] dropped, a leading _ or - trimmed
# (probed: <mcp-client-2> → mcp-client-2, _Lead.Kit → leadkit). The raw <mcp-client-N> dir a headless scrubbed import
# keeps never matched, so the check never ran there (bundle audit F5).
_proj=${_proj,,}; _proj=${_proj//[^a-z0-9_-]/}
while [[ "$_proj" == [-_]* ]]; do _proj=${_proj#?}; done
command -v docker >/dev/null 2>&1 || exit 0
[[ -n "$(timeout 3 docker ps -q --filter "label=com.docker.compose.project=${_proj}" 2>/dev/null)" ]] || exit 0

_backend_up "8569" || _warn_backend_down "jira-mcp"       "8569"
_backend_up "8570" || _warn_backend_down "confluence-mcp" "8570"
exit 0
