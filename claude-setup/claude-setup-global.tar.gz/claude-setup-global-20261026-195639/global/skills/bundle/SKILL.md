---
name: bundle
spotlight: true
description: Use when packaging the current Claude Code setup into a portable .tar.gz archive for transfer to another machine or project. Use to export global config, generalize a project CLAUDE.md into a template, or prepare a shareable setup bundle.
user-invocable: true
disable-model-invocation: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /bundle — Package the current Claude Code setup into a portable .tar.gz archive for transfer to another machine or project.
> ```
>
> Then output the complete flag table from the **"Step 1: Parse Arguments"** section below. Then STOP.

---

Bundle the current Claude Code setup into a portable `.tar.gz` archive.

Parse `$ARGUMENTS` and narrate each phase as it runs.

**Lean-mode interlock**: Before doing anything, run:
```bash
if [[ -f "$HOME/.claude/LEAN_MODE" ]]; then
  echo "⛔ Lean mode is active — CLAUDE.md files are stubs and would produce a broken bundle."
  echo "   Run /lean off first, then retry /bundle."
  exit 1
fi
```
If LEAN_MODE exists, abort immediately with the above message. Do not proceed.

**Trust model**: this machine is the origin. Produced bundles do NOT include the export infrastructure (`bundle.md`, `claude-export.sh`, `bin/lib/claude-export/`). All other tools — including `claude-adapt.sh`, `lib/claude-adapt/`, `claude-import.sh`, and `lib/claude-import/` — ARE included so targets can adapt and install future bundles. Targets can RECEIVE bundles but cannot CREATE them (no export tooling).

---

## Step 1: Parse Arguments

Extract from `$ARGUMENTS`:
- `--scope <value>` — one of `global`, `project`, `all`, or comma-separated `global,project` (default: `project`)
- `--target <path>` — source project path for project scope (default: current working directory)
- `--output <path>` — explicit output path (single scope only; silently ignored with a warning if multiple scopes are requested)
- `--output-dir <dir>` — output directory for any scope count (mutually exclusive with `--output`)
- `--dry-run` — show what would be staged, no archive created
- `--scrub` — strip PII and machine-specific paths from text content (**DEFAULT ON**; project scope always force-scrubs regardless of this flag)
- `--no-scrub` — opt out of scrubbing for **global scope only** (personal machine-to-machine migration); project scope always force-scrubs and ignores this flag
- `--include-memories` — opt-in: include `~/.claude/projects/*/memory/` in global archive (private per-project notes; **default: excluded** — memory scaffold template written instead)
- `--include-claude-json` — opt-in: include `~/.claude.json` in global archive (contains OAuth tokens, userID, org UUIDs, project paths; **default: excluded**)
- `--scrub-claude-json` — strip identity and stale fields from `~/.claude.json` before archiving: identity (`oauthAccount`, `userID`, `accountUuid`, `organizationUuid`, `machineID`, `projects`, `firstStartTime`, `numStartups`), skill/usage tracking (`skillUsage`, `tipsHistory`, usage counters), all caches (`clientDataCache`, `additionalModelCostsCache`, `metricsStatusCache`, …), stale timestamps (`changelogLastFetched`, `lastPlanModeUse`, …), stale migration booleans (**DEFAULT ON**; only has effect when `--include-claude-json` is set)
- `--no-scrub-claude-json` — skip `~/.claude.json` scrubbing — full fidelity; use ONLY for same-machine backups, **never share** the resulting archive
- `--share` — a bundle for other people: `--scope global` with the scrub on, and the settings template loses `skipDangerousModePermissionPrompt`, `skipAutoPermissionPrompt`, `remoteControlAtStartup`, every `CLAUDE_CODE_EXPERIMENTAL_*` env key and `permissions.defaultMode` (`model` and `enabledPlugins` stay). Refuses `--no-scrub` and any other `--scope`. `MANIFEST.json` records `"share": 1`.
- `--include-pipeline` — include the export toolchain in the global bundle: `bin/claude-export.sh`, `bin/lib/claude-export/`, `skills/bundle/SKILL.md`, `bin/tests/`. Makes the **target a full origin** — it can create its own bundles and re-export. Requires `--scope global`. Safe to distribute (scripts only, no credentials). **Default: excluded** — targets are consumers, not origins.

If both `--output` and `--output-dir` are present: report error and stop.

Determine `TARGET` (for project scope):
- If `--target` appears in `$ARGUMENTS`: use that value
- Otherwise: use current working directory

Determine output path(s) for project scope:
- If `--output` set (single scope): use that path directly
- If `--output-dir` set: `<dir>/claude-setup-project-<YYYYMMDD-HHMMSS>.tar.gz`
- Otherwise: `./claude-setup-project-<YYYYMMDD-HHMMSS>.tar.gz`

---

## Step 2: Announce What Will Be Bundled

State clearly before doing any work:
- Scope(s) being exported
- Source path (project scope): `$TARGET`
- Output path(s)

---

## Step 3: Execute by Scope

### If `--scope global` (or the global half of `--scope all`)

**Pre-flight: unfilled CONFIGURE marker check**

Before calling the bundler, scan `~/.claude/` for unfilled `<!-- CONFIGURE:` markers
(these are global template placeholders that must be filled manually by the team admin):

```bash
rg -n --no-ignore -g '*.md' -g '*.json' '<!-- CONFIGURE:' ~/.claude/ \
  2>/dev/null | grep -v '/projects/' | grep -v '/plugins/'
```

`rg`, not `grep -rn`: rg skips hidden files, so it never opens `~/.claude/.credentials.json` (a `*.json`
under the tree). The bash firewall asks on a recursive `grep` over a tree holding a credential store, and
denies it at TOTAL (plan credential-ancestor-tiering, S4). `--no-ignore` keeps gitignored files in the scan
and does not add hidden ones.

If any matches are found: warn the user:
> "Found unfilled CONFIGURE markers in these files — the bundle will ship an incomplete template.
> Fill them manually using `/adapt-project`, then re-run `/bundle`."
> List each file:line match.

In `--dry-run` mode: still run the check and print any findings, but do not abort — let the dry-run complete so the user can see the full picture.
In live mode: invoke the `ask-human` skill: question 'Unfilled CONFIGURE markers found — bundle will ship an incomplete template. Proceed anyway?', options: 'Abort — I will fill the markers first (Recommended)' / 'Proceed anyway — ship the incomplete template'. Do not call the bundler until the user confirms.

Call the bash bundler — it handles global scope completely:

```bash
bash ~/.claude/bin/claude-export.sh --scope global \
  [--scrub|--no-scrub] \
  [--include-memories] \
  [--include-claude-json] [--scrub-claude-json|--no-scrub-claude-json] \
  [--include-pipeline] \
  [--output PATH] [--output-dir DIR] \
  [--dry-run]
```

Pass through all relevant flags from `$ARGUMENTS`. Then jump to Step 4.

**What global scope bundles** (from `~/.claude/`):

| Included | Notes |
|----------|-------|
| `CLAUDE.md` | Global reasoning framework |
| `THINKING.md` | Thinking frameworks library (required by `@THINKING.md` in CLAUDE.md) |
| `RTK.md` | RTK usage reference (required by `@RTK.md` in CLAUDE.md) |
| `RTK-local.md` | RTK local notes (required by `@RTK-local.md` in CLAUDE.md) |
| `BLAST-RADIUS.md` | Destructive-command gate reference (CLAUDE.md's "Destructive & Risky Command Protocol" section) |
| `refs/` | Reference docs: `SKILLS.md` (global skill index), `SESSION-REMEMBER.md` (pipeline tuning), `PREREQUISITES.md` (prerequisite checklist) |
| `README.md` | If present |
| `settings.json` | Renamed to `settings.json.template` in archive |
| `skills/` | All generic skills. **`_CE_GENERIC_SKILLS` in `~/.claude/bin/lib/claude-export/config/defaults.sh` is the canonical, authoritative list** — consult it rather than this prose, which is illustrative only. Includes (non-exhaustive): memory-off/on/readonly/status/block/unblock, lean/lean-block/lean-unblock, ask-human, expanding-context, audit, inspect, sleuth, gaps, mega-analysis, skill-audit, memory-promote, aggregate-findings, converge, skill-extractor, retrospective, handoff, loop, recent, repair, bootstrap, consolidate, install, adapt-project, learning-on/off, cleanup, sweep, forge, templatize, expand, cross-check, qa-sweep, model-audit, pre-session-health, sr-health, progress, next, goal-brief. Agent I in `/audit` surfaces drift between defaults.sh and actual skills. |
| `agents/` | User-authored agent definition files (`~/.claude/agents/*.md`) — discovered automatically by Claude Code |
| `hooks/session-remember/` | Full session-remember pipeline |
| `hooks/*.sh` | Top-level hook scripts listed explicitly in `_CE_GENERIC_SKILLS` (intentional manifest, not glob discovery — bundle contents must be auditable). Includes: `backup-before-write.sh`, `session-status.sh`, `log-helpers.sh`, `ask-human-gate-block.sh` (PreToolUse — blocks tool calls when a new user message arrived since the last ask-human invocation), `ask-human-gate-track.sh` (PostToolUse — clears the gate after ask-human successfully runs), `ask-bash-firewall.sh` (PreToolUse Bash — v3 boundary gate, **needs python3 on the target**, see `refs/PREREQUISITES.md`), the advisor guards, and others. Some are library scripts sourced by others, not registered hooks. |
| `hooks/tests/` | Exactly the three gate self-tests `/install` tells the target to run: `test-ask-human-gate.sh`, `test-bash-firewall.sh`, `test-question-guard.sh` (fixture-free). Other hook tests stay origin-only. |
| `templates/` | Project-tier templates consumed by `/bootstrap`: `project-settings.json` (bare `Bash`/`Read`/`Edit`/`Write` allow — the global boundary gate does the tiering inside a repo) and `project-boundary.json` (`protected[]` / `trusted_outside[]` overrides read by `ask-bash-firewall.sh`), and `project-progress.json` (the `/progress` adapter read by `bin/project-state.sh`: cursor files, registers, targeted `test_cmd`, `shas_unstable`, the liveness `probe_cmd`/`probe_timeout_s`; all paths relative to the repo, so it is bundle-safe). |
| `bin/` | Every `bin/` script and `bin/lib/` module named in `_CE_GENERIC_SKILLS` (the authoritative list, about 55 entries): the install toolchain (`claude-adapt.sh`, `claude-import.sh` and their libs), the gate executor and grid (`gates-bypass.sh`, `gates-status.sh`), the permission engine's scripts (not its rules file), `unattended.sh`, `apply-parked.sh`, `bypass-review.sh`, `project-state.sh`, `claude-cleanup.sh`, the hook registrars (`*-apply.sh`) and the expertise tools. Note: `bin/claude-export.sh` and `bin/lib/claude-export/` are origin-only and excluded. |
| `mcp/` | MCP servers — organized per-client: `mcp/<client>/` (e.g. `mcp/acme/`). Scripts, `package.json`, `package-lock.json`; `*.env` scrubbed to `CHANGE_ME_*` placeholders (an `export KEY=` line too); every other env variant (`.env.local`, `.env.bak`, `prod.env.bak`, …) is stripped, except `*.example`/`*.sample`/`*.template`, and a credential `KEY=literal` line left in any staged `mcp/` file after the scrub FATALs the bundle (file:line:key, never the value); `node_modules/` excluded (rebuilt by `/install` via `npm ci`). In scrubbed bundles: folder names become `mcp/<mcp-client-N>/` stubs (org-neutral, numbered); import-time setup renames them interactively. |
| `~/.claude.json` | Opt-in only via `--include-claude-json` |
| Memory | Scaffold template by default; real `projects/*/memory/` with `--include-memories` |
| `plugins-reinstall.sh` | Generated at bundle time from `installed_plugins.json` + `known_marketplaces.json`. Run on target: `bash ~/.claude/plugins-reinstall.sh` (installs bundle plugins). Add `--reconcile` to also uninstall plugins present on the target but absent from the bundle. |

**Always excluded** (transient/sensitive): `projects/` (except memories if opted in), `statsig/`, `cache/`, `shell-snapshots/`, `file-history/`, `session-env/`, `sessions/`, `run/`, `state/` (live bypass/autonomous sentinels **and `gates-bypass-rules.json`, which maps every recursive bypass scope and except-list on this machine** — never bundle; asserted at build time in `bin/lib/claude-export/core/scope.sh`, regression tests (e)/(f) in `bin/tests/claude-export-leak-check.test.sh`), `tmp/`, `history.jsonl`, `paste-cache/`, `ide/`, `chrome/`, `backups/`, `tasks/`, `agent-memory/`, `plans/`, `plugins/`, `policy-limits.json`, `settings.json.bak.*`, backup copies anywhere in staging (`*.claude-bak.*`, `*.bak.<digits>`, `*.bak`, `*.bak-*`, `*.backup`, `*.orig`, `*.old`, `*.save`, `*~` — staging only, nothing on disk is deleted), `*.log`, `security_warnings_state_*.json`, `downloads/`, `telemetry/`, `mcp/**/node_modules/`, `llm-sandbox/` (runtime scratch space for session-remember LLM calls — machine-local temp content, not portable)

**Origin-only tools excluded from every bundle by default** (targets are consumers, not origins): `bin/claude-export.sh`, `bin/lib/claude-export/`, `skills/bundle/SKILL.md`, and every `bin/tests/` suite not named in `_CE_GENERIC_SKILLS` (about a dozen are: the shipped tools' own suites and `bin/tests/lib/isolate.sh`). Pass `--include-pipeline` to override — the target becomes a full origin and can create its own bundles.

**What `--scrub` does** (default ON — pass `--no-scrub` to disable for global scope):
- Strips PII patterns (name, email) → `[redacted]`
- Replaces `/path/to/your/project` → `/path/to/your/project`, `/home/user` → `/home/user`; the org/client name (from `.private-renames`) → a valid identifier-safe token (e.g. `acme`) — a RENAME, not `[redacted]`, so JS/shell/YAML/env identifiers stay syntactically valid
- Replaces `{{TZ}}` → `{{TZ}}` — **resolved to the host timezone automatically at import time** (`claude-import.sh` → `ci_resolve_tz`); only un-resolved if the target machine cannot detect a timezone (falls back to `UTC`)
- Truncates `CLAUDE.md` at `## Specific to this computer setup` (machine-specific routing, paths, timezone stripped), then re-appends the whole-line `@FILE` include block from its end for every file the bundle ships (`@RTK.md`, `@RTK-local.md`, `@THINKING.md`, `@BLAST-RADIUS.md`); an include of an unshipped file and any prose `@` mention stay stripped (row 26ze, B6c-f)
- Rewrites `/path/to/your/project/`-prefixed deny paths in `settings.json.template` to generic placeholders
- **`*.env` files**: credential keys (any case, a credential word — `TOKEN KEY SECRET PASSWORD PASSWD PASSPHRASE PASS PWD CREDENTIAL(S) COOKIE AUTH BEARER PAT APIKEY` — as the whole key or an `_`-separated tail, optional numeric suffix; `docs/SPEC.md` export section) → `CHANGE_ME_<KEY>`; `HTTP(S)_PROXY` → `http://CHANGE_ME_PROXY_HOST:PROXY_PORT`; external `*_URL`/`*_URI`/`*_WEBHOOK`/`*_ENDPOINT` values and corporate-hostname URLs → `https://CHANGE_ME_SERVICE_URL`; a `user:pw@` URL under any key → `CHANGE_ME_<KEY>`
- **`settings.json.template`**: `env` keys of the same grammar, keys naming `NTFY|HEADER|WEBHOOK|DSN|PROXY`, and secret-shaped values (bearer/authorization, URL userinfo, external URLs), and Claude Code's `AWS_BEARER_TOKEN_BEDROCK` / `AWS_ACCESS_KEY_ID` → `CHANGE_ME_<KEY>`; a hook or statusLine command with any such literal `KEY=value` assignment, anywhere in its text (quotes included), is replaced WHOLE by a `true # CHANGE_ME_HOOK_COMMAND …` placeholder naming the key (row 26zq; a pure `$VAR` / `${VAR}` / `$(cmd)` / backtick reference is kept)
- **`mcp/<client>/` folders** → `mcp/<mcp-client-N>/` stubs (org-neutral, numbered; resolved interactively at import)
- **`config/defaults.sh`**: literal PII pattern lines removed

> 🔁 **Refill on import**: every placeholder the scrub pass introduces is recorded in
> `MANIFEST.json` under `scrubbed_placeholders`, and `claude-import.sh` prints a
> **"Scrubbed placeholders — replace with real values"** guide (with a ready `grep`) on both
> fresh-install and existing-`~/.claude/` merge paths. `{{TZ}}` is auto-resolved; everything
> else (`CHANGE_ME_*`, `/path/to/your/project`, `YOUR_SERVICE_INSTANCE`) must be filled in by the
> installer. `<your-lead-agent>` is **legacy** — its scrub rule was removed 2026-08-19 with the
> agent it generalised, so nothing produces it now; the importer still detects it because bundles
> scrubbed before that date can carry it.

> ⚠️ **`--scrub` rewrites only credential-like `KEY=value` assignments inside `settings.json`'s `hooks` commands** (above); the rest of each command travels verbatim. PreToolUse hooks that call machine-local binaries (e.g. `rtk hook claude`) travel verbatim in `settings.json.template` even with `--scrub`. For shared bundles, review `settings.json.template` manually and remove any `PreToolUse` hooks that call local binaries before distributing. One exception is always stripped, scrub or not: the permission-engine wiring (the engine entry, the SessionStart canary and the firewall's rules-file env), because its rules file never ships (framework-health row 26l). Only a whole-command registration is removed, and the firewall's rules-file env prefix is cut from its command: any other hook text naming the engine, its python module or its rules file, a `hooks` value of the wrong type, or a failed copy during collection (such as a dangling symlink under `agents/`) aborts the export instead of shipping an engine-wired or partial bundle (rows 26n/26p, docs/SPEC.md §2.19).

**What `--scrub-claude-json` strips** (default ON when `--include-claude-json` is set):
- **Identity**: `oauthAccount`, `userID`, `accountUuid`, `organizationUuid`, `machineID`, `projects`, `firstStartTime`, `numStartups`
- **Skill/usage tracking**: `skillUsage`, `tipsHistory`, `btwUseCount`, `ideHintShownCount`, `promptQueueUseCount`, `remoteControlUpsellSeenCount`, `autoPermissionsNotificationCount`, `hasUsedBackgroundTask`, `hasSeenTasksHint`, `claudeCodeFirstTokenDate`
- **Caches**: `clientDataCache`, `additionalModelCostsCache`, `additionalModelOptionsCache`, `cachedGrowthBookFeatures`, `cachedExtraUsageDisabledReason`, `metricsStatusCache`, `overageCreditGrantCache`
- **Stale timestamps/state**: `changelogLastFetched`, `closedIssuesLastChecked`, `lastReleaseNotesSeen`, `lastPlanModeUse`, `lastOnboardingVersion`
- **Stale migration flags**: `migrationVersion`, `sonnet1m45MigrationComplete`, `opusProMigrationComplete`, `unpinOpus47LaunchEffort`, `opus47LaunchSeenCount`, `hasResetAutoModeOptInForDefaultOffer`, `officialMarketplaceAutoInstallAttempted`, `officialMarketplaceAutoInstalled`
- **MCP server secrets** (within `mcpServers[].env`): keys matching `token|secret|password|credential` → `CHANGE_ME_<key>`; non-local URLs (not localhost/127.0.0.1) → `https://YOUR_SERVICE_INSTANCE`; `/home/<user>/` in `command` → `/home/user/` (the text pass's placeholder, so the importer rewrites both; bundles made before 2026-10-25 carry `/home/CHANGE_ME_HOME/`, which it rewrites too); identity blocks (`oauthAccount`, `githubRepoPaths`, …) deleted
- **Identity values, anywhere** (P1-3, 2026-10-25): the account UUID, org UUID, userID and email are captured before the strip and swept from the whole file — any entry whose key or string value contains one, any array string that does — so a cache key a newer Claude Code adds cannot carry them (four did: `promoStartupStatusCache`, `cachedArtifactRoster`, `githubWebConnectionStatusCache`, `apiCreditLinkStatusCache`). **Fails closed**: no jq, a jq error, or a surviving value aborts the export; the raw file never ships

### If `--scope project` (or the project half of `--scope all`)

**Phase 0 — LLM Generalization** (Claude does this, no bash call):

1. Check `$TARGET/CLAUDE.md` exists. If not: invoke the `ask-human` skill: question '`$TARGET/CLAUDE.md` not found. How should the bundle proceed?', options: 'Continue with blank-slate template — ADAPT markers only, no content to generalize (Recommended)' / 'Abort — I will add CLAUDE.md first'.

2. Create temp staging directory and subdirs:
   ```bash
   STAGING=$(mktemp -d /tmp/claude-export-project-XXXX)
   mkdir -p "$STAGING/project/.claude/skills"
   mkdir -p "$STAGING/project/.claude/hooks"
   mkdir -p "$STAGING/project/.claude/agents"
   ```

3. **Generalize `CLAUDE.md`**: read `$TARGET/CLAUDE.md`, apply the
   [CLAUDE.md Transformation Rules](#claudemd-transformation-rules). Write result to
   `$STAGING/project/CLAUDE.md`.

4. **Generate hook templates**: regardless of what lives in `$TARGET/.claude/hooks/`,
   emit exactly two generic templates (see [Hook Transformation Rules](#hook-transformation-rules)):
   - `$STAGING/project/.claude/hooks/lint-on-write.sh.template` — exit-code reporter
     (for linters like `eslint`, `pylint`, `hadolint`, `shellcheck`)
   - `$STAGING/project/.claude/hooks/format-on-write.sh.template` — diff reporter
     (for formatters like `prettier`, `black`, `shfmt`, `rustfmt`)
   Skip subdirs like `session-remember/`. Don't copy project hooks verbatim — the target
   picks its own toolchain during `/install` adaptation.

5. **Generalize skills**: for each `SKILL.md` file in `$TARGET/.claude/skills/*/`, apply
   [Command Transformation Rules](#command-transformation-rules). Write to
   `$STAGING/project/.claude/skills/<name>/SKILL.md` preserving the directory structure.

6. **Generalize agents**: for each `.md` file in `$TARGET/.claude/agents/`, apply
   [Agent Transformation Rules](#agent-transformation-rules). Write to
   `$STAGING/project/.claude/agents/lead-agent.md.template`.

7. **Write permission skeleton + guidance**: create `$STAGING/project/.claude/settings.json`
   and `$STAGING/project/.claude/settings.notes.md` using [Settings Templates](#settings-templates).

8. **No memory scaffold**: Claude Code reads memory only from `~/.claude/projects/<slug>/memory/`, so a
   project bundle carries none (a scaffold in `<project>/.claude/projects/` is never read; bundle audit F7).

9. **Embed bootstrapper**:
   ```bash
   cp ~/.claude/bin/claude-import.sh "$STAGING/claude-import.sh"
   mkdir -p "$STAGING/lib"
   cp -a ~/.claude/bin/lib/claude-import "$STAGING/lib/"
   ```

9b. **Write MANIFEST.json** (required by `claude-import.sh` — without it, extraction fails):
    ```bash
    cat > "$STAGING/MANIFEST.json" <<EOF
    {
      "version": "1.0.0",
      "scope": "project",
      "scrub": true,
      "generated_at": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
      "source_machine_hash": "llm-generated",
      "install_command": "bash ./claude-import.sh"
    }
    EOF
    ```

9c. **Bundle consumer skills** (these live in `~/.claude/skills/`, not in `$TARGET/.claude/skills/`,
    so Step 5 does not pick them up — they must be copied explicitly):

    - **`adapt-project/SKILL.md`**: copy `~/.claude/skills/adapt-project/SKILL.md` verbatim to
      `$STAGING/project/.claude/skills/adapt-project/SKILL.md`. No modification needed —
      the skill is already location-aware: Phase 4 checks for `.claude/skills/adapt-project/SKILL.md`
      relative to the project root and self-destructs that copy when all markers are resolved.
      The global `~/.claude/skills/adapt-project/SKILL.md` is never affected.

    Note: `repair.md` ships in the **global** bundle only — do NOT copy it here.

9d. **Write root README**: create `$STAGING/README.md` — the first thing a recipient reads
    after extracting the archive:

    ```markdown
    # Claude Code Setup — Project Bundle

    ## Prerequisites — install the global bundle first

    This project bundle works best with the global `~/.claude/` config already in place.
    If you haven't done so, install the global bundle first:
    ```bash
    tar -xzf claude-setup-global-<ts>.tar.gz && cd claude-setup-global-<ts>/
    bash ./claude-import.sh
    cp ~/.claude/settings.json.template ~/.claude/settings.json   # edit to fit your tools
    # claude-import.sh already restored +x on shipped *.sh — next line only needed if you skip it
    chmod +x ~/.claude/hooks/*.sh
    ```
    Then open a Claude Code session: `/memory-status` → `/audit --quick`.

    ## Install

    ```bash
    bash ./claude-import.sh --target /path/to/your/project
    ```

    ## After installing

    **1. Activate hook scripts** (required before they fire):
    ```bash
    chmod +x .claude/hooks/*.sh
    ```

    **2. Open a Claude Code session inside the target project** and run in order:
    ```
    /repair --check    — verify config coherence
    /adapt-project     — probe stack, fill ADAPT markers (~2 min)
    /audit --quick     — confirm command coverage and hook wiring (~2 min)
    /memory-status     — confirm session-remember pipeline is active
    ```

    `/adapt-project` probes your project (language, framework, tests, linter, formatter) and fills all
    `<!-- ADAPT: -->` markers in `CLAUDE.md` and `.claude/` automatically. Safe to re-run.

    ## What's included

    | Item | Purpose |
    |------|---------|
    | `CLAUDE.md` | Project context skeleton — filled by `/adapt-project` |
    | `.claude/skills/` | Slash skills: /lint, /fmt, /validate, /recent, /adapt-project |
    | `.claude/hooks/` | Hook templates — activated by `/adapt-project` |
    | `.claude/agents/` | Lead agent skeleton — fill after `/adapt-project` |
    | `.claude/settings.json` | Permission skeleton |
    ```

**Phase 1 — Archive**:

10. If `--dry-run`: show the staged file tree and total count, then stop:
    ```bash
    find "$STAGING" -type f | sort | sed "s|$STAGING/||"
    echo ""
    echo "Total: $(find "$STAGING" -type f | wc -l) file(s)"
    rm -rf "$STAGING"
    ```

11. Determine output path (from Step 1 logic). Create output directory if needed:
    ```bash
    mkdir -p "$(dirname "$OUTPUT_PATH")"
    ```

12. Rename the staging dir to the archive basename so extracted files land cleanly:
    ```bash
    ARCHIVE_BASE=$(basename "$OUTPUT_PATH" .tar.gz)
    mv "$STAGING" "$(dirname "$STAGING")/$ARCHIVE_BASE"
    STAGING="$(dirname "$STAGING")/$ARCHIVE_BASE"
    ```

    Create the archive:
    ```bash
    tar --create --gzip --file="$OUTPUT_PATH" \
        --owner=0 --group=0 --numeric-owner \
        --directory="$(dirname "$STAGING")" "$(basename "$STAGING")" 2>/dev/null
    ```

13. Write SHA256 sidecar:
    ```bash
    (cd "$(dirname "$OUTPUT_PATH")" && sha256sum "$(basename "$OUTPUT_PATH")" > "$(basename "$OUTPUT_PATH").sha256")
    ```

14. Clean up: `rm -rf "$STAGING"`

### If `--scope all`

Run the project scope (Phase 0+1 above) first, then run bash for global scope.
Both scopes produce independent archives. Report both paths.

---

## Step 4: Verify Each Archive

For each archive produced:
```bash
cd <archive-dir> && sha256sum -c <archive-name>.sha256
```

---

## Step 5: Show Bundle Structure

For each archive:
```bash
tar -tzf <archive> | head -30
```

Confirm:
- `claude-import.sh` appears at bundle root
- Installable content is inside `project/` subdir (for project scope)
- No `bin/claude-export.sh` in bundle (export tooling is origin-only)
- `bin/claude-adapt.sh` and `bin/lib/claude-adapt/` ARE present in global bundles (expected — targets need them)
- ADAPT markers present in project CLAUDE.md: `tar -xOf <archive> "*/project/CLAUDE.md" | grep -c "ADAPT:"` should be > 0

---

## Step 6: Report Summary

State: scope(s) bundled, output path(s), SHA256 path(s), how to install on a target machine:
- Project: `tar -xzf <archive> && cd <extracted-dir>/ && bash ./claude-import.sh --target /path/to/project`
- Global: `tar -xzf <archive> && cd <extracted-dir>/ && bash ./claude-import.sh`

**After the bash installer completes — what the target does next:**

**Global install:**
```bash
cp ~/.claude/settings.json.template ~/.claude/settings.json   # activate settings (edit to fit)
chmod +x ~/.claude/hooks/*.sh                                 # no-op after claude-import.sh (auto-restores +x); needed only on manual copy
```
Open a Claude Code session: `/memory-status` → `/audit --quick`

**Project install** (open Claude Code inside the target project):
```
chmod +x .claude/hooks/*.sh    # activate project hooks
/repair --check                # verify config coherence
/adapt-project                 # fill ADAPT markers (~2 min, 4-agent probe)
/audit --quick                 # confirm command coverage and hook wiring (~2 min)
```
Full post-install checklist: see `/install` → Step 5h.

If any step fails, show the error and stop.

---

## CLAUDE.md Transformation Rules

Apply these when reading `$TARGET/CLAUDE.md` to produce the generalized template.

### PREPEND skeleton banner (always — before any other content)

Insert this at the very top of the output CLAUDE.md before the routing rule or any other
content:

```markdown
> **This is a project-scope skeleton.** Fill every `<!-- ADAPT: ... -->` block with
> content specific to your project.
>
> The universal reasoning framework (8-Phase Workflow, Mental Models, Core Rules, Memory
> Toggles, Destructive Command Protocol) lives in `~/.claude/CLAUDE.md` and is **not**
> repeated here. Claude loads both files automatically in every session.
>
> Once you have filled all ADAPT markers, delete this banner.

---
```

### KEEP verbatim (copy as-is, zero changes)

These sections are universal — keep them word-for-word in the template:
- "Global Reasoning Framework" heading + intro
- "Task Categorization Protocol" (the whole section)
- "Software Craftsmanship & Thinking Frameworks" (keep the entire section verbatim — all sub-sections regardless of their names, including Core Working Set, all Full Reference sections, and Phase-to-Framework Mapping; do not enumerate exhaustively or you will miss future additions)
- "The 8-Phase Workflow" (all phases, all tables)
- "Core Operating Rules" (all numbered rules)
- "Memory System Toggles" (if present)
- "Destructive & Risky Command Protocol" (if present)
- "Communication Style" (if present)
- "Core Operating Rule — Keep Docs In Sync" table (if present)

### TRANSFORM to ADAPT markers (keep heading, replace body)

For each of these sections, keep the `##` heading but replace the body with an ADAPT comment:

```markdown
## What This Project Is
<!-- ADAPT: Describe your project. What it does, platform, key tech choices,
single-developer vs team, version/release cadence. 2–5 sentences. -->

## Architecture
<!-- ADAPT: Describe your architecture. Key components, data flows, important patterns
(e.g. microservices, event-driven, monolith). A table or diagram is ideal. -->

## Common Workflows
<!-- ADAPT: Your project's most frequent workflows as bash one-liners with comments.
Example:
  make test           # Run test suite
  make dev            # Start dev server
-->

## Testing & Verification
<!-- ADAPT: How to run tests, what types exist, expected output.
Include unit, integration, E2E commands and what "passing" looks like. -->

## File Layout Quick Reference
<!-- ADAPT: Annotated directory tree. Focus on non-obvious structure.
Example:
  src/
    handlers/   # HTTP handlers — one file per route group
    models/     # Domain models — never import handlers from here
-->

## Gotchas & Pitfalls
<!-- ADAPT: Project-specific traps for future Claude sessions.
Env vars that must be set, ports that conflict, files never to delete, etc. -->

## Credentials & Stateful Data
<!-- ADAPT: Where credentials, keys, and persistent data live in this project. -->

## Debugging a Failed [Service/Component/Test]
<!-- ADAPT: Your debugging protocol. What to check first, what commands to run,
escalation path. Use the same numbered steps pattern. -->
```

For any other project-description sections: keep the heading, replace body with an ADAPT comment describing what goes there.

### GENERALIZE (keep structure, remove project-specific content)

**Top-of-file routing/delegation rule** — replace entire block with:
```markdown
<!-- ADAPT: If this project has a specialized domain warranting a lead agent, add the
delegation rule here. Example:
> **[Domain] tasks MUST be delegated to the `[agent-name]` agent** (subagent_type: `[agent-name]`).
Delete this block if no specialist agent is needed. -->
```

**"Claude Code Tooling" section** — keep section heading and sub-headings (Slash commands, Automatic hooks, Permission rules). Replace lists with ADAPT placeholders:
```markdown
**Slash commands** (type `/command` in any session):
<!-- ADAPT: List your project's slash commands here as they're created.
Format: `/command-name` — one-line description -->

**Automatic hooks** (PostToolUse on Edit/Write):
<!-- ADAPT: List your PostToolUse hooks here.
Format: `hook-name.sh` — what it watches and what it runs -->

**Permission rules** (`.claude/settings.json`):
<!-- ADAPT: Summarize your allow/deny/ask model here after configuring settings.json. -->
```

**"Claude Code Configuration"** (file layout of `.claude/`) — keep section structure, replace specific filenames with a generic template showing standard layout:
```markdown
## Claude Code Configuration

Claude Code's configuration for this project lives in:

```
~/.claude/CLAUDE.md                      # Global reasoning framework (all projects)
~/.claude/settings.json                  # Global settings
.claude/agents/                          # Project-scoped agent definitions
<!-- ADAPT: List your agent files here after creating them -->
.claude/settings.json                    # Project permissions, hooks
.claude/hooks/                           # PostToolUse hook scripts
<!-- ADAPT: List your hook files here after activating them -->
.claude/skills/                          # Slash command skill definitions
<!-- ADAPT: List your skill directories here -->
```
```

**Shell coding conventions section** (if present) — keep patterns (include guards, strict mode, error propagation, function naming), but:
- Replace project-specific prefixes (e.g. `_GS_EU_`, `_GS_ES_`) with `_<PROJECT>_` and add:
  `<!-- ADAPT: Replace _<PROJECT>_ with your project's actual variable prefix. -->`
- Remove specific binary dependencies list; replace with:
  `<!-- ADAPT: List your actual runtime dependencies here. -->`

**"Specific to this computer setup" section** — replace entire body with:
```markdown
> Everything above is generic and portable. Everything below is machine-specific —
> adapt or delete when replicating this config elsewhere. See `~/.claude/README.md`
> for the full replication guide.

### Project-specific routing
<!-- ADAPT: Add routing rules for this machine's projects here. -->

### Timezone
<!-- ADAPT: Set SR_TZ in ~/.claude/hooks/session-remember/common.sh to your timezone. -->
```

Then re-append, unchanged and in order, every whole-line `@FILE` include that closed the original section whose file the bundle ships (the global exporter does the same, row 26ze); an include of a file that does not ship is dropped.

### STRIP entirely (do not include — too project-specific to generalize)

- Numbered tier/layer architecture tables (e.g. Docker image tiers 00–05)
- Environment variable annotation system docs (`@todo env-update` syntax)
- Key Scripts sections with specific file paths and CLI flag reference
- Makefile patterns with project-specific macros
- Credentials paths, container names, port ranges, service names
- Container/service-specific debugging guides (Docker healthcheck patterns, etc.)
- Version numbers, Docker image names, registry URLs
- Any section whose entire purpose is explaining one project's unique infrastructure

---

## Hook Transformation Rules

Every project bundle ships with **exactly two** hook templates — one for linters, one for
formatters. Do **not** copy the origin project's hooks verbatim; emit the two generic
skeletons below regardless of what exists in `$TARGET/.claude/hooks/`. This keeps the
bundle toolchain-neutral: the target fills in its own linter/formatter during
`/install` adaptation.

Both templates share the same structural pattern:
- `set -euo pipefail`
- `INPUT=$(cat)` + `FILE_PATH` extraction via jq
- extension guard: `[[ "$FILE_PATH" == *".EXT" ]] || exit 0`
- existence guard: `[[ -f "$FILE_PATH" ]] || exit 0`
- tool presence guard: `command -v "$TOOL" &>/dev/null || exit 0`
- output: one JSON object carrying the finding twice — `hookSpecificOutput.additionalContext`
  (the only exit-0 channel that reaches the MODEL) and `systemMessage` (shown to the user). Never
  hard-fail on lint diffs — just surface the finding. Measured 2026-09-28 (review-remediation row
  33, 5 variants × 2 models): with exit 0, stderr, plain stdout and `systemMessage` never reach
  the model; only `additionalContext` does (and stderr with exit 2).

### Template 1 — `lint-on-write.sh.template`

Exit-code reporter. Runs the tool, captures stdout+stderr, reports only if the tool exits
non-zero.

```bash
#!/usr/bin/env bash
# PostToolUse hook: lint files on Edit/Write
# ADAPT: Set LINTER to your linter binary name (e.g. eslint, pylint, shellcheck, hadolint)
# ADAPT: Set EXT to the file extension/pattern to watch (e.g. .js, .py, .sh, Dockerfile)
# ADAPT: Rename from .sh.template to .sh, then add to .claude/settings.json PostToolUse
set -euo pipefail

LINTER="YOUR_LINTER"   # ADAPT
EXT=".YOUR_EXT"        # ADAPT

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

[[ -z "$FILE_PATH" ]] && exit 0
[[ "$FILE_PATH" == *"$EXT" ]] || exit 0
[[ -f "$FILE_PATH" ]] || exit 0
command -v "$LINTER" &>/dev/null || exit 0

if ! OUTPUT=$("$LINTER" "$FILE_PATH" 2>&1); then
  jq -n --arg msg "[$LINTER] $FILE_PATH:"$'\n'"$OUTPUT" \
    '{systemMessage: $msg, hookSpecificOutput: {hookEventName: "PostToolUse", additionalContext: $msg}}'
fi
```

### Template 2 — `format-on-write.sh.template`

Check reporter. Runs the formatter in check/diff mode and reports only if it exits non-zero —
`prettier --check`, `black --check`, `rustfmt --check` and `shfmt -d` all exit 1 on an
unformatted file (the first version reported only on exit 0 + a diff, so it never fired for them).
For a tool that exits 0 with a diff (`gofmt -d`), adapt the test to `[[ -n "$DIFF" ]]`.
Does **not** auto-fix — that's a user decision.

```bash
#!/usr/bin/env bash
# PostToolUse hook: check formatting on Edit/Write (diff only, never auto-fix)
# ADAPT: Set FORMATTER to your formatter binary (e.g. prettier, black, shfmt, rustfmt)
# ADAPT: Set DIFF_FLAG to the formatter's diff-mode flag (e.g. --check, --diff, -d)
# ADAPT: Set EXT to the file extension/pattern to watch
# ADAPT: Rename from .sh.template to .sh, then add to .claude/settings.json PostToolUse
set -euo pipefail

FORMATTER="YOUR_FORMATTER"   # ADAPT
DIFF_FLAG="--check"          # ADAPT (--check, --diff, -d)
EXT=".YOUR_EXT"              # ADAPT

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

[[ -z "$FILE_PATH" ]] && exit 0
[[ "$FILE_PATH" == *"$EXT" ]] || exit 0
[[ -f "$FILE_PATH" ]] || exit 0
command -v "$FORMATTER" &>/dev/null || exit 0

if ! DIFF=$("$FORMATTER" "$DIFF_FLAG" "$FILE_PATH" 2>&1); then   # ADAPT for exit-0-with-diff tools
  jq -n --arg msg "[$FORMATTER] $FILE_PATH not formatted:"$'\n'"$DIFF" \
    '{systemMessage: $msg, hookSpecificOutput: {hookEventName: "PostToolUse", additionalContext: $msg}}'
fi
```

### Writing the templates

```bash
cat > "$STAGING/project/.claude/hooks/lint-on-write.sh.template" <<'EOF'
[contents of Template 1 above]
EOF

cat > "$STAGING/project/.claude/hooks/format-on-write.sh.template" <<'EOF'
[contents of Template 2 above]
EOF
```

The `.template` suffix signals these need filling + renaming before they become active
hooks. `/install` picks one or both during adaptation.

---

## Command Transformation Rules

### STRIP (remove entirely — too project-specific)
- Commands that query project-specific services, infrastructure, or proprietary tooling
- Commands with project-specific macros, paths, or annotation syntax hardcoded
- Commands that wrap project-unique env-management systems (e.g. `/check-versions` wrapping
  `env-update-v2`, `/env-diff` assuming `.env`/`.env.local` split with `@todo` annotations)
- Service scaffolding commands tied to a project's exact structure (e.g. `/new-service`
  generating Docker tier directories with project-specific naming conventions)

### GENERALIZE (keep purpose, replace project content)
- `/lint` → keep structure, replace hardcoded tool names with:
  ```
  <!-- ADAPT: Replace with your project's actual linter(s) and file discovery patterns. -->
  ```
- `/fmt` → keep structure, replace formatter with:
  ```
  <!-- ADAPT: Replace with your project's formatter(s) and target file types. -->
  ```
- `/validate` → keep purpose + output format, replace specific checks with:
  ```
  <!-- ADAPT: Replace with your project's validation commands and what "passing" looks like. -->
  ```
- `/recent` → keep as-is; it uses generic `git log` patterns. Remove any project-specific
  health-check commands from the bottom.

### EXCLUDE entirely (don't copy — wrong scope)

The following commands are **global-resource commands** — they manipulate `~/.claude/` and
belong only in the **global** bundle, not a project-scope bundle:

- `skills/memory-off/`, `skills/memory-on/`, `skills/memory-readonly/`, `skills/memory-status/`
  — session-remember pipeline toggles tied to `~/.claude/hooks/session-remember/`
- `skills/handoff/`, `skills/loop/`, `skills/mega-analysis/`, `skills/retrospective/`
  — session-lifecycle commands that save state under `~/.claude/projects/`

The bundler itself is excluded from every bundle (origin-only):
`skills/bundle/SKILL.md` — requires bash export infrastructure; targets are consumers, not exporters.

**Note**: `skills/adapt-project/`, `skills/repair/`, `skills/install/` and all other analysis commands
(`skills/inspect/`, `skills/sleuth/`, `skills/gaps/`, `skills/audit/`, etc.) ship in the **global** bundle.
A project bundle does not need to re-include them — the install flow is global-first.

---

## Agent Transformation Rules

For each agent `.md` file in `$TARGET/.claude/agents/`:

Replace the entire content with this skeleton:

```markdown
# [ADAPT: Agent Name] — Project Lead Agent

> Use this agent for all [ADAPT: domain] work in this project.
> Always use this agent as the primary orchestrator for [ADAPT: domain]-related tasks.

<!-- ADAPT: Describe when to delegate to this agent vs handle directly.
What task types trigger delegation? What doesn't? Be specific with examples. -->

## Domain Knowledge

<!-- ADAPT: The agent's project-specific expertise. Typical sections:
- Architecture & key files
- Common workflows (as bash commands with comments)
- Debugging protocol (numbered steps)
- Gotchas & pitfalls
- Coding conventions specific to this domain -->

## Mental Models Applied

<!-- ADAPT: Which mental models from the global reasoning framework apply most here?
List them with brief domain-specific application notes. Example:
- **Binary Search Debugging**: when a container won't start, bisect: last working commit → narrow to failing change
- **Gall's Law**: add services incrementally — never spin up 3 new dependencies at once -->
```

Output as `agents/lead-agent.md.template`. If there are multiple agent files, generalize
the most important one as the template; discard the rest.

---

## Settings Templates

### `.claude/settings.json` — permission skeleton
Source of truth: `~/.claude/templates/project-settings.json` (copy it verbatim; the block below mirrors it).
Boundary model (2026-08-29): inside the repo the global `hooks/ask-bash-firewall.sh` boundary gate decides
(silent inside the root, ask outside, deny host-critical/credentials, ask on Claude self-mod paths), so the
project file allows the tools outright and lists only this repo's own footguns under `ask`/`deny`.
`~/.claude/templates/project-boundary.json` → `.claude/boundary.json` adds `protected[]` (always-ask paths
inside the repo) and `trusted_outside[]` (silent write targets outside it).
```json
{
  "permissions": {
    "allow": ["Bash", "Read", "Edit", "Write", "Glob", "Grep"],
    "ask": ["Bash(bin/deploy.sh *)", "Bash(* migrate:fresh*)"],
    "deny": ["Bash(* db:wipe*)"]
  }
}
```

### `.claude/settings.notes.md` — adaptation guide (delete after configuring)
```markdown
# Permission Model — Adaptation Guide

## Add to `allow`
- Your test runner: `Bash(pytest:*)`, `Bash(npm test:*)`, `Bash(rspec:*)`, etc.
- Your build tool: `Bash(make:*)`, `Bash(cargo build:*)`, `Bash(gradle:*)`, etc.
- Docker read-only: `Bash(docker compose ps:*)`, `Bash(docker logs:*)` (if applicable)
- Your linter/formatter binaries

## Add to `deny`
- Production deploy commands
- Destructive database commands: `Bash(DROP TABLE:*)`, `Bash(db:reset:*)`
- Commands that modify shared/production state

## Add to `ask`
- Commands that change config you want to review first
- Anything touching production or staging environments

## Format reference
- `Bash(command:*)` — matches any invocation starting with `command`
- `Bash(command subcommand:*)` — matches specific subcommand
- `Read(/path/**)` — path-scoped read permission
```

---

## Usage Examples

- `/bundle` — project-scoped archive from current directory
- `/bundle --scope global` — shareable global archive (scrub ON by default, memories excluded)
- `/bundle --scope global --no-scrub` — global archive keeping all machine-specific paths (unsafe to share)
- `/bundle --scope global --no-scrub --include-memories` — personal machine-to-machine copy (full fidelity + private memories, no `~/.claude.json`)
- `/bundle --scope global --no-scrub --include-memories --include-claude-json --no-scrub-claude-json` — **maximum fidelity personal backup**: all paths, memories, and full `~/.claude.json` including OAuth tokens; use ONLY for same-account same-environment machine-to-machine transfer, **never share**
- `/bundle --scope global --include-claude-json` — global archive with `~/.claude.json` stripped of identity fields (safe to share)
- `/bundle --scope global --include-claude-json --no-scrub-claude-json` — global archive with full `~/.claude.json` (same-machine backup only, **never share**)
- `/bundle --scope global --include-pipeline` — global archive where target becomes a full origin (can create its own bundles)
- `/bundle --scope all` — both scopes as two separate archives
- `/bundle --scope global,project` — same as `--scope all`
- `/bundle --scope project --target /path/to/proj` — archive from a specific project
- `/bundle --output ~/Desktop/my-setup.tar.gz` — custom output path (single scope)
- `/bundle --output-dir /tmp --scope all` — both archives into `/tmp`
- `/bundle --dry-run` — show what would be staged, no archive created
- `/bundle --scope global --dry-run` — preview global bundle contents

### Full-fidelity transfer: what the bundle does NOT cover

Even with all flags, some things require manual steps on the target after import:

1. **Plugins** — installed plugins from external marketplaces (e.g. `superpowers`, `feature-dev`, `code-review` from `claude-plugins-official`) are NOT bundled. After importing, re-install: `claude plugin install <name>@<marketplace>`. Run `cat ~/.claude/plugins/installed_plugins.json` on the origin to see your list.

2. **Memory project slugs** — project memory directories are named after absolute paths (e.g. `projects/-stack-projects-x/`). `--include-memories` ships them at the origin's slugs, so they load only where the same paths exist. For another username or layout use `bin/claude-memories.sh` instead: `export --project <slug-prefix>` on the origin (scrubbed archive + `.sha256`), then `place <archive>` on the target. It finds each project as the one git repo of that name under `--search DIR` (default `$HOME`; pass `--search /path/to/your/project/projects` or `--map NAME=PATH` when they live elsewhere), writes it under Claude Code's own slug for that path (every non-alphanumeric byte becomes `-`), refills the scrubbed paths (`--root DIR` for `/path/to/your/project`), and never overwrites an existing note.

3. **`~/.claude.json` on existing machines** — if the target already has `~/.claude.json` (any logged-in machine), the importer installs everything else and stages the bundle's copy as `~/.claude.json.imported` (mode 600); the manual merge guide is printed last. Keep your existing OAuth tokens; take other preferences from the incoming file.
