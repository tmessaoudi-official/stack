# Claude Code Setup — Global Bundle

## Install

```bash
bash ./claude-import.sh
```

## After installing

Open a Claude Code session and run:

```
/memory-status    # verify the session pipeline is active
/handoff          # create your first session state
```

## What's included

| Item | Purpose |
|------|---------|
| `CLAUDE.md` | Global reasoning framework (8-phase workflow, 30+ mental models, core rules) |
| `THINKING.md` | Full thinking frameworks library |
| `skills/` | Slash commands: /audit, /inspect, /repair, /handoff, /memory-*, /mega-analysis, and more |
| `hooks/session-remember/` | Automatic session continuity pipeline |
| `settings.json.template` | Permission scaffold — review before applying to your settings.json |
| `bin/` | Shared utilities |
| `.claude.json` | Only with `--include-claude-json`: Claude Code preferences + MCP registrations; identity fields and every copy of the account/org UUID, userID and email removed (with `--no-scrub-claude-json`: verbatim — never share) |

## If ~/.claude/ already exists

The installer shows a manual merge guide — follow it to cherry-pick sections.
Do NOT blindly overwrite — you may have local customizations worth keeping.

## Built with --share

`settings.json.template` carries none of the origin's consent switches: both permission-prompt skips,
`remoteControlAtStartup`, `permissions.defaultMode` and every `CLAUDE_CODE_EXPERIMENTAL_*` env key were removed.
Set any of them in your own settings.json only if you want them.
