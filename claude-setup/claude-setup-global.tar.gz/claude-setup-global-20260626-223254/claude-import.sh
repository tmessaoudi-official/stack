#!/usr/bin/env bash
# claude-import.sh — Install a claude-export bundle onto this machine.
# Usage: claude-import.sh [--from BUNDLE.tar.gz] [--target PATH] [--help]
# This script is normally run from inside an extracted bundle directory.
# It installs config and then deletes its own extraction directory.
set -eEuo pipefail

_CI_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_CI_LIB_DIR="${_CI_SCRIPT_DIR}/lib/claude-import"

# shellcheck source=lib/claude-import/core/args.sh
source "${_CI_LIB_DIR}/core/args.sh"
# shellcheck source=lib/claude-import/core/extract.sh
source "${_CI_LIB_DIR}/core/extract.sh"
# shellcheck source=lib/claude-import/core/detect.sh
source "${_CI_LIB_DIR}/core/detect.sh"
# shellcheck source=lib/claude-import/core/install_project.sh
source "${_CI_LIB_DIR}/core/install_project.sh"
# shellcheck source=lib/claude-import/core/install_global.sh
source "${_CI_LIB_DIR}/core/install_global.sh"
# shellcheck source=lib/claude-import/core/tutorial.sh
source "${_CI_LIB_DIR}/core/tutorial.sh"
# shellcheck source=lib/claude-import/core/cleanup.sh
source "${_CI_LIB_DIR}/core/cleanup.sh"
# shellcheck source=lib/claude-import/core/path-rewrite.sh
source "${_CI_LIB_DIR}/core/path-rewrite.sh"
# shellcheck source=lib/claude-import/core/tz-resolve.sh
source "${_CI_LIB_DIR}/core/tz-resolve.sh"
# shellcheck source=lib/claude-import/core/cleanup_stale_projects.sh
source "${_CI_LIB_DIR}/core/cleanup_stale_projects.sh"

main() {
  ci_parse_args "$@"

  trap ci_cleanup EXIT

  if [[ -n "$_CI_FROM" ]]; then
    ci_extract_bundle "$_CI_FROM"
    # _CI_BUNDLE_DIR is set as a global by ci_extract_bundle
  else
    _CI_BUNDLE_DIR="$_CI_SCRIPT_DIR"
  fi

  ci_detect_scopes "$_CI_BUNDLE_DIR"

  if [[ "$_CI_HAS_PROJECT" -eq 0 && "$_CI_HAS_GLOBAL" -eq 0 ]]; then
    echo "Error: bundle contains neither 'project/' nor 'global/' directory — nothing to install." >&2
    exit 1
  fi

  # Path rewrite: /home/<origin>/ → /home/<you>/ in bundle text files (before install)
  if [[ "${_CI_KEEP_ORIGIN_PATHS:-0}" -eq 0 ]]; then
    ci_path_rewrite "$_CI_BUNDLE_DIR"
  fi

  # Resolve the {{TZ}} placeholder left by scrub → this host's timezone (before install).
  # No-op on un-scrubbed bundles. Independent of --keep-origin-paths.
  ci_resolve_tz "$_CI_BUNDLE_DIR"

  if [[ "$_CI_HAS_PROJECT" -eq 1 ]]; then
    ci_install_project "$_CI_BUNDLE_DIR" "$_CI_TARGET"
  fi

  if [[ "$_CI_HAS_GLOBAL" -eq 1 ]]; then
    ci_install_global "$_CI_BUNDLE_DIR"
  fi

  # Plugin reinstall notification (after install — plugins-reinstall.sh is now in place)
  if [[ "${_CI_GLOBAL_SKIPPED:-0}" -eq 0 && -f "$HOME/.claude/plugins-reinstall.sh" ]]; then
    local n_plugins
    n_plugins=$(grep -c '^claude plugin install' "$HOME/.claude/plugins-reinstall.sh" 2>/dev/null || echo 0)
    echo "  ${n_plugins} plugins were installed on origin machine. To reinstall:" >&2
    echo "    bash ~/.claude/plugins-reinstall.sh" >&2
  fi

  # Stale project cleanup: remove ~/.claude.json entries for non-existent paths (after install)
  if [[ "${_CI_HAS_GLOBAL:-0}" -eq 1 && "${_CI_GLOBAL_SKIPPED:-0}" -eq 0 && "${_CI_KEEP_PROJECTS:-0}" -eq 0 ]]; then
    ci_cleanup_stale_projects
  fi

  if [[ "$_CI_GLOBAL_SKIPPED" -eq 1 ]]; then
    exit 2
  fi
}

main "$@"
