#!/usr/bin/env bash
[[ -n "${_CI_PATH_REWRITE_SH_LOADED:-}" ]] && return 0
readonly _CI_PATH_REWRITE_SH_LOADED=1
set -euo pipefail

# ci_path_rewrite <bundle_dir>
# Rewrites /home/<origin-user>/ → /home/<current-user>/ in bundle text files.
# Detects origin user from first /home/<word>/ pattern in bundle content.
# Skips if origin == current user, or if _CI_KEEP_ORIGIN_PATHS=1.
ci_path_rewrite() {
  local bundle_dir="$1"
  local global_dir="${bundle_dir}/global"

  [[ ! -d "$global_dir" ]] && return 0

  # Detect origin user: most frequent /home/<word>/ match across text files
  # (most-frequent avoids false positives from CI or example paths like /home/runner/)
  local origin_user
  origin_user=$(
    find "$global_dir" -type f \( -name "*.sh" -o -name "*.json" -o -name "*.yaml" -o -name "*.yml" -o -name "*.template" \) \
      -not -path "*/projects/*" \
      -not -path "*/hooks/session-remember/*.md" \
      -not -path "$global_dir/bin/*" \
      -exec grep -ohP '/home/\K[a-zA-Z0-9_-]+(?=/)' {} \; 2>/dev/null \
      | sort | uniq -c | sort -rn | awk 'NR==1 {print $2}'
  )

  if [[ -z "$origin_user" ]]; then
    echo "  [path-rewrite] no /home/<user>/ paths found in bundle — skipping" >&2
    return 0
  fi

  local current_user
  current_user=$(whoami)

  if [[ "$origin_user" == "$current_user" ]]; then
    echo "  [path-rewrite] same user ($current_user) — no rewrite needed" >&2
    return 0
  fi

  echo "  [path-rewrite] /home/${origin_user}/ → /home/${current_user}/ ..." >&2

  # Warn if .claude.json is present (OAuth tokens are tied to origin account)
  if [[ -f "${global_dir}/.claude.json" ]]; then
    echo "  ⚠️  [path-rewrite] .claude.json contains OAuth tokens tied to origin account (${origin_user}) — re-auth may be needed on this machine" >&2
  fi

  local count=0
  while IFS= read -r -d '' f; do
    local matches
    # grep without trailing slash catches both plain (/home/user/) and quoted forms (\"/home/user\")
    matches=$(grep -c "/home/${origin_user}" "$f" 2>/dev/null || true)
    if [[ "$matches" -gt 0 ]]; then
      # \b word boundary replaces both forms: /home/user/path and \"/home/user\" (JSON-escaped quotes)
      sed -i "s|/home/${origin_user}\\b|/home/${current_user}|g" "$f"
      echo "  [path-rewrite] /home/${origin_user} → /home/${current_user} in $(basename "$f") (${matches} matches)" >&2
      ((count++)) || true
    fi
  done < <(find "$global_dir" -type f \( -name "*.sh" -o -name "*.json" -o -name "*.yaml" -o -name "*.yml" -o -name "*.template" \) \
    -not -path "*/projects/*" \
    -not -path "*/hooks/session-remember/*.md" \
    -not -path "$global_dir/bin/*" \
    -print0)
  # bin/ is the shipped toolchain (CODE, not user config). It carries placeholder/path
  # literals in its own source (sanitize.sh's /home/<user> sed pattern); rewriting them
  # corrupts the toolchain on cross-user import — the WSL self-corruption bug.

  echo "  [path-rewrite] done — ${count} file(s) rewritten" >&2
}
