#!/usr/bin/env bash
[[ -n "${_CI_TZ_RESOLVE_SH_LOADED:-}" ]] && return 0
readonly _CI_TZ_RESOLVE_SH_LOADED=1
set -euo pipefail

# ci_resolve_tz <bundle_dir>
# Scrubbed bundles carry the {{TZ}} placeholder wherever the origin timezone was removed
# (e.g. session-remember/common.sh's SR_TZ fallback). Replace it with THIS host's timezone
# so the installed config has a correct default instead of a literal {{TZ}}.
# No-op on un-scrubbed bundles (they keep the origin's literal zone, never {{TZ}}).
ci_resolve_tz() {
  local bundle_dir="$1"
  local global_dir="${bundle_dir}/global"
  [[ -d "$global_dir" ]] || return 0

  # Detect host timezone. timedatectl is absent in minimal/CI containers (no systemd-dbus),
  # so the 2>/dev/null + fallback chain is documented expected behavior, not an
  # undiagnosed error mask (CLAUDE.md anti-bandaid gate).
  local tz=""
  tz="$(timedatectl show -p Timezone --value 2>/dev/null || true)"
  if [[ -z "$tz" && -r /etc/timezone ]]; then
    tz="$(cat /etc/timezone 2>/dev/null || true)"
  fi
  if [[ -z "$tz" && -L /etc/localtime ]]; then
    tz="$(readlink /etc/localtime 2>/dev/null | sed 's|.*/zoneinfo/||' || true)"
  fi
  [[ -z "$tz" ]] && tz="${TZ:-}"
  tz="${tz:-UTC}"   # guarantee non-empty — never leave a half-resolved {{TZ}}

  # Config files only — NOT *.md: documentation legitimately teaches the {{TZ}} token,
  # and rewriting it there would corrupt the docs that explain the placeholder.
  local count=0
  while IFS= read -r -d '' f; do
    if grep -q '{{TZ}}' "$f" 2>/dev/null; then
      # tz is a zone name (may contain '/'), so '|' is a safe sed delimiter.
      sed -i "s|{{TZ}}|${tz}|g" "$f"
      ((count++)) || true
    fi
  done < <(find "$global_dir" -type f \
    \( -name "*.sh" -o -name "*.json" -o -name "*.yaml" -o -name "*.yml" -o -name "*.template" \) \
    -not -path "$global_dir/bin/*" \
    -print0)
  # bin/ is the shipped toolchain (CODE, not user config). Its own source carries {{TZ}}
  # literals (this resolver, sanitize.sh); rewriting them corrupts the toolchain — the WSL
  # self-corruption bug. Never resolve placeholders inside bin/.

  if [[ "$count" -gt 0 ]]; then
    echo "  [tz-resolve] {{TZ}} → ${tz} in ${count} file(s)" >&2
  fi
}
