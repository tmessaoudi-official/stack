#!/usr/bin/env bash
[[ -n "${_CI_CLEANUP_SH_LOADED:-}" ]] && return 0
readonly _CI_CLEANUP_SH_LOADED=1
set -euo pipefail

ci_cleanup() {
  [[ -n "${_CI_EXTRACT_DIR:-}" && -d "$_CI_EXTRACT_DIR" \
    && "$_CI_EXTRACT_DIR" == /tmp/claude-import-* ]] \
      && rm -rf -- "$_CI_EXTRACT_DIR"
}
