#!/usr/bin/env bash
[[ -n "${_CI_ARGS_SH_LOADED:-}" ]] && return 0
readonly _CI_ARGS_SH_LOADED=1
set -euo pipefail

_CI_FROM=""
_CI_TARGET=""
_CI_EXTRACT_DIR=""
_CI_BUNDLE_DIR=""
_CI_KEEP_ORIGIN_PATHS=0
_CI_KEEP_PROJECTS=0

ci_usage() {
  cat >&2 <<'EOF'
Usage: claude-import.sh [OPTIONS]

Install a claude-export bundle onto this machine.

OPTIONS:
  --from BUNDLE.tar.gz   Verify, extract and install from a bundle archive
  --target PATH          Project directory to install project-scope config into
                         (default: current working directory)
  --keep-origin-paths    Skip automatic /home/<origin-user>/ → /home/<you>/ path rewrite
  --keep-projects        Skip removal of stale ~/.claude.json project entries
  --help                 Show this help message

MODES:
  In-place (normal):
    Extract the archive manually, cd into the extracted directory, then run:
      bash claude-import.sh [--target PATH]

  From archive (--from):
    Run from anywhere, passing the archive path:
      bash claude-import.sh --from claude-setup-global-<ts>.tar.gz [--target PATH]
    The archive's .sha256 sidecar is verified before extraction.

EXIT CODES:
  0  — success (all applicable scopes installed)
  2  — global scope skipped (existing ~/.claude detected; see manual merge guide)
EOF
}

ci_parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --from)
        [[ -z "${2:-}" ]] && { echo "Error: --from requires a path argument" >&2; exit 1; }
        _CI_FROM="$2"
        shift 2
        ;;
      --target)
        [[ -z "${2:-}" ]] && { echo "Error: --target requires a path argument" >&2; exit 1; }
        _CI_TARGET="$2"
        shift 2
        ;;
      --keep-origin-paths)
        _CI_KEEP_ORIGIN_PATHS=1
        shift
        ;;
      --keep-projects)
        _CI_KEEP_PROJECTS=1
        shift
        ;;
      --help|-h)
        ci_usage
        exit 0
        ;;
      *)
        echo "Error: unknown option '$1'" >&2
        ci_usage
        exit 1
        ;;
    esac
  done

  if [[ -z "$_CI_TARGET" ]]; then
    _CI_TARGET="$(pwd)"
  fi
}
