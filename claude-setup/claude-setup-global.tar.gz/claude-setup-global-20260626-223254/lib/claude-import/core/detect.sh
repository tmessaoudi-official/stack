#!/usr/bin/env bash
[[ -n "${_CI_DETECT_SH_LOADED:-}" ]] && return 0
readonly _CI_DETECT_SH_LOADED=1
set -euo pipefail

_CI_HAS_GLOBAL=0
_CI_HAS_PROJECT=0
_CI_MANIFEST_SCOPE=""

# ci_detect_scopes <bundle_dir>
# Inspects the bundle directory and sets _CI_HAS_GLOBAL, _CI_HAS_PROJECT, _CI_MANIFEST_SCOPE.
ci_detect_scopes() {
  local bundle_dir="$1"

  [[ -d "$bundle_dir/global" ]]  && _CI_HAS_GLOBAL=1
  [[ -d "$bundle_dir/project" ]] && _CI_HAS_PROJECT=1

  local manifest="$bundle_dir/MANIFEST.json"
  if [[ -f "$manifest" ]]; then
    if command -v jq &>/dev/null; then
      _CI_MANIFEST_SCOPE="$(jq -r '.scope // empty' "$manifest" 2>/dev/null || true)"
    else
      _CI_MANIFEST_SCOPE="$(grep -o '"scope"[[:space:]]*:[[:space:]]*"[^"]*"' "$manifest" \
        | sed 's/.*"scope"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' || true)"
    fi
  fi

  echo "Bundle scope: ${_CI_MANIFEST_SCOPE:-unknown} (global=${_CI_HAS_GLOBAL}, project=${_CI_HAS_PROJECT})" >&2
}
