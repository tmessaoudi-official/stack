#!/usr/bin/env bash
[[ -n "${_CI_INSTALL_PROJECT_SH_LOADED:-}" ]] && return 0
readonly _CI_INSTALL_PROJECT_SH_LOADED=1
set -euo pipefail

# ci_install_project <bundle_dir> <target_dir>
ci_install_project() {
  local bundle_dir="$1"
  local target_dir="$2"
  local project_src="$bundle_dir/project"

  [[ ! -d "$project_src" ]] && return 0

  local mode="merge"

  if [[ -d "$target_dir/.claude" || -f "$target_dir/CLAUDE.md" ]]; then
    echo "" >&2
    echo "⚠️  Existing Claude config detected at $target_dir" >&2
    echo "   How to proceed?" >&2
    echo "     1) merge     — keep existing CLAUDE.md, only add missing .claude/ files [default]" >&2
    echo "     2) overwrite — replace existing config completely (backup created)" >&2
    echo "     3) abort     — exit without changes" >&2
    printf "   → choice (Enter for default): " >&2

    local response
    read -r response

    case "${response}" in
      ""|1|merge)    mode="merge" ;;
      2|overwrite)   mode="overwrite" ;;
      3|abort)
        echo "Aborted — no changes made." >&2
        return 0
        ;;
      *)
        echo "Unrecognised choice; using default: merge" >&2
        mode="merge"
        ;;
    esac
  fi

  if [[ "$mode" == "overwrite" ]]; then
    local ts; ts="$(date '+%s')"
    if [[ -d "$target_dir/.claude" ]]; then
      cp -a "$target_dir/.claude" "$target_dir/.claude.bak.${ts}"
      echo "  backup: .claude.bak.${ts}" >&2
    fi
    if [[ -f "$target_dir/CLAUDE.md" ]]; then
      cp "$target_dir/CLAUDE.md" "$target_dir/CLAUDE.md.bak.${ts}"
      echo "  backup: CLAUDE.md.bak.${ts}" >&2
    fi
    cp -a "$project_src/." "$target_dir/"
    echo "Project config installed to $target_dir (overwrite)" >&2
    return 0
  fi

  # merge mode: copy only files that do not already exist
  if [[ -d "$project_src/.claude" ]]; then
    mkdir -p "$target_dir/.claude"
    while IFS= read -r -d '' src_file; do
      local rel="${src_file#"$project_src/.claude/"}"
      local dst="$target_dir/.claude/$rel"
      if [[ ! -f "$dst" ]]; then
        mkdir -p "$(dirname "$dst")"
        cp "$src_file" "$dst"
        echo "  added: .claude/$rel" >&2
      else
        echo "  skip (exists): .claude/$rel" >&2
      fi
    done < <(find "$project_src/.claude" -type f -print0)
  fi

  # CLAUDE.md is kept in merge mode
  if [[ -f "$project_src/CLAUDE.md" && ! -f "$target_dir/CLAUDE.md" ]]; then
    cp "$project_src/CLAUDE.md" "$target_dir/CLAUDE.md"
    echo "  added: CLAUDE.md" >&2
  elif [[ -f "$project_src/CLAUDE.md" ]]; then
    echo "  skip (exists): CLAUDE.md" >&2
  fi

  echo "Project config merged into $target_dir" >&2
}
