#!/usr/bin/env bash
[[ -n "${_CI_CLEANUP_STALE_SH_LOADED:-}" ]] && return 0
readonly _CI_CLEANUP_STALE_SH_LOADED=1
set -euo pipefail

# ci_cleanup_stale_projects
# Removes ~/.claude.json project entries whose path does not exist on this machine.
# ~/.claude.json stores projects as an object keyed by absolute path:
#   {"projects": {"/home/user/proj": {...}, ...}}
# Runs only when ~/.claude.json exists and jq is available.
# Skipped if _CI_KEEP_PROJECTS=1.
ci_cleanup_stale_projects() {
  local claude_json="$HOME/.claude.json"

  [[ -f "$claude_json" ]] || return 0

  if ! command -v jq >/dev/null 2>&1; then
    echo "  [cleanup] jq not found — skipping stale project cleanup" >&2
    return 0
  fi

  # Collect all project keys (each key IS the project path)
  local -a stale_keys=()
  while IFS= read -r key; do
    [[ -z "$key" ]] && continue
    if [[ ! -d "$key" && ! -f "$key" ]]; then
      stale_keys+=("$key")
    fi
  done < <(jq -r '.projects | keys[] // empty' "$claude_json" 2>/dev/null || true)

  if [[ ${#stale_keys[@]} -eq 0 ]]; then
    echo "  [cleanup] all project paths exist — nothing to remove" >&2
    return 0
  fi

  # Remove stale entries one at a time via temp file (safe for paths with special chars)
  local tmp_file
  tmp_file=$(mktemp "${claude_json}.XXXXXX")
  cp "$claude_json" "$tmp_file"

  local removed=0
  for key in "${stale_keys[@]}"; do
    local new_tmp
    new_tmp=$(mktemp "${claude_json}.XXXXXX")
    if jq --arg k "$key" 'del(.projects[$k])' "$tmp_file" > "$new_tmp" 2>/dev/null; then
      mv "$new_tmp" "$tmp_file"
      ((removed++)) || true
      echo "  [cleanup] removed project entry: ${key} (path not found)" >&2
    else
      rm -f "$new_tmp"
      echo "  [cleanup] warning: failed to remove entry for ${key}" >&2
    fi
  done

  if [[ "$removed" -gt 0 ]]; then
    mv "$tmp_file" "$claude_json"
    echo "  Removed ${removed} stale project entries (paths not found on this machine)." >&2
    echo "  Use --keep-projects to skip this cleanup." >&2
  else
    rm -f "$tmp_file"
  fi
}
