#!/usr/bin/env bash
[[ -n "${_CI_EXTRACT_SH_LOADED:-}" ]] && return 0
readonly _CI_EXTRACT_SH_LOADED=1
set -euo pipefail

# ci_extract_bundle <bundle_path>
# Verifies sha256, extracts to /tmp, sets _CI_EXTRACT_DIR and _CI_BUNDLE_DIR.
ci_extract_bundle() {
  local bundle_path="$1"

  [[ ! -f "$bundle_path" ]] && { echo "Error: bundle not found: $bundle_path" >&2; exit 1; }

  local sidecar="${bundle_path}.sha256"
  [[ ! -f "$sidecar" ]] && { echo "Error: checksum sidecar not found: $sidecar" >&2; exit 1; }

  local bundle_dir; bundle_dir="$(dirname "$(realpath "$bundle_path")")"
  (cd "$bundle_dir" && sha256sum -c "$(basename "$sidecar")") 2>/dev/null || {
    echo "Error: checksum mismatch for ${bundle_path}" >&2
    exit 1
  }

  _CI_EXTRACT_DIR="/tmp/claude-import-$$-$(date '+%s')"
  mkdir -p "$_CI_EXTRACT_DIR"

  tar -xzf "$bundle_path" -C "$_CI_EXTRACT_DIR"

  local _manifest
  _manifest="$(find "$_CI_EXTRACT_DIR" -maxdepth 2 -name "MANIFEST.json" -print -quit)"
  _CI_BUNDLE_DIR="$(dirname "$_manifest")"

  if [[ -z "$_CI_BUNDLE_DIR" || ! -d "$_CI_BUNDLE_DIR" ]]; then
    echo "Error: could not locate MANIFEST.json inside extracted archive" >&2
    exit 1
  fi
}
