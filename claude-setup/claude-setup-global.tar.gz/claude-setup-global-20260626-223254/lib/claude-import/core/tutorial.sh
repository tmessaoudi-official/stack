#!/usr/bin/env bash
[[ -n "${_CI_TUTORIAL_SH_LOADED:-}" ]] && return 0
readonly _CI_TUTORIAL_SH_LOADED=1
set -euo pipefail

# ci_print_tutorial <global_src_dir>
ci_print_tutorial() {
  local global_src="$1"
  local skill_count=0
  if [[ -d "$global_src/skills" ]]; then
    skill_count="$(find "$global_src/skills/" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')"
  fi

  cat >&2 <<EOF
┌─ ~/.claude/ already exists — manual merge required ──────────────────────┐
│ Refusing to overwrite your existing global config.                        │
│ The bundle's content is staged at: ${global_src}
│ Follow the guide below to cherry-pick what you want.                      │
└───────────────────────────────────────────────────────────────────────────┘

BUNDLE INVENTORY:
  CLAUDE.md                  — global reasoning framework (8-phase workflow, 30+ mental models)
  README.md                  — replication guide
  settings.json.template     — permissions/hooks/MCP/plugins (template — review before using)
  skills/ (${skill_count} skills)       — slash command skill definitions
  hooks/session-remember/    — session continuity pipeline (7 scripts + prompts)
  bin/                       — shared utilities (no authoring tools)
  plugins-reinstall.sh       — (if present) re-install origin plugins: bash plugins-reinstall.sh

MERGE GUIDE:

  1. CLAUDE.md — diff and cherry-pick sections:
       diff ~/.claude/CLAUDE.md ${global_src}/CLAUDE.md

  2. settings.json — compare and manually merge (do NOT use jq * — it replaces arrays,
     losing existing hook entries; instead diff and add missing entries by hand):
       diff ~/.claude/settings.json ${global_src}/settings.json.template
       # Key sections to check:
       #   hooks.SessionStart, hooks.Stop, hooks.PreCompact, hooks.PostToolUse,
       #   hooks.PreToolUse, hooks.SubagentStop, hooks.SubagentStart, hooks.UserPromptSubmit
       #   permissions.allow, mcpServers
       # For each missing hook entry: add it to your existing settings.json manually.

  3. skills/ — copy non-conflicting skill directories:
       for d in ${global_src}/skills/*/; do
         name=\$(basename "\$d")
         [[ -d ~/.claude/skills/\$name ]] \\
           || cp -r "\$d" ~/.claude/skills/
       done

  4. hooks/session-remember/ — skip if pipeline already installed:
       ls ~/.claude/hooks/session-remember/ 2>/dev/null \\
         || cp -r ${global_src}/hooks/session-remember ~/.claude/hooks/

  5. bin/ — review and copy individual scripts:
       diff ~/.claude/bin/ ${global_src}/bin/

  6. Do NOT copy memory/ or projects/ — those are machine-local state.

After merging, run /memory-status and /validate to confirm nothing regressed.
EOF
}

# ci_print_refill_guide <install_dir>
# Scrubbed bundles ship placeholders in place of real values. After install/merge, tell
# the user which scrubbed values must be replaced. The grep is the always-correct source
# of truth; MANIFEST.json (when adjacent) tailors the "this bundle scrubbed:" summary.
# No-op when no placeholders are present (un-scrubbed bundle / nothing left to refill).
ci_print_refill_guide() {
  local dir="$1"
  [[ -d "$dir" ]] || return 0

  # Exclude bin/: the import tooling source legitimately contains these literals and would
  # otherwise produce false positives.
  local hits
  hits="$(grep -rlE 'CHANGE_ME_|\{\{TZ\}\}|<your-lead-agent>|/path/to/your/project|YOUR_SERVICE_INSTANCE' \
            "$dir" --exclude-dir=bin 2>/dev/null | head -20 || true)"
  [[ -z "$hits" ]] && return 0

  cat >&2 <<'REFILL_HEADER'

  ┌─ Scrubbed placeholders — replace with real values before use ─────────────┐
  │ This bundle was scrubbed: the values below are placeholders, not real      │
  │ config. Replace each with your environment's actual value.                 │
  └────────────────────────────────────────────────────────────────────────────┘

  Placeholder conventions you may encounter:
    CHANGE_ME_*               credential / token / proxy / service-URL values (e.g. mcp/*.env)
    {{TZ}}                    timezone (auto-resolved on install; refill any that remain)
    <your-lead-agent>         project lead-agent name
    /path/to/your/project     origin project path
    YOUR_SERVICE_INSTANCE     MCP service base URL

REFILL_HEADER

  echo "  Find every remaining placeholder:" >&2
  echo "    grep -rnE 'CHANGE_ME_|\\{\\{TZ\\}\\}|<your-lead-agent>|/path/to/your/project|YOUR_SERVICE_INSTANCE' \\" >&2
  echo "      \"${dir}\" --exclude-dir=bin" >&2
  echo "" >&2

  # If a MANIFEST.json sits in or beside the install dir, list exactly what was scrubbed.
  local manifest
  for manifest in "${dir}/MANIFEST.json" "$(dirname "$dir")/MANIFEST.json"; do
    if [[ -f "$manifest" ]] && command -v jq >/dev/null 2>&1; then
      local applied
      applied="$(jq -r '.scrubbed_placeholders // [] | join(", ")' "$manifest" 2>/dev/null || true)"
      if [[ -n "$applied" ]]; then
        echo "  This bundle scrubbed: ${applied}" >&2
        echo "" >&2
      fi
      break
    fi
  done
}
