#!/usr/bin/env bash
# Stop hook: backstop for the AskUserQuestion rule (global CLAUDE.md "Presenting options"). If the
# assistant's final user-facing text ends with a question ('?') but AskUserQuestion was NOT used in the
# turn, block the stop with a reminder so the question is re-asked via AskUserQuestion.
# Conservative by design (false-NEGATIVE-leaning): only inspects the last non-blank, non-code line;
# honors stop_hook_active (no loop); QGUARD_OFF=1 disables. Transcript schema: one content-block per
# JSONL line, so a turn = all lines after the last 'user' entry.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

[[ "${QGUARD_OFF:-}" == "1" ]] && exit 0
# Global sentinel bypass (parity with ask-human-gate-block.sh + ask-bash-firewall.sh).
[[ -f "$HOME/.claude/state/ask-human-question-guard-bypass" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

# Per-project sentinel bypass: ~/.claude/projects/<slug>/state/ask-human-question-guard-bypass (slug = cwd, / -> -).
QG_CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
if [[ -n "$QG_CWD" ]]; then
  QG_SLUG=$(printf '%s' "$QG_CWD" | tr '/' '-')
  [[ -f "$HOME/.claude/projects/${QG_SLUG}/state/ask-human-question-guard-bypass" ]] && exit 0
fi

# Avoid loops: if we already blocked once this stop-cycle, let it through.
[[ "$(printf '%s' "$INPUT" | jq -r '.stop_hook_active // false' 2>/dev/null)" == "true" ]] && exit 0

TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
[[ -n "$TRANSCRIPT" && -f "$TRANSCRIPT" ]] || exit 0

# Parse the last turn (lines after the last 'user' entry): gather assistant text + tool names.
# tail bounds cost; jq -R fromjson? tolerates a partial first line from tail.
FILTER='
  . as $a
  | ([range(0; ($a|length)) | select($a[.].type=="user")] | last) as $u0
  | (($u0 // -1) + 1) as $start
  | {
      used_auq: ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="tool_use") | .name ] | any(. == "AskUserQuestion")),
      text:     ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="text") | .text ] | join("\n"))
    }'
RES=$(tail -n 800 "$TRANSCRIPT" 2>/dev/null | jq -Rc 'fromjson? // empty' 2>/dev/null | jq -s "$FILTER" 2>/dev/null || true)
[[ -z "$RES" ]] && exit 0

USED_AUQ=$(printf '%s' "$RES" | jq -r '.used_auq' 2>/dev/null || echo false)
TEXT=$(printf '%s' "$RES" | jq -r '.text' 2>/dev/null || echo "")

# If AskUserQuestion was used this turn, the rule was honored → pass.
[[ "$USED_AUQ" == "true" ]] && exit 0
[[ -z "$TEXT" || "$TEXT" == "null" ]] && exit 0

# Last non-blank line; skip code fences / blockquotes / table rows / indented code (false positives).
last_line=$(printf '%s\n' "$TEXT" | sed 's/[[:space:]]*$//' | grep -v '^[[:space:]]*$' | tail -1)
case "$last_line" in
  '```'* | '>'* | '|'* | '    '*) exit 0 ;;
esac

if [[ "$last_line" == *'?' ]]; then
  {
    echo "⛔ END-OF-TURN QUESTION NOT ASKED VIA AskUserQuestion"
    echo "   Final line: \"${last_line: -100}\""
    echo "   CLAUDE.md (Presenting options): ALL user-facing questions MUST use AskUserQuestion — zero exceptions."
    echo "   Re-ask this via AskUserQuestion (recommended option first). Disable backstop: QGUARD_OFF=1"
  } >&2
  log_obs WARN ask-human-question-guard "blocked free-text question: ${last_line: -100}" 2>/dev/null || true
  exit 2
fi
exit 0
