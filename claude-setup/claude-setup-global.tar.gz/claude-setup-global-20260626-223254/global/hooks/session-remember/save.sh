#!/usr/bin/env bash
# save.sh — Extract session exchanges, summarize with Haiku, append to buffer.md
#
# USAGE:
#   save.sh [<session-id>] [--force] [--dry-run] [--mark-only]
#
# --mark-only: bypass flock, write raw extract to WAL in STATE_DIR, exit
#              without Haiku or position advance. WAL filenames include
#              timestamp+PID — safe for concurrent writes. Used by stop.sh
#              Phase 1. Full save.sh cleans the WAL at lock time.
#
# Called by trigger.sh in background, or start.sh for missed-session recovery.
# Never blocks. Locks atomically. Skips on cooldown, held lock, or insufficient
# messages. Logs all decisions to stderr — never silent.

set -eEuo pipefail
trap 'sr_error "FAILED at line $LINENO (exit $?)"' ERR

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh" || exit 0

# SR_READONLY kill-switch: load context only, skip all capture.
sr_is_readonly && exit 0

sr_ensure_dirs

# ── Parse args ────────────────────────────────────────────────────────────────
FORCE=false
DRY_RUN=false
MARK_ONLY=false
SESSION_ID=""
for arg in "$@"; do
  case "$arg" in
    --force)      FORCE=true ;;
    --dry-run)    DRY_RUN=true ;;
    --mark-only)  MARK_ONLY=true ;;
    *)            SESSION_ID="$arg" ;;
  esac
done

# ── Early exit for --mark-only: bypass flock ─────────────────────────────────
# WAL filenames include timestamp+PID — concurrent WAL files are unique, making
# locking unnecessary. extract.py is read-only on the JSONL. Must exit BEFORE
# the _cleanup trap is set (trap removes SR_LOCK which Phase 2 may hold).
if [[ "$MARK_ONLY" == true ]]; then
  _mo_extract=$(mktemp /tmp/sr-mark-extract-XXXXXX.txt)
  _mo_stderr=$(mktemp /tmp/sr-mark-stderr-XXXXXX.txt)
  trap 'rm -f "$_mo_extract" "$_mo_stderr" 2>/dev/null || true' EXIT
  _mo_args=(--project-dir "$PROJECT_DIR" --state-dir "$STATE_DIR" --since-last-save)
  [[ -n "$SESSION_ID" ]] && _mo_args+=(--session "$SESSION_ID")
  _mo_exit=0
  python3 "$SCRIPT_DIR/extract.py" "${_mo_args[@]}" \
    > "$_mo_extract" 2> "$_mo_stderr" || _mo_exit=$?
  if [[ $_mo_exit -eq 1 ]]; then
    sr_warn "mark-only: extract failed — WAL skipped"
    exit 0
  fi
  _mo_exchanges=$(grep -oP '__EXCHANGES__:\K\d+' "$_mo_stderr" 2>/dev/null || echo 0)
  if (( _mo_exchanges > 0 )); then
    _wal="$STATE_DIR/wal-$(date +%s)-$$.md"
    if printf '## %s [STOP-WAL — raw capture before async haiku]\n\n%s\n\n' \
        "$(date -Iseconds)" "$(cat "$_mo_extract")" > "$_wal" 2>/dev/null; then
      sr_info "mark-only: WAL written to ${_wal##*/} (no lock, position not advanced)"
    else
      sr_warn "mark-only: WAL write failed for ${_wal##*/} — stop content not captured"
    fi
  else
    sr_info "mark-only: no new exchanges — WAL skipped"
  fi
  exit 0
fi

# ── Cleanup on exit ───────────────────────────────────────────────────────────
_CLEANUP_FILES=()
_cleanup() {
  rm -f "${_CLEANUP_FILES[@]}" 2>/dev/null || true
}
trap _cleanup EXIT

# ── Buffer size guard ─────────────────────────────────────────────────────────
# Fires before every NDC run. Prevents Haiku context overflow when Haiku
# failures have caused raw-content accumulation in buffer.md.
_sr_buffer_guard() {
  local max_lines=2000 keep_lines=500
  [[ ! -f "$SR_BUFFER" ]] && return 0
  local current_lines
  current_lines=$(wc -l < "$SR_BUFFER" 2>/dev/null || echo 0)
  if (( current_lines > max_lines )); then
    sr_warn "buffer.md at ${current_lines} lines (max ${max_lines}) — truncating to ${keep_lines} oldest lines dropped"
    local tmp
    tmp=$(mktemp /tmp/sr-buffer-guard-XXXXXX.md)
    _CLEANUP_FILES+=("$tmp")
    printf '## %s [BUFFER GUARD — was %d lines, oldest entries dropped, kept last %d]\n\n' \
      "$(date -Iseconds)" "$current_lines" "$keep_lines" > "$tmp"
    tail -n "$keep_lines" "$SR_BUFFER" >> "$tmp"
    mv "$tmp" "$SR_BUFFER"
  fi
}

# ── Prune stale per-session ts files (older than 7 days) ─────────────────────
find "$STATE_DIR" -maxdepth 1 -name "last-save-ts.*" -mtime +7 -delete 2>/dev/null || true

# ── Atomic lock (flock — wait up to 30s for team members) ────────────────────
# _SR_LOCK_TIMEOUT overridable for tests; production default 30s
exec 9>"$SR_LOCK"
if ! flock --wait "${_SR_LOCK_TIMEOUT:-30}" 9; then
  sr_warn "could not acquire lock after ${_SR_LOCK_TIMEOUT:-30}s — skipping (another save.sh may be stuck)"
  exit 0
fi

# ── WAL cleanup — once any save.sh holds the lock the prior --mark-only WAL is
# redundant: this run will re-extract the same lines (position not advanced).
rm -f "$STATE_DIR"/wal-*.md 2>/dev/null || true

# ── Anti-stampede (5s global guard — prevents concurrent saves racing the same lines) ──
_SR_STAMPEDE_WINDOW=5
if [[ "$FORCE" != true && "$DRY_RUN" != true && -f "$STATE_DIR/last-save-ts" ]]; then
  LAST_TS=$(cat "$STATE_DIR/last-save-ts" 2>/dev/null || echo 0)
  if (( $(date +%s) - LAST_TS < _SR_STAMPEDE_WINDOW )); then
    sr_info "anti-stampede: <${_SR_STAMPEDE_WINDOW}s since last save, skipping"
    exit 0
  fi
fi

# ── Extract session ───────────────────────────────────────────────────────────
EXTRACT_FILE=$(mktemp /tmp/sr-extract-XXXXXX.txt)
EXTRACT_STDERR=$(mktemp /tmp/sr-stderr-XXXXXX.txt)
_CLEANUP_FILES+=("$EXTRACT_FILE" "$EXTRACT_STDERR")

sr_info "extracting session${SESSION_ID:+ $SESSION_ID}"

EXTRACT_ARGS=(
  --project-dir "$PROJECT_DIR"
  --state-dir   "$STATE_DIR"
  --since-last-save
)
[[ -n "$SESSION_ID" ]] && EXTRACT_ARGS+=(--session "$SESSION_ID")

EXTRACT_EXIT=0
python3 "$SCRIPT_DIR/extract.py" "${EXTRACT_ARGS[@]}" \
  > "$EXTRACT_FILE" \
  2> "$EXTRACT_STDERR" || EXTRACT_EXIT=$?

if [[ $EXTRACT_EXIT -eq 1 ]]; then
  sr_error "extraction failed (session file not found or unreadable)"
  cat "$EXTRACT_STDERR" >&2
  exit 1
elif [[ $EXTRACT_EXIT -eq 2 ]]; then
  sr_warn "extraction: some corrupted JSONL lines skipped — proceeding with partial results"
fi

TOTAL_LINES=$(grep -oP '__POSITION__:\K\d+' "$EXTRACT_STDERR" 2>/dev/null || echo 0)
HUMAN_COUNT=$(grep -oP '__HUMAN__:\K\d+'    "$EXTRACT_STDERR" 2>/dev/null || echo 0)
EXCHANGE_COUNT=$(grep -oP '__EXCHANGES__:\K\d+' "$EXTRACT_STDERR" 2>/dev/null || echo 0)
ACTUAL_SESSION=$(head -1 "$EXTRACT_FILE" 2>/dev/null | sed 's/^Session: //' || echo "unknown")

sr_info "extracted: ${EXCHANGE_COUNT} exchanges, ${HUMAN_COUNT} human msgs, position ${TOTAL_LINES}"

# ── Per-session cooldown (each session tracked independently — multi-developer safe) ──
SESSION_SAVE_TS="$STATE_DIR/last-save-ts.${ACTUAL_SESSION}"
if [[ "$FORCE" != true && "$DRY_RUN" != true && -f "$SESSION_SAVE_TS" ]]; then
  LAST_TS=$(cat "$SESSION_SAVE_TS" 2>/dev/null || echo 0)
  ELAPSED=$(( $(date +%s) - LAST_TS ))
  if (( ELAPSED < SR_SAVE_COOLDOWN )); then
    sr_info "cooldown: session ${ACTUAL_SESSION:0:8}… ${ELAPSED}s < ${SR_SAVE_COOLDOWN}s, skipping"
    exit 0
  fi
fi

# ── Threshold check ───────────────────────────────────────────────────────────
if [[ "$FORCE" != true && "$EXCHANGE_COUNT" -eq 0 ]]; then
  sr_info "0 exchanges extracted — skipping (position not advanced)"
  exit 0
fi

if [[ "$FORCE" != true && "$HUMAN_COUNT" -lt "$SR_MIN_HUMAN" ]]; then
  sr_info "${HUMAN_COUNT} human msgs < ${SR_MIN_HUMAN}, skipping"
  exit 0
fi

# ── Dry run ───────────────────────────────────────────────────────────────────
if [[ "$DRY_RUN" == true ]]; then
  echo "=== DRY RUN: extracted exchanges ==="
  cat "$EXTRACT_FILE"
  exit 0
fi

# ── Build Haiku summarization prompt ─────────────────────────────────────────
PROMPT_FILE=$(mktemp /tmp/sr-prompt-XXXXXX.txt)
_CLEANUP_FILES+=("$PROMPT_FILE")

CURRENT_TIME=$(sr_now)
BRANCH=$(cd "$PROJECT_DIR" && git branch --show-current 2>/dev/null || echo "unknown")

# Get last buffer entry for dedup context (capped to avoid inflating Haiku prompt)
LAST_ENTRY="(no previous entry)"
if [[ -f "$SR_BUFFER" ]]; then
  LAST_LINE=$(grep -n '^## ' "$SR_BUFFER" 2>/dev/null | tail -1 | cut -d: -f1 || echo "")
  if [[ -n "$LAST_LINE" ]]; then
    _RAW_LAST=$(tail -n +"$LAST_LINE" "$SR_BUFFER")
    LAST_ENTRY="${_RAW_LAST:0:800}"
    unset _RAW_LAST
  fi
fi

EXTRACT_CONTENT=$(cat "$EXTRACT_FILE")

# Substitute static placeholders in prompt template, then append dynamic content
# Using | as sed delimiter — safe because git enforces no | in branch names (git-check-ref-format)
sed \
  -e "s|{{TIME}}|${CURRENT_TIME}|g" \
  -e "s|{{BRANCH}}|${BRANCH}|g" \
  "$SCRIPT_DIR/prompts/summarize.txt" \
  > "$PROMPT_FILE"

# Append dynamic sections safely (avoids sed delimiter conflicts with content)
printf '\nPrevious entry for context (do not repeat):\n---\n%s\n---\n\nConversation to summarize:\n---\n%s\n---\n\nWrite the entry now:\n' \
  "$LAST_ENTRY" \
  "$EXTRACT_CONTENT" \
  >> "$PROMPT_FILE"

# ── Call Haiku ────────────────────────────────────────────────────────────────
sr_info "calling Haiku"
HAIKU_RESULT=""
sr_call_haiku "$PROMPT_FILE" HAIKU_RESULT || {
  sr_error "Haiku summarization failed — preserving raw content in buffer.md; advancing position to ${TOTAL_LINES} (check SR_MODEL: ${SR_MODEL:-claude-haiku-4-5})"
  # Cap raw dump to 100 lines — prevents a single failure from bloating buffer.md
  # NDC will compress it; full content is still in the JSONL transcript
  _EXTRACT_CAPPED=$(printf '%s' "$EXTRACT_CONTENT" | head -100)
  # Only advance position if the raw dump write succeeds — disk-full must not silently
  # drop entries (position advance without buffer write = permanent data loss).
  if printf '## %s [UNSUMMARIZED — haiku failed, extract capped at 100 lines]\n\n%s\n\n' \
      "$(date -Iseconds)" "$_EXTRACT_CAPPED" >> "$SR_BUFFER" 2>/dev/null; then
    sr_write_last_save "$ACTUAL_SESSION" "$TOTAL_LINES"
    date +%s > "$STATE_DIR/last-save-ts"
    date +%s > "$SESSION_SAVE_TS"
  else
    sr_warn "buffer write failed — position NOT advanced; entries will be retried on next save"
  fi
  unset _EXTRACT_CAPPED
  exit 1
}

# Detect SKIP response
if [[ "$HAIKU_RESULT" =~ ^SKIP[[:space:]]*$ ]]; then
  sr_info "Haiku returned SKIP (no meaningful new progress)"
  # Log to skipped.log for human review — position IS advanced so lines won't be retried
  printf '%s SKIP %s exchanges=%s human=%s\n' \
    "$(date -Iseconds)" "$ACTUAL_SESSION" "$EXCHANGE_COUNT" "$HUMAN_COUNT" \
    >> "$STATE_DIR/skipped.log" 2>/dev/null || true
  sr_write_last_save "$ACTUAL_SESSION" "$TOTAL_LINES"
  date +%s > "$STATE_DIR/last-save-ts"
  date +%s > "$SESSION_SAVE_TS"
  exit 0
fi

# ── Append to buffer.md ───────────────────────────────────────────────────────
sr_info "appending to buffer.md"
printf '%s\n\n' "$HAIKU_RESULT" >> "$SR_BUFFER"
log_obs INFO save.sh "session saved to buffer.md (session=${ACTUAL_SESSION})" 2>/dev/null || true

# ── Update position ───────────────────────────────────────────────────────────
sr_write_last_save "$ACTUAL_SESSION" "$TOTAL_LINES"
date +%s > "$STATE_DIR/last-save-ts"
date +%s > "$SESSION_SAVE_TS"

# ── Buffer size guard (before NDC to prevent Haiku context overflow) ─────────
_sr_buffer_guard

# ── NDC: buffer → today (hourly compression) ─────────────────────────────────
NDC_NEEDED=false
if [[ -f "$STATE_DIR/last-ndc-ts" ]]; then
  LAST_NDC=$(cat "$STATE_DIR/last-ndc-ts" 2>/dev/null || echo 0)
  NDC_ELAPSED=$(( $(date +%s) - LAST_NDC ))
  (( NDC_ELAPSED >= SR_NDC_COOLDOWN )) && NDC_NEEDED=true
else
  # First NDC run — seed as if cooldown already elapsed so compression runs immediately
  printf '%s\n' "$(( $(date +%s) - SR_NDC_COOLDOWN ))" > "$STATE_DIR/last-ndc-ts"
  NDC_NEEDED=true
fi

if [[ "$NDC_NEEDED" == true && -f "$SR_BUFFER" && -s "$SR_BUFFER" ]]; then
  sr_info "running NDC: compressing buffer into today.md"
  NDC_PROMPT=$(mktemp /tmp/sr-ndc-XXXXXX.txt)
  _CLEANUP_FILES+=("$NDC_PROMPT")

  BUFFER_CONTENT=$(cat "$SR_BUFFER")
  cat "$SCRIPT_DIR/prompts/compress.txt" > "$NDC_PROMPT"
  printf '\n\nText:\n%s\n' "$BUFFER_CONTENT" >> "$NDC_PROMPT"

  NDC_RESULT=""
  if sr_call_haiku "$NDC_PROMPT" NDC_RESULT; then
    TODAY_DATE=$(sr_today)
    printf '## %s\n\n%s\n\n' "$TODAY_DATE" "$NDC_RESULT" >> "$SR_TODAY"
    : > "$SR_BUFFER"
    date +%s > "$STATE_DIR/last-ndc-ts"
    sr_info "NDC complete: buffer compressed into today.md"
  else
    sr_warn "NDC Haiku call failed — buffer kept as-is"
  fi
fi

sr_info "save complete"
