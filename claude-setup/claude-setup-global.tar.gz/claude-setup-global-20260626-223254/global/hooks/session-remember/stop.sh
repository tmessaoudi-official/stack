#!/usr/bin/env bash
# stop.sh — StopHook: unconditional flush of session-remember buffer on session exit.
# Fires on both graceful exit and crashes. Always exits 0 — must never block or
# delay session termination. Uses save.sh --force to bypass cooldown and delta threshold.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/../log-helpers.sh" 2>/dev/null || true
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh" || exit 0

# Read StopHook payload from stdin — Claude Code sends JSON with session_id and other
# fields. Safe degradation: if jq unavailable or field absent, _SESSION_ID stays empty
# and save.sh falls back to the most-recent JSONL (which IS the current session at
# stop time). Strictly better than current behavior with no downside on payload mismatch.
_STOP_PAYLOAD=$(cat 2>/dev/null || true)
_SESSION_ID=""
if command -v jq &>/dev/null; then
  _SESSION_ID=$(printf '%s' "$_STOP_PAYLOAD" | jq -r '.session_id // empty' 2>/dev/null || true)
fi
_SESSION_ARGS=()
[[ -n "$_SESSION_ID" ]] && _SESSION_ARGS=("$_SESSION_ID")

# Respect kill switches — use absolute paths (canonical from common.sh) to avoid
# resolving to the wrong directory when stop.sh is called via a symlink.
[[ -f "$HOME/.claude/hooks/session-remember/DISABLED" ]] && exit 0
[[ -f "$HOME/.claude/hooks/session-remember/DISABLED.lean" ]] && exit 0
[[ -f "$HOME/.claude/hooks/session-remember/READONLY" ]] && { log_obs INFO stop.sh "READONLY sentinel active — skipping capture" 2>/dev/null || true; exit 0; }

# Two-phase flush (bypasses cooldown + delta threshold via --force):
#   Phase 1 (sync, <3s): write raw extract to WAL — no Haiku, no position advance.
#     Guards against data loss if the machine hard-kills Phase 2 before it finishes.
#   Phase 2 (async): full Haiku summarization + position advance + WAL cleanup.
#     nohup survives parent exit; disown removes it from the job table so the
#     hook exits after Phase 1 completes (~2s) instead of after the Haiku call (~25s).
mkdir -p "$HOME/.claude/logs"
log_obs INFO stop.sh "session flush triggered (session=${_SESSION_ID:-auto})" 2>/dev/null || true
timeout 3 "$SCRIPT_DIR/save.sh" "${_SESSION_ARGS[@]}" --force --mark-only \
  >> "$HOME/.claude/logs/session-remember.log" 2>&1 || true
nohup "$SCRIPT_DIR/save.sh" "${_SESSION_ARGS[@]}" --force \
  >> "$HOME/.claude/logs/session-remember.log" 2>&1 &
disown $! 2>/dev/null || true
log_obs INFO stop.sh "async save dispatched (PID=$!)" 2>/dev/null || true

exit 0
