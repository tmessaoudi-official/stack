#!/usr/bin/env bash
# run-tests.sh — Unified test runner for the session-remember pipeline
# Usage: bash run-tests.sh
# Exits 0 if all suites pass, 1 if any fail.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TESTS_DIR="$SCRIPT_DIR/tests"

if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
  G='\033[0;32m' R='\033[0;31m' B='\033[1m' D='\033[0m'
else
  G='' R='' B='' D=''
fi

SUITES_PASS=0; SUITES_FAIL=0
declare -a FAILED_SUITES=()

run_suite() {
  local name="$1"; shift
  printf "\n${B}══ %s ══${D}\n" "$name"
  if "$@"; then
    printf "${G}  → PASS${D}\n"
    (( ++SUITES_PASS )) || true
  else
    printf "${R}  → FAIL${D}\n"
    (( ++SUITES_FAIL )) || true
    FAILED_SUITES+=("$name")
  fi
}

printf "\n${B}  session-remember — full test suite${D}\n"

run_suite "extract.test.py"     python3 "$TESTS_DIR/extract.test.py"
run_suite "common.test.sh"      bash    "$TESTS_DIR/common.test.sh"
run_suite "save.test.sh"        bash    "$TESTS_DIR/save.test.sh"
run_suite "smoke.test.sh"       bash    "$TESTS_DIR/smoke.test.sh"
run_suite "consolidate.test.sh" bash    "$TESTS_DIR/consolidate.test.sh"
run_suite "stop.test.sh"        bash    "$TESTS_DIR/stop.test.sh"
run_suite "trigger.test.sh"     bash    "$TESTS_DIR/trigger.test.sh"
run_suite "start.test.sh"       bash    "$TESTS_DIR/start.test.sh"

TOTAL=$(( SUITES_PASS + SUITES_FAIL ))
echo ""
printf "${B}═══════════════════════════════════════════${D}\n"
if (( SUITES_FAIL == 0 )); then
  printf "${G}All %d suite(s) passed${D}\n" "$TOTAL"
  exit 0
else
  printf "${R}%d/%d suite(s) failed: %s${D}\n" \
    "$SUITES_FAIL" "$TOTAL" "${FAILED_SUITES[*]}"
  exit 1
fi
