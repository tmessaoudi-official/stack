#!/usr/bin/env python3
"""
extract.py — Claude Code session JSONL extractor for session-remember hooks.

Reads a session JSONL file, extracts human/assistant exchanges since the last
saved position, and prints them as formatted text for Haiku summarization.

USAGE:
  python3 extract.py \\
    --project-dir /path/to/your/project \\
    --state-dir ~/.claude/projects/-stack/memory/sessions/.state \\
    [--session <uuid>] \\
    [--since-last-save] \\
    [--all]

OUTPUT:
  stdout: Formatted exchange text
  stderr: __POSITION__:<n>  (total JSONL lines)
          __HUMAN__:<n>     (human message count)
          __EXCHANGES__:<n> (total exchange count)

EXIT CODES:
  0  Success (even if 0 exchanges — check __HUMAN__)
  1  Session file not found or unreadable
  2  Corrupted JSONL lines were skipped (partial results; __ERRORS__:<n> on stderr)
"""

import sys
import os
import json
import glob


def session_dir(project_dir: str) -> str:
    slug = project_dir.replace("/", "-")
    return os.path.expanduser(f"~/.claude/projects/{slug}")


def find_session(session_id, project_dir: str) -> str:
    sdir = session_dir(project_dir)
    if session_id:
        if any(c in session_id for c in ("/", "\\", "..")):
            raise ValueError(f"invalid session_id: {session_id}")
        path = os.path.join(sdir, session_id + ".jsonl")
        if os.path.exists(path):
            return path
    files = glob.glob(os.path.join(sdir, "*.jsonl"))
    if not files:
        raise FileNotFoundError(f"no session JSONL files in {sdir}")
    return max(files, key=os.path.getmtime)


def get_last_save_line(session_id: str, state_dir: str) -> int:
    path = os.path.join(state_dir, "last-save.json")
    if not os.path.exists(path):
        return 0
    try:
        with open(path) as f:
            data = json.load(f)
        if data.get("session") == session_id:
            return int(data.get("line", 0))
    except (json.JSONDecodeError, OSError, ValueError, TypeError):
        pass
    return 0


def format_tool_use(block: dict) -> str:
    name = block.get("name", "?")
    inp = block.get("input", {})
    if name in ("Edit", "Read", "Write"):
        fname = inp.get("file_path", "?").split("/")[-1]
        return f"[TOOL: {name} {fname}]"
    elif name == "Bash":
        cmd = inp.get("command", "?")[:80]
        return f"[TOOL: Bash `{cmd}`]"
    elif name in ("Grep", "Glob"):
        return f"[TOOL: {name} '{inp.get('pattern', inp.get('path', '?'))}']"
    else:
        return f"[TOOL: {name}]"


_FILTER_MARKERS = ("<system-reminder>", "<command-name>", "<local-command")


def extract_texts(content) -> list:
    texts = []
    if isinstance(content, str):
        if any(m in content for m in _FILTER_MARKERS):
            return texts
        s = content.strip()
        if s:
            texts.append(s)
    elif isinstance(content, list):
        for block in content:
            btype = block.get("type", "")
            if btype == "text":
                t = block.get("text", "").strip()
                if t and not any(m in t for m in _FILTER_MARKERS):
                    texts.append(t)
            elif btype == "tool_use":
                texts.append(format_tool_use(block))
    return texts


def extract_messages(path: str, skip_lines: int = 0):
    """Return (messages, total_line_count, error_count)."""
    messages = []
    total = 0
    errors = 0
    try:
        with open(path) as f:
            for line_num, line in enumerate(f):
                total += 1
                if line_num < skip_lines:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    errors += 1
                    continue
                if obj.get("isMeta", False):
                    continue
                msg_type = obj.get("type")
                if msg_type not in ("user", "assistant"):
                    continue
                content = obj.get("message", {}).get("content", "")
                texts = extract_texts(content)
                if texts:
                    role = "HUMAN" if msg_type == "user" else "AGENT"
                    messages.append((role, "\n".join(texts)))
    except OSError as e:
        print(f"error reading {path}: {e}", file=sys.stderr)
        sys.exit(1)
    return messages, total, errors


def main():
    args = sys.argv[1:]
    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", ".")
    state_dir = None
    session_id = None
    since_last_save = False
    show_all = False

    i = 0
    while i < len(args):
        if args[i] == "--project-dir" and i + 1 < len(args):
            project_dir = args[i + 1]
            i += 2
        elif args[i] == "--state-dir" and i + 1 < len(args):
            state_dir = args[i + 1]
            i += 2
        elif args[i] == "--session" and i + 1 < len(args):
            session_id = args[i + 1]
            i += 2
        elif args[i] == "--since-last-save":
            since_last_save = True
            i += 1
        elif args[i] == "--all":
            show_all = True
            i += 1
        else:
            print(f"unknown arg: {args[i]}", file=sys.stderr)
            sys.exit(1)

    try:
        path = find_session(session_id, project_dir)
    except (FileNotFoundError, ValueError) as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    actual_id = os.path.basename(path).replace(".jsonl", "")

    skip = 0
    if since_last_save and state_dir and state_dir != "/dev/null":
        skip = get_last_save_line(actual_id, state_dir)
    elif show_all:
        skip = 0

    messages, total_lines, error_count = extract_messages(path, skip_lines=skip)

    human_count = sum(1 for r, _ in messages if r == "HUMAN")
    exchange_count = len(messages)

    # Format output
    lines = [f"Session: {actual_id}", f"Lines: {total_lines}", "=" * 60]
    for role, text in messages:
        lines.append(f"\n[{role}]")
        lines.append(text)
        lines.append("-" * 40)

    print("\n".join(lines))

    # Machine-readable stats to stderr
    print(f"__POSITION__:{total_lines}", file=sys.stderr)
    print(f"__HUMAN__:{human_count}", file=sys.stderr)
    print(f"__EXCHANGES__:{exchange_count}", file=sys.stderr)
    if error_count > 0:
        print(f"__ERRORS__:{error_count}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
