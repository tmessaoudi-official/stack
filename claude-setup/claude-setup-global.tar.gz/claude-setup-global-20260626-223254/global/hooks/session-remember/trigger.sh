#!/usr/bin/env bash
# trigger.sh — PostToolUse hook: check JSONL delta, fire save.sh when needed
#
# Fires on ALL tool calls (no matcher). Always exits 0 — never blocks the agent.
# Reads tool call JSON from stdin (provided by Claude Code) but doesn't need it.

set -euo pipefail

# Consume stdin (required by Claude Code hook protocol)
# shellcheck disable=SC2034
_input=$(cat 2>/dev/null || true)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh" || exit 0
[[ "${SR_READONLY:-}" == "1" ]] && exit 0

sr_ensure_dirs || { sr_warn "sr_ensure_dirs failed — skipping trigger"; exit 0; }

# ── Find latest session JSONL ─────────────────────────────────────────────────
LATEST_JSONL=$(ls -t "$SESSION_STORE"/*.jsonl 2>/dev/null | head -1 || true)
[[ -n "$LATEST_JSONL" ]] || exit 0

# ── Count current lines ───────────────────────────────────────────────────────
CURRENT_LINES=$(wc -l < "$LATEST_JSONL" 2>/dev/null | tr -d ' ' || echo 0)
SESSION_ID=$(basename "$LATEST_JSONL" .jsonl)

# ── Get last saved position ───────────────────────────────────────────────────
LAST_LINE=0
SAVED_SESSION=$(sr_last_save_field "session" "")
if [[ "$SAVED_SESSION" == "$SESSION_ID" ]]; then
  LAST_LINE=$(sr_last_save_field "line" "0")
fi

# ── Check delta ───────────────────────────────────────────────────────────────
DELTA=$(( CURRENT_LINES - LAST_LINE ))
if (( DELTA <= SR_DELTA_THRESHOLD )); then
  exit 0
fi

# ── Check if save already running ────────────────────────────────────────────
if [[ -f "$SR_PID" ]]; then
  OLD_PID=$(cat "$SR_PID" 2>/dev/null || echo "")
  if [[ -n "$OLD_PID" ]] && kill -0 "$OLD_PID" 2>/dev/null; then
    sr_info "save already running (PID $OLD_PID), skipping trigger"
    exit 0
  fi
fi

# ── Launch save.sh in background ─────────────────────────────────────────────
mkdir -p "$SESSION_DIR/logs"
LOG_FILE="$SESSION_DIR/logs/save-$(TZ="$SR_TZ" date +%H%M%S).log"
nohup "$SCRIPT_DIR/save.sh" "$SESSION_ID" \
  > "$LOG_FILE" 2>&1 &
echo $! > "$SR_PID"
sr_info "triggered save (delta=${DELTA}, PID=$!, session=${SESSION_ID})"
log_obs INFO trigger.sh "save.sh dispatched (delta=${DELTA}, session=${SESSION_ID}, PID=$!)" 2>/dev/null || true

# Rotate: keep only 20 newest save-*.log files
{ ls -t "$SESSION_DIR/logs"/save-*.log 2>/dev/null | tail -n +21 | xargs rm -f --; } 2>/dev/null || true

exit 0
