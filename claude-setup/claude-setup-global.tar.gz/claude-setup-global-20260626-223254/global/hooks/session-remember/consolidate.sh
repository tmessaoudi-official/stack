#!/usr/bin/env bash
# consolidate.sh — Temporal compression: buffer→today, today→history, history→archive
#
# Called by start.sh when stale data is detected (yesterday's today.md exists).
# Can be run standalone for debugging: CLAUDE_PROJECT_DIR=/path/to/your/project bash consolidate.sh
# Always exits 0.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh" || exit 0
[[ "${SR_READONLY:-}" == "1" ]] && exit 0

sr_ensure_dirs || { sr_error "consolidate: failed to create session directories"; exit 0; }

# Acquire the same lock as save.sh — prevents concurrent buffer/today.md writes
exec 9>"$SR_LOCK"
flock --wait 30 9 || { sr_warn "consolidate: could not acquire lock after 30s, skipping"; exit 0; }

TODAY_DATE=$(sr_today)

# ── Step 1: Final NDC — flush stale buffer into today.md ─────────────────────
if [[ -f "$SR_BUFFER" && -s "$SR_BUFFER" ]]; then
  sr_info "consolidate: flushing stale buffer via NDC"
  NDC_PROMPT=$(mktemp /tmp/sr-ndc-XXXXXX.txt)
  BUFFER_CONTENT=$(cat "$SR_BUFFER")
  cat "$SCRIPT_DIR/prompts/compress.txt" > "$NDC_PROMPT"
  printf '\n\nText:\n%s\n' "$BUFFER_CONTENT" >> "$NDC_PROMPT"

  NDC_RESULT=""
  if sr_call_haiku "$NDC_PROMPT" NDC_RESULT; then
    STALE_DATE=$(grep -m1 '^## [0-9]' "$SR_TODAY" 2>/dev/null | sed 's/^## //' | head -c 10) || true
    [[ -z "$STALE_DATE" ]] && STALE_DATE=$(grep -m1 '^## [0-9]' "$SR_BUFFER" 2>/dev/null | sed 's/^## //' | head -c 10) || true
    [[ -z "$STALE_DATE" ]] && STALE_DATE="$TODAY_DATE"
    printf '## %s\n\n%s\n\n' "$STALE_DATE" "$NDC_RESULT" >> "$SR_TODAY"
    : > "$SR_BUFFER"
    sr_info "consolidate: buffer flushed into today.md"
  else
    sr_warn "consolidate: NDC Haiku failed — keeping buffer"
  fi
  rm -f "$NDC_PROMPT" 2>/dev/null || true
fi

# ── Step 2: Roll stale today.md → history.md ─────────────────────────────────
if [[ ! -f "$SR_TODAY" || ! -s "$SR_TODAY" ]]; then
  sr_info "consolidate: no today.md content to roll up"
else
  FIRST_DATE=$(grep -m1 '^## [0-9]' "$SR_TODAY" 2>/dev/null | sed 's/^## //' | head -c 10 || echo "")
  if [[ "$FIRST_DATE" == "$TODAY_DATE" ]]; then
    sr_info "consolidate: today.md is current ($TODAY_DATE), no rollup needed"
  else
    sr_info "consolidate: today.md is stale (${FIRST_DATE:-unknown}), rolling into history.md"

    CONS_PROMPT=$(mktemp /tmp/sr-cons-XXXXXX.txt)
    TODAY_CONTENT=$(cat "$SR_TODAY")
    HISTORY_CONTENT=""
    [[ -f "$SR_HISTORY" ]] && HISTORY_CONTENT=$(cat "$SR_HISTORY")

    cat "$SCRIPT_DIR/prompts/consolidate.txt" > "$CONS_PROMPT"
    printf '\n\n### Daily entries to compress:\n%s\n\n### Current history.md:\n%s\n\nWrite the updated history.md now (oldest first, newest last):\n' \
      "$TODAY_CONTENT" \
      "$HISTORY_CONTENT" \
      >> "$CONS_PROMPT"

    CONS_RESULT=""
    if sr_call_haiku "$CONS_PROMPT" CONS_RESULT; then
      echo "$CONS_RESULT" > "$SR_HISTORY"
      : > "$SR_TODAY"
      sr_info "consolidate: today.md rolled into history.md"
    else
      sr_warn "consolidate: rollup Haiku failed — keeping today.md"
    fi
    rm -f "$CONS_PROMPT" 2>/dev/null || true
  fi
fi

# ── Step 3: Rotate old history entries → archive.md ──────────────────────────
if [[ -f "$SR_HISTORY" && -s "$SR_HISTORY" ]]; then
  ENTRY_COUNT=$(grep -c '^## [0-9]' "$SR_HISTORY" 2>/dev/null) || ENTRY_COUNT=0
  if (( ENTRY_COUNT > SR_HISTORY_MAX_ENTRIES )); then
    sr_info "consolidate: history has ${ENTRY_COUNT} entries (max ${SR_HISTORY_MAX_ENTRIES}), rotating to archive"

    ARCH_PROMPT=$(mktemp /tmp/sr-arch-XXXXXX.txt)
    HISTORY_CONTENT=$(cat "$SR_HISTORY")
    ARCHIVE_CONTENT=""
    [[ -f "$SR_ARCHIVE" ]] && ARCHIVE_CONTENT=$(cat "$SR_ARCHIVE")

    # Build prompt with user-controlled content appended via printf (not heredoc expansion)
    # to prevent shell injection from $(cmd) or backtick sequences in session files.
    cat > "$ARCH_PROMPT" <<EOF
You are a memory archivist. Keep the newest ${SR_HISTORY_MAX_ENTRIES} daily entries in history, compress older ones into weekly summaries in archive.

Rules:
- A week summary covers Mon-Sun, header: ## Week of YYYY-MM-DD (Monday)
- Each week: 2-3 sentences covering conventions, infrastructure changes, major deliverables
- Drop daily details, keep patterns and decisions
- Return EXACTLY this structure, no other text:

=== HISTORY ===
[newest ${SR_HISTORY_MAX_ENTRIES} daily entries, unchanged]

=== ARCHIVE ===
[existing archive content, then new weekly entries appended]

### Current history.md (keep newest ${SR_HISTORY_MAX_ENTRIES} entries):
EOF
    printf '%s\n' "$HISTORY_CONTENT" >> "$ARCH_PROMPT"
    printf '\n### Current archive.md:\n' >> "$ARCH_PROMPT"
    printf '%s\n' "$ARCHIVE_CONTENT" >> "$ARCH_PROMPT"

    ARCH_RESULT=""
    if sr_call_haiku "$ARCH_PROMPT" ARCH_RESULT; then
      HIST_PART=$(echo "$ARCH_RESULT" | awk '/^=== HISTORY ===/{ found=1; next } /^=== ARCHIVE ===/{ found=0 } found{ print }')
      ARCH_PART=$(echo "$ARCH_RESULT" | awk '/^=== ARCHIVE ===/{ found=1; next } found{ print }')

      if [[ -n "$HIST_PART" ]]; then
        echo "$HIST_PART" > "$SR_HISTORY"
        [[ -n "$ARCH_PART" ]] && echo "$ARCH_PART" >> "$SR_ARCHIVE"
        sr_info "consolidate: rotated ${ENTRY_COUNT} → ≤${SR_HISTORY_MAX_ENTRIES} entries in history"
        log_obs INFO consolidate.sh "archive rotation complete (${ENTRY_COUNT} entries compressed)" 2>/dev/null || true
      else
        sr_warn "consolidate: could not parse archive output — history unchanged"
        log_obs WARN consolidate.sh "archive rotation: could not parse Haiku output — history unchanged" 2>/dev/null || true
      fi
    else
      sr_warn "consolidate: archive rotation Haiku failed"
      log_obs ERROR consolidate.sh "archive rotation: Haiku call failed" 2>/dev/null || true
    fi
    rm -f "$ARCH_PROMPT" 2>/dev/null || true
  fi
fi

sr_info "consolidate: done"
