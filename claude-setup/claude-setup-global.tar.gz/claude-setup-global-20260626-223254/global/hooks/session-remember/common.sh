#!/usr/bin/env bash
# common.sh — Shared config and utilities for session-remember hooks (GLOBAL)
# Sourced by start.sh, trigger.sh, save.sh, consolidate.sh
# Works for any project — derives all paths from $CLAUDE_PROJECT_DIR
# shellcheck disable=SC2034  # Variables are intentionally defined for use by sourcing scripts

[[ -n "${_SR_COMMON_LOADED:-}" ]] && return 0
readonly _SR_COMMON_LOADED=1

set -euo pipefail
umask 077  # session files contain conversation content — restrict to owner only

# ── Centralized observability (log_obs → ~/.claude/logs/hooks-errors.log) ────
_SR_HOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck disable=SC1091
source "$_SR_HOOKS_DIR/log-helpers.sh" 2>/dev/null || true

# ── Logging (defined first so other sections can use it) ──────────────────────
_sr_log() {
  local level="$1"; shift
  printf '%s [session-remember] [%s] %s\n' "$(date -Iseconds)" "$level" "$*" >&2
}

sr_info()  { _sr_log "info"  "$@"; }
sr_warn()  { _sr_log "warn"  "$@"; }
sr_error() { _sr_log "error" "$@"; }

# ── Global toggles ────────────────────────────────────────────────────────────
# File-presence kill switches — independent of project and blacklist.
# DISABLED: touch this file → no load, no capture (full silence)
# READONLY: touch this file → load prior context but skip capture
_SR_DISABLED_FILE="$HOME/.claude/hooks/session-remember/DISABLED"
_SR_LEAN_DISABLED_FILE="${_SR_DISABLED_FILE}.lean"
_SR_READONLY_FILE="$HOME/.claude/hooks/session-remember/READONLY"

sr_is_disabled() { [[ -f "$_SR_DISABLED_FILE" ]] || [[ -f "$_SR_LEAN_DISABLED_FILE" ]]; }
sr_is_readonly()  { [[ -f "$_SR_READONLY_FILE" ]]; }

if sr_is_disabled; then
  sr_info "DISABLED toggle active — session-remember fully off"
  return 1 2>/dev/null || exit 0
fi

if sr_is_readonly; then
  sr_info "READONLY toggle active — context will load, no capture"
  SR_READONLY=1
fi

# ── Path derivation ───────────────────────────────────────────────────────────
# Graceful handling: if CLAUDE_PROJECT_DIR is not set, return 1 so the sourcing
# script can exit cleanly (e.g., `source common.sh || exit 0`)
PROJECT_DIR="${CLAUDE_PROJECT_DIR:-}"
if [[ -z "$PROJECT_DIR" ]]; then
  sr_warn "CLAUDE_PROJECT_DIR not set — session-remember disabled for this session"
  return 1 2>/dev/null || exit 0
fi

_SR_PROJECT_SLUG="$(echo "$PROJECT_DIR" | tr '/' '-')"
MEMORY_DIR="$HOME/.claude/projects/${_SR_PROJECT_SLUG}/memory"
SESSION_DIR="$MEMORY_DIR/sessions"
STATE_DIR="$SESSION_DIR/.state"
SESSION_STORE="$HOME/.claude/projects/${_SR_PROJECT_SLUG}"

# ── Blacklist check ───────────────────────────────────────────────────────────
# If ~/.claude/hooks/session-remember/blacklist exists, skip projects listed there.
# Format: one project slug per line (e.g., "-tmp" or "-home-developer-scratch")
_SR_BLACKLIST_FILE="$HOME/.claude/hooks/session-remember/blacklist"
if [[ -f "$_SR_BLACKLIST_FILE" ]]; then
  while IFS= read -r _bl_slug || [[ -n "$_bl_slug" ]]; do
    # Skip comments and blank lines
    [[ "$_bl_slug" =~ ^[[:space:]]*#.*$ || -z "${_bl_slug// }" ]] && continue
    if [[ "$_SR_PROJECT_SLUG" == "$_bl_slug" ]]; then
      sr_info "project ${_SR_PROJECT_SLUG} is blacklisted — session-remember disabled"
      return 1 2>/dev/null || exit 0
    fi
  done < "$_SR_BLACKLIST_FILE"
fi

# ── Per-project readonly-list check ──────────────────────────────────────────
# If a project slug appears in readonly-list, set SR_READONLY=1 (load, no capture).
# Complements the global READONLY toggle; does not abort the pipeline.
# Format: one project slug per line — same as blacklist.
_SR_READONLY_LIST_FILE="$HOME/.claude/hooks/session-remember/readonly-list"
sr_is_readonly_project() {
  [[ -f "$_SR_READONLY_LIST_FILE" ]] || return 1
  while IFS= read -r _rl_slug || [[ -n "$_rl_slug" ]]; do
    [[ "$_rl_slug" =~ ^[[:space:]]*#.*$ || -z "${_rl_slug// }" ]] && continue
    [[ "$_SR_PROJECT_SLUG" == "$_rl_slug" ]] && return 0
  done < "$_SR_READONLY_LIST_FILE"
  return 1
}
if sr_is_readonly_project; then
  sr_info "project ${_SR_PROJECT_SLUG} in readonly-list — context loads, no capture"
  SR_READONLY=1
fi

# ── Session data files ────────────────────────────────────────────────────────
SR_HANDOFF="$SESSION_DIR/handoff.md"
SR_BUFFER="$SESSION_DIR/buffer.md"
SR_TODAY="$SESSION_DIR/today.md"
SR_HISTORY="$SESSION_DIR/history.md"
SR_ARCHIVE="$SESSION_DIR/archive.md"

# ── State files ───────────────────────────────────────────────────────────────
SR_LAST_SAVE="$STATE_DIR/last-save.json"
SR_LAST_NDC="$STATE_DIR/last-ndc-ts"
SR_LOCK="$STATE_DIR/save.lock"
SR_PID="$STATE_DIR/save.pid"

# ── Tunable config (override via env vars) ────────────────────────────────────
SR_SAVE_COOLDOWN="${SR_SAVE_COOLDOWN:-120}"       # seconds between saves
SR_NDC_COOLDOWN="${SR_NDC_COOLDOWN:-3600}"        # seconds between NDC compressions
SR_MIN_HUMAN="${SR_MIN_HUMAN:-3}"                 # min human messages before saving
SR_DELTA_THRESHOLD="${SR_DELTA_THRESHOLD:-50}"    # JSONL lines delta to trigger save
SR_TZ="${SR_TZ:-${TZ:-{{TZ}}}}"  # machine-specific: set SR_TZ in env to override (bundle default: {{TZ}})
SR_HISTORY_MAX_ENTRIES="${SR_HISTORY_MAX_ENTRIES:-10}"
SR_MODEL="${SR_MODEL:-claude-haiku-4-5}" # model used for all LLM calls (date-suffix-free = forward-compatible)

# ── Directory bootstrap ───────────────────────────────────────────────────────
sr_ensure_dirs() {
  mkdir -p "$SESSION_DIR" "$STATE_DIR"
  [[ -f "$STATE_DIR/source-path" ]] || echo "$PROJECT_DIR" > "$STATE_DIR/source-path"
}

# ── Timezone-aware date helpers ───────────────────────────────────────────────
sr_today() { TZ="$SR_TZ" date '+%Y-%m-%d'; }
sr_now()   { TZ="$SR_TZ" date '+%H:%M'; }

# ── Read a field from last-save.json (jq-based, no Python) ───────────────────
sr_last_save_field() {
  local field="$1" default="${2:-}"
  if [[ -f "$SR_LAST_SAVE" ]]; then
    # .[$f] // $d: returns $d for null/missing fields (jq 'empty' exits 0 with no
    # output, so the bash || fallback would never fire for missing-field cases).
    jq -r --arg f "$field" --arg d "$default" '.[$f] // $d' "$SR_LAST_SAVE" 2>/dev/null || echo "$default"
  else
    echo "$default"
  fi
}

# ── Write last-save.json ──────────────────────────────────────────────────────
sr_write_last_save() {
  local session="$1" line="$2"
  jq -n \
    --arg  session   "$session" \
    --argjson line   "$line" \
    --argjson ts     "$(date +%s)" \
    '{"session": $session, "line": $line, "timestamp": $ts}' \
    > "$SR_LAST_SAVE"
}

# ── Call Haiku (sandboxed: cwd=/tmp, no tools, max-turns 1) ──────────────────
# Usage: sr_call_haiku <prompt_file> <result_varname>
# Returns 0 on success, 1 on failure.
sr_call_haiku() {
  local prompt_file="$1"
  local -n _sr_result_ref="$2"

  if [[ ! -f "$prompt_file" ]]; then
    sr_error "prompt file not found: $prompt_file"
    return 1
  fi

  local raw attempt
  for attempt in 1 2 3; do
    raw=$(cd "$HOME/.claude/llm-sandbox" && timeout 90 claude -p \
      --model "${SR_MODEL}" \
      --max-turns 1 \
      --output-format json \
      --tools "" \
      < "$prompt_file" 2>/dev/null) && break
    [[ $attempt -lt 3 ]] && sr_warn "Haiku call failed (attempt ${attempt}/3), retrying in $(( attempt * 2 ))s" && sleep $(( attempt * 2 ))
    [[ $attempt -eq 3 ]] && { sr_error "Haiku call failed after 3 attempts"; return 1; }
  done

  _sr_result_ref=$(echo "$raw" | jq -r '.result // empty' 2>/dev/null | sed '/^[[:space:]]*$/d')
  [[ -n "$_sr_result_ref" ]]
}
