#!/usr/bin/env bash
# start.test.sh — Tests for start.sh
# Run with: bash tests/start.test.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

_PASS=0; _FAIL=0

assert_equals() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n    expected: %q\n    actual:   %q\n' "$desc" "$expected" "$actual"
    (( _FAIL++ )) || true
  fi
}
assert_output_contains() {
  local desc="$1" output="$2" pattern="$3"
  if [[ "$output" == *"$pattern"* ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s — pattern %q not in output\n' "$desc" "$pattern"
    (( _FAIL++ )) || true
  fi
}
assert_output_not_contains() {
  local desc="$1" output="$2" pattern="$3"
  if [[ "$output" != *"$pattern"* ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s — unexpected pattern %q found in output\n' "$desc" "$pattern"
    (( _FAIL++ )) || true
  fi
}
assert_file_exists() {
  local desc="$1" path="$2"
  if [[ -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — not found: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}
assert_file_not_exists() {
  local desc="$1" path="$2"
  if [[ ! -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — unexpected: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}

_HOME="" _PROJ="" _SLUG="" _SESSION_DIR=""

_setup() {
  _HOME=$(mktemp -d /tmp/sr-test-home-XXXXXX)
  _PROJ=$(mktemp -d /tmp/sr-test-proj-XXXXXX)
  git -C "$_PROJ" init -q 2>/dev/null || true
  _SLUG=$(echo "$_PROJ" | tr '/' '-')
  _SESSION_DIR="$_HOME/.claude/projects/$_SLUG/memory/sessions"
  mkdir -p "$_SESSION_DIR/.state" "$_HOME/.claude/projects/$_SLUG"
}

_teardown() { rm -rf "$_HOME" "$_PROJ" 2>/dev/null || true; }

_run_start() {
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" \
    bash "$PIPELINE_DIR/start.sh" 2>/dev/null
}

# ── st1: today.md present → injected under "--- Today ---" ──────────────────
echo "Section 1: today.md injected"
_setup
printf '## 2026-04-29\n\nToday work done.\n' > "$_SESSION_DIR/today.md"
out=$(_run_start)
assert_output_contains "st1: Today section header present" "$out" "--- Today"
assert_output_contains "st1: today.md content present" "$out" "Today work done"
_teardown

# ── st2: buffer.md present → injected under "--- Recent Activity ---" ────────
echo "Section 2: buffer.md injected"
_setup
printf '## Recent\n\nRecent activity log.\n' > "$_SESSION_DIR/buffer.md"
out=$(_run_start)
assert_output_contains "st2: Recent Activity header present" "$out" "--- Recent Activity"
assert_output_contains "st2: buffer content present" "$out" "Recent activity log"
_teardown

# ── st3: history.md present → NOT injected at startup ────────────────────────
echo "Section 3: history.md not injected at startup"
_setup
{
  for i in $(seq 1 60); do
    printf 'History line %d\n' "$i"
  done
} > "$_SESSION_DIR/history.md"
out=$(_run_start)
assert_output_not_contains "st3: history header absent" "$out" "--- History ---"
assert_output_not_contains "st3: history content absent" "$out" "History line"
_teardown

# ── st4: history.md only → no SESSION CONTINUITY block ───────────────────────
echo "Section 4: history.md only — no SESSION CONTINUITY block"
_setup
printf 'Short history line\n' > "$_SESSION_DIR/history.md"
out=$(_run_start)
assert_output_not_contains "st4: no SESSION CONTINUITY block" "$out" "SESSION CONTINUITY"
_teardown

# ── st5: missed session → save.sh launched in background ─────────────────────
echo "Section 5: Missed session recovery"
_STDIR=$(mktemp -d /tmp/sr-test-start-XXXXXX)
_HOME5=$(mktemp -d /tmp/sr-test-home-XXXXXX)
_PROJ5=$(mktemp -d /tmp/sr-test-proj-XXXXXX)
git -C "$_PROJ5" init -q 2>/dev/null || true
_SLUG5=$(echo "$_PROJ5" | tr '/' '-')
_STORE5="$_HOME5/.claude/projects/$_SLUG5"
_SESS5="$_STORE5/memory/sessions"
mkdir -p "$_SESS5/.state" "$_STORE5"

# Create 2 JSONL files — second one (older) is "missed"
printf '{"type":"user","isMeta":false,"message":{"content":"new"}}\n' > "$_STORE5/session-new.jsonl"
printf '{"type":"user","isMeta":false,"message":{"content":"missed"}}\n' > "$_STORE5/session-missed.jsonl"
# Touch missed to be older
touch -t 202001010000 "$_STORE5/session-missed.jsonl"

_SAVE_INVOKED="$_STDIR/save-invoked"
cp "$PIPELINE_DIR/start.sh" "$_STDIR/start.sh"
ln -sf "$PIPELINE_DIR/common.sh" "$_STDIR/common.sh"
cat > "$_STDIR/save.sh" << EOF
#!/usr/bin/env bash
printf '%s\\n' "\$@" > "$_SAVE_INVOKED"
EOF
chmod +x "$_STDIR/save.sh"
# consolidate.sh needed but won't be triggered (no stale today.md)
cp "$PIPELINE_DIR/consolidate.sh" "$_STDIR/consolidate.sh" 2>/dev/null || \
  printf '#!/bin/bash\nexit 0\n' > "$_STDIR/consolidate.sh"

HOME="$_HOME5" CLAUDE_PROJECT_DIR="$_PROJ5" bash "$_STDIR/start.sh" 2>/dev/null || true
sleep 0.5
assert_file_exists "st5: save.sh launched for missed session" "$_SAVE_INVOKED"
saved_args=$(cat "$_SAVE_INVOKED" 2>/dev/null || echo "")
assert_output_contains "st5: --force passed to save.sh" "$saved_args" "force"
rm -rf "$_STDIR" "$_HOME5" "$_PROJ5"

# ── st6: stale today.md → consolidate.sh launched in background ──────────────
echo "Section 6: Stale today.md triggers consolidation"
_STDIR=$(mktemp -d /tmp/sr-test-start-XXXXXX)
_HOME6=$(mktemp -d /tmp/sr-test-home-XXXXXX)
_PROJ6=$(mktemp -d /tmp/sr-test-proj-XXXXXX)
_SLUG6=$(echo "$_PROJ6" | tr '/' '-')
_SESS6="$_HOME6/.claude/projects/$_SLUG6/memory/sessions"
mkdir -p "$_SESS6/.state"
# Stale today.md
printf '## 2020-01-01\n\nOld work.\n' > "$_SESS6/today.md"

_CONS_INVOKED="$_STDIR/consolidate-invoked"
cp "$PIPELINE_DIR/start.sh" "$_STDIR/start.sh"
ln -sf "$PIPELINE_DIR/common.sh" "$_STDIR/common.sh"
printf '#!/bin/bash\nexit 0\n' > "$_STDIR/save.sh"; chmod +x "$_STDIR/save.sh"
cat > "$_STDIR/consolidate.sh" << EOF
#!/usr/bin/env bash
printf 'called\n' > "$_CONS_INVOKED"
EOF
chmod +x "$_STDIR/consolidate.sh"

HOME="$_HOME6" CLAUDE_PROJECT_DIR="$_PROJ6" bash "$_STDIR/start.sh" 2>/dev/null || true
sleep 0.5
assert_file_exists "st6: consolidate.sh launched for stale today.md" "$_CONS_INVOKED"
rm -rf "$_STDIR" "$_HOME6" "$_PROJ6"

# ── st7: READONLY mode → context injected, no background tasks ───────────────
echo "Section 7: READONLY mode — context injected, no background tasks"
_setup
# Stale today.md to trigger consolidation if not READONLY
printf '## 2020-01-01\n\nOld content.\n' > "$_SESSION_DIR/today.md"
# Missed session to trigger recovery if not READONLY
SESSION_STORE_7="$_HOME/.claude/projects/$_SLUG"
printf '{"type":"user","isMeta":false,"message":{"content":"msg"}}\n' > "$SESSION_STORE_7/sess-new.jsonl"
printf '{"type":"user","isMeta":false,"message":{"content":"old"}}\n' > "$SESSION_STORE_7/sess-old.jsonl"
touch -t 202001010000 "$SESSION_STORE_7/sess-old.jsonl"
mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/READONLY"
out=$(HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" bash "$PIPELINE_DIR/start.sh" 2>/dev/null)
sleep 0.3
assert_output_contains "st7: context still injected in READONLY mode" "$out" "SESSION CONTINUITY"
# No recovery logs should have been created
LOG_DIR="$_SESSION_DIR/logs"
log_count=$(ls "$LOG_DIR"/recovery-*.log 2>/dev/null | wc -l | tr -d ' ')
assert_equals "st7: no background recovery in READONLY mode" "0" "$log_count"
_teardown

# ── st8: WAL recovery — orphaned WAL files appended to buffer.md ─────────────
echo "Section 8: WAL recovery — orphaned WAL appended to buffer.md"
_setup
_STATE_DIR8="$_SESSION_DIR/.state"
_BUFFER8="$_SESSION_DIR/buffer.md"

# Seed a WAL file as if stop.sh Phase 1 wrote it but Phase 2 never ran
_WAL_FILE8="$_STATE_DIR8/wal-$(date +%s)-12345.md"
printf '## 2026-01-01T00:00:00 [STOP-WAL — raw capture before async haiku]\n\nWAL-TEST-CONTENT\n\n' \
  > "$_WAL_FILE8"

out=$(_run_start)
assert_output_contains "st8: SESSION CONTINUITY injected" "$out" "SESSION CONTINUITY"
assert_output_contains "st8: WAL content visible in context" "$out" "WAL-TEST-CONTENT"
assert_file_not_exists "st8: WAL file removed after recovery" "$_WAL_FILE8"
if [[ -f "$_BUFFER8" ]]; then
  if grep -q "WAL-TEST-CONTENT" "$_BUFFER8" 2>/dev/null; then
    printf '  PASS: st8: WAL content in buffer.md\n'; (( _PASS++ )) || true
  else
    printf '  FAIL: st8: WAL content missing from buffer.md\n'; (( _FAIL++ )) || true
  fi
else
  printf '  FAIL: st8: buffer.md not created\n'; (( _FAIL++ )) || true
fi
_teardown

# ── st9: WAL recovery skipped in READONLY mode ───────────────────────────────
echo "Section 9: WAL recovery skipped in READONLY mode"
_setup
_STATE_DIR9="$_SESSION_DIR/.state"

_WAL_FILE9="$_STATE_DIR9/wal-$(date +%s)-99999.md"
printf '## [STOP-WAL]\n\nREADONLY-WAL-CONTENT\n\n' > "$_WAL_FILE9"

mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/READONLY"
out=$(HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" bash "$PIPELINE_DIR/start.sh" 2>/dev/null)
assert_file_exists "st9: WAL NOT removed in READONLY mode" "$_WAL_FILE9"
assert_output_not_contains "st9: WAL content not in context in READONLY mode" "$out" "READONLY-WAL-CONTENT"
_teardown

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo "Results: ${_PASS} passed, ${_FAIL} failed"
(( _FAIL == 0 )) && exit 0 || exit 1
