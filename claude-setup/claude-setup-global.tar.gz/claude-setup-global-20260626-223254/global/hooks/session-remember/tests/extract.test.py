#!/usr/bin/env python3
"""Tests for extract.py — run with: python3 extract.test.py"""

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
PIPELINE_DIR = SCRIPT_DIR.parent
EXTRACT_PY = PIPELINE_DIR / "extract.py"

sys.path.insert(0, str(PIPELINE_DIR))
import extract

# ─── Helpers ──────────────────────────────────────────────────────────────────

def _user_line(text: str, is_meta: bool = False) -> str:
    return json.dumps({"type": "user", "isMeta": is_meta,
                       "message": {"content": text}})

def _assistant_line(text: str) -> str:
    return json.dumps({"type": "assistant",
                       "message": {"content": [{"type": "text", "text": text}]}})

def _tool_line(name: str, inp: dict) -> str:
    return json.dumps({"type": "assistant",
                       "message": {"content": [{"type": "tool_use", "name": name, "input": inp}]}})

def run_cli(args: list, input_file: Path | None = None) -> tuple[int, str, str]:
    """Run extract.py as subprocess; return (exit_code, stdout, stderr)."""
    cmd = [sys.executable, str(EXTRACT_PY)] + args
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode, result.stdout, result.stderr

def make_jsonl(tmp: Path, lines: list[str], name: str = "session.jsonl") -> Path:
    f = tmp / name
    f.write_text("\n".join(lines) + "\n")
    return f

# ─── Section 1: extract_texts ─────────────────────────────────────────────────

class TestExtractTexts(unittest.TestCase):

    def test_plain_string_returned(self):
        self.assertEqual(extract.extract_texts("hello world"), ["hello world"])

    def test_empty_string_skipped(self):
        self.assertEqual(extract.extract_texts("   "), [])

    def test_system_reminder_filtered(self):
        self.assertEqual(extract.extract_texts("<system-reminder>ignore me</system-reminder>"), [])

    def test_list_text_block_returned(self):
        content = [{"type": "text", "text": "answer"}]
        self.assertEqual(extract.extract_texts(content), ["answer"])

    def test_list_text_with_system_reminder_filtered(self):
        content = [{"type": "text", "text": "<system-reminder>skip</system-reminder>"}]
        self.assertEqual(extract.extract_texts(content), [])

    def test_tool_use_edit_formatted(self):
        block = {"type": "tool_use", "name": "Edit",
                 "input": {"file_path": "/path/to/your/project/bin/env-scan.sh"}}
        result = extract.extract_texts([block])
        self.assertEqual(result, ["[TOOL: Edit env-scan.sh]"])

    def test_tool_use_bash_truncated(self):
        long_cmd = "a" * 100
        block = {"type": "tool_use", "name": "Bash", "input": {"command": long_cmd}}
        result = extract.extract_texts([block])
        self.assertIn("[TOOL: Bash", result[0])
        self.assertLessEqual(len(result[0]), len("[TOOL: Bash `") + 80 + 2)

    def test_tool_use_unknown_name(self):
        block = {"type": "tool_use", "name": "WeirdTool", "input": {}}
        result = extract.extract_texts([block])
        self.assertEqual(result, ["[TOOL: WeirdTool]"])

# ─── Section 2: get_last_save_line ────────────────────────────────────────────

class TestGetLastSaveLine(unittest.TestCase):

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp)

    def test_missing_file_returns_zero(self):
        self.assertEqual(extract.get_last_save_line("abc", str(self.tmp)), 0)

    def test_matching_session_returns_line(self):
        data = {"session": "mysession", "line": 42, "timestamp": 1000}
        (self.tmp / "last-save.json").write_text(json.dumps(data))
        self.assertEqual(extract.get_last_save_line("mysession", str(self.tmp)), 42)

    def test_different_session_returns_zero(self):
        data = {"session": "other-session", "line": 99, "timestamp": 1000}
        (self.tmp / "last-save.json").write_text(json.dumps(data))
        self.assertEqual(extract.get_last_save_line("mysession", str(self.tmp)), 0)

    def test_corrupt_json_returns_zero(self):
        (self.tmp / "last-save.json").write_text("not json at all {{{")
        self.assertEqual(extract.get_last_save_line("mysession", str(self.tmp)), 0)

# ─── Section 3: extract_messages ──────────────────────────────────────────────

class TestExtractMessages(unittest.TestCase):

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp)

    def test_valid_jsonl_returns_messages_and_total(self):
        f = make_jsonl(self.tmp, [
            _user_line("hello"),
            _assistant_line("world"),
        ])
        messages, total, errors = extract.extract_messages(str(f))
        self.assertEqual(len(messages), 2)
        self.assertEqual(total, 2)
        self.assertEqual(errors, 0)
        self.assertEqual(messages[0], ("HUMAN", "hello"))
        self.assertEqual(messages[1], ("AGENT", "world"))

    def test_skip_lines_honoured(self):
        f = make_jsonl(self.tmp, [
            _user_line("skip me"),
            _user_line("keep me"),
        ])
        messages, total, errors = extract.extract_messages(str(f), skip_lines=1)
        self.assertEqual(len(messages), 1)
        self.assertEqual(messages[0][1], "keep me")
        self.assertEqual(total, 2)  # total counts ALL lines including skipped

    def test_is_meta_lines_skipped(self):
        f = make_jsonl(self.tmp, [
            _user_line("meta", is_meta=True),
            _user_line("real"),
        ])
        messages, total, errors = extract.extract_messages(str(f))
        self.assertEqual(len(messages), 1)
        self.assertEqual(messages[0][1], "real")

    def test_unknown_type_skipped(self):
        unknown = json.dumps({"type": "summary", "message": {"content": "ignored"}})
        f = make_jsonl(self.tmp, [unknown, _user_line("visible")])
        messages, total, errors = extract.extract_messages(str(f))
        self.assertEqual(len(messages), 1)

    def test_corrupted_line_counted_as_error(self):
        # TDD: this MUST return error_count > 0 when a line is malformed JSON.
        # Verifies the silent-skip bug is fixed.
        f = make_jsonl(self.tmp, [
            _user_line("good line"),
            "THIS IS NOT JSON }{{{",
            _assistant_line("another good line"),
        ])
        messages, total, errors = extract.extract_messages(str(f))
        self.assertEqual(errors, 1, "corrupted line must be counted, not silently ignored")
        self.assertEqual(len(messages), 2)   # valid lines still extracted
        self.assertEqual(total, 3)

    def test_multiple_corrupted_lines_all_counted(self):
        f = make_jsonl(self.tmp, [
            "BAD1",
            "BAD2",
            _user_line("good"),
        ])
        messages, total, errors = extract.extract_messages(str(f))
        self.assertEqual(errors, 2)
        self.assertEqual(len(messages), 1)

# ─── Section 4: CLI integration (subprocess) ──────────────────────────────────

class TestCLI(unittest.TestCase):

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        # Build a fake project layout: ~/.claude/projects/<slug>/<session>.jsonl
        self.project_dir = str(self.tmp / "myproject")
        slug = self.project_dir.replace("/", "-")
        self.session_dir = self.tmp / ".claude" / "projects" / slug
        self.session_dir.mkdir(parents=True)
        self.state_dir = self.tmp / "state"
        self.state_dir.mkdir()
        os.environ["HOME"] = str(self.tmp)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmp)
        os.environ.pop("HOME", None)

    def _write_session(self, lines: list[str], name: str = "abc123.jsonl") -> str:
        f = self.session_dir / name
        f.write_text("\n".join(lines) + "\n")
        return "abc123"

    def test_valid_session_exit_zero(self):
        self._write_session([_user_line("hi"), _assistant_line("hello")])
        code, out, err = run_cli(["--project-dir", self.project_dir,
                                  "--state-dir", "/dev/null"])
        self.assertEqual(code, 0)
        self.assertIn("__POSITION__:", err)
        self.assertIn("__HUMAN__:1", err)
        self.assertIn("__EXCHANGES__:2", err)

    def test_missing_project_exit_one(self):
        code, out, err = run_cli(["--project-dir", "/nonexistent/project",
                                  "--state-dir", "/dev/null"])
        self.assertEqual(code, 1)

    def test_path_traversal_session_id_rejected(self):
        self._write_session([_user_line("hi")])
        code, out, err = run_cli(["--project-dir", self.project_dir,
                                  "--session", "../../../etc/passwd",
                                  "--state-dir", "/dev/null"])
        self.assertEqual(code, 1)

    def test_since_last_save_respects_position(self):
        sid = self._write_session([
            _user_line("old msg"),
            _user_line("new msg"),
        ])
        last_save = {"session": sid, "line": 1, "timestamp": 1}
        (self.state_dir / "last-save.json").write_text(json.dumps(last_save))
        code, out, err = run_cli(["--project-dir", self.project_dir,
                                  "--session", sid,
                                  "--state-dir", str(self.state_dir),
                                  "--since-last-save"])
        self.assertEqual(code, 0)
        self.assertIn("new msg", out)
        self.assertNotIn("old msg", out)
        self.assertIn("__HUMAN__:1", err)

    def test_corrupted_jsonl_exit_two(self):
        # TDD: extract.py MUST exit 2 (not 0) when corrupted lines are found.
        self._write_session([
            _user_line("good"),
            "CORRUPT LINE NOT JSON",
        ])
        code, out, err = run_cli(["--project-dir", self.project_dir,
                                  "--state-dir", "/dev/null"])
        self.assertEqual(code, 2, "corrupted JSONL must exit 2, not 0")
        self.assertIn("__ERRORS__:", err)

    def test_stderr_markers_present(self):
        self._write_session([_user_line("msg1"), _assistant_line("msg2")])
        code, out, err = run_cli(["--project-dir", self.project_dir,
                                  "--state-dir", "/dev/null"])
        self.assertIn("__POSITION__:", err)
        self.assertIn("__HUMAN__:", err)
        self.assertIn("__EXCHANGES__:", err)


if __name__ == "__main__":
    unittest.main(verbosity=2)
