#!/usr/bin/env bash
# save.test.sh — Tests for save.sh
#
# Run with: bash save.test.sh
#
# Tests behaviors:
#   1. Per-session cooldown gate — skips without advancing position
#   2. Zero-exchange skip — position NOT advanced (verifies fix at save.sh:90-93)
#   3. Insufficient human messages — skips without advancing
#   4. Extraction failure (exit 1) — session file missing → save exits 1
#   4b. Partial corruption (exit 2) — corrupt lines skipped, save continues → exits 0
#   5. Live lock gate — held flock → skip after timeout
#   6. Successful save — buffer.md written, last-save.json advanced
#   7. Anti-stampede gate — global last-save-ts < 5s → skip
#   8. Per-session cooldown independence — session A saves while session B throttled
#   9. Haiku failure → raw dump fallback
#   10a-d. --mark-only: WAL written, no position advance; d) bypasses held flock

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# ─── Counters ──────────────────────────────────────────────────────────────────
_PASS=0; _FAIL=0

assert_equals() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n' "$desc"
    printf '    expected: %q\n' "$expected"
    printf '    actual:   %q\n' "$actual"
    (( _FAIL++ )) || true
  fi
}

assert_file_exists() {
  local desc="$1" path="$2"
  if [[ -f "$path" ]]; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s — file not found: %s\n' "$desc" "$path"
    (( _FAIL++ )) || true
  fi
}

assert_file_not_exists() {
  local desc="$1" path="$2"
  if [[ ! -f "$path" ]]; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s — unexpected file: %s\n' "$desc" "$path"
    (( _FAIL++ )) || true
  fi
}

assert_file_contains() {
  local desc="$1" path="$2" pattern="$3"
  if [[ -f "$path" ]] && grep -q "$pattern" "$path" 2>/dev/null; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s — pattern %q not found in %s\n' "$desc" "$pattern" "$path"
    (( _FAIL++ )) || true
  fi
}

assert_file_not_contains() {
  local desc="$1" path="$2" pattern="$3"
  if [[ -f "$path" ]] && grep -q "$pattern" "$path" 2>/dev/null; then
    printf '  FAIL: %s — unexpected pattern %q found in %s\n' "$desc" "$pattern" "$path"
    (( _FAIL++ )) || true
  else
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  fi
}

# ─── Per-test isolation ─────────────────────────────────────────────────────────
_HOME="" _PROJ="" _FAKE_BIN="" _SLUG="" _SESSION_STORE="" _STATE_DIR=""

_setup() {
  _HOME=$(mktemp -d /tmp/sr-test-home-XXXXXX)
  _PROJ=$(mktemp -d /tmp/sr-test-proj-XXXXXX)
  git -C "$_PROJ" init -q 2>/dev/null || true

  _SLUG=$(echo "$_PROJ" | tr '/' '-')
  _SESSION_STORE="$_HOME/.claude/projects/$_SLUG"
  _STATE_DIR="$_SESSION_STORE/memory/sessions/.state"
  mkdir -p "$_STATE_DIR"

  # Pre-seed last-ndc-ts so NDC never triggers during tests
  date +%s > "$_STATE_DIR/last-ndc-ts"

  # sr_call_haiku does "cd $HOME/.claude/llm-sandbox" — create it in the test HOME
  mkdir -p "$_HOME/.claude/llm-sandbox"

  # Fake claude binary — returns a valid JSON response for sr_call_haiku.
  # printf '%s\n' keeps \n as the JSON escape sequence in the argument;
  # using printf '...\n...' would make printf expand \n to actual newlines,
  # producing invalid JSON (literal newlines inside a JSON string).
  _FAKE_BIN=$(mktemp -d /tmp/sr-test-bin-XXXXXX)
  cat > "$_FAKE_BIN/claude" <<'CLAUDEEOF'
#!/usr/bin/env bash
printf '%s\n' '{"result": "## Fake Entry\n\nFake summary."}'
CLAUDEEOF
  chmod +x "$_FAKE_BIN/claude"
}

_teardown() {
  rm -rf "$_HOME" "$_PROJ" "$_FAKE_BIN" 2>/dev/null || true
}

# Write N human+assistant exchange pairs to a session JSONL
_write_session() {
  local session="$1" n_human="${2:-3}"
  local i
  {
    for i in $(seq 1 "$n_human"); do
      printf '{"type":"user","isMeta":false,"message":{"content":"msg %d"}}\n' "$i"
      printf '{"type":"assistant","message":{"content":[{"type":"text","text":"resp %d"}]}}\n' "$i"
    done
  } > "$_SESSION_STORE/$session.jsonl"
}

# Write only isMeta=true lines — produces 0 real exchanges
_write_meta_only_session() {
  local session="$1"
  printf '%s\n' \
    '{"type":"user","isMeta":true,"message":{"content":"tool result 1"}}' \
    '{"type":"user","isMeta":true,"message":{"content":"tool result 2"}}' \
    > "$_SESSION_STORE/$session.jsonl"
}

# Write 3 valid exchanges + 1 corrupt line — extract.py exits 2 (partial)
_write_partial_corrupt_session() {
  local session="$1"
  local i
  {
    for i in 1 2 3; do
      printf '{"type":"user","isMeta":false,"message":{"content":"msg %d"}}\n' "$i"
      printf '{"type":"assistant","message":{"content":[{"type":"text","text":"resp %d"}]}}\n' "$i"
    done
    printf 'CORRUPT LINE }{{{\n'
  } > "$_SESSION_STORE/$session.jsonl"
}

# Run save.sh with isolated environment and fake claude
_run_save() {
  HOME="$_HOME" \
  CLAUDE_PROJECT_DIR="$_PROJ" \
  PATH="$_FAKE_BIN:$PATH" \
  SR_SAVE_COOLDOWN=0 \
  SR_NDC_COOLDOWN=999999 \
  SR_MIN_HUMAN=3 \
  bash "$PIPELINE_DIR/save.sh" "$@" 2>/dev/null
}

# ─── Section 1: Per-session cooldown gate ─────────────────────────────────────
echo "Section 1: Per-session cooldown gate"
_setup
_write_session "sid-cool" 3
# Seed global ts as 10s old (past 5s anti-stampede window) so per-session cooldown fires
printf '%s\n' "$(( $(date +%s) - 10 ))" > "$_STATE_DIR/last-save-ts"
# Seed per-session ts as current (within SR_SAVE_COOLDOWN=9999)
date +%s > "$_STATE_DIR/last-save-ts.sid-cool"

rc=0
HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" PATH="$_FAKE_BIN:$PATH" \
  SR_SAVE_COOLDOWN=9999 SR_NDC_COOLDOWN=999999 SR_MIN_HUMAN=3 \
  bash "$PIPELINE_DIR/save.sh" "sid-cool" 2>/dev/null || rc=$?

assert_equals "per-session cooldown: exits 0" "0" "$rc"
assert_file_not_exists "per-session cooldown: last-save.json not created" \
  "$_STATE_DIR/last-save.json"
_teardown

# ─── Section 2: Zero-exchange skip (position not advanced) ────────────────────
echo "Section 2: Zero-exchange skip"
_setup
_write_meta_only_session "sid-meta"

rc=0; _run_save "sid-meta" || rc=$?

assert_equals "zero-exchange: exits 0" "0" "$rc"
assert_file_not_exists "zero-exchange: last-save.json NOT created (position not advanced)" \
  "$_STATE_DIR/last-save.json"
_teardown

# ─── Section 3: Insufficient human messages ───────────────────────────────────
echo "Section 3: Insufficient human messages"
_setup
_write_session "sid-few" 1   # 1 human message; SR_MIN_HUMAN=3

rc=0; _run_save "sid-few" || rc=$?

assert_equals "min-human: exits 0" "0" "$rc"
assert_file_not_exists "min-human: last-save.json not created" \
  "$_STATE_DIR/last-save.json"
_teardown

# ─── Section 4: Extraction failure (exit 1 — file not found) ─────────────────
echo "Section 4: Extraction failure (exit 1 — missing session file)"
_setup
# No JSONL written for "sid-missing" — extract.py raises FileNotFoundError → exit 1

rc=0; _run_save "sid-missing" || rc=$?

assert_equals "extract-fail: exits 1" "1" "$rc"
assert_file_not_exists "extract-fail: last-save.json not created" \
  "$_STATE_DIR/last-save.json"
_teardown

# ─── Section 4b: Partial corruption (exit 2) — save continues ─────────────────
echo "Section 4b: Partial corruption (exit 2 — save continues)"
_setup
_write_partial_corrupt_session "sid-partial"

rc=0; _run_save "sid-partial" || rc=$?

assert_equals "partial-corrupt: exits 0" "0" "$rc"
_teardown

# ─── Section 5: Live lock gate — held flock → skip after 1s timeout ──────────
echo "Section 5: Live lock gate"
_setup
_write_session "sid-lock" 3
# Hold a real kernel flock in background; release it after 3s
_LOCK_FILE="$_STATE_DIR/save.lock"
touch "$_LOCK_FILE"
(
  exec 9>"$_LOCK_FILE"
  flock --exclusive 9
  sleep 3
) &
_LOCK_PID=$!
sleep 0.1  # let background process acquire the lock

rc=0
HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" PATH="$_FAKE_BIN:$PATH" \
  SR_SAVE_COOLDOWN=0 SR_NDC_COOLDOWN=999999 SR_MIN_HUMAN=3 \
  _SR_LOCK_TIMEOUT=1 \
  bash "$PIPELINE_DIR/save.sh" "sid-lock" 2>/dev/null || rc=$?

assert_equals "live-lock: exits 0 (skip after timeout)" "0" "$rc"
assert_file_not_exists "live-lock: last-save.json not created" \
  "$_STATE_DIR/last-save.json"
wait "$_LOCK_PID" 2>/dev/null || true
_teardown

# ─── Section 6: Successful save ───────────────────────────────────────────────
echo "Section 6: Successful save"
_setup
_write_session "sid-ok" 3

rc=0; _run_save "sid-ok" || rc=$?

assert_equals "success: exits 0" "0" "$rc"
assert_file_exists "success: buffer.md created" \
  "$_SESSION_STORE/memory/sessions/buffer.md"
assert_file_contains "success: buffer.md contains Haiku summary" \
  "$_SESSION_STORE/memory/sessions/buffer.md" "Fake"
assert_file_exists "success: last-save.json created" \
  "$_STATE_DIR/last-save.json"
assert_file_contains "success: last-save.json records session id" \
  "$_STATE_DIR/last-save.json" "sid-ok"
_teardown

# ─── Section 7: Anti-stampede gate ────────────────────────────────────────────
echo "Section 7: Anti-stampede gate (global last-save-ts < 5s)"
_setup
_write_session "sid-stamp" 3
# Seed global last-save-ts as current — within the 5s anti-stampede window
date +%s > "$_STATE_DIR/last-save-ts"

rc=0
HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" PATH="$_FAKE_BIN:$PATH" \
  SR_SAVE_COOLDOWN=0 SR_NDC_COOLDOWN=999999 SR_MIN_HUMAN=3 \
  bash "$PIPELINE_DIR/save.sh" "sid-stamp" 2>/dev/null || rc=$?

assert_equals "anti-stampede: exits 0 (skipped)" "0" "$rc"
assert_file_not_exists "anti-stampede: last-save.json not created" \
  "$_STATE_DIR/last-save.json"
_teardown

# ─── Section 8: Per-session cooldown independence ─────────────────────────────
echo "Section 8: Per-session cooldown independence (A cold, B hot)"
_setup
_write_session "sid-A" 3
_write_session "sid-B" 3
# Global ts: 10s old — past anti-stampede window so neither session is blocked by it
printf '%s\n' "$(( $(date +%s) - 10 ))" > "$_STATE_DIR/last-save-ts"
# Session B: recently saved (per-session cooldown will fire)
date +%s > "$_STATE_DIR/last-save-ts.sid-B"
# Session A: no per-session ts file — cold, should save normally

rc=0
HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" PATH="$_FAKE_BIN:$PATH" \
  SR_SAVE_COOLDOWN=9999 SR_NDC_COOLDOWN=999999 SR_MIN_HUMAN=3 \
  bash "$PIPELINE_DIR/save.sh" "sid-A" 2>/dev/null || rc=$?

assert_equals "independence: session A saves (exits 0)" "0" "$rc"
assert_file_exists "independence: session A creates last-save.json" \
  "$_STATE_DIR/last-save.json"
assert_file_contains "independence: last-save.json has sid-A" \
  "$_STATE_DIR/last-save.json" "sid-A"

# Reset global ts to 10s old so anti-stampede doesn't block session B check
printf '%s\n' "$(( $(date +%s) - 10 ))" > "$_STATE_DIR/last-save-ts"

rc=0
HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" PATH="$_FAKE_BIN:$PATH" \
  SR_SAVE_COOLDOWN=9999 SR_NDC_COOLDOWN=999999 SR_MIN_HUMAN=3 \
  bash "$PIPELINE_DIR/save.sh" "sid-B" 2>/dev/null || rc=$?

assert_equals "independence: session B throttled (exits 0)" "0" "$rc"
assert_file_not_contains "independence: last-save.json still shows sid-A (B not saved)" \
  "$_STATE_DIR/last-save.json" "sid-B"
_teardown

# ─── Section 9: Haiku failure → raw dump fallback ─────────────────────────────
# When the claude binary fails (exit 1), save.sh must:
#   - Exit 1 (not 0 — caller knows it wasn't a clean save)
#   - Still write raw content to buffer.md (UNSUMMARIZED marker)
#   - Still advance last-save.json (position not retried indefinitely)
echo "Section 9: Haiku failure — claude exits 1 → raw dump fallback"
_setup

_FAIL_BIN=$(mktemp -d /tmp/sr-test-fail-bin-XXXXXX)
cat > "$_FAIL_BIN/claude" <<'FAILEOF'
#!/usr/bin/env bash
exit 1
FAILEOF
chmod +x "$_FAIL_BIN/claude"

_write_session "sid-fail-claude" 3

rc=0
HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" \
  PATH="$_FAIL_BIN:$PATH" \
  SR_SAVE_COOLDOWN=0 SR_NDC_COOLDOWN=999999 SR_MIN_HUMAN=3 \
  bash "$PIPELINE_DIR/save.sh" "sid-fail-claude" 2>/dev/null || rc=$?

assert_equals "haiku-fail: exits 1" "1" "$rc"
assert_file_exists "haiku-fail: buffer.md written (raw fallback)" \
  "$_SESSION_STORE/memory/sessions/buffer.md"
assert_file_contains "haiku-fail: buffer.md has UNSUMMARIZED marker" \
  "$_SESSION_STORE/memory/sessions/buffer.md" "UNSUMMARIZED"
assert_file_exists "haiku-fail: last-save.json created (position advanced)" \
  "$_STATE_DIR/last-save.json"

rm -rf "$_FAIL_BIN"
_teardown

# ─── Section 10: --mark-only flag ────────────────────────────────────────────
# Phase 1 of stop.sh two-phase flush: write WAL, exit without Haiku or position advance.
echo "Section 10: --mark-only flag"

# 10a: WAL is written, position not advanced, buffer untouched
_setup
_write_session "sid-wal" 3

rc=0; _run_save "sid-wal" --force --mark-only || rc=$?

assert_equals "mark-only: exits 0" "0" "$rc"

_WAL_COUNT=$(ls "$_STATE_DIR"/wal-*.md 2>/dev/null | wc -l)
assert_equals "mark-only: WAL file created" "1" "$_WAL_COUNT"

_WAL_PATH=$(ls "$_STATE_DIR"/wal-*.md 2>/dev/null | head -1)
if [[ -n "$_WAL_PATH" ]]; then
  assert_file_contains "mark-only: WAL has STOP-WAL marker" \
    "$_WAL_PATH" "STOP-WAL"
  assert_file_contains "mark-only: WAL contains exchange content" \
    "$_WAL_PATH" "msg 1"
fi

assert_file_not_exists "mark-only: last-save.json NOT created (position not advanced)" \
  "$_STATE_DIR/last-save.json"
assert_file_not_exists "mark-only: buffer.md NOT created" \
  "$_SESSION_STORE/memory/sessions/buffer.md"

# 10b: full save.sh after --mark-only cleans WAL and processes normally
rc=0; _run_save "sid-wal" --force || rc=$?

assert_equals "mark-only + full-save: full save exits 0" "0" "$rc"

_WAL_COUNT=$(ls "$_STATE_DIR"/wal-*.md 2>/dev/null | wc -l)
assert_equals "mark-only + full-save: WAL cleaned by full save" "0" "$_WAL_COUNT"

assert_file_exists "mark-only + full-save: last-save.json created" \
  "$_STATE_DIR/last-save.json"
assert_file_contains "mark-only + full-save: buffer.md written" \
  "$_SESSION_STORE/memory/sessions/buffer.md" "Fake"
_teardown

# 10c: --mark-only with no new exchanges (empty extract) — no WAL written
_setup
_write_meta_only_session "sid-wal-empty"

rc=0; _run_save "sid-wal-empty" --force --mark-only || rc=$?

assert_equals "mark-only empty: exits 0" "0" "$rc"
_WAL_COUNT=$(ls "$_STATE_DIR"/wal-*.md 2>/dev/null | wc -l)
assert_equals "mark-only empty: no WAL written (nothing to capture)" "0" "$_WAL_COUNT"
_teardown

# 10d: --mark-only bypasses flock — WAL written even when lock is held
_setup
_write_session "sid-wal-flock" 3
_LOCK_FILE_MO="$_STATE_DIR/save.lock"
touch "$_LOCK_FILE_MO"
(
  exec 9>"$_LOCK_FILE_MO"
  flock --exclusive 9
  sleep 5
) &
_LOCK_PID_MO=$!
sleep 0.1  # let background process acquire the lock

rc=0; _run_save "sid-wal-flock" --force --mark-only || rc=$?

assert_equals "mark-only flock: exits 0 despite held lock" "0" "$rc"
_WAL_COUNT=$(ls "$_STATE_DIR"/wal-*.md 2>/dev/null | wc -l)
assert_equals "mark-only flock: WAL written despite held lock" "1" "$_WAL_COUNT"
_WAL_PATH=$(ls "$_STATE_DIR"/wal-*.md 2>/dev/null | head -1)
if [[ -n "$_WAL_PATH" ]]; then
  assert_file_contains "mark-only flock: WAL has STOP-WAL marker" "$_WAL_PATH" "STOP-WAL"
fi
kill "$_LOCK_PID_MO" 2>/dev/null || true
wait "$_LOCK_PID_MO" 2>/dev/null || true
_teardown

# ─── Final summary ────────────────────────────────────────────────────────────
echo ""
echo "Results: ${_PASS} passed, ${_FAIL} failed"
(( _FAIL == 0 )) && exit 0 || exit 1
