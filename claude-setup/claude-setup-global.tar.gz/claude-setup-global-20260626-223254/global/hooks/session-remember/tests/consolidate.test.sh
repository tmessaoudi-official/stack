#!/usr/bin/env bash
# consolidate.test.sh — Tests for consolidate.sh
# Run with: bash tests/consolidate.test.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

_PASS=0; _FAIL=0

assert_equals() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n    expected: %q\n    actual:   %q\n' "$desc" "$expected" "$actual"
    (( _FAIL++ )) || true
  fi
}
assert_file_exists() {
  local desc="$1" path="$2"
  if [[ -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — not found: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}
assert_file_not_exists() {
  local desc="$1" path="$2"
  if [[ ! -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — unexpected: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}
assert_file_contains() {
  local desc="$1" path="$2" pattern="$3"
  if [[ -f "$path" ]] && grep -q "$pattern" "$path" 2>/dev/null; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s — pattern %q not in %s\n' "$desc" "$pattern" "$path"
    (( _FAIL++ )) || true
  fi
}
assert_file_empty() {
  local desc="$1" path="$2"
  if [[ -f "$path" && ! -s "$path" ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s — non-empty or missing: %s\n' "$desc" "$path"
    (( _FAIL++ )) || true
  fi
}

_HOME="" _PROJ="" _SLUG="" _SESSION_DIR="" _STATE_DIR="" _FAKE_BIN=""
_SR_TODAY="" _SR_BUFFER="" _SR_HISTORY="" _SR_ARCHIVE=""

_setup() {
  _HOME=$(mktemp -d /tmp/sr-test-home-XXXXXX)
  _PROJ=$(mktemp -d /tmp/sr-test-proj-XXXXXX)
  _SLUG=$(echo "$_PROJ" | tr '/' '-')
  _SESSION_DIR="$_HOME/.claude/projects/$_SLUG/memory/sessions"
  _STATE_DIR="$_SESSION_DIR/.state"
  mkdir -p "$_SESSION_DIR" "$_STATE_DIR"
  # sr_call_haiku does "cd $HOME/.claude/llm-sandbox" — create it in the test HOME
  mkdir -p "$_HOME/.claude/llm-sandbox"
  _SR_TODAY="$_SESSION_DIR/today.md"
  _SR_BUFFER="$_SESSION_DIR/buffer.md"
  _SR_HISTORY="$_SESSION_DIR/history.md"
  _SR_ARCHIVE="$_SESSION_DIR/archive.md"
  _FAKE_BIN=$(mktemp -d /tmp/sr-test-bin-XXXXXX)
}

_teardown() { rm -rf "$_HOME" "$_PROJ" "$_FAKE_BIN" 2>/dev/null || true; }

_make_claude_succeed() {
  cat > "$_FAKE_BIN/claude" << 'CLAUDEEOF'
#!/usr/bin/env bash
printf '%s\n' '{"result": "## Summary\n\nTest content."}'
CLAUDEEOF
  chmod +x "$_FAKE_BIN/claude"
}

_make_claude_fail() {
  printf '#!/usr/bin/env bash\nexit 1\n' > "$_FAKE_BIN/claude"
  chmod +x "$_FAKE_BIN/claude"
}

_run() {
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" SR_TZ=UTC \
    PATH="$_FAKE_BIN:$PATH" \
    bash "$PIPELINE_DIR/consolidate.sh" 2>/dev/null
}

# ── c1: DISABLED sentinel ────────────────────────────────────────────────────
echo "Section 1: DISABLED sentinel"
_setup
_make_claude_succeed
printf 'stale content\n' > "$_SR_BUFFER"
mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/DISABLED"
rc=0; _run || rc=$?
assert_equals "c1: DISABLED → exits 0" "0" "$rc"
assert_file_contains "c1: buffer untouched when DISABLED" "$_SR_BUFFER" "stale content"
_teardown

# ── c2: READONLY sentinel ────────────────────────────────────────────────────
echo "Section 2: READONLY sentinel"
_setup
_make_claude_succeed
printf 'stale content\n' > "$_SR_BUFFER"
mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/READONLY"
rc=0; _run || rc=$?
assert_equals "c2: READONLY → exits 0" "0" "$rc"
assert_file_contains "c2: buffer preserved when READONLY" "$_SR_BUFFER" "stale content"
_teardown

# ── c3: Empty state ──────────────────────────────────────────────────────────
echo "Section 3: Empty state (no buffer, no today.md)"
_setup
_make_claude_fail
rc=0; _run || rc=$?
assert_equals "c3: empty state → exits 0" "0" "$rc"
assert_file_not_exists "c3: no today.md created" "$_SR_TODAY"
assert_file_not_exists "c3: no history.md created" "$_SR_HISTORY"
_teardown

# ── c4: Buffer flush — success ───────────────────────────────────────────────
echo "Section 4: Buffer flush (Haiku succeeds)"
_setup
printf '## 2020-01-01\n\nOld buffer content.\n' > "$_SR_BUFFER"
_make_claude_succeed
rc=0; _run || rc=$?
assert_equals "c4: buffer flush → exits 0" "0" "$rc"
assert_file_empty "c4: buffer cleared after flush" "$_SR_BUFFER"
assert_file_exists "c4: today.md written" "$_SR_TODAY"
_teardown

# ── c5: Buffer flush — Haiku fails ──────────────────────────────────────────
echo "Section 5: Buffer flush (Haiku fails)"
_setup
printf '## 2020-01-01\n\nBuffer content.\n' > "$_SR_BUFFER"
_make_claude_fail
rc=0; _run || rc=$?
assert_equals "c5: Haiku failure → exits 0" "0" "$rc"
assert_file_contains "c5: buffer preserved on Haiku failure" "$_SR_BUFFER" "Buffer content"
_teardown

# ── c6: Today.md stale → rolled into history.md ─────────────────────────────
echo "Section 6: Today.md rollup (stale date)"
_setup
printf '## 2020-01-01\n\nYesterday work.\n' > "$_SR_TODAY"
_make_claude_succeed
rc=0; _run || rc=$?
assert_equals "c6: stale rollup → exits 0" "0" "$rc"
assert_file_empty "c6: today.md cleared after rollup" "$_SR_TODAY"
assert_file_exists "c6: history.md written" "$_SR_HISTORY"
_teardown

# ── c7: Today.md current → no rollup ────────────────────────────────────────
echo "Section 7: Today.md current (no rollup needed)"
_setup
TODAY=$(TZ=UTC date '+%Y-%m-%d')
printf '## %s\n\nToday work.\n' "$TODAY" > "$_SR_TODAY"
_make_claude_fail
rc=0; _run || rc=$?
assert_equals "c7: current today.md → exits 0" "0" "$rc"
assert_file_contains "c7: today.md untouched" "$_SR_TODAY" "Today work"
assert_file_not_exists "c7: history.md NOT written" "$_SR_HISTORY"
_teardown

# ── c8: History rotation ─────────────────────────────────────────────────────
echo "Section 8: History rotation (entry count > max)"
_setup
{
  for i in 1 2 3; do
    printf '## 2026-01-0%d\n\nEntry %d.\n\n' "$i" "$i"
  done
} > "$_SR_HISTORY"
# Fake claude returns the structured output consolidate.sh expects
cat > "$_FAKE_BIN/claude" << 'CLAUDEEOF'
#!/usr/bin/env bash
printf '%s\n' '{"result": "=== HISTORY ===\n## 2026-01-03\n\nEntry 3.\n\n=== ARCHIVE ===\n## Week of 2025-12-29\n\nOld summary."}'
CLAUDEEOF
chmod +x "$_FAKE_BIN/claude"
rc=0
HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" SR_TZ=UTC SR_HISTORY_MAX_ENTRIES=2 \
  PATH="$_FAKE_BIN:$PATH" bash "$PIPELINE_DIR/consolidate.sh" 2>/dev/null || rc=$?
assert_equals "c8: rotation → exits 0" "0" "$rc"
assert_file_contains "c8: history.md updated with newest entry" "$_SR_HISTORY" "Entry 3"
assert_file_exists "c8: archive.md written" "$_SR_ARCHIVE"
_teardown

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo "Results: ${_PASS} passed, ${_FAIL} failed"
(( _FAIL == 0 )) && exit 0 || exit 1
