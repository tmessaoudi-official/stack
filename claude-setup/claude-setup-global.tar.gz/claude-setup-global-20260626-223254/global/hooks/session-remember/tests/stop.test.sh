#!/usr/bin/env bash
# stop.test.sh — Tests for stop.sh
# Run with: bash tests/stop.test.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

_PASS=0; _FAIL=0

assert_equals() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n    expected: %q\n    actual:   %q\n' "$desc" "$expected" "$actual"
    (( _FAIL++ )) || true
  fi
}
assert_file_exists() {
  local desc="$1" path="$2"
  if [[ -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — not found: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}
assert_file_not_exists() {
  local desc="$1" path="$2"
  if [[ ! -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — unexpected: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}

_HOME="" _STOP_DIR="" _INVOKED=""

_setup() {
  _HOME=$(mktemp -d /tmp/sr-test-home-XXXXXX)
  _STOP_DIR=$(mktemp -d /tmp/sr-test-stop-XXXXXX)
  _INVOKED="$_STOP_DIR/save-invoked"

  # Copy stop.sh into isolation dir — SCRIPT_DIR derives as _STOP_DIR
  cp "$PIPELINE_DIR/stop.sh" "$_STOP_DIR/stop.sh"
  # F-15 fix: stop.sh now sources common.sh — symlink it so the source succeeds.
  # log-helpers.sh is sourced inside common.sh with || true, so its absence is safe.
  ln -sf "$PIPELINE_DIR/common.sh" "$_STOP_DIR/common.sh"

  # Default fake save.sh: records invocation with its args
  cat > "$_STOP_DIR/save.sh" << EOF
#!/usr/bin/env bash
printf '%s\n' "\$@" > "$_INVOKED"
exit 0
EOF
  chmod +x "$_STOP_DIR/save.sh"
}

_teardown() { rm -rf "$_HOME" "$_STOP_DIR" 2>/dev/null || true; }

_run() {
  echo '' | HOME="$_HOME" CLAUDE_PROJECT_DIR="$_HOME" bash "$_STOP_DIR/stop.sh" 2>/dev/null
  sleep 0.3  # allow async Phase 2 (nohup save.sh) to complete
}

# ── s1: DISABLED sentinel ────────────────────────────────────────────────────
echo "Section 1: DISABLED sentinel"
_setup
mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/DISABLED"
rc=0; _run || rc=$?
assert_equals "s1: DISABLED → exits 0" "0" "$rc"
assert_file_not_exists "s1: save.sh NOT invoked when DISABLED" "$_INVOKED"
_teardown

# ── s2: READONLY sentinel ────────────────────────────────────────────────────
echo "Section 2: READONLY sentinel"
_setup
mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/READONLY"
rc=0; _run || rc=$?
assert_equals "s2: READONLY → exits 0" "0" "$rc"
assert_file_not_exists "s2: save.sh NOT invoked when READONLY" "$_INVOKED"
_teardown

# ── s3: Normal operation — save.sh --force invoked ──────────────────────────
echo "Section 3: Normal operation"
_setup
rc=0; _run || rc=$?
assert_equals "s3: no sentinels → exits 0" "0" "$rc"
assert_file_exists "s3: save.sh was invoked" "$_INVOKED"
invoked_args=$(cat "$_INVOKED" 2>/dev/null || echo "")
if [[ "$invoked_args" == *"--force"* ]]; then
  printf '  PASS: s3: save.sh called with --force\n'; (( _PASS++ )) || true
else
  printf '  FAIL: s3: --force not found in save.sh args\n    args: %q\n' "$invoked_args"
  (( _FAIL++ )) || true
fi
_teardown

# ── s4: save.sh fails — stop.sh still exits 0 ───────────────────────────────
echo "Section 4: save.sh failure is suppressed"
_setup
printf '#!/usr/bin/env bash\nexit 1\n' > "$_STOP_DIR/save.sh"
chmod +x "$_STOP_DIR/save.sh"
rc=0; _run || rc=$?
assert_equals "s4: save.sh exit 1 → stop.sh still exits 0" "0" "$rc"
_teardown

# ── s5: session_id in stdin JSON → passed to save.sh ────────────────────────
echo "Section 5: session_id from StopHook payload passed to save.sh"
_setup
# Append-mode save.sh: collects args from both Phase 1 and Phase 2 invocations
cat > "$_STOP_DIR/save.sh" << EOF
#!/usr/bin/env bash
printf '%s\n' "\$@" >> "$_INVOKED"
exit 0
EOF
chmod +x "$_STOP_DIR/save.sh"

printf '{"session_id":"test-sid-xyz","stop_reason":"normal"}' \
  | HOME="$_HOME" CLAUDE_PROJECT_DIR="$_HOME" bash "$_STOP_DIR/stop.sh" 2>/dev/null || true
sleep 0.5  # allow async Phase 2 to complete

assert_file_exists "s5: save.sh was invoked" "$_INVOKED"
invoked5=$(cat "$_INVOKED" 2>/dev/null || echo "")
if [[ "$invoked5" == *"test-sid-xyz"* ]]; then
  printf '  PASS: s5: session_id passed to save.sh\n'; (( _PASS++ )) || true
else
  printf '  FAIL: s5: session_id not found in save.sh args\n    args: %q\n' "$invoked5"
  (( _FAIL++ )) || true
fi
if [[ "$invoked5" == *"--force"* ]]; then
  printf '  PASS: s5: --force passed to save.sh\n'; (( _PASS++ )) || true
else
  printf '  FAIL: s5: --force not found in save.sh args\n'; (( _FAIL++ )) || true
fi
_teardown

# ── s6: no session_id in payload → save.sh called without session arg ────────
echo "Section 6: no session_id in payload → save.sh called without session arg"
_setup
cat > "$_STOP_DIR/save.sh" << EOF
#!/usr/bin/env bash
printf '%s\n' "\$@" >> "$_INVOKED"
exit 0
EOF
chmod +x "$_STOP_DIR/save.sh"

printf '{"stop_reason":"normal"}' \
  | HOME="$_HOME" CLAUDE_PROJECT_DIR="$_HOME" bash "$_STOP_DIR/stop.sh" 2>/dev/null || true
sleep 0.5

invoked6=$(cat "$_INVOKED" 2>/dev/null || echo "")
if [[ "$invoked6" != *"test-sid"* && -n "$invoked6" ]]; then
  printf '  PASS: s6: no session arg when field absent\n'; (( _PASS++ )) || true
else
  printf '  FAIL: s6: unexpected session arg or empty invocation\n    args: %q\n' "$invoked6"
  (( _FAIL++ )) || true
fi
_teardown

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo "Results: ${_PASS} passed, ${_FAIL} failed"
(( _FAIL == 0 )) && exit 0 || exit 1
