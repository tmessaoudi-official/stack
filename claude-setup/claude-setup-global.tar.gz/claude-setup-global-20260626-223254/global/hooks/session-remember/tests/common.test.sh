#!/usr/bin/env bash
# common.test.sh — Tests for common.sh utility functions
#
# Run with: bash common.test.sh
#
# Tests four utility areas:
#   1. sr_ensure_dirs — creates dirs, writes source-path (idempotent)
#   2. sr_write_last_save — writes valid JSON to last-save.json
#   3. sr_last_save_field — reads fields from last-save.json (with defaults)
#   4. sr_today / sr_now — timezone-aware date format helpers

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# ─── Counters ──────────────────────────────────────────────────────────────────
_PASS=0; _FAIL=0

assert_equals() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n' "$desc"
    printf '    expected: %q\n' "$expected"
    printf '    actual:   %q\n' "$actual"
    (( _FAIL++ )) || true
  fi
}

assert_matches() {
  local desc="$1" pattern="$2" actual="$3"
  if [[ "$actual" =~ $pattern ]]; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n' "$desc"
    printf '    pattern: %s\n' "$pattern"
    printf '    actual:  %q\n' "$actual"
    (( _FAIL++ )) || true
  fi
}

assert_dir_exists() {
  local desc="$1" path="$2"
  if [[ -d "$path" ]]; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s — dir not found: %s\n' "$desc" "$path"
    (( _FAIL++ )) || true
  fi
}

assert_file_exists() {
  local desc="$1" path="$2"
  if [[ -f "$path" ]]; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s — file not found: %s\n' "$desc" "$path"
    (( _FAIL++ )) || true
  fi
}

assert_file_contains() {
  local desc="$1" path="$2" pattern="$3"
  if [[ -f "$path" ]] && grep -q "$pattern" "$path" 2>/dev/null; then
    printf '  PASS: %s\n' "$desc"
    (( _PASS++ )) || true
  else
    printf '  FAIL: %s — pattern %q not found in %s\n' "$desc" "$pattern" "$path"
    (( _FAIL++ )) || true
  fi
}

# ─── Per-test isolation ─────────────────────────────────────────────────────────
_HOME="" _PROJ="" _SLUG="" _SESSION_DIR="" _STATE_DIR=""

_setup() {
  _HOME=$(mktemp -d /tmp/sr-test-home-XXXXXX)
  _PROJ=$(mktemp -d /tmp/sr-test-proj-XXXXXX)
  _SLUG=$(echo "$_PROJ" | tr '/' '-')
  _SESSION_DIR="$_HOME/.claude/projects/$_SLUG/memory/sessions"
  _STATE_DIR="$_SESSION_DIR/.state"
}

_teardown() {
  rm -rf "$_HOME" "$_PROJ" 2>/dev/null || true
}

# Run a bash snippet with common.sh sourced in the isolated environment.
# Stdout from the snippet is captured by the caller; stderr is suppressed.
# Filesystem side-effects persist (shared $_HOME directory).
_with_common() {
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" SR_TZ="${_SR_TZ:-UTC}" \
    bash --norc --noprofile -c "
source '$PIPELINE_DIR/common.sh' 2>/dev/null || exit 1
$1
" 2>/dev/null
}

# ─── Section 1: sr_ensure_dirs ────────────────────────────────────────────────
echo "Section 1: sr_ensure_dirs"
_setup

_with_common 'sr_ensure_dirs' 2>/dev/null || true

assert_dir_exists "ensure_dirs: SESSION_DIR created" "$_SESSION_DIR"
assert_dir_exists "ensure_dirs: STATE_DIR created"   "$_STATE_DIR"
assert_file_exists "ensure_dirs: source-path written" "$_STATE_DIR/source-path"
assert_file_contains "ensure_dirs: source-path contains PROJECT_DIR" \
  "$_STATE_DIR/source-path" "$_PROJ"

# Idempotent: overwrite source-path, call again — must not restore original
printf '%s\n' "modified" > "$_STATE_DIR/source-path"
_with_common 'sr_ensure_dirs' 2>/dev/null || true
result=$(cat "$_STATE_DIR/source-path")
assert_equals "ensure_dirs: idempotent (source-path not overwritten)" "modified" "$result"

_teardown

# ─── Section 2: sr_write_last_save ────────────────────────────────────────────
echo "Section 2: sr_write_last_save"
_setup
_with_common 'sr_ensure_dirs' 2>/dev/null || true
_with_common 'sr_write_last_save "abc123" 42' 2>/dev/null || true

assert_file_exists "write_last_save: last-save.json created" \
  "$_STATE_DIR/last-save.json"

session_val=$(jq -r '.session' "$_STATE_DIR/last-save.json" 2>/dev/null || echo "")
assert_equals "write_last_save: session field" "abc123" "$session_val"

line_val=$(jq -r '.line' "$_STATE_DIR/last-save.json" 2>/dev/null || echo "")
assert_equals "write_last_save: line field" "42" "$line_val"

ts_val=$(jq -r '.timestamp' "$_STATE_DIR/last-save.json" 2>/dev/null || echo "0")
assert_matches "write_last_save: timestamp is a positive integer" \
  '^[1-9][0-9]+$' "$ts_val"

_teardown

# ─── Section 3: sr_last_save_field ────────────────────────────────────────────
echo "Section 3: sr_last_save_field"
_setup
_with_common 'sr_ensure_dirs' 2>/dev/null || true

# File absent → returns default
result=$(_with_common 'sr_last_save_field "session" "fallback"')
assert_equals "last_save_field: missing file returns default" "fallback" "$result"

# Populate last-save.json then read back
_with_common 'sr_write_last_save "mysession" 77' 2>/dev/null || true

result=$(_with_common 'sr_last_save_field "session" "fallback"')
assert_equals "last_save_field: reads session" "mysession" "$result"

result=$(_with_common 'sr_last_save_field "line" "0"')
assert_equals "last_save_field: reads line" "77" "$result"

# Missing field in existing file → returns default (no second arg → empty default)
result=$(_with_common 'sr_last_save_field "nosuchfield" "mydefault"')
assert_equals "last_save_field: missing field returns default" "mydefault" "$result"

_teardown

# ─── Section 4: sr_today / sr_now ─────────────────────────────────────────────
echo "Section 4: sr_today / sr_now"
_setup

result=$(_with_common 'sr_today')
assert_matches "sr_today: YYYY-MM-DD format" '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' "$result"

result=$(_with_common 'sr_now')
assert_matches "sr_now: HH:MM format" '^[0-9]{2}:[0-9]{2}$' "$result"

# Timezone is respected: UTC date matches what date +%Y-%m-%d produces for UTC
expected=$(TZ=UTC date '+%Y-%m-%d')
result=$(_with_common 'sr_today')
assert_equals "sr_today: uses SR_TZ=UTC" "$expected" "$result"

_teardown

# ─── Section 5: sr_is_readonly_project / per-project readonly-list ────────────
echo "Section 5: sr_is_readonly_project"
_setup

READONLY_LIST_DIR="$_HOME/.claude/hooks/session-remember"
READONLY_LIST="$READONLY_LIST_DIR/readonly-list"
mkdir -p "$READONLY_LIST_DIR"

# 5a: readonly-list absent → function returns 1
result=$(_with_common 'sr_is_readonly_project && echo yes || echo no')
assert_equals "5a: list absent → not readonly" "no" "$result"

# 5b: list present but project not in it → returns 1
printf '%s\n' "-other-project" > "$READONLY_LIST"
result=$(_with_common 'sr_is_readonly_project && echo yes || echo no')
assert_equals "5b: project not in list → not readonly" "no" "$result"

# 5c: project slug IS in list → returns 0
printf '%s\n' "$_SLUG" > "$READONLY_LIST"
result=$(_with_common 'sr_is_readonly_project && echo yes || echo no')
assert_equals "5c: project in list → is readonly" "yes" "$result"

# 5d: comment lines are ignored
printf '# comment\n%s\n' "$_SLUG" > "$READONLY_LIST"
result=$(_with_common 'sr_is_readonly_project && echo yes || echo no')
assert_equals "5d: comment lines ignored" "yes" "$result"

# 5e: blank lines are ignored
printf '\n%s\n\n' "$_SLUG" > "$READONLY_LIST"
result=$(_with_common 'sr_is_readonly_project && echo yes || echo no')
assert_equals "5e: blank lines ignored" "yes" "$result"

# 5f: SR_READONLY=1 is set when project is in readonly-list
printf '%s\n' "$_SLUG" > "$READONLY_LIST"
result=$(_with_common 'sr_ensure_dirs; echo "${SR_READONLY:-unset}"')
assert_equals "5f: SR_READONLY=1 set when in list" "1" "$result"

# 5g: SR_READONLY stays unset when project is NOT in list
printf '%s\n' "-other-project" > "$READONLY_LIST"
result=$(_with_common 'sr_ensure_dirs; echo "${SR_READONLY:-unset}"')
assert_equals "5g: SR_READONLY unset when not in list" "unset" "$result"

# 5h: readonly-list does NOT trigger pipeline exit (project can still load context)
printf '%s\n' "$_SLUG" > "$READONLY_LIST"
exit_code=0
HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" SR_TZ="UTC" \
  bash --norc --noprofile -c "source '$PIPELINE_DIR/common.sh' 2>/dev/null; echo ok" \
  2>/dev/null | grep -q "^ok$" || exit_code=1
assert_equals "5h: readonly-list does not abort pipeline" "0" "$exit_code"

_teardown

# ─── Final summary ────────────────────────────────────────────────────────────
echo ""
echo "Results: ${_PASS} passed, ${_FAIL} failed"
(( _FAIL == 0 )) && exit 0 || exit 1
