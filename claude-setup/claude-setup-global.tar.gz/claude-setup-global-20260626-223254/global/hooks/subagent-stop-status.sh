#!/usr/bin/env bash
# SubagentStop hook: print agent summary line to stderr when a subagent finishes.
# Reads stdin JSON: {agent_name, transcript_path, session_id, cwd, hook_event_name}
# Output goes to stderr — zero tokens, Claude never sees it.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/log-helpers.sh"    2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)

# ask-human gate: remove this subagent's bypass marker FIRST — before any early-exit below — so a
# missing transcript or a failed session-status.sh source cannot leak the marker (which would hold
# the gate open until the 120-min staleness window expires). Removed per agent_id; rmdir clears the
# session dir only once the LAST parallel subagent has stopped.
_SID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
_AID=$(printf '%s' "$INPUT" | jq -r '.agent_id   // empty' 2>/dev/null || true)
if [[ -n "$_SID" && -n "$_AID" ]]; then
  _GATE_DIR="${GATE_DIR_OVERRIDE:-/tmp/ask-human-gate}"
  rm -f "$_GATE_DIR/subagent/$_SID/$_AID" 2>/dev/null || true
  rmdir "$_GATE_DIR/subagent/$_SID"       2>/dev/null || true
fi

# shellcheck disable=SC1091
source "$SCRIPT_DIR/session-status.sh" 2>/dev/null || {
  log_obs ERROR subagent-stop-status "failed to source session-status.sh" 2>/dev/null || true
  exit 0
}

_RUN_DIR="${HOME}/.claude/run"

# Payload field is .agent_type; .agent_name does NOT exist (verified via SubagentStop keys)
AGENT=$(     printf '%s' "$INPUT" | jq -r '.agent_type // .agent_name // empty' 2>/dev/null || true)
TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)

if [[ -z "$TRANSCRIPT" || ! -f "$TRANSCRIPT" ]]; then
  log_obs WARN subagent-stop-status "no transcript for agent=${AGENT:-?}" 2>/dev/null || true
  exit 0
fi

# ── Parse subagent transcript ─────────────────────────────────────────────────
if ! ss_parse_transcript "$TRANSCRIPT"; then
  log_obs WARN subagent-stop-status "transcript parse failed for agent=${AGENT:-?}" 2>/dev/null || true
  exit 0
fi

# SS_INPUT_TOKENS = last input_tokens (total context the subagent used)
# SS_OUTPUT_SUM   = sum of output_tokens (all text the subagent generated)
# SS_MODEL        = model used

# ── Duration: file birth-time → mtime (avoids the historical-context timestamp bug) ──
# Subagent transcripts include full conversation history, so .[0] would be the
# session-start timestamp (potentially hours ago). stat %W (birth time) and %Y
# (mtime) give accurate wall-clock times independent of transcript content.
DURATION_STR=''
DURATION=0
_BIRTH=$(stat -c '%W' "$TRANSCRIPT" 2>/dev/null || echo 0)
_MTIME=$(stat -c '%Y' "$TRANSCRIPT" 2>/dev/null || echo 0)
# stat %W outputs '-' on filesystems without birth-time support (ext3, overlayfs, etc.)
# Strip non-numeric chars so arithmetic below doesn't fatal under set -euo pipefail
_BIRTH="${_BIRTH//[^0-9]/}"; _BIRTH="${_BIRTH:-0}"
_MTIME="${_MTIME//[^0-9]/}"; _MTIME="${_MTIME:-0}"
if (( _BIRTH > 0 && _MTIME > _BIRTH )); then
  DURATION=$(( _MTIME - _BIRTH ))
fi
# Fallback: use jq timestamps but skip historical context (only use last 30 min)
if (( DURATION == 0 )); then
  DURATION=$(jq -Rs '
    split("\n") |
    map(select(length > 0) | try fromjson catch null) |
    map(select(. != null and .timestamp? != null) |
      .timestamp | split(".") | .[0] + "Z" | try fromdateiso8601 catch null) |
    map(select(. != null)) |
    if length >= 2 then
      . as $ts |
      ($ts | last) as $end |
      [$ts[] | select(. >= ($end - 1800))] as $recent |
      if ($recent | length) >= 2 then ($end - $recent[0]) | floor else 0 end
    else 0 end
  ' < "$TRANSCRIPT" 2>/dev/null || echo 0)
fi

if (( DURATION > 0 )); then
  MINS=$(( DURATION / 60 ))
  SECS=$(( DURATION % 60 ))
  DURATION_STR=$(printf '%d:%02d' "$MINS" "$SECS")
fi

# ── Last output (response to parent context) ─────────────────────────────────
LAST_OUTPUT=$(jq -Rs '
  split("\n") |
  map(select(length > 0) | try fromjson catch null) |
  map(select(. != null)) |
  [.[] | select(.type? == "assistant") | (.message?.usage?.output_tokens? // 0)] |
  last // 0
' < "$TRANSCRIPT" 2>/dev/null || echo 0)

# ── Short model name ──────────────────────────────────────────────────────────
SHORT_MODEL="${SS_MODEL}"
case "$SS_MODEL" in
  *haiku*)  SHORT_MODEL='haiku'  ;;
  *sonnet*) SHORT_MODEL='sonnet' ;;
  *opus*)   SHORT_MODEL='opus'   ;;
esac

# K values
local_output_k=$(( SS_OUTPUT_SUM  / 1000 ))
last_out_k=$((   LAST_OUTPUT    / 1000 ))
[[ $local_output_k -lt 1 && $SS_OUTPUT_SUM  -gt 0 ]] && local_output_k=1
[[ $last_out_k     -lt 1 && $LAST_OUTPUT    -gt 0 ]] && last_out_k=1

AGENT_LABEL="${AGENT:-agent}"
FINISH_TIME=$(date '+%H:%M' 2>/dev/null || true)
LINE="  ↳ ${AGENT_LABEL} [${SHORT_MODEL}]"
[[ -n "$DURATION_STR" ]] && LINE+="  done in ${DURATION_STR}"
LINE+="  · consumed ${local_output_k}K tokens · response ${last_out_k}K → +${last_out_k}K ctx"
[[ -n "$FINISH_TIME" ]] && LINE+="  @${FINISH_TIME}"

printf '%s\n' "$LINE" >&2

# ── Append to status file (for cc/Screen status pane) ────────────────────────
_STATUS_AGENTS="${_RUN_DIR}/status-agents.txt"
_AGENTS_LOCK="${_RUN_DIR}/.status-agents.lock"
(
  flock -x 9 2>/dev/null || true
  printf '%s\n' "$LINE" >> "$_STATUS_AGENTS" 2>/dev/null || true
  # Keep only the last 3 agent lines to avoid overflowing the pane
  if command -v tail &>/dev/null && [[ -f "$_STATUS_AGENTS" ]]; then
    _TMP=$(mktemp "${_RUN_DIR}/.status-agents.XXXXXX" 2>/dev/null || mktemp)
    tail -n 3 "$_STATUS_AGENTS" > "$_TMP" 2>/dev/null || true
    mv -f "$_TMP" "$_STATUS_AGENTS" 2>/dev/null || true
  fi
) 9>"$_AGENTS_LOCK" 2>/dev/null || true

log_obs INFO subagent-stop-status "agent=${AGENT_LABEL} model=${SS_MODEL} output=${SS_OUTPUT_SUM} response=${LAST_OUTPUT}" 2>/dev/null || true
