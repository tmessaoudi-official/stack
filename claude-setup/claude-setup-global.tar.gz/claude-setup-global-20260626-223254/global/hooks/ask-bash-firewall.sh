#!/usr/bin/env bash
# PreToolUse: Bash — settings-aware SUPERVISOR (advisory). Reconciles a curated dangerous/irreversible
# EFFECT model against ~/.claude/settings.json: emits permissionDecision "ask" (a user prompt) for risky
# commands the verb-based settings denylist can be bypassed around (touch→echo>, rm→find -delete,
# absolute-path secret reads), but DEFERS — never overrides — when settings already 'allow's the exact
# command. settings deny/ask are still enforced by Claude Code itself; this only ADDS asks for the
# bypass-forms CC misses. All flags + suggested settings rules are appended to
# logs/firewall-suggestions.log for review. HONEST: Bash is arbitrary code execution; this is
# best-effort supervision, NOT a sandbox. CLAUDE_BASH_FIREWALL_OFF=1 disables (the user's escape, never set by Claude).
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

SETTINGS="${CLAUDE_BASH_FIREWALL_SETTINGS:-$HOME/.claude/settings.json}"   # CLAUDE_BASH_FIREWALL_SETTINGS: test injection
SUG_LOG="${CLAUDE_BASH_FIREWALL_LOG:-$HOME/.claude/logs/firewall-suggestions.log}"

[[ "${CLAUDE_BASH_FIREWALL_OFF:-}" == "1" ]] && exit 0
# Global off-switch: sentinel disables the gate everywhere (defer to literal settings.json).
[[ -f "$HOME/.claude/state/ask-bash-firewall-bypass" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

# Per-project off-switch: sentinel at ~/.claude/projects/<slug>/state/ask-bash-firewall-bypass (slug = cwd, / → -).
CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
if [[ -n "$CWD" ]]; then
  PROJ_SLUG=$(printf '%s' "$CWD" | tr '/' '-')
  [[ -f "$HOME/.claude/projects/${PROJ_SLUG}/state/ask-bash-firewall-bypass" ]] && exit 0
fi
CMD=$(printf '%s' "$INPUT" | jq -r '.tool_input.command // empty' 2>/dev/null || true)
[[ -z "$CMD" ]] && exit 0

log_flag() {  # $1=action  $2=reason  $3=suggestion
  local ts; ts=$(date -Is 2>/dev/null || date 2>/dev/null || echo '?')
  printf '%s | %s | %s | suggest: %s | cmd: %s\n' \
    "$ts" "$1" "$2" "$3" "${CMD:0:200}" >> "$SUG_LOG" 2>/dev/null || true
  log_obs INFO ask-bash-firewall "$1 ($2)" 2>/dev/null || true
}

emit_ask() {  # $1=reason (shown to USER)  $2=suggestion (logged)
  jq -nc --arg r "$1" \
    '{hookSpecificOutput:{hookEventName:"PreToolUse",permissionDecision:"ask",permissionDecisionReason:$r}}' \
    2>/dev/null || printf '%s' '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"ask","permissionDecisionReason":"bash firewall: review this command"}}'
  log_flag "ASK" "$1" "$2"
  exit 0
}

# Does settings.json explicitly ALLOW this exact command? (honor allow → defer, never ask/block)
allowed_by_settings() {
  local pat
  while IFS= read -r pat; do
    [[ -z "$pat" ]] && continue
    pat="${pat//:\*/\*}"                        # CC ':*' suffix → glob '*'
    # shellcheck disable=SC2053
    [[ "$CMD" == $pat ]]   && return 0          # full glob match
    [[ "$CMD" == "$pat "* ]] && return 0        # rule + trailing args
  done < <(jq -r '.permissions.allow[]? | select(startswith("Bash(")) | .[5:-1]' "$SETTINGS" 2>/dev/null)
  return 1
}

# ── Curated dangerous / irreversible EFFECT model (high-confidence) ────────────
# A substring appearing anywhere in the command that signals a risky effect the verb-based settings
# denylist can be bypassed around. Match → ask (unless settings explicitly allows the command).
danger_patterns=(
  'rm -rf' 'rm -fr' 'rm -r ' 'rm --recursive' ' -delete' 'unlink ' ' dd ' 'mkfs' 'shred'
  'truncate ' 'git reset --hard' 'git clean' 'git push --force' 'git push -f' ':(){'
  'chmod -R' 'chmod 777' 'chown -R'
  'ask-human-gate-bypass' 'ask-bash-firewall-bypass' 'ask-human-question-guard-bypass'
  'session-remember/DISABLED' 'session-remember/READONLY' 'session-remember/blacklist' 'session-remember/readonly-list'
  'autonomous-3c'
  '.ssh/' 'id_rsa' 'id_ed25519' '.pem' '.key' '.credentials.json' '.claude.json' '.git-credentials'
  '.netrc' '/.env' '.aws/' '.gnupg/' '.kube/' '.claude/mcp/'
)

hit=""
for p in "${danger_patterns[@]}"; do
  [[ "$CMD" == *"$p"* ]] && { hit="$p"; break; }
done

if [[ -n "$hit" ]]; then
  if allowed_by_settings; then
    # settings explicitly blesses this command → DEFER (pass) but log the disagreement for review
    log_flag "DEFER(allowed)" "risky effect '$hit' but settings.json ALLOWS this exact command" \
      "review the allow rule that permits this; tighten it if unintended"
    exit 0
  fi
  emit_ask "Bash firewall: dangerous/irreversible effect ('$hit') reachable in a form your settings denylist may not cover. Approve this command?" \
    "codify into settings.json — deny Bash(* ${hit}*) and/or guard the path; OS option (later): restrict PATH / immutable secret. See logs/firewall-suggestions.log. Disable gate — global: touch ~/.claude/state/ask-bash-firewall-bypass | project: mkdir -p ~/.claude/projects/<slug>/state && touch ~/.claude/projects/<slug>/state/ask-bash-firewall-bypass | session: CLAUDE_BASH_FIREWALL_OFF=1"
fi

# Obfuscation present without a danger hit → log only (advisory), do not interrupt.
case "$CMD" in
  *'$('*|*'`'*) log_flag "NOTE" "command substitution present (can hide effects)" "informational — no action" ;;
esac

exit 0   # defer: no opinion → settings/auto + the rtk hook decide
