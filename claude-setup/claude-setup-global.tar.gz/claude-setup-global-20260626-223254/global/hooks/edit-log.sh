#!/usr/bin/env bash
# PostToolUse hook: log Edit/Write tool calls to a daily log file.
set -euo pipefail

# shellcheck source=log-helpers.sh
source "$(dirname "${BASH_SOURCE[0]}")/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

OP=$(printf '%s' "$INPUT" | jq -r '.tool_name // "EDIT"' 2>/dev/null || echo "EDIT")
FILE=$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null || true)
[[ -n "$FILE" ]] || exit 0

LOG="${HOME}/.claude/logs/edits/$(date +%Y%m%d).txt"
mkdir -p "$(dirname "$LOG")" 2>/dev/null \
  || { log_obs ERROR edit-log "failed to create log dir: $(dirname "$LOG")" 2>/dev/null || true; exit 0; }
printf '%s %s %s\n' "$(date +%H:%M:%S)" "$OP" "$FILE" >> "$LOG" 2>/dev/null || true
exit 0
