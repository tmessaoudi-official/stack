#!/usr/bin/env bash
# PreToolUse hook: enforce Rule 8 backup policy for Edit and Write tool calls.
#
# Non-git files that exist: create a timestamped backup. If backup fails, BLOCK
# the edit — proceeding without a backup defeats the entire purpose of this hook.
# Git files with uncommitted changes: emit a warning (exit 0 — git history is
# the backup, so blocking would be overcorrection for normal development workflow).
# New files or clean git files: silent, always allow.

set -eEuo pipefail

# shellcheck source=log-helpers.sh
source "$(dirname "${BASH_SOURCE[0]}")/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

TOOL=$(printf '%s' "$INPUT" | jq -r '.tool_name // empty' 2>/dev/null || true)
FILE=$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null || true)

[[ "$TOOL" == "Edit" || "$TOOL" == "Write" ]] || exit 0
[[ -n "$FILE" ]] || exit 0

# New file being created — no backup needed
[[ -f "$FILE" ]] || exit 0

FILE=$(realpath "$FILE" 2>/dev/null || echo "$FILE")

if git -C "$(dirname "$FILE")" rev-parse --is-inside-work-tree &>/dev/null 2>&1; then
    # Inside git: warn on uncommitted/untracked changes, never block (git is the backup)
    STATUS=$(git -C "$(dirname "$FILE")" status --porcelain -- "$FILE" 2>/dev/null || true)
    UNTRACKED=$(git -C "$(dirname "$FILE")" ls-files --others -- "$FILE" 2>/dev/null || true)
    if [[ -n "$STATUS" || -n "$UNTRACKED" ]]; then
        echo "[WARNING] Rule 8: '$FILE' has uncommitted/untracked changes in git." >&2
        echo "   Consider committing or stashing before editing to avoid losing work." >&2
        echo "   Proceeding anyway — confirm this is intentional." >&2
    fi
    exit 0
fi

# Outside git: create a timestamped backup. BLOCK if backup fails.
BACKUP="${FILE}.bak.$(date +%s)"
if cp -a "$FILE" "$BACKUP" 2>/dev/null; then
    echo "[backup] Rule 8 backup created: $BACKUP" >&2
    OBS_LOG="$HOME/.claude/logs/backups.log" log_obs INFO backup-before-write "backed up $FILE → $BACKUP"
    exit 0
else
    echo "[BLOCKED] Rule 8: Could not create backup for '$FILE'." >&2
    echo "   'cp -a \"$FILE\" \"$BACKUP\"' failed (disk full? permissions?)." >&2
    echo "   Create a manual backup before proceeding:" >&2
    echo "   cp -a \"$FILE\" \"${FILE}.bak.manual\"" >&2
    log_obs ERROR backup-before-write "backup failed for $FILE"
    exit 1
fi
