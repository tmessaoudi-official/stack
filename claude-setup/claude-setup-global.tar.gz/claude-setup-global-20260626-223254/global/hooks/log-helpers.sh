#!/usr/bin/env bash
# Shared observability helper. Source this from hooks that need structured logging.
# Never fatal — all writes use || true.

umask 077  # hook-created files (logs, state, WAL) should be owner-only

log_obs() {
  local level="$1" script="$2"; shift 2
  printf '%s | %s | %s | %s\n' \
    "$(date -Iseconds)" "$level" "$script" "$*" \
    >> "${OBS_LOG:-$HOME/.claude/logs/hooks-errors.log}" 2>/dev/null || true
}
