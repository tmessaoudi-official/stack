#!/usr/bin/env bash
# UserPromptSubmit: write a turn token on every new user message.
# The block hook (ask-human-gate-block.sh) uses this to enforce the gate
# once per request rather than once per 20-min session.
# Subagents have no UserPromptSubmit → no turn token → block hook allows them through.
# Emergency bypass: touch ~/.claude/state/ask-human-gate-bypass to disable gate globally.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

[[ -f "$HOME/.claude/state/ask-human-gate-bypass" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$SESSION_ID" ]] || exit 0

# Per-project bypass: skip the turn token when ~/.claude/projects/<slug>/state/ask-human-gate-bypass exists
# (slug = cwd, / → -). Symmetric with the global bypass above.
CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
if [[ -n "$CWD" ]]; then
  PROJ_SLUG=$(printf '%s' "$CWD" | tr '/' '-')
  [[ -f "$HOME/.claude/projects/${PROJ_SLUG}/state/ask-human-gate-bypass" ]] && exit 0
fi

GATE_DIR="${GATE_DIR_OVERRIDE:-/tmp/ask-human-gate}"  # GATE_DIR_OVERRIDE: test-only injection point
mkdir -p "$GATE_DIR/turns" 2>/dev/null || true
printf '%s' "$(date +%s)" > "$GATE_DIR/turns/${SESSION_ID}"
log_obs INFO ask-human-gate-arm "turn token written for session ${SESSION_ID}" || true

exit 0
