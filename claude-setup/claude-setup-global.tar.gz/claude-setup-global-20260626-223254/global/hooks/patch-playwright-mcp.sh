#!/usr/bin/env bash
# Ensures playwright plugin cache .mcp.json always has npm_config_registry=npmjs.org
# so npx can resolve 'playwright' and 'playwright-core' deps (unscoped, not in ACME Artifactory).
# Runs at SessionStart; no-ops if already patched.
set -euo pipefail

# shellcheck source=log-helpers.sh
source "$(dirname "${BASH_SOURCE[0]}")/log-helpers.sh" 2>/dev/null || true

find "$HOME/.claude/plugins/cache/claude-plugins-official/playwright" \
    -name ".mcp.json" 2>/dev/null \
| while read -r f; do
    grep -q "npm_config_registry" "$f" 2>/dev/null && continue
    python3 - "$f" <<'EOF' \
      || { log_obs WARN patch-playwright-mcp "json patch failed for $f" 2>/dev/null || true; continue; }
import json, sys
path = sys.argv[1]
with open(path) as fh:
    data = json.load(fh)
if "playwright" in data:
    data["playwright"].setdefault("env", {})["npm_config_registry"] = "https://registry.npmjs.org/"
    with open(path, "w") as fh:
        json.dump(data, fh, indent=2)
        fh.write("\n")
EOF
    log_obs INFO patch-playwright-mcp "patched npm_config_registry in $f" 2>/dev/null || true
done
exit 0