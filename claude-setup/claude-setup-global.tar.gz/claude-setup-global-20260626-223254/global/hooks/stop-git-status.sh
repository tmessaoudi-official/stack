#!/usr/bin/env bash
# stop-git-status.sh — Stop hook: atomically refresh git fields in status-banner.txt.
# Fires after every Claude turn. Keeps git info current without restarting the session.
# Reads CWD from status-banner.txt, re-runs git queries, rewrites only git-related lines.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/log-helpers.sh"    2>/dev/null || true
# shellcheck disable=SC1091
source "$SCRIPT_DIR/session-status.sh" 2>/dev/null || true

_RUN_DIR="${HOME}/.claude/run"
_BNR_GLOBAL="${_RUN_DIR}/status-banner.txt"

# P0-2: target this session's per-session banner when present (created by session-start-banner.sh);
# fall back to the global fixed-name file. Stop stdin carries {session_id, transcript_path, cwd, ...}.
INPUT=$(cat 2>/dev/null || true)
SESSION_ID_IN=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
if [[ -n "$SESSION_ID_IN" && -f "${_RUN_DIR}/status-banner-${SESSION_ID_IN}.txt" ]]; then
  BANNER="${_RUN_DIR}/status-banner-${SESSION_ID_IN}.txt"
else
  BANNER="$_BNR_GLOBAL"
fi

[[ -f "$BANNER" ]] || {
  log_obs INFO stop-git-status "no status-banner.txt, skipping" 2>/dev/null || true
  exit 0
}

CWD=$(grep "^CWD:" "$BANNER" 2>/dev/null | head -1 | cut -d: -f2- || true)
[[ -z "$CWD" ]] && {
  log_obs INFO stop-git-status "no CWD in banner, skipping" 2>/dev/null || true
  exit 0
}

git -C "$CWD" rev-parse --is-inside-work-tree &>/dev/null 2>&1 || {
  log_obs INFO stop-git-status "CWD=$CWD not a git repo, skipping" 2>/dev/null || true
  exit 0
}

# ── Compute git fields (parallel, wall-clock ≈ 2s vs 14s sequential) ─────────
# Five background subshells write results to a temp dir; collected after wait.
# EXIT trap guarantees cleanup even if the hook is killed by the 5s timeout.
_TMP_GIT=$(mktemp -d /tmp/.gs-stopgit.XXXXXX 2>/dev/null || mktemp -d)
trap 'rm -rf "$_TMP_GIT" 2>/dev/null || true' EXIT

( _b=$(timeout 2 git -C "$CWD" branch --show-current 2>/dev/null || echo '?')
  printf '%s\n' "${_b:-?}" ) > "$_TMP_GIT/branch" &
_p1=$!

# Scope status to CWD subtree only ("-- ."). Without this, git scans the entire
# repo root — catastrophic in home-dir repos with thousands of tracked files (tested:
# unscoped = 46s on this machine; scoped = 53ms). Timeout 2 is safe with scoping.
( _d=$(timeout 2 git -C "$CWD" status --porcelain -- . 2>/dev/null | wc -l | tr -d ' ') \
    || { log_obs WARN stop-git-status "git status failed/timed out" 2>/dev/null || true; }
  printf '%s\n' "${_d:-0}" ) > "$_TMP_GIT/dirty" &
_p2=$!

( _s=$(timeout 2 git -C "$CWD" stash list 2>/dev/null | wc -l | tr -d ' ') \
    || { log_obs WARN stop-git-status "git stash list failed/timed out" 2>/dev/null || true; }
  printf '%s\n' "${_s:-0}" ) > "$_TMP_GIT/stashes" &
_p3=$!

# Combined: last commit timestamp + CLAUDEMD staleness (single git log call shared by both,
# eliminating the duplicate git-log call that existed in the sequential version).
(
  _ct=$(timeout 2 git -C "$CWD" log -1 --format='%ct' 2>/dev/null || echo 0)
  printf '%s\n' "${_ct:-0}" > "$_TMP_GIT/lastct"
  _CLAUDEMD_F="${CWD}/CLAUDE.md"
  if [[ -f "$_CLAUDEMD_F" ]]; then
    _CM_MTIME=$(stat -c '%Y' "$_CLAUDEMD_F" 2>/dev/null || echo 0)
    _CM_GAP=$(( ${_ct:-0} - ${_CM_MTIME:-0} ))
    if (( _CM_GAP > 259200 )); then
      printf '⚠ %sd behind HEAD\n' "$(( _CM_GAP / 86400 ))" > "$_TMP_GIT/claudemd"
    fi
  fi
) &
_p4=$!

# Unpushed: probe upstream first; -1 = no upstream configured
(
  if timeout 2 git -C "$CWD" rev-parse '@{u}' &>/dev/null 2>&1; then
    _u=$(timeout 2 git -C "$CWD" log '@{u}..' --oneline 2>/dev/null | wc -l | tr -d ' ') \
      || { log_obs WARN stop-git-status "git log @{u} failed/timed out" 2>/dev/null || true; }
    printf '%s\n' "${_u:-0}"
  else
    printf '%s\n' '-1'
  fi
) > "$_TMP_GIT/unpushed" &
_p5=$!

wait "$_p1" || true
wait "$_p2" || true
wait "$_p3" || true
wait "$_p4" || true
wait "$_p5" || true

# ── Collect results ───────────────────────────────────────────────────────────
GIT_BRANCH=$(cat "$_TMP_GIT/branch" 2>/dev/null | head -1 | tr -d '[:space:]' || echo '?')
[[ -z "$GIT_BRANCH" ]] && GIT_BRANCH='?'
DIRTY_COUNT=$(cat "$_TMP_GIT/dirty" 2>/dev/null | head -1 | tr -d '[:space:]' || echo 0)
DIRTY_COUNT="${DIRTY_COUNT//[^0-9]/}"; DIRTY_COUNT="${DIRTY_COUNT:-0}"
GIT_DIRTY="$DIRTY_COUNT"
GIT_UNPUSHED=$(cat "$_TMP_GIT/unpushed" 2>/dev/null | head -1 | tr -d '[:space:]' || echo '-1')
[[ "$GIT_UNPUSHED" =~ ^-?[0-9]+$ ]] || GIT_UNPUSHED='-1'
GIT_STASHES=$(cat "$_TMP_GIT/stashes" 2>/dev/null | head -1 | tr -d '[:space:]' || echo 0)
GIT_STASHES="${GIT_STASHES//[^0-9]/}"; GIT_STASHES="${GIT_STASHES:-0}"
_LAST_CT=$(cat "$_TMP_GIT/lastct" 2>/dev/null | head -1 | tr -d '[:space:]' || echo 0)
_LAST_CT="${_LAST_CT//[^0-9]/}"; _LAST_CT="${_LAST_CT:-0}"
CLAUDEMD_STATUS=$(cat "$_TMP_GIT/claudemd" 2>/dev/null | head -1 || true)
# Temp dir cleaned by EXIT trap

GIT_LAST=''
if (( _LAST_CT > 0 )) && type ss_age &>/dev/null; then
  _NOW=$(date +%s)
  GIT_LAST=$(ss_age $(( _NOW - _LAST_CT )))
fi

# Composite string (backward compat for GIT: field + plain stderr display)
GIT_INFO="${GIT_BRANCH}"
if (( DIRTY_COUNT > 0 )); then
  GIT_INFO+=" · ${DIRTY_COUNT} uncommitted"
else
  GIT_INFO+=" · clean"
fi
if [[ "$GIT_UNPUSHED" != "-1" && "$GIT_UNPUSHED" -gt 0 ]]; then
  GIT_INFO+=" · ↑${GIT_UNPUSHED} to push"
fi
if (( GIT_STASHES > 0 )); then
  GIT_INFO+=" · ⚑${GIT_STASHES} stashed"
fi
[[ -n "$GIT_LAST" ]] && GIT_INFO+=" · ${GIT_LAST}"

# ── Atomic update: preserve all non-git fields, replace git fields ────────────
_TMP=$(mktemp "${_RUN_DIR}/.status-banner.XXXXXX" 2>/dev/null || mktemp)

grep -vE '^(GIT|GIT_BRANCH|GIT_DIRTY|GIT_UNPUSHED|GIT_STASHES|GIT_LAST|CLAUDEMD):' \
  "$BANNER" > "$_TMP" 2>/dev/null || true

{
  printf 'GIT:%s\n'           "${GIT_INFO}"
  printf 'GIT_BRANCH:%s\n'    "${GIT_BRANCH}"
  printf 'GIT_DIRTY:%s\n'     "${GIT_DIRTY}"
  printf 'GIT_UNPUSHED:%s\n'  "${GIT_UNPUSHED}"
  printf 'GIT_STASHES:%s\n'   "${GIT_STASHES}"
  printf 'GIT_LAST:%s\n'      "${GIT_LAST}"
  printf 'CLAUDEMD:%s\n'      "${CLAUDEMD_STATUS}"
} >> "$_TMP"

mv -f "$_TMP" "$BANNER" 2>/dev/null || true
# Dual-write the global fixed-name file so external readers + statusline's global fallback stay current.
[[ "$BANNER" != "$_BNR_GLOBAL" ]] && cp -f "$BANNER" "$_BNR_GLOBAL" 2>/dev/null || true

log_obs INFO stop-git-status \
  "refreshed: branch=${GIT_BRANCH} dirty=${GIT_DIRTY} unpushed=${GIT_UNPUSHED} stashes=${GIT_STASHES}" \
  2>/dev/null || true
