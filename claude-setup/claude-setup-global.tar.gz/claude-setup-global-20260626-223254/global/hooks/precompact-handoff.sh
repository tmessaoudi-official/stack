#!/usr/bin/env bash
# PreCompact hook (matcher: auto): auto-generate handoff note before compaction.
# Reads stdin JSON: {session_id, transcript_path, cwd, compact_type, hook_event_name}
# Calls claude -p (Haiku) to write handoff.md. Exits 0 to allow compaction.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
CWD=$(printf '%s'        "$INPUT" | jq -r '.cwd           // empty' 2>/dev/null || true)
SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id    // empty' 2>/dev/null || true)
[[ -z "$CWD" && -n "${CLAUDE_PROJECT_DIR:-}" ]] && CWD="$CLAUDE_PROJECT_DIR"
if [[ -z "$CWD" ]]; then
  CWD="$PWD"
  log_obs WARN precompact-handoff "CLAUDE_PROJECT_DIR unset — falling back to PWD ($CWD); handoff may be misrouted" 2>/dev/null || true
fi

log_obs INFO precompact-handoff "triggered (cwd=$CWD)" 2>/dev/null || true

if [[ -z "$TRANSCRIPT" || ! -f "$TRANSCRIPT" ]]; then
  log_obs WARN precompact-handoff "no transcript — skipping handoff generation" 2>/dev/null || true
  exit 0
fi

# ── Derive handoff path from cwd ──────────────────────────────────────────────
SLUG=$(printf '%s' "$CWD" | sed 's|/|-|g')
HANDOFF_DIR="$HOME/.claude/projects/${SLUG}/memory/sessions"
HANDOFF_FILE="$HANDOFF_DIR/handoff.md"
mkdir -p "$HANDOFF_DIR" || { log_obs ERROR precompact-handoff "mkdir failed for $HANDOFF_DIR — handoff lost" 2>/dev/null || true; exit 0; }

# ── Extract last ~100 exchanges from transcript ───────────────────────────────
EXCERPT=$(jq -Rs '
  split("\n") |
  map(select(length > 0) | try fromjson catch null) |
  map(select(. != null)) |
  map(select(.type? == "user" or .type? == "assistant")) |
  map(
    if .type == "user" then
      "USER: " + (
        [.message?.content? |
          if type == "string" then .
          elif type == "array" then (.[] | select(.type? == "text") | .text)
          else "" end
        ] | join(" ") | .[0:400]
      )
    else
      "CLAUDE: " + (
        [.message?.content? |
          if type == "string" then .
          elif type == "array" then (.[] | select(.type? == "text") | .text)
          else "" end
        ] | join(" ") | .[0:300]
      )
    end
  ) |
  .[(-30):] |
  join("\n---\n")
' < "$TRANSCRIPT" 2>/dev/null | head -c 8000 || true)

if [[ -z "$EXCERPT" ]]; then
  log_obs WARN precompact-handoff "empty excerpt — skipping handoff generation" 2>/dev/null || true
  exit 0
fi

# ── Build prompt from handoff skill (single source of truth for format) ───────
HANDOFF_SKILL="$HOME/.claude/skills/handoff/SKILL.md"
PROMPT_FILE=$(mktemp /tmp/precompact-handoff-XXXXXX.txt)
trap 'rm -f "$PROMPT_FILE"' EXIT

{
  printf 'You are generating a session handoff note from a transcript excerpt (not a live session).\n'
  printf 'Follow the format and rules below exactly. Output ONLY the handoff note — no confirmation, no "Saved.", nothing else.\n\n'
  if [[ -f "$HANDOFF_SKILL" ]]; then
    cat "$HANDOFF_SKILL"
  else
    printf '## State\n{done/not done, files modified}\n\n## Next\n{1-3 items, priority order}\n\n'
    printf 'Rules: under 25 lines. Forward-looking only. If nothing to hand off: "No active work."\n'
  fi
  printf '\n\nHere is the recent session transcript:\n---\n'
  printf '%s\n' "$EXCERPT"
  printf '\n---\nWrite the handoff note now:\n'
} > "$PROMPT_FILE"

# ── Call Haiku ────────────────────────────────────────────────────────────────
HAIKU_MODEL="${SR_MODEL:-claude-haiku-4-5}"

log_obs INFO precompact-handoff "calling Haiku for handoff generation" 2>/dev/null || true

RESULT=""
# Guard: tell the Stop hook not to spawn another handoff generation for this Haiku turn.
# Without this, stop-context-bar.sh sees the Haiku Stop event and re-spawns → loop.
export GS_NO_AUTO_HANDOFF=1
# Retry up to 3×: Haiku API can fail transiently (network hiccup, rate limit, API cold-start).
for attempt in 1 2 3; do
  # cd /tmp: prevents the claude subprocess from inheriting CLAUDE_PROJECT_DIR,
  # which would trigger project-level SessionStart hooks and pick up wrong context.
  RAW=$(cd /tmp && env -u CLAUDE_PROJECT_DIR timeout 60 claude -p \
    --model "$HAIKU_MODEL" \
    --max-turns 1 \
    --output-format json \
    --tools "" \
    < "$PROMPT_FILE" 2>/dev/null) && break
  [[ $attempt -lt 3 ]] && sleep $(( attempt * 3 ))
  [[ $attempt -eq 3 ]] && {
    log_obs ERROR precompact-handoff "Haiku call failed after 3 attempts" 2>/dev/null || true
    exit 0
  }
done

RESULT=$(printf '%s' "$RAW" | jq -r '.result // empty' 2>/dev/null | sed '/^[[:space:]]*$/d')

if [[ -z "$RESULT" ]]; then
  log_obs WARN precompact-handoff "empty Haiku result — handoff not written" 2>/dev/null || true
  exit 0
fi

# ── Write handoff ─────────────────────────────────────────────────────────────
# IMP-9: append auto-generated marker so statusline can show ⟳ auto vs ⟳ (manual)
printf '%s\n\n<!-- auto-generated by precompact -->\n' "$RESULT" > "$HANDOFF_FILE"
log_obs INFO precompact-handoff "handoff written: $HANDOFF_FILE" 2>/dev/null || true

# Update status-banner.txt HANDOFF field immediately so the statusline shows "auto"
# without waiting for the next session start (which would otherwise miss the async write).
_RUN_DIR="$HOME/.claude/run"
_BNR_GLOBAL="${_RUN_DIR}/status-banner.txt"
# P0-2: update this session's per-session banner when present (created by session-start-banner.sh);
# dual-write the global fixed-name file. SESSION_ID comes from the PreCompact stdin payload.
if [[ -n "$SESSION_ID" && -f "${_RUN_DIR}/status-banner-${SESSION_ID}.txt" ]]; then
  _BNR="${_RUN_DIR}/status-banner-${SESSION_ID}.txt"
else
  _BNR="$_BNR_GLOBAL"
fi
if [[ -f "$_BNR" ]]; then
  _BNR_TMP=$(mktemp "${_RUN_DIR}/.status-banner.XXXXXX" 2>/dev/null || true)
  if [[ -n "$_BNR_TMP" ]]; then
    sed 's|^HANDOFF:.*|HANDOFF:just now auto|' "$_BNR" \
      > "$_BNR_TMP" 2>/dev/null \
      && mv -f "$_BNR_TMP" "$_BNR" 2>/dev/null \
      || rm -f "$_BNR_TMP" 2>/dev/null || true
    [[ "$_BNR" != "$_BNR_GLOBAL" ]] && cp -f "$_BNR" "$_BNR_GLOBAL" 2>/dev/null || true
    log_obs INFO precompact-handoff "status-banner HANDOFF updated to 'just now auto'" 2>/dev/null || true
  fi
fi

printf '\n[auto-handoff saved before compaction]\n' >&2
