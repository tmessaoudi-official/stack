# MCP ↔ bundle/install integration — Design Spec (v1)

> Date: 2026-06-20 · Status: Drafted (design), pending user review
> Targets: `~/.claude/skills/{bundle,install,adapt-project,bootstrap}/SKILL.md`, `~/.claude/bin/lib/claude-export/core/sanitize.sh`, `~/.claude/bin/lib/claude-import/core/tutorial.sh`
> This is **subsystem #3** of the desktop-mcp effort thread. It **depends on #1** (`desktop-mcp` at `~/.claude/mcp/<mcp-client-1>/`) and **#2** (the Python-ported Trivy MCP) existing, but is designed to be *generic over any MCP dir under `~/.claude/mcp/<name>/`* — it does **not** hardcode those two.

---

## 1. Purpose

Make MCP servers living under `~/.claude/mcp/<name>/` **first-class bundle citizens**: packaged on `/bundle`, secret-scrubbed on the way out, npm/build-rehydrated on `/install`, and re-registered into `~/.claude.json → mcpServers` on the target — with `~/.claude.json` edits *presented for manual `!` execution*, never auto-written (classifier-blocked). The goal is a clean bundle→install round-trip for an MCP server such that a target machine ends up with the server's code, a scrubbed `*.env` skeleton, and a ready-to-paste registration snippet.

## 2. Why

Today the bundle/install flow already *moves the files* under `mcp/` and *scrubs `*.env`/`.claude.json`*, but the coverage is partial and convention-implicit:

- The set of MCP dirs that get registered on the target is **not declared anywhere** — install only knows to run `npm ci` if a `package.json` is present [Verified: read install Step 4, the `for pkg_dir in ~/.claude/mcp/*/` loop]. There is no parallel step that re-registers the `mcpServers` entries.
- The two new MCPs are **Python**, not Node — the `npm ci` rehydration loop will skip them, and nothing builds/installs a Python env in its place [Verified: install Step 4 guards on `package.json`; desktop spec §5 ships `pyproject.toml`; trivy #2 is a Python port].
- `desktop-mcp` builds a **Docker image** on first run and has **no `*.env`** [Verified: desktop spec §4 wrapper does `docker build … || …`, registration `env:{}`]. Its rehydration need is "image builds", not "npm ci".

So the integration must move from "Node-only, implicit" to a **generic per-MCP manifest** that each `mcp/<name>/` dir carries, declaring how it is bundled, scrubbed, rehydrated, and registered. New MCPs are then covered without editing any of the four skills.

## 3. Current state (verified)

### 3.1 What `/bundle` does with `mcp/` today

- `mcp/` is in the **global** include set: scripts, `package.json`, `package-lock.json` are packaged; `*.env` is scrubbed to `CHANGE_ME_*`; `node_modules/` is excluded (rebuilt by install via `npm ci`); in scrubbed bundles each `mcp/<client>/` folder is renamed to a numbered org-neutral stub `mcp/<mcp-client-N>/` [Verified: read bundle SKILL "What global scope bundles" table, `mcp/` row + scrub bullet list]. `mcp/**/node_modules/` is in the always-excluded list [Verified: same file, "Always excluded" line].
- The folder-stub rename + the `*.env` credential scrub are the only MCP-aware behaviors; there is **no manifest, no Python awareness, no Docker-image awareness, no registration capture** [Verified: bundle SKILL contains no "pyproject", "docker build", or "mcpServers"-capture step].

### 3.2 What `sanitize.sh` scrubs today (MCP-relevant rules)

- **`mcp/<client>/ → mcp/<mcp-client-N>/`** folder rename, run *before* the PII pass, with all in-file refs (`mcp/<client>/`, slash- and non-slash-prefixed) rewritten across every staging file; records placeholder `<mcp-client-stub>` [Verified: read sanitize.sh lines 30–54].
- **`*.env` value scrub**: keys matching `_(TOKEN|KEY|SECRET|PASSWORD|CREDENTIAL|COOKIE)=` → `CHANGE_ME_<KEY>`; `HTTPS?_PROXY=` → placeholder; URL values matching `.private-patterns` → `https://CHANGE_ME_SERVICE_URL`; residual corporate-domain patterns → `[redacted]` [Verified: read sanitize.sh lines 209–248].
- **`.claude.json` `mcpServers` scrub** (only on `--include-claude-json --scrub-claude-json`): `env` keys matching `token|secret|password|credential` → `CHANGE_ME_<key>`; non-local `https?://` env values → `https://YOUR_SERVICE_INSTANCE`; `/home/<user>/` inside `command` → `/home/CHANGE_ME_HOME/` [Verified: read `_ce_scrub_claude_json` lines 291–306].
- **The four ACME env files carry exactly these secret-bearing keys** [Verified: `grep -oE '^[A-Za-z_]+='` over `mcp/<mcp-client-3>/*.env`]: `confluence.env` → `CONFLUENCE_PERSONAL_TOKEN` (+ `CONFLUENCE_URL`, `CONFLUENCE_SSL_VERIFY`); `gitlab.env` → `GITLAB_PERSONAL_ACCESS_TOKEN`; `jira.env` → `JIRA_PERSONAL_TOKEN` (+ `JIRA_URL`, `JIRA_SSL_VERIFY`); `trivy.env` → `ACME_INTERNAL_PORTAL_COOKIE`. The `*_TOKEN`/`*_COOKIE` suffixes are caught by the existing env regex; **`ACME_INTERNAL_PORTAL_COOKIE` matches `_COOKIE`** so it is already covered [Verified: regex includes `COOKIE`].

### 3.3 What `/install` does with `mcp/` today

- Step 4 runs `npm ci` for every `~/.claude/mcp/*/` that has a `package.json`; explicit no-op if none [Verified: read install Step 4 loop].
- Step 4 also reminds to wire `ensure-mcp-health.sh` (SessionStart) and prints the scrubbed-placeholder refill guide [Verified: install Step 4 hook table + refill bullet].
- There is **no MCP registration step** — `mcpServers` entries are not added to `~/.claude.json`; the manual-merge tutorial only mentions `mcpServers` as a section to "compare and merge by hand" [Verified: read tutorial.sh `MERGE GUIDE` step 2].

### 3.4 bootstrap / adapt-project

- **Neither touches MCPs at all** [Verified: read both SKILLs end-to-end — no `mcp`, `mcpServers`, or `~/.claude/mcp` reference]. `/bootstrap` writes a *project* `.claude/` from scratch; `/adapt-project` fills ADAPT markers in a project. MCPs are **global** (`~/.claude/mcp/`, registered in `~/.claude.json`), so neither is the natural home — see §4.4.

### 3.5 Registration shape (keys only, no secrets)

`~/.claude.json → mcpServers` currently has 4 keys [Verified: read keys + field shape via python3, values withheld]:

| Key | type | Shape (fields only) |
|-----|------|---------------------|
| `acme-jira-http` | `http` | `url` (remote HTTP MCP — no local dir) |
| `acme-confluence-http` | `http` | `url` (remote HTTP MCP — no local dir) |
| `acme-gitlab-stdio` | stdio | `command` → `gitlab-mcp-wrapper.sh`, `env: {GITLAB_API_URL, GITLAB_READ_ONLY_MODE, USE_PIPELINE}` |
| `acme-trivy-stdio` | stdio | `command` → `trivy-mcp-wrapper.sh`, `args: []` |

The two stdio wrappers source their secrets from `mcp/<mcp-client-3>/*.env` at runtime and use `${HOME}`-relative paths internally [Verified: read both wrapper scripts — `ENV_FILE="${HOME}/.claude/mcp/<mcp-client-3>/..."`]. But the `command` value stored in `~/.claude.json` is an **absolute path** (`/home/user/.claude/mcp/...`) [Verified: desktop spec §7 registration example uses the absolute path; `_ce_scrub_claude_json` exists specifically to rewrite `/home/<user>/` in `command`]. That absolute path is the portability hazard the registration step must fix on the target.

---

## 4. Design

The spine is a **per-MCP manifest** — a small declarative file each `mcp/<name>/` dir ships — so the four skills stay generic.

### 4.1 The generic convention — `mcp/<name>/mcp.bundle.json`

Each MCP dir declares its own bundling contract. Absent file ⇒ safe defaults (today's behavior). Proposed schema [Speculative — new artifact]:

```jsonc
{
  "name": "desktop",                 // logical MCP name; default = dir basename
  "runtime": "docker",               // "node" | "python" | "docker" | "remote"
  "rehydrate": "docker-build",       // "npm-ci" | "pip-install" | "docker-build" | "none"
  "env_files": [],                   // *.env files carrying secrets (scrubbed by existing rules)
  "register": [                      // one entry per ~/.claude.json mcpServers key to emit
    {
      "key": "desktop",
      "type": "stdio",               // "stdio" | "http"
      "command": "{{MCP_DIR}}/desktop-mcp-wrapper.sh",  // {{MCP_DIR}} resolved on target
      "args": [],
      "env": {}
    }
  ],
  "scrub_stub": true                 // participate in the mcp/<name>→<mcp-client-N> rename
}
```

`{{MCP_DIR}}` is a new placeholder resolved at install time to the target's `$HOME/.claude/mcp/<name>` — this is the fix for the absolute-path hazard in §3.5. Examples derived from the verified state:

- **acme** (one dir, multiple servers): `runtime:"node"`/`rehydrate:"npm-ci"` for the gitlab wrapper + `runtime:"python"`? No — acme/trivy is **node today, Python after #2**. The manifest is what lets that migration be a one-line edit. `env_files: ["confluence.env","gitlab.env","jira.env","trivy.env"]`; `register:` the 4 keys from §3.5.
- **desktop**: `runtime:"docker"`, `rehydrate:"docker-build"`, `env_files: []`, one stdio `register` entry, `scrub_stub:false` (it has no client name to leak — it is org-neutral already).

> **Why a manifest, not more `if` branches:** the alternative (teach each skill to sniff `pyproject.toml` vs `package.json` vs `Dockerfile`) re-encodes the same knowledge four times and breaks the moment an MCP has *both* (e.g. a Node wrapper + a Dockerfile). The manifest is the single source of truth; the skills become generic interpreters of it [Speculative — design judgment].

### 4.2 `/bundle` changes

1. **Discover manifests**: for each `~/.claude/mcp/<name>/`, read `mcp.bundle.json` (or synthesize defaults). [Inferred: bundle already iterates `mcp/` for staging — read "What global scope bundles" mcp row.]
2. **Stage by runtime**: package code as today; additionally ensure Python MCPs ship `pyproject.toml`/`requirements.txt` and exclude `.venv/`, `__pycache__/`, `*.egg-info/` (parallel to the existing `node_modules/` exclude) [Inferred: `node_modules/` is excluded for the same reason — read "Always excluded"]. Docker MCPs ship `Dockerfile` only (no built image).
3. **Capture registration**: copy each manifest into the staging tree (it travels with the dir) **and** record the manifest's `register[]` entries into `MANIFEST.json` under a new `mcp_servers` array, so install can emit the snippet even without re-reading every dir [Speculative].
4. **Scrub** runs unchanged (see §5) — manifest declares `scrub_stub` and `env_files` so the scrubber knows scope without guessing.
5. Update the bundle SKILL's `mcp/` table row + scrub bullets to mention: manifest, Python/Docker runtimes, `register[]` capture, `.venv`/`__pycache__` excludes.

### 4.3 `/install` changes

1. **Rehydrate by runtime** (replaces today's npm-only loop): for each staged `mcp/<name>/`, dispatch on `rehydrate`:
   - `npm-ci` → `(cd … && npm ci)` (today's behavior),
   - `pip-install` → `(cd … && python3 -m venv .venv && .venv/bin/pip install -e .)` or `uv` per the dir,
   - `docker-build` → wrapper builds on first run (no install-time action, but **verify Docker present** and note it),
   - `none` → skip.
   [Verified: today's loop is npm-only — read install Step 4; this generalizes it.]
2. **Emit registration snippet (manual `!`)**: read `MANIFEST.json.mcp_servers` (fallback: each dir's manifest), resolve `{{MCP_DIR}}` → `$HOME/.claude/mcp/<name>`, and **present** a ready `jq`/`python3` merge command or a paste-ready `mcpServers` JSON block for the user to apply to `~/.claude.json` **manually via `!`** — never auto-written (classifier HARD block on `~/.claude.json`) [Verified: desktop spec §7 states the same constraint; `_ce_scrub_claude_json` shows `/home/<user>/` rewrite is needed].
3. **Refill `*.env`**: the existing refill guide already lists `CHANGE_ME_*`; add an explicit line per MCP env file so the user knows *which* token/cookie to paste (e.g. "`mcp/<mcp-client-3>/trivy.env` → `ACME_INTERNAL_PORTAL_COOKIE` from DevTools cookie") [Verified: refill guide structure in tutorial.sh `ci_print_refill_guide`].
4. Update install Step 4 prose + the hook/MCP section accordingly.

### 4.4 `/adapt-project` and `/bootstrap` changes

- **Scope decision: out of band for these two.** MCPs are global (`~/.claude/mcp/` + `~/.claude.json`); bootstrap/adapt-project operate on a *project* `.claude/` [Verified: both SKILLs write only project-scoped files]. Forcing MCP setup into them would be a scope violation.
- **Minimal touch**: add one **advisory line** to each — after their completion report, note: *"MCP servers are global; if this machine received an MCP bundle, run the `/install` MCP-registration step (presented snippet) — not handled here."* This keeps them honest without expanding their scope [Speculative — design judgment; the alternative of adding MCP logic is rejected as scope creep].

---

## 5. Secret-scrubbing model (reuse, don't reinvent)

**No new scrub mechanism.** Every secret the two new MCPs introduce is already covered or covered by extension of the existing passes [Verified: read sanitize.sh in full]:

| File (origin) | Secret(s) by role | Existing rule that catches it | Placeholder |
|---|---|---|---|
| `mcp/<mcp-client-3>/gitlab.env` | GitLab PAT | `*.env` key suffix `_(…\|TOKEN…)` → `CHANGE_ME_<KEY>` | `CHANGE_ME_GITLAB_PERSONAL_ACCESS_TOKEN` |
| `mcp/<mcp-client-3>/jira.env` | Jira PAT + corporate URL | `_TOKEN` rule; URL→`CHANGE_ME_SERVICE_URL` | `CHANGE_ME_*` / service-URL |
| `mcp/<mcp-client-3>/confluence.env` | Confluence PAT + URL | same | same |
| `mcp/<mcp-client-3>/trivy.env` | Internal-Portal session **cookie** | `_COOKIE` rule (regex already lists `COOKIE`) | `CHANGE_ME_ACME_INTERNAL_PORTAL_COOKIE` |
| `~/.claude.json` mcpServers | per-server `env` token/cookie; absolute `command` path | `_ce_scrub_claude_json` (`token\|secret\|password\|credential`; `/home/<user>/`→`/home/CHANGE_ME_HOME/`) | `CHANGE_ME_*` / rewritten path |
| `mcp/<mcp-client-3>/` folder name | org/client name | `mcp/<client>/→<mcp-client-N>/` stub rename | `<mcp-client-N>` |

**~~One verified gap to fix in the plan~~ — FIXED 2026-06-20:** the `.claude.json` env-key regex now includes `cookie` (`token|secret|password|credential|cookie`), and the `.mcpServers` scrub now also rewrites the **top-level `url`** of `http`-type servers (non-localhost `https?://` → `https://YOUR_SERVICE_INSTANCE`). Both fixes shipped in `sanitize.sh` with regression tests in `bin/tests/scrub-claude-json.test.sh` (10/10 green; bundle-import suite 109/0). The `desktop` MCP has `env:{}` so contributes no secret. These two items are no longer open — see §10.

**Refill on install** is the existing mechanism: every placeholder is recorded in `MANIFEST.json.scrubbed_placeholders` and surfaced by `ci_print_refill_guide` [Verified: read sanitize `_ce_scrub_record` + tutorial `ci_print_refill_guide`]. New manifest-introduced placeholder `{{MCP_DIR}}` must be added to that guide's known-conventions list and resolved at install (not refilled by hand).

## 6. Registration re-setup (manual on install)

- **Source of truth on target**: `MANIFEST.json.mcp_servers` (captured at bundle time) ⇒ resolved snippet.
- **Resolution**: `{{MCP_DIR}}` → `$HOME/.claude/mcp/<name>`; `/home/CHANGE_ME_HOME/` (from `.claude.json` scrub) → the target's `$HOME`.
- **Application**: **presented, never auto-written.** `~/.claude.json` is a classifier HARD block for the agent loop [Verified: desktop spec §7 + bash-firewall spec §6 both state `~/.claude.json`/`settings.json` edits are manual-`!` only]. Install prints either a `jq` merge one-liner or a paste-ready block; the user runs it via `!`.
- **HTTP MCPs** (`acme-jira-http`, `acme-confluence-http`) have no local dir and a `url` only — their registration is a pure `mcpServers` snippet (no rehydration); the manifest for them is `runtime:"remote"`, `rehydrate:"none"`, with `register[].type:"http"`.

## 7. Testing (CLAUDE.md Rule 7 — TDD)

Reuse the existing **bundle test-isolation pattern** (fake `~/.claude` home seeded with `.private-patterns`/`.private-renames`, per the bundle-import test memory) [Verified: bundle SKILL Step 5 verification + memory `project_bundle_test_isolation`].

- **Scrub round-trip (infra/unit)**: seed a fake home with `mcp/acme/x.env` (fake token) + `mcp/<mcp-client-1>/` (no env) + a `mcp.bundle.json`; run the export scrub; assert (a) `x.env` token → `CHANGE_ME_*`, (b) `mcp/acme/` → `<mcp-client-N>`, (c) `desktop` untouched, (d) `MANIFEST.json.mcp_servers` populated, (e) **no real token literal** present anywhere in staging (`grep -L` the fixture token). This is the Coverage row.
- **Registration emit (unit)**: from a fixture `MANIFEST.json.mcp_servers`, assert the install snippet resolves `{{MCP_DIR}}` to the fake `$HOME` and produces valid JSON (`python3 -c json.load`).
- **Rehydrate dispatch (unit)**: assert `runtime:node→npm ci`, `python→pip/uv`, `docker→build-noted`, `remote→skip` — using `command -v` stubs so nothing actually installs.
- **Infra**: `bash -n` on any new install/export helper; `docker compose --env-file … config` unaffected; `shellcheck` clean on edited scripts.
- Run the full `bin/tests/bundle-import.test.sh` suite (or its successor) and **paste pass/fail counts** as Coverage evidence — per Rule 7 tests must be executed, not just written.

## 8. Scope

**In:** the `mcp.bundle.json` convention; bundle discovery+staging+`MANIFEST.json.mcp_servers` capture; Python/Docker runtime awareness (`.venv`/`__pycache__` excludes); install rehydrate-dispatch + presented registration snippet + per-env refill lines; ~~the `.claude.json` env regex widening to include `cookie`~~ (done 2026-06-20, with top-level `url` scrub); the `{{MCP_DIR}}` placeholder + refill-guide entry; one advisory line each in bootstrap/adapt-project; tests above; doc updates to the four SKILLs + sanitize comments.

**Out:** auto-writing `~/.claude.json` or `settings.json` (always manual `!`); implementing desktop-mcp (#1) or the Python Trivy port (#2) — this spec consumes them; adding MCP setup *logic* to bootstrap/adapt-project beyond the advisory line; a new scrub engine; secret storage/rotation; non-ACME MCP marketplaces.

## 9. Blast radius

Five files + tests [Verified: enumerated against the actual files read]:
- `skills/bundle/SKILL.md` — mcp table row, scrub bullets, MANIFEST capture step.
- `skills/install/SKILL.md` — Step 4 rehydrate loop generalization + registration emit + refill lines.
- `skills/adapt-project/SKILL.md` + `skills/bootstrap/SKILL.md` — one advisory line each (no logic).
- `bin/lib/claude-export/core/sanitize.sh` — `cookie` regex widening (1 line); `.venv`/`__pycache__` staging excludes; `MANIFEST.json.mcp_servers` capture (likely in the caller `claude-export.sh`/`ce_write_manifest`, not sanitize itself — confirm in plan).
- `bin/lib/claude-import/core/tutorial.sh` — `{{MCP_DIR}}` in refill known-conventions; possibly the registration-snippet emitter (or a new `core/mcp.sh`).
- Indirect: `_CE_GENERIC_SKILLS` / `defaults.sh` if the manifest must be allow-listed for inclusion; `MANIFEST.json` schema version bump.

## 10. Open items to resolve in the plan

- **`mcp.bundle.json` vs convention-only**: is an explicit manifest worth it, or can `runtime` be sniffed (`pyproject.toml`→python, `package.json`→node, `Dockerfile`-only→docker) with a manifest only for the `register[]` block? Leaning manifest-for-register, sniff-for-runtime as a hybrid.
- **Where `MANIFEST.json.mcp_servers` is written** — `ce_write_manifest` vs the scope runner; confirm by reading `claude-export.sh`.
- **Python rehydration tool** — `pip -e .` vs `uv` (desktop spec §11 leaves uv-vs-pip open for #1; keep consistent).
- **acme single-dir, multi-server**: one `mcp.bundle.json` with 4 `register[]` entries, or per-server manifests? The dir holds 4 servers + 4 env files today.
- ~~**Cookie-in-env regex widening**~~ — **DONE 2026-06-20** (regex widened to include `cookie`; tested). No consumer relied on an unscrubbed `cookie` env key.
- ~~**HTTP MCP URLs**~~ — **DONE 2026-06-20**: the `.claude.json` scrub now rewrites the top-level `url` on `http` servers (the confirmed gap); localhost URLs are preserved (regression-tested). `acme-jira-http`/`acme-confluence-http` URLs no longer travel unscrubbed.
