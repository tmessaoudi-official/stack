"""WaylandDriver unit tests — input argv construction + D-Bus capture, all
mocked (no real GNOME/ydotool needed). Live input verification is deferred
until ydotool is installed (see docs/wayland-setup.md)."""
import io
import subprocess
import types

import pytest
from PIL import Image as PILImage

from desktop_mcp.drivers.wayland import _CLICK, _EVDEV, _PRESS, _RELEASE, WaylandDriver


def _png_bytes(w=320, h=200):
    buf = io.BytesIO()
    PILImage.new("RGB", (w, h), (1, 2, 3)).save(buf, format="PNG")
    return buf.getvalue()


@pytest.fixture
def calls(monkeypatch):
    """Capture every ydotool argv; subprocess.run is a no-op success."""
    seen = []

    def fake_run(argv, **kw):
        seen.append(argv)
        return types.SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr(subprocess, "run", fake_run)
    return seen


def test_cursor_position_unsupported():
    with pytest.raises(NotImplementedError, match="Wayland"):
        WaylandDriver().cursor_position()


def test_move_builds_absolute_mousemove(calls):
    WaylandDriver().move(100, 200)
    assert calls == [["ydotool", "mousemove", "--absolute", "-x", "100", "-y", "200"]]


def test_click_moves_then_clicks(calls):
    WaylandDriver().click(10, 20, "left")
    assert calls[0] == ["ydotool", "mousemove", "--absolute", "-x", "10", "-y", "20"]
    assert calls[1] == ["ydotool", "click", _CLICK["left"]]


def test_click_without_coords_skips_move(calls):
    WaylandDriver().click(None, None, "left")
    assert calls == [["ydotool", "click", _CLICK["left"]]]


def test_right_click_uses_right_code(calls):
    WaylandDriver().right_click(5, 6)
    assert calls[-1] == ["ydotool", "click", _CLICK["right"]]


def test_double_click_emits_two_clicks(calls):
    WaylandDriver().double_click(1, 2)
    click_calls = [c for c in calls if c[:2] == ["ydotool", "click"]]
    assert click_calls == [["ydotool", "click", _CLICK["left"]]] * 2


def test_drag_press_move_release(calls):
    WaylandDriver().drag(50, 60, "left")
    assert calls[0] == ["ydotool", "click", _PRESS["left"]]
    assert calls[1] == ["ydotool", "mousemove", "--absolute", "-x", "50", "-y", "60"]
    assert calls[2] == ["ydotool", "click", _RELEASE["left"]]


def test_scroll_uses_wheel(calls):
    WaylandDriver().scroll(0, -3)
    assert calls == [["ydotool", "mousemove", "--wheel", "-x", "0", "-y", "-3"]]


def test_type_invokes_ydotool_type(calls):
    WaylandDriver().type("hello")
    assert calls == [["ydotool", "type", "hello"]]


def test_key_builds_evdev_press_release_sequence(calls):
    WaylandDriver().key("ctrl+c")
    expected = ["ydotool", "key",
                f"{_EVDEV['ctrl']}:1", f"{_EVDEV['c']}:1",
                f"{_EVDEV['c']}:0", f"{_EVDEV['ctrl']}:0"]
    assert calls == [expected]


def test_key_unknown_raises(calls):
    with pytest.raises(RuntimeError, match="unknown key"):
        WaylandDriver().key("ctrl+nope")


def test_ydotool_missing_raises_runtimeerror(monkeypatch):
    def boom(*a, **k):
        raise FileNotFoundError("ydotool")
    monkeypatch.setattr(subprocess, "run", boom)
    with pytest.raises(RuntimeError, match="ydotool not installed"):
        WaylandDriver().move(1, 1)


def test_ydotool_failure_mentions_daemon(monkeypatch):
    def boom(*a, **k):
        raise subprocess.CalledProcessError(1, "ydotool", stderr="no socket")
    monkeypatch.setattr(subprocess, "run", boom)
    with pytest.raises(RuntimeError, match="ydotoold"):
        WaylandDriver().move(1, 1)


def test_screenshot_uses_first_successful_backend():
    payload = _png_bytes()
    d = WaylandDriver()
    tried = []

    def fail(path):
        tried.append("a")
        return False

    def ok(path):
        tried.append("b")
        with open(path, "wb") as f:
            f.write(payload)
        return True

    d._capture_a, d._capture_b = fail, ok
    d._capture_chain = ("a", "b")
    assert d.screenshot() == payload
    assert tried == ["a", "b"]  # stops at first success


def test_screenshot_all_backends_fail_raises():
    d = WaylandDriver()
    d._capture_x = lambda path: False
    d._capture_chain = ("x",)
    with pytest.raises(RuntimeError, match="all Wayland capture backends failed"):
        d.screenshot()


def test_screenshot_records_backend_exceptions():
    d = WaylandDriver()

    def boom(path):
        raise RuntimeError("portal denied")

    d._capture_x = boom
    d._capture_chain = ("x",)
    with pytest.raises(RuntimeError, match="portal denied"):
        d.screenshot()


def test_capture_shell_dbus_parses_true(monkeypatch):
    payload = _png_bytes()

    def fake_run(argv, **kw):
        path = argv[-1]
        with open(path, "wb") as f:
            f.write(payload)
        return types.SimpleNamespace(returncode=0, stdout="(true, '%s')" % path, stderr="")

    monkeypatch.setattr(subprocess, "run", fake_run)
    d = WaylandDriver()
    d._capture_chain = ("shell_dbus",)
    assert d.screenshot() == payload


def test_screen_size_reads_png_dimensions(monkeypatch):
    monkeypatch.setattr(WaylandDriver, "screenshot", lambda self: _png_bytes(640, 480))
    assert WaylandDriver().screen_size() == (640, 480)
