"""PS-level unit test for the `key` verb combo parser (Get-KeyEvents).

The combo->virtual-key logic lives in windows_helper.ps1, so it can only be
exercised by PowerShell. This test dot-sources the helper's *functions* (with
$Verb unset, so the dispatch switch is skipped) via powershell.exe and asserts
the ordered (vk, up) event sequence for representative combos -- including the
Win key, which the old SendKeys path could not express.

Skipped automatically where powershell.exe is unavailable (CI / non-WSL), so the
pure-Python suite still runs anywhere.
"""
import base64
import shutil
import subprocess
from pathlib import Path

import pytest

_HELPER = Path(__file__).resolve().parent.parent / "src" / "desktop_mcp" / "windows_helper.ps1"

pytestmark = pytest.mark.skipif(
    shutil.which("powershell.exe") is None, reason="powershell.exe not available"
)

# Expected (vk:up) sequences. vk in decimal: LWIN=91 R=82 CTRL=17 A=65 ALT=18 F4=115 ESC=27.
EXPECT = {
    "win+r": "91:0,82:0,82:1,91:1",
    "ctrl+a": "17:0,65:0,65:1,17:1",
    "alt+F4": "18:0,115:0,115:1,18:1",
    "esc": "27:0,27:1",
}


def _run_get_key_events(combos):
    """Dot-source the helper functions and emit '<combo>=<vk:up,...>' per line."""
    body = _HELPER.read_text(encoding="utf-8")
    emit = "\n".join(
        f"$e = Get-KeyEvents '{c}'; "
        f"$s = ($e | ForEach-Object {{ '{{0}}:{{1}}' -f $_.vk, ([int]$_.up) }}) -join ','; "
        f"Write-Output ('{c}=' + $s)"
        for c in combos
    )
    script = "$Verb=$null\n" + body + "\n" + emit
    encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    proc = subprocess.run(
        ["powershell.exe", "-NoProfile", "-EncodedCommand", encoded],
        capture_output=True,
    )
    assert proc.returncode == 0, proc.stderr.decode(errors="replace")
    out = {}
    for line in proc.stdout.decode(errors="replace").splitlines():
        line = line.strip()
        if "=" in line and not line.startswith("<"):
            k, _, v = line.partition("=")
            out[k] = v
    return out


def test_key_event_sequences():
    got = _run_get_key_events(list(EXPECT))
    for combo, expected in EXPECT.items():
        assert got.get(combo) == expected, f"{combo}: got {got.get(combo)!r}, want {expected!r}"
