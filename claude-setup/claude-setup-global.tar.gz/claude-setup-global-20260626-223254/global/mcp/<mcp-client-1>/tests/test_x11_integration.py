import os
import shutil

import pytest

pytestmark = pytest.mark.skipif(
    not os.environ.get("DISPLAY") or shutil.which("Xvfb") is None,
    reason="needs an X display (run inside the container or under xvfb-run)",
)


def _driver():
    from desktop_mcp.drivers.x11 import X11Driver

    return X11Driver()


def test_screen_size_matches_xvfb():
    w, h = _driver().screen_size()
    assert (w, h) == (1280, 800)


def test_screenshot_is_png():
    data = _driver().screenshot()
    assert data.startswith(b"\x89PNG\r\n\x1a\n")
    assert len(data) > 100


def test_move_then_cursor_position():
    d = _driver()
    d.move(100, 120)
    assert d.cursor_position() == (100, 120)
