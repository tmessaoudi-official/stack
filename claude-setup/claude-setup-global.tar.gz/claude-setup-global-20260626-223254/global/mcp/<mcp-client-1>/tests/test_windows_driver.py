"""WindowsDriver unit tests — the _run_ps shell-out seam is mocked, so these
run anywhere (no real Windows / powershell.exe needed). Live capture is proven
separately by a smoke run on the WSL host."""
import base64

import pytest

from desktop_mcp.drivers.base import Driver
from desktop_mcp.drivers.windows import WindowsDriver

# 8-byte PNG signature + filler — enough to assert "decoded real PNG bytes".
_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 16


@pytest.fixture
def drv(monkeypatch):
    d = WindowsDriver()
    calls = []

    def fake_run_ps(verb, *args):
        calls.append((verb, args))
        if verb == "screenshot":
            return base64.b64encode(_PNG) + b"\r\n"  # PS appends CRLF
        if verb == "screen_size":
            return b"1536 960\r\n"
        if verb == "cursor_position":
            return b"100 200\r\n"
        return b"ok\r\n"

    monkeypatch.setattr(d, "_run_ps", fake_run_ps)
    d._calls = calls  # type: ignore[attr-defined]
    return d


def test_constructs_as_driver():
    # Construction must be cheap and must not raise (matches wayland driver).
    assert isinstance(WindowsDriver(), Driver)


def test_screenshot_decodes_png(drv):
    out = drv.screenshot()
    assert isinstance(out, bytes)
    assert out.startswith(b"\x89PNG"), "screenshot must return decoded PNG bytes"
    assert drv._calls[0] == ("screenshot", ())


def test_screen_size_parses(drv):
    assert drv.screen_size() == (1536, 960)
    assert drv._calls[0][0] == "screen_size"


def test_cursor_position_parses(drv):
    assert drv.cursor_position() == (100, 200)


def test_move_argv(drv):
    drv.move(10, 20)
    assert drv._calls == [("move", (10, 20))]


def test_click_argv(drv):
    drv.click(30, 40, "left")
    assert drv._calls == [("click", (30, 40, "left"))]


def test_right_click_argv(drv):
    drv.right_click(5, 6)
    assert drv._calls == [("right_click", (5, 6))]


def test_double_click_argv(drv):
    drv.double_click(7, 8)
    assert drv._calls == [("double_click", (7, 8))]


def test_drag_argv(drv):
    drv.drag(11, 12, "left")
    assert drv._calls == [("drag", (11, 12, "left"))]


def test_scroll_argv(drv):
    drv.scroll(0, 3)
    assert drv._calls == [("scroll", (0, 3))]


def test_type_argv(drv):
    drv.type("hello world")
    assert drv._calls == [("type", ("hello world",))]


def test_key_argv(drv):
    drv.key("ctrl+c")
    assert drv._calls == [("key", ("ctrl+c",))]


def test_focus_argv_ok(drv):
    # The fixture's fake_run_ps returns "ok\r\n" by default -> focus succeeds.
    assert drv.focus("mspaint") is True
    assert drv._calls == [("focus", ("mspaint",))]


def test_focus_failed_returns_false(monkeypatch):
    d = WindowsDriver()
    monkeypatch.setattr(d, "_run_ps", lambda verb, *a: b"focus-failed\r\n")
    assert d.focus("nope") is False
