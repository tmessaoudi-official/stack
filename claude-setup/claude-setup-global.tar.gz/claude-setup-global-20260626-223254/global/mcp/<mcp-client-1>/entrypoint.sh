#!/usr/bin/env bash
# Container entrypoint: boot the virtual X stack, then exec the MCP on stdio.
set -euo pipefail

export DISPLAY=:99
# python-xlib (via pyautogui) requires an Xauthority file to exist; -ac
# disables host access control (the container is the sandbox — spec §9).
export XAUTHORITY="${HOME:-/root}/.Xauthority"
touch "$XAUTHORITY"
Xvfb :99 -screen 0 1280x800x24 -ac -nolisten tcp >/dev/null 2>&1 &

# Wait for X to accept connections (max ~5s).
for _ in $(seq 1 50); do
  xdpyinfo -display :99 >/dev/null 2>&1 && break
  sleep 0.1
done

fluxbox >/dev/null 2>&1 &
x11vnc -display :99 -forever -shared -nopw -quiet -bg >/dev/null 2>&1
websockify --web /usr/share/novnc 6080 localhost:5900 >/dev/null 2>&1 &

# stdout/stdin are the MCP JSON-RPC channel — nothing above wrote to stdout.
exec python3 -m desktop_mcp
