#!/usr/bin/env bash
# Host stdio entrypoint for the WINDOWS driver — drives the REAL Windows desktop
# from inside WSL via powershell.exe interop. NOT sandboxed: input/capture hit the
# live Windows session. Coordinates are Windows virtual-screen pixels.
#
# This mode requires WSL->Windows interop (powershell.exe on PATH). WSLg windows
# (Linux GUI apps) are RAIL windows on the same Windows desktop, so this driver
# also captures them.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DESKTOP_MCP_DRIVER=windows

# Preflight: powershell.exe must be reachable, or the driver cannot work. Fail
# loudly with the fix — never crash later with a raw subprocess error. stdout is
# the MCP JSON-RPC channel, so all diagnostics go to stderr.
if ! command -v powershell.exe >/dev/null 2>&1; then
  {
    echo "[desktop-mcp:windows] powershell.exe not found on PATH."
    echo "  This driver needs WSL->Windows interop. Check:"
    echo "    - You are running inside WSL2 on Windows (you appear not to be if this fails)."
    echo "    - /etc/wsl.conf has [interop] enabled=true and appendWindowsPath=true (default)."
    echo "    - cat /proc/sys/fs/binfmt_misc/WSLInterop shows 'enabled'."
  } >&2
  exit 1
fi

# First-run bootstrap: build the project venv if missing (mirrors the x11 wrapper).
# All uv output -> stderr; stdout is reserved for MCP JSON-RPC.
if [[ ! -x "$DIR/.venv/bin/python" ]]; then
  if command -v uv >/dev/null 2>&1; then
    ( cd "$DIR" && { uv sync --frozen || uv sync; } ) >&2 || true
  fi
  if [[ ! -x "$DIR/.venv/bin/python" ]]; then
    {
      echo "[desktop-mcp:windows] Python venv missing and could not be built automatically."
      command -v uv >/dev/null 2>&1 \
        || echo "  - 'uv' is not installed. Install it:  curl -LsSf https://astral.sh/uv/install.sh | sh"
      echo "  - Build the venv manually:  cd \"$DIR\" && uv sync"
      echo "  - Then re-launch this MCP from Claude Code."
    } >&2
    exit 1
  fi
fi

# stdout/stdin are the MCP JSON-RPC channel — write nothing to stdout above.
exec "$DIR/.venv/bin/python" -m desktop_mcp
