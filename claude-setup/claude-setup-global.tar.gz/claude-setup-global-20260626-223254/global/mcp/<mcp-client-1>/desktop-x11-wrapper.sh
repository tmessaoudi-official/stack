#!/usr/bin/env bash
# Host stdio entrypoint for the REAL X11 display (DISPLAY=:0) — NOT sandboxed.
# Input goes to the focused window; capture grabs the X root.
#
# This mode is for a GENUINE X11 login session, where it works fully.
# On a GNOME/Wayland session :0 is XWayland: this wrapper still connects
# (see the cookie-normalization below), but capture is BLACK and input cannot
# reach native Wayland windows — use desktop-wayland-wrapper.sh instead.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DESKTOP_MCP_DRIVER=x11
export DISPLAY="${DISPLAY:-:0}"

if [ -z "${XAUTHORITY:-}" ]; then
  if [ -f "$HOME/.Xauthority" ]; then
    export XAUTHORITY="$HOME/.Xauthority"          # real X11 session
  else
    # XWayland-under-Wayland: mutter writes its cookie with an EMPTY display
    # number (host/unix:), which C-Xlib accepts but python-xlib rejects.
    # Re-emit it as an explicit host/unix:<N> entry python-xlib can match.
    for c in "${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"/.mutter-Xwaylandauth.*; do
      [ -e "$c" ] || continue
      hex="$(xauth -f "$c" list 2>/dev/null | awk '/MIT-MAGIC-COOKIE/{print $3; exit}')"
      [ -n "$hex" ] || continue
      norm="${XDG_RUNTIME_DIR:-/tmp}/dmcp-x11-xauth"
      rm -f "$norm"
      xauth -f "$norm" add "$(hostname)/unix:${DISPLAY#:}" \
        MIT-MAGIC-COOKIE-1 "$hex" >/dev/null 2>&1 || true
      export XAUTHORITY="$norm"
      break
    done
  fi
fi

# First-run bootstrap: build the project venv if missing (self-healing, mirrors the
# trivy wrapper). All uv output → stderr; stdout is reserved for MCP JSON-RPC. If the
# venv cannot be created (uv absent, sync failed), report the manual steps and stop —
# never exit silently, never crash with a raw error.
if [[ ! -x "$DIR/.venv/bin/python" ]]; then
  if command -v uv >/dev/null 2>&1; then
    ( cd "$DIR" && { uv sync --frozen || uv sync; } ) >&2 || true
  fi
  if [[ ! -x "$DIR/.venv/bin/python" ]]; then
    {
      echo "[desktop-mcp] Python venv missing and could not be built automatically."
      command -v uv >/dev/null 2>&1 \
        || echo "  - 'uv' is not installed. Install it:  curl -LsSf https://astral.sh/uv/install.sh | sh"
      echo "  - Build the venv manually:  cd \"$DIR\" && uv sync"
      echo "  - Then re-launch this MCP from Claude Code."
    } >&2
    exit 1
  fi
fi

# stdout/stdin are the MCP JSON-RPC channel — write nothing to stdout above.
exec "$DIR/.venv/bin/python" -m desktop_mcp
