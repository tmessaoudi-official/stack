#!/usr/bin/env bash
# wsl-setup.sh — set up the desktop-mcp SANDBOX server on WSL2 Ubuntu.
#
# The sandbox server runs entirely inside a Docker container (Xvfb + fluxbox
# + x11vnc + noVNC), so the host display stack is irrelevant — WSL needs only
# a working Docker. This is the one desktop-mcp mode that fits WSL; the x11 and
# wayland modes target a real Linux desktop session, which WSL does not provide.
#
# Usage:   bash wsl-setup.sh            # check docker, chmod, build if needed
#          bash wsl-setup.sh --rebuild  # force a fresh image build
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IMAGE="desktop-mcp:latest"
WRAPPER="$DIR/desktop-mcp-wrapper.sh"

log() { printf '[wsl-setup] %s\n' "$*" >&2; }

# 1. Docker present and daemon reachable.
if ! command -v docker >/dev/null 2>&1; then
  log "ERROR: docker not found."
  log "  Install Docker Desktop and enable WSL integration for this distro,"
  log "  or install Docker Engine inside the distro."
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  log "ERROR: docker daemon not reachable."
  log "  Start Docker Desktop, or in-distro: sudo service docker start"
  exit 1
fi
log "docker OK"

# 2. Sanity-check that the whole desktop/ directory was copied over.
for f in Dockerfile entrypoint.sh pyproject.toml desktop-mcp-wrapper.sh src; do
  if [ ! -e "$DIR/$f" ]; then
    log "ERROR: missing '$DIR/$f' — copy the entire desktop/ directory, not just this script."
    exit 1
  fi
done
log "required files present"

# 3. Restore the executable bit (git core.fileMode=false drops +x on copy/clone).
chmod +x "$WRAPPER"
log "wrapper executable: $WRAPPER"

# 4. Build the image (idempotent: skips if already present unless --rebuild).
if [ "${1:-}" = "--rebuild" ] || ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
  log "building $IMAGE (first run takes a few minutes) ..."
  docker build --load -t "$IMAGE" "$DIR" >&2
  log "build complete"
else
  log "$IMAGE already built (pass --rebuild to force a fresh build)"
fi

# 5. Emit the registration block — paste into mcpServers in ~/.claude.json.
log "SETUP COMPLETE. Add this entry to the \"mcpServers\" object in ~/.claude.json:"
cat <<EOF

  "desktop": {
    "command": "$WRAPPER",
    "args": []
  }

EOF
log "Then restart Claude Code. The mcp__desktop__* tools will appear."
log "View the virtual desktop in a Windows browser at: http://localhost:6080"
