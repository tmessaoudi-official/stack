#!/usr/bin/env bash
# Host stdio entrypoint for the REAL Wayland desktop — NOT sandboxed.
# Capture: org.gnome.Shell.Screenshot D-Bus (works out of the box on GNOME).
# Input:   ydotool -> ydotoold -> /dev/uinput (REQUIRES setup, see
#          docs/wayland-setup.md). Input goes to the focused window.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DESKTOP_MCP_DRIVER=wayland

# ydotoold listening socket (input path). Capture uses the session D-Bus,
# inherited from the environment — no socket needed for screenshots.
export YDOTOOL_SOCKET="${YDOTOOL_SOCKET:-${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/.ydotool_socket}"

# First-run bootstrap: build the project venv if missing (self-healing, mirrors the
# trivy wrapper). All uv output → stderr; stdout is reserved for MCP JSON-RPC. If the
# venv cannot be created (uv absent, sync failed), report the manual steps and stop —
# never exit silently, never crash with a raw error.
if [[ ! -x "$DIR/.venv/bin/python" ]]; then
  if command -v uv >/dev/null 2>&1; then
    ( cd "$DIR" && { uv sync --frozen || uv sync; } ) >&2 || true
  fi
  if [[ ! -x "$DIR/.venv/bin/python" ]]; then
    {
      echo "[desktop-mcp] Python venv missing and could not be built automatically."
      command -v uv >/dev/null 2>&1 \
        || echo "  - 'uv' is not installed. Install it:  curl -LsSf https://astral.sh/uv/install.sh | sh"
      echo "  - Build the venv manually:  cd \"$DIR\" && uv sync"
      echo "  - Then re-launch this MCP from Claude Code."
    } >&2
    exit 1
  fi
fi

# stdout/stdin are the MCP JSON-RPC channel — write nothing to stdout above.
exec "$DIR/.venv/bin/python" -m desktop_mcp
