#!/usr/bin/env bash
# Host stdio entrypoint registered in ~/.claude.json. Builds the image on
# first run (to stderr — stdout is reserved for MCP JSON-RPC), then runs it.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IMAGE="desktop-mcp:latest"

if ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
  echo "[desktop-mcp] building $IMAGE (first run)..." >&2
  # --load ensures the image lands in the local image store even when the
  # active buildx builder uses the docker-container driver.
  docker build --load -t "$IMAGE" "$DIR" >&2
fi

exec docker run -i --rm -p 6080:6080 "$IMAGE"
