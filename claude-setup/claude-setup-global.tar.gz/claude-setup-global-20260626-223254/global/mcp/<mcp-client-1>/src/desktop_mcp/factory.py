"""Driver selection — platform + env, overridable by DESKTOP_MCP_DRIVER."""
import os
import sys

from .drivers.base import Driver


def select_driver_name(override, platform, session_type):
    if override:
        return override
    if platform.startswith("win"):
        return "windows"
    if session_type == "wayland":
        return "wayland"
    return "x11"


def make_driver(override: str | None = None) -> Driver:
    name = select_driver_name(
        override or os.environ.get("DESKTOP_MCP_DRIVER"),
        sys.platform,
        os.environ.get("XDG_SESSION_TYPE", ""),
    )
    if name == "x11":
        from .drivers.x11 import X11Driver

        return X11Driver()
    if name == "wayland":
        from .drivers.wayland import WaylandDriver

        return WaylandDriver()
    if name == "windows":
        from .drivers.windows import WindowsDriver

        return WindowsDriver()
    raise ValueError(f"Unknown driver: {name}")
