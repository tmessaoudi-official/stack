"""Wayland host driver — real GNOME desktop control (NOT sandboxed).

Capture: ``org.gnome.Shell.Screenshot`` D-Bus (no install needed).
Input:   ``ydotool`` → ``ydotoold`` → ``/dev/uinput`` (privileged setup
         required — see ``docs/wayland-setup.md``).

Limits (honest, by design of Wayland):
  * ``cursor_position`` is unsupported — Wayland exposes no global pointer
    query. It raises NotImplementedError.
  * Input commands target ydotool >= 1.0 syntax; they are unit-tested for
    argv construction and must be verified LIVE once ydotool is installed
    (the empirical risk recorded in the plan). Capture works today.
"""
import io
import os
import shutil
import subprocess
import tempfile
import urllib.parse

from PIL import Image as PILImage

from .base import Driver

_DOC = "see docs/wayland-setup.md"

# evdev keycodes — ydotool's `key` takes numeric codes, not names.
_EVDEV = {
    "ctrl": 29, "control": 29, "leftctrl": 29, "rightctrl": 97,
    "shift": 42, "leftshift": 42, "rightshift": 54,
    "alt": 56, "leftalt": 56, "altgr": 100,
    "super": 125, "meta": 125, "win": 125,
    "enter": 28, "return": 28, "tab": 15, "esc": 1, "escape": 1,
    "backspace": 14, "delete": 111, "insert": 110, "space": 57,
    "up": 103, "down": 108, "left": 105, "right": 106,
    "home": 102, "end": 107, "pageup": 104, "pagedown": 109,
    "capslock": 58, "minus": 12, "equal": 13,
}
# digits 1..9,0 -> 2..11
_EVDEV.update({d: 2 + i for i, d in enumerate("1234567890")})
# letters a..z
_EVDEV.update({
    "a": 30, "b": 48, "c": 46, "d": 32, "e": 18, "f": 33, "g": 34, "h": 35,
    "i": 23, "j": 36, "k": 37, "l": 38, "m": 50, "n": 49, "o": 24, "p": 25,
    "q": 16, "r": 19, "s": 31, "t": 20, "u": 22, "v": 47, "w": 17, "x": 45,
    "y": 21, "z": 44,
})
# function keys f1..f12
_EVDEV.update({"f1": 59, "f2": 60, "f3": 61, "f4": 62, "f5": 63, "f6": 64,
               "f7": 65, "f8": 66, "f9": 67, "f10": 68, "f11": 87, "f12": 88})

# ydotool click button codes: 0x40 press-bit | 0x80 release-bit | index.
_PRESS = {"left": "0x40", "right": "0x41", "middle": "0x42"}
_RELEASE = {"left": "0x80", "right": "0x81", "middle": "0x82"}
_CLICK = {"left": "0xC0", "right": "0xC1", "middle": "0xC2"}  # press+release


class WaylandDriver(Driver):
    """Drives the real GNOME/Wayland session. Construction is cheap and never
    probes hardware; methods fail loudly with a doc pointer if tooling is
    missing, so the driver is constructible (and unit-testable) anywhere."""

    def __init__(self) -> None:
        # Capture backends tried in order until one yields a non-empty PNG.
        # Each is a sanctioned path; which works depends on GNOME version +
        # installed tooling (see docs/wayland-setup.md):
        #   portal         — org.freedesktop.portal.Screenshot via jeepney
        #                    (install-free; may show a one-time consent dialog)
        #   gnome_screenshot — `gnome-screenshot -f` (needs the apt package)
        #   shell_dbus     — org.gnome.Shell.Screenshot (works < GNOME 41;
        #                    AccessDenied on modern GNOME)
        self._capture_chain = ("portal", "gnome_screenshot", "shell_dbus")

    # --- input plumbing -------------------------------------------------
    def _ydotool(self, *args: str) -> None:
        try:
            subprocess.run(["ydotool", *args], check=True,
                           capture_output=True, text=True)
        except FileNotFoundError as e:
            raise RuntimeError(f"ydotool not installed — {_DOC}") from e
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"ydotool failed (exit {e.returncode}): {e.stderr.strip()} "
                f"— is ydotoold running and YDOTOOL_SOCKET set? {_DOC}"
            ) from e

    # --- capture --------------------------------------------------------
    def _capture_shell_dbus(self, path: str) -> bool:
        """Legacy org.gnome.Shell.Screenshot — denied on modern GNOME."""
        out = subprocess.run(
            ["gdbus", "call", "--session",
             "--dest", "org.gnome.Shell.Screenshot",
             "--object-path", "/org/gnome/Shell/Screenshot",
             "--method", "org.gnome.Shell.Screenshot.Screenshot",
             "true", "false", path],
            capture_output=True, text=True,
        )
        return out.returncode == 0 and "true" in out.stdout.lower()

    def _capture_gnome_screenshot(self, path: str) -> bool:
        """`gnome-screenshot -f` — needs the apt package installed."""
        if not shutil.which("gnome-screenshot"):
            return False
        r = subprocess.run(["gnome-screenshot", "-f", path],
                           capture_output=True, text=True)
        return r.returncode == 0

    def _capture_portal(self, path: str) -> bool:
        """org.freedesktop.portal.Screenshot via jeepney — install-free.
        May raise a one-time GNOME consent dialog. Async Request/Response."""
        from jeepney import DBusAddress, MatchRule, new_method_call
        from jeepney.bus_messages import message_bus
        from jeepney.io.blocking import open_dbus_connection

        conn = open_dbus_connection(bus="SESSION")
        try:
            token = "dmcp_shot"
            sender = conn.unique_name[1:].replace(".", "_")
            req_path = f"/org/freedesktop/portal/desktop/request/{sender}/{token}"
            match = MatchRule(type="signal", path=req_path,
                              interface="org.freedesktop.portal.Request",
                              member="Response")
            conn.send_and_get_reply(message_bus.AddMatch(match))
            with conn.filter(match) as queue:
                portal = DBusAddress(
                    "/org/freedesktop/portal/desktop",
                    bus_name="org.freedesktop.portal.Desktop",
                    interface="org.freedesktop.portal.Screenshot")
                opts = {"handle_token": ("s", token),
                        "interactive": ("b", False)}
                conn.send_and_get_reply(
                    new_method_call(portal, "Screenshot", "sa{sv}", ("", opts)))
                resp = conn.recv_until_filtered(queue, timeout=120)
            code, results = resp.body
            if code != 0:
                return False  # user denied / cancelled
            uri = results["uri"][1]
            src = urllib.parse.unquote(urllib.parse.urlparse(uri).path)
            shutil.copyfile(src, path)
            try:
                os.unlink(src)  # portal writes into the runtime dir; clean up
            except OSError:
                pass
            return True
        finally:
            conn.close()

    def screenshot(self) -> bytes:
        fd, path = tempfile.mkstemp(suffix=".png", prefix="dmcp-wl-")
        os.close(fd)
        try:
            errors = []
            for backend in self._capture_chain:
                try:
                    if getattr(self, f"_capture_{backend}")(path) \
                            and os.path.getsize(path) > 0:
                        with open(path, "rb") as f:
                            return f.read()
                    errors.append(f"{backend}: no image produced")
                except Exception as e:  # try the next backend, record why
                    errors.append(f"{backend}: {type(e).__name__}: {e}")
            raise RuntimeError(
                "all Wayland capture backends failed [" + "; ".join(errors)
                + f"] — {_DOC}")
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass

    def screen_size(self) -> tuple[int, int]:
        img = PILImage.open(io.BytesIO(self.screenshot()))
        return (int(img.width), int(img.height))

    def cursor_position(self) -> tuple[int, int]:
        raise NotImplementedError(
            "cursor_position is unsupported on Wayland — no global pointer "
            f"query exists. {_DOC}")

    # --- pointer --------------------------------------------------------
    def move(self, x: int, y: int) -> None:
        self._ydotool("mousemove", "--absolute", "-x", str(x), "-y", str(y))

    def click(self, x, y, button: str = "left") -> None:
        if x is not None and y is not None:
            self.move(x, y)
        self._ydotool("click", _CLICK[button])

    def double_click(self, x, y) -> None:
        if x is not None and y is not None:
            self.move(x, y)
        self._ydotool("click", _CLICK["left"])
        self._ydotool("click", _CLICK["left"])

    def right_click(self, x, y) -> None:
        if x is not None and y is not None:
            self.move(x, y)
        self._ydotool("click", _CLICK["right"])

    def drag(self, x: int, y: int, button: str = "left") -> None:
        self._ydotool("click", _PRESS[button])
        self.move(x, y)
        self._ydotool("click", _RELEASE[button])

    def scroll(self, dx: int, dy: int) -> None:
        # ydotool >= 1.0 wheel movement; verify live (see _DOC).
        self._ydotool("mousemove", "--wheel", "-x", str(dx), "-y", str(dy))

    # --- keyboard -------------------------------------------------------
    def type(self, text: str) -> None:
        self._ydotool("type", text)

    def key(self, combo: str) -> None:
        try:
            codes = [_EVDEV[k.strip().lower()] for k in combo.split("+")]
        except KeyError as e:
            raise RuntimeError(
                f"unknown key {e} in combo {combo!r}; supported keys are in "
                f"_EVDEV ({_DOC})") from e
        seq = [f"{c}:1" for c in codes] + [f"{c}:0" for c in reversed(codes)]
        self._ydotool("key", *seq)
