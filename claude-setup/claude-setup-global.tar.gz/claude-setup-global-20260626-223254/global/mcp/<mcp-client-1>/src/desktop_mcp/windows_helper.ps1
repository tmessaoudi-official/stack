# windows_helper.ps1 — Windows side of the desktop-mcp Windows driver.
# Runs on the Windows host; captures the real desktop and injects Win32 input.
# stdout carries the result (base64 PNG / "W H" / "x y" / "ok"); errors -> stderr + nonzero exit.
#
# Driven from WSL via powershell.exe -EncodedCommand (NOT -File: a .ps1 on the
# \\wsl.localhost UNC path trips the AuthorizationManager zone check). The Python
# driver prepends "$Verb=...; $A1=...; $A2=...; $A3=..." before this body, so these
# variables are already set when execution reaches here. For a manual run, assign
# them first, e.g.:  $Verb='screen_size'; . .\windows_helper.ps1
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public struct POINT { public int X; public int Y; }
public static class Win32 {
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] public static extern short VkKeyScan(char ch);
  // --- foreground-steal surface (see Set-Foreground / Trap 6) ---
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a, uint b, UIntPtr p, uint f);
  public const uint LEFTDOWN=0x0002, LEFTUP=0x0004, RIGHTDOWN=0x0008, RIGHTUP=0x0010,
                    MIDDLEDOWN=0x0020, MIDDLEUP=0x0040, WHEEL=0x0800;
  public const uint KEYUP=0x0002, KEYEXT=0x0001;
}
"@

function Get-BtnFlags([string]$name) {
  switch ($name) {
    "right"  { @([Win32]::RIGHTDOWN,  [Win32]::RIGHTUP) }
    "middle" { @([Win32]::MIDDLEDOWN, [Win32]::MIDDLEUP) }
    default  { @([Win32]::LEFTDOWN,   [Win32]::LEFTUP) }
  }
}

function Invoke-ClickAt([int]$x, [int]$y, [string]$name) {
  [Win32]::SetCursorPos($x, $y) | Out-Null
  $f = Get-BtnFlags $name
  [Win32]::mouse_event($f[0], 0, 0, 0, [UIntPtr]::Zero)
  [Win32]::mouse_event($f[1], 0, 0, 0, [UIntPtr]::Zero)
}

# Escape literal text for SendKeys (its metachars: + ^ % ~ ( ) { } [ ]).
function Get-EscapedText([string]$s) {
  $special = '+^%~(){}[]'
  $sb = New-Object System.Text.StringBuilder
  foreach ($c in $s.ToCharArray()) {
    if ($special.IndexOf($c) -ge 0) { [void]$sb.Append('{' + $c + '}') }
    else { [void]$sb.Append($c) }
  }
  $sb.ToString()
}

# Named keys / modifiers -> Win32 virtual-key codes. keybd_event (not SendKeys)
# is used so the Windows/Super key and system combos like Alt+Tab actually work.
$script:VK = @{
  'return'=0x0D;'enter'=0x0D;'tab'=0x09;'esc'=0x1B;'escape'=0x1B;'space'=0x20;
  'backspace'=0x08;'bksp'=0x08;'delete'=0x2E;'del'=0x2E;'home'=0x24;'end'=0x23;
  'pgup'=0x21;'pgdn'=0x22;'insert'=0x2D;'up'=0x26;'down'=0x28;'left'=0x25;'right'=0x27;
  'f1'=0x70;'f2'=0x71;'f3'=0x72;'f4'=0x73;'f5'=0x74;'f6'=0x75;
  'f7'=0x76;'f8'=0x77;'f9'=0x78;'f10'=0x79;'f11'=0x7A;'f12'=0x7B
}
$script:MODVK = @{ 'ctrl'=0x11;'control'=0x11;'alt'=0x12;'shift'=0x10;'win'=0x5B;'super'=0x5B;'lwin'=0x5B;'cmd'=0x5B;'meta'=0x5B }
# Virtual keys that require the extended-key flag for reliable delivery.
$script:EXTVK = @(0x5B,0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x2D,0x2E)

# Pure: translate 'ctrl+shift+a' / 'win+r' / 'alt+Tab' into an ordered list of
# @{vk=<int>; up=<bool>} press/release events. No input is injected here, so it
# is unit-testable. Modifiers press in order then release in reverse, wrapping a
# single down/up of the final key.
function Get-KeyEvents([string]$combo) {
  $parts = $combo.Split('+')
  $modVks = @()
  for ($i = 0; $i -lt $parts.Count - 1; $i++) {
    $m = $parts[$i].ToLower()
    if (-not $script:MODVK.ContainsKey($m)) { throw "unknown modifier: $($parts[$i])" }
    $modVks += $script:MODVK[$m]
  }
  $last = $parts[$parts.Count - 1]
  $lk = $last.ToLower()
  $needShift = $false
  if ($script:VK.ContainsKey($lk)) {
    $keyVk = $script:VK[$lk]
  } elseif ($last.Length -eq 1) {
    $scan = [Win32]::VkKeyScan($last[0])
    if ($scan -eq -1) { throw "unsupported key in combo: $last" }
    $keyVk = $scan -band 0xFF
    if (($scan -shr 8) -band 0x01) { $needShift = $true }   # char requires Shift
  } else {
    throw "unknown key: $last"
  }
  if ($needShift -and ($modVks -notcontains 0x10)) { $modVks = @(0x10) + $modVks }
  $events = @()
  foreach ($v in $modVks) { $events += @{ vk = [int]$v; up = $false } }
  $events += @{ vk = [int]$keyVk; up = $false }
  $events += @{ vk = [int]$keyVk; up = $true }
  for ($i = $modVks.Count - 1; $i -ge 0; $i--) { $events += @{ vk = [int]$modVks[$i]; up = $true } }
  ,$events
}

# Inject a combo by replaying its Get-KeyEvents sequence through keybd_event.
function Invoke-KeyCombo([string]$combo) {
  foreach ($e in (Get-KeyEvents $combo)) {
    $flags = 0
    if ($script:EXTVK -contains $e.vk) { $flags = $flags -bor [Win32]::KEYEXT }
    if ($e.up) { $flags = $flags -bor [Win32]::KEYUP }
    [Win32]::keybd_event([byte]$e.vk, 0, [uint32]$flags, [UIntPtr]::Zero)
  }
}

# Resolve a focus target to a top-level window handle. Accepts a numeric window
# handle ('396130') or a process name ('mspaint'); IntPtr::Zero if none found.
function Resolve-WindowHandle([string]$target) {
  if ($target -match '^\d+$') { return [IntPtr][int64]$target }
  $p = Get-Process -Name $target -ErrorAction SilentlyContinue |
       Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
  if ($null -eq $p) { return [IntPtr]::Zero }
  return $p.MainWindowHandle
}

# Transfer INPUT FOCUS to $h from a WSL-launched (windowless) background powershell,
# defeating the Windows foreground-lock. Plain SetForegroundWindow is silently
# refused for a process that doesn't already own the foreground; attaching our input
# thread to the current foreground thread (AttachThreadInput) makes the OS accept it.
# Returns $true iff $h actually became foreground (verified via GetForegroundWindow).
# This is the fix for Trap 6 — without it, clicks/keys land on whatever IS focused.
function Set-Foreground([IntPtr]$h) {
  if ($h -eq [IntPtr]::Zero) { return $false }
  $fg = [Win32]::GetForegroundWindow()
  if ($fg -eq $h) { return $true }
  $fgThr = [Win32]::GetWindowThreadProcessId($fg, [IntPtr]::Zero)
  $myThr = [Win32]::GetCurrentThreadId()
  [Win32]::SystemParametersInfo(0x2001, 0, [UIntPtr]::Zero, 0) | Out-Null  # SPI_SETFOREGROUNDLOCKTIMEOUT=0
  [Win32]::AttachThreadInput($fgThr, $myThr, $true) | Out-Null
  [Win32]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero)                  # Alt down/up: satisfies the "user input" unlock
  [Win32]::keybd_event(0x12, 0, [Win32]::KEYUP, [UIntPtr]::Zero)
  [Win32]::ShowWindow($h, 9) | Out-Null                             # SW_RESTORE (un-minimize)
  [Win32]::BringWindowToTop($h) | Out-Null
  [Win32]::SetForegroundWindow($h) | Out-Null
  [Win32]::AttachThreadInput($fgThr, $myThr, $false) | Out-Null
  Start-Sleep -Milliseconds 250
  return ([Win32]::GetForegroundWindow() -eq $h)
}

if ($null -ne $Verb -and $Verb -ne '') {
switch ($Verb) {
  "screenshot" {
    $b = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $bmp = New-Object System.Drawing.Bitmap($b.Width, $b.Height)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen($b.X, $b.Y, 0, 0, $bmp.Size)
    $ms = New-Object System.IO.MemoryStream
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose()
    [Console]::Out.Write([System.Convert]::ToBase64String($ms.ToArray()))
  }
  "screen_size" {
    $b = [System.Windows.Forms.SystemInformation]::VirtualScreen
    [Console]::Out.Write("$($b.Width) $($b.Height)")
  }
  "cursor_position" {
    $p = [System.Windows.Forms.Cursor]::Position
    [Console]::Out.Write("$($p.X) $($p.Y)")
  }
  "move" {
    [Win32]::SetCursorPos([int]$A1, [int]$A2) | Out-Null
    [Console]::Out.Write("ok")
  }
  "click"        { Invoke-ClickAt ([int]$A1) ([int]$A2) $A3; [Console]::Out.Write("ok") }
  "right_click"  { Invoke-ClickAt ([int]$A1) ([int]$A2) "right"; [Console]::Out.Write("ok") }
  "double_click" {
    Invoke-ClickAt ([int]$A1) ([int]$A2) "left"
    Invoke-ClickAt ([int]$A1) ([int]$A2) "left"
    [Console]::Out.Write("ok")
  }
  "drag" {
    # Stream the motion in small steps so drawing apps (Paint shapes/freehand)
    # track a real stroke instead of a single teleport from start to end.
    $f = Get-BtnFlags $A3
    $pt = New-Object POINT
    [void][Win32]::GetCursorPos([ref]$pt)
    $sx = $pt.X; $sy = $pt.Y; $ex = [int]$A1; $ey = [int]$A2
    [Win32]::mouse_event($f[0], 0, 0, 0, [UIntPtr]::Zero)    # press at current pos
    Start-Sleep -Milliseconds 40
    $steps = 40
    for ($i = 1; $i -le $steps; $i++) {
      $x = [int]($sx + ($ex - $sx) * $i / $steps)
      $y = [int]($sy + ($ey - $sy) * $i / $steps)
      [Win32]::SetCursorPos($x, $y) | Out-Null
      Start-Sleep -Milliseconds 8
    }
    Start-Sleep -Milliseconds 40
    [Win32]::mouse_event($f[1], 0, 0, 0, [UIntPtr]::Zero)    # release
    [Console]::Out.Write("ok")
  }
  "scroll" {
    $dy = [int]$A2                                           # +up / -down, one notch = 120
    if ($dy -ne 0) { [Win32]::mouse_event([Win32]::WHEEL, 0, 0, [uint32]($dy * 120), [UIntPtr]::Zero) }
    [Console]::Out.Write("ok")
  }
  "type" {
    [System.Windows.Forms.SendKeys]::SendWait((Get-EscapedText $A1))
    [Console]::Out.Write("ok")
  }
  "key" {
    Invoke-KeyCombo $A1
    [Console]::Out.Write("ok")
  }
  "focus" {
    # Raise a window (by process name or handle) to the foreground so subsequent
    # type/key/click land on it. Reports success; never throws for "couldn't focus".
    $h = Resolve-WindowHandle $A1
    if (Set-Foreground $h) { [Console]::Out.Write("ok") } else { [Console]::Out.Write("focus-failed") }
  }
  default {
    [Console]::Error.Write("unknown verb: $Verb")
    exit 2
  }
}
}
