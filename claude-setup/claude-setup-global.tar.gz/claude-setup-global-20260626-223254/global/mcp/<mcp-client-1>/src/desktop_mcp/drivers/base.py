"""Driver ABC — backend-agnostic desktop control contract."""
from abc import ABC, abstractmethod


class Driver(ABC):
    @abstractmethod
    def screenshot(self) -> bytes:
        """Return the virtual screen as PNG bytes."""

    @abstractmethod
    def screen_size(self) -> tuple[int, int]:
        """Return (width, height) in pixels."""

    @abstractmethod
    def cursor_position(self) -> tuple[int, int]:
        """Return current (x, y)."""

    @abstractmethod
    def move(self, x: int, y: int) -> None: ...

    @abstractmethod
    def click(self, x: int | None, y: int | None, button: str = "left") -> None: ...

    @abstractmethod
    def double_click(self, x: int | None, y: int | None) -> None: ...

    @abstractmethod
    def right_click(self, x: int | None, y: int | None) -> None: ...

    @abstractmethod
    def drag(self, x: int, y: int, button: str = "left") -> None: ...

    @abstractmethod
    def scroll(self, dx: int, dy: int) -> None: ...

    @abstractmethod
    def type(self, text: str) -> None: ...

    @abstractmethod
    def key(self, combo: str) -> None: ...

    def focus(self, target: str) -> bool:
        """Raise a window to the foreground so input lands on it.

        Not abstract: only the Windows driver (WSL→Windows foreground-lock) needs
        it, so x11/wayland inherit this default and stay instantiable. Returns True
        if the target became foreground; raises if the backend can't support it.
        """
        raise NotImplementedError("focus is not supported by this driver")
