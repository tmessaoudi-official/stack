"""X11 driver — pyautogui for input, mss+Pillow for capture (DISPLAY=:99)."""
import io

import mss
import pyautogui
from PIL import Image as PILImage

from .base import Driver

pyautogui.FAILSAFE = False  # no corner-abort: the screen is virtual & sandboxed


class X11Driver(Driver):
    def screenshot(self) -> bytes:
        with mss.MSS() as sct:
            raw = sct.grab(sct.monitors[1])
        img = PILImage.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()

    def screen_size(self) -> tuple[int, int]:
        size = pyautogui.size()
        return (int(size.width), int(size.height))

    def cursor_position(self) -> tuple[int, int]:
        pos = pyautogui.position()
        return (int(pos.x), int(pos.y))

    def move(self, x: int, y: int) -> None:
        pyautogui.moveTo(x, y)

    def click(self, x: int, y: int, button: str = "left") -> None:
        pyautogui.click(x=x, y=y, button=button)

    def double_click(self, x: int, y: int) -> None:
        pyautogui.doubleClick(x=x, y=y)

    def right_click(self, x: int, y: int) -> None:
        pyautogui.rightClick(x=x, y=y)

    def drag(self, x: int, y: int, button: str = "left") -> None:
        pyautogui.dragTo(x, y, button=button)

    def scroll(self, dx: int, dy: int) -> None:
        if dy:
            pyautogui.scroll(dy)
        if dx:
            pyautogui.hscroll(dx)

    def type(self, text: str) -> None:
        pyautogui.write(text)

    def key(self, combo: str) -> None:
        pyautogui.hotkey(*combo.split("+"))
