"""Windows driver — drives the REAL Windows desktop from inside WSL.

WSLg renders Linux GUI apps via rootless/RAIL Xwayland, so a Linux-side
screen grab (x11/wayland) cannot see the Windows desktop, and pyautogui-in-Linux
(the original v1 design note) cannot reach Windows windows. The only bridge that
works is WSL->Windows interop: shell out to powershell.exe, which runs on the
Windows host. windows_helper.ps1 does BitBlt capture + Win32 SendInput/mouse_event.

Capture is proven: a BitBlt of the virtual screen round-trips into WSL as a real
(non-black) PNG. Per-call powershell.exe latency is ~300-700ms; a persistent
helper is a future optimization, not required for correctness.

Coordinates are Windows virtual-screen pixels. Because WSLg windows are RAIL
windows on that same desktop, this driver also captures (and likely drives) any
visible WSLg Linux app — validated separately by the WSLg input spike.
"""
import base64
import subprocess
from pathlib import Path

from .base import Driver

# windows_helper.ps1 ships next to the package (src/desktop_mcp/windows_helper.ps1).
_HELPER = Path(__file__).resolve().parent.parent / "windows_helper.ps1"


def _ps_literal(value) -> str:
    """A PowerShell single-quoted string literal (doubling embedded quotes)."""
    return "'" + str(value).replace("'", "''") + "'"


class WindowsDriver(Driver):
    def __init__(self) -> None:
        # Construction stays cheap and never raises (mirrors WaylandDriver): the
        # powershell.exe preflight lives in desktop-windows-wrapper.sh. Methods
        # fail loudly via _run_ps if interop is genuinely broken.
        self._body: str | None = None

    # --- interop seam (mocked in unit tests) -------------------------------
    def _helper_body(self) -> str:
        if self._body is None:
            self._body = _HELPER.read_text(encoding="utf-8")
        return self._body

    def _run_ps(self, verb: str, *args) -> bytes:
        # Drive the helper via -EncodedCommand (NOT -File): a .ps1 on the
        # \\wsl.localhost UNC path trips PowerShell's AuthorizationManager
        # zone check even under -ExecutionPolicy Bypass. EncodedCommand has no
        # file, so no zone check, and args embed safely as PS string literals.
        assigns = [f"$Verb={_ps_literal(verb)}"]
        for i in range(3):
            assigns.append(f"$A{i + 1}=" + (_ps_literal(args[i]) if i < len(args) else "$null"))
        script = "; ".join(assigns) + "\n" + self._helper_body()
        encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
        cmd = [
            "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-EncodedCommand", encoded,
        ]
        proc = subprocess.run(cmd, capture_output=True)
        if proc.returncode != 0:
            err = proc.stderr.decode(errors="replace").strip()
            raise RuntimeError(f"windows_helper '{verb}' failed (rc={proc.returncode}): {err}")
        return proc.stdout

    # --- capture / query ---------------------------------------------------
    def screenshot(self) -> bytes:
        return base64.b64decode(self._run_ps("screenshot").strip())

    def screen_size(self) -> tuple[int, int]:
        w, h = self._run_ps("screen_size").decode().split()
        return (int(w), int(h))

    def cursor_position(self) -> tuple[int, int]:
        x, y = self._run_ps("cursor_position").decode().split()
        return (int(x), int(y))

    # --- input -------------------------------------------------------------
    def move(self, x: int, y: int) -> None:
        self._run_ps("move", x, y)

    def click(self, x: int, y: int, button: str = "left") -> None:
        self._run_ps("click", x, y, button)

    def double_click(self, x: int, y: int) -> None:
        self._run_ps("double_click", x, y)

    def right_click(self, x: int, y: int) -> None:
        self._run_ps("right_click", x, y)

    def drag(self, x: int, y: int, button: str = "left") -> None:
        self._run_ps("drag", x, y, button)

    def scroll(self, dx: int, dy: int) -> None:
        self._run_ps("scroll", dx, dy)

    def type(self, text: str) -> None:
        self._run_ps("type", text)

    def key(self, combo: str) -> None:
        self._run_ps("key", combo)

    def focus(self, target: str) -> bool:
        # Raise `target` (process name like "mspaint", or a numeric window handle)
        # to the foreground via the helper's AttachThreadInput steal. Returns True
        # only if the helper verified the window actually became foreground.
        return self._run_ps("focus", target).decode(errors="replace").strip() == "ok"
