# desktop-mcp Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Ship a Python MCP server that lets Claude see and drive a sandboxed virtual Linux desktop (v1), behind a driver abstraction shaped for future Wayland/Windows backends.

**Architecture:** A FastMCP stdio server exposes 11 computer-use tools. Each tool delegates to a `Driver` instance selected at startup by `factory.select_driver_name()`. v1 ships only `X11Driver` (pyautogui for input, mss for capture, against `DISPLAY=:99`); `WaylandDriver`/`WindowsDriver` are ABC-shaped stubs that raise `NotImplementedError`. The server runs inside an ephemeral container (Xvfb + fluxbox + x11vnc + noVNC) launched by a host `docker run -i` wrapper, so it works identically on Wayland/X11/fresh hosts. Tests inject a `FakeDriver` so the unit layer never touches a display.

**Tech Stack:** Python ≥3.11, `mcp` SDK (FastMCP), `pyautogui`, `mss`, `Pillow`; `uv` + `hatchling` (src layout, mirrors the #2 trivy convention); Docker (`ubuntu:24.04`, Xvfb, fluxbox, x11vnc, novnc/websockify); pytest.

## Global Constraints

- Package name `desktop_mcp`, src layout `src/desktop_mcp/`, build backend `hatchling`, deps `mcp>=1.2`, `pyautogui>=0.9.54`, `mss>=9`, `Pillow>=10`; dev `pytest>=8`. (Mirror `~/.claude/mcp/<mcp-client-3>/trivy/pyproject.toml` structure verbatim where applicable.)
- `requires-python = ">=3.11"`.
- Transport is stdio via `FastMCP`. The `@mcp.tool()` decorator returns the original callable — tools are directly callable in tests.
- Coordinates are absolute, top-left origin.
- Virtual screen is fixed at **1280×800×24** (Xvfb `-screen 0 1280x800x24`). No runtime screenshot downscaling in v1 (resolves spec §11 open item — YAGNI at this resolution).
- In-container Python env via `uv pip install --system .` (resolves spec §11; consistent with #2).
- Base image `ubuntu:24.04`, standalone — NOT layered on /path/to/your/project `00base` (resolves spec §11; this is not a /path/to/your/project tier image).
- noVNC live view on host port `6080`; one ephemeral container per session (`docker run -i --rm`).
- v1 driver matrix: `X11Driver` real; `WaylandDriver` + `WindowsDriver` raise `NotImplementedError` with a clear message; the ABC must force any real driver to implement all 11 methods.
- `--selftest` must be display-free (CI-safe): it lists MCP tools and verifies the expected set, mirroring `~/.claude/mcp/<mcp-client-3>/trivy/src/acme_trivy_mcp/__main__.py`. It must NOT instantiate `X11Driver`.
- Build output and all X-stack process logs go to **stderr/`/dev/null`** — stdout carries only JSON-RPC.
- `~/.claude.json` edits hit the Claude Code classifier → the registration snippet is presented for **manual `!`-prefixed execution**, never written autonomously (CLAUDE.md machine note).
- Every `.sh` / `Dockerfile` write goes through the `Write`/`Edit` tool (PostToolUse shellcheck/hadolint hooks must fire — Bash-written files bypass them).

---

## File Structure

```
~/.claude/mcp/<mcp-client-1>/
  desktop-mcp-wrapper.sh        # host stdio entrypoint: build-if-absent + docker run -i  [Task 6]
  Dockerfile                    # ubuntu:24.04 + Xvfb/fluxbox/x11vnc/novnc + uv install   [Task 6]
  entrypoint.sh                 # container: boot X stack (bg) then exec the MCP on stdio [Task 6]
  pyproject.toml                # `desktop_mcp` package                                   [Task 1]
  .gitignore                    # .venv/ __pycache__/ *.egg-info/ .pytest_cache/          [Task 1]
  src/desktop_mcp/
    __init__.py                                                                            [Task 1]
    drivers/__init__.py                                                                     [Task 1]
    drivers/base.py             # Driver ABC (11 @abstractmethod)                          [Task 1]
    drivers/wayland.py          # stub → NotImplementedError                               [Task 2]
    drivers/windows.py          # stub → NotImplementedError                               [Task 2]
    factory.py                  # select_driver_name() + make_driver()                     [Task 3]
    server.py                   # FastMCP, 11 tools, get_driver/set_driver seam            [Task 4]
    drivers/x11.py              # pyautogui + mss against DISPLAY=:99                       [Task 5]
    __main__.py                 # `python -m desktop_mcp` + --selftest                     [Task 4]
  tests/
    test_factory.py             # name-resolution + stub raises                            [Task 2,3]
    test_tool_mapping.py        # FakeDriver: each tool → correct driver call/args         [Task 4]
    test_x11_integration.py     # Xvfb-gated: screen_size/screenshot/move round-trip       [Task 5]
  docs/2026-06-20-desktop-mcp-design.md   # spec (exists)
  docs/2026-06-20-desktop-mcp-plan.md     # this plan
```

---

### Task 1: Package scaffold + Driver ABC

**Files:**
- Create: `pyproject.toml`, `.gitignore`, `src/desktop_mcp/__init__.py`, `src/desktop_mcp/drivers/__init__.py`, `src/desktop_mcp/drivers/base.py`
- Test: covered by Task 2 (`test_factory.py` imports the ABC); this task's verification is import + abstract-enforcement.

**Interfaces:**
- Produces: `desktop_mcp.drivers.base.Driver` — ABC with 11 abstract methods: `screenshot() -> bytes`, `screen_size() -> tuple[int,int]`, `cursor_position() -> tuple[int,int]`, `move(x,y)`, `click(x,y,button="left")`, `double_click(x,y)`, `right_click(x,y)`, `drag(x,y,button="left")`, `scroll(dx,dy)`, `type(text)`, `key(combo)`. All input methods return `None`.

- [x] **Step 1: Write `pyproject.toml`**

```toml
[project]
name = "desktop-mcp"
version = "1.0.0"
description = "Desktop control MCP — sandboxed virtual Linux desktop (computer use)"
requires-python = ">=3.11"
dependencies = ["mcp>=1.2", "pyautogui>=0.9.54", "mss>=9", "Pillow>=10"]

[project.scripts]
desktop-mcp = "desktop_mcp.__main__:main"

[dependency-groups]
dev = ["pytest>=8"]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/desktop_mcp"]
```

- [x] **Step 2: Write `.gitignore`**

```
.venv/
__pycache__/
*.egg-info/
.pytest_cache/
```

- [x] **Step 3: Write empty `src/desktop_mcp/__init__.py` and `src/desktop_mcp/drivers/__init__.py`**

Both files: empty (package markers).

- [x] **Step 4: Write the failing test** (`tests/test_factory.py`, ABC portion only for now)

```python
import pytest
from desktop_mcp.drivers.base import Driver


def test_driver_is_abstract():
    with pytest.raises(TypeError):
        Driver()  # cannot instantiate an ABC with unimplemented abstractmethods
```

- [x] **Step 5: Run it to verify it fails**

Run: `cd ~/.claude/mcp/desktop && uv run pytest tests/test_factory.py -q`
Expected: FAIL — `ModuleNotFoundError: No module named 'desktop_mcp.drivers.base'` (base.py not written yet).

- [x] **Step 6: Write `src/desktop_mcp/drivers/base.py`**

```python
"""Driver ABC — backend-agnostic desktop control contract."""
from abc import ABC, abstractmethod


class Driver(ABC):
    @abstractmethod
    def screenshot(self) -> bytes:
        """Return the virtual screen as PNG bytes."""

    @abstractmethod
    def screen_size(self) -> tuple[int, int]:
        """Return (width, height) in pixels."""

    @abstractmethod
    def cursor_position(self) -> tuple[int, int]:
        """Return current (x, y)."""

    @abstractmethod
    def move(self, x: int, y: int) -> None: ...

    @abstractmethod
    def click(self, x: int | None, y: int | None, button: str = "left") -> None: ...

    @abstractmethod
    def double_click(self, x: int | None, y: int | None) -> None: ...

    @abstractmethod
    def right_click(self, x: int | None, y: int | None) -> None: ...

    @abstractmethod
    def drag(self, x: int, y: int, button: str = "left") -> None: ...

    @abstractmethod
    def scroll(self, dx: int, dy: int) -> None: ...

    @abstractmethod
    def type(self, text: str) -> None: ...

    @abstractmethod
    def key(self, combo: str) -> None: ...
```

- [x] **Step 7: Run test to verify it passes**

Run: `cd ~/.claude/mcp/desktop && uv run pytest tests/test_factory.py::test_driver_is_abstract -q`
Expected: PASS (1 passed).

- [x] **Step 8: Commit**

```bash
git add mcp/<mcp-client-1>/pyproject.toml mcp/<mcp-client-1>/.gitignore mcp/<mcp-client-1>/src/desktop_mcp/__init__.py mcp/<mcp-client-1>/src/desktop_mcp/drivers/__init__.py mcp/<mcp-client-1>/src/desktop_mcp/drivers/base.py mcp/<mcp-client-1>/tests/test_factory.py
git commit -m "feat(desktop-mcp): package scaffold + Driver ABC"
```
> Run via `!` from `~/.claude` — autonomous commit there is classifier-blocked.

---

### Task 2: Driver stubs (Wayland / Windows)

**Files:**
- Create: `src/desktop_mcp/drivers/wayland.py`, `src/desktop_mcp/drivers/windows.py`
- Test: `tests/test_factory.py` (extend)

**Interfaces:**
- Produces: `WaylandDriver`, `WindowsDriver` — both subclass `Driver`, implement all 11 methods, and raise `NotImplementedError` (in `__init__` and every method) with a clear designed-for message.

- [x] **Step 1: Write the failing test** (append to `tests/test_factory.py`)

```python
from desktop_mcp.drivers.wayland import WaylandDriver
from desktop_mcp.drivers.windows import WindowsDriver


def test_wayland_stub_raises():
    with pytest.raises(NotImplementedError, match="Wayland"):
        WaylandDriver()


def test_windows_stub_raises():
    with pytest.raises(NotImplementedError, match="Windows"):
        WindowsDriver()
```

- [x] **Step 2: Run to verify it fails**

Run: `cd ~/.claude/mcp/desktop && uv run pytest tests/test_factory.py -q`
Expected: FAIL — `ModuleNotFoundError` for `desktop_mcp.drivers.wayland`.

- [x] **Step 3: Write `src/desktop_mcp/drivers/wayland.py`**

```python
"""Wayland host driver — designed-for, NOT implemented in v1.

Design: xdg-desktop-portal (ScreenCast/RemoteDesktop) for capture +
ydotool (/dev/uinput) for input, behind a per-session allow-gate before
it touches the real screen. See docs/2026-06-20-desktop-mcp-design.md §9.
"""
from .base import Driver

_MSG = (
    "Wayland host driver is not implemented in v1. "
    "Designed: xdg-desktop-portal capture + ydotool input behind a "
    "per-session allow-gate. Use the X11 container driver instead."
)


class WaylandDriver(Driver):
    def __init__(self) -> None:
        raise NotImplementedError(_MSG)

    def screenshot(self) -> bytes:
        raise NotImplementedError(_MSG)

    def screen_size(self) -> tuple[int, int]:
        raise NotImplementedError(_MSG)

    def cursor_position(self) -> tuple[int, int]:
        raise NotImplementedError(_MSG)

    def move(self, x, y):
        raise NotImplementedError(_MSG)

    def click(self, x, y, button="left"):
        raise NotImplementedError(_MSG)

    def double_click(self, x, y):
        raise NotImplementedError(_MSG)

    def right_click(self, x, y):
        raise NotImplementedError(_MSG)

    def drag(self, x, y, button="left"):
        raise NotImplementedError(_MSG)

    def scroll(self, dx, dy):
        raise NotImplementedError(_MSG)

    def type(self, text):
        raise NotImplementedError(_MSG)

    def key(self, combo):
        raise NotImplementedError(_MSG)
```

- [x] **Step 4: Write `src/desktop_mcp/drivers/windows.py`** (identical shape, Windows message)

```python
"""Windows driver — designed-for, NOT implemented in v1.

Design: pyautogui (cross-platform) reusing the X11Driver code path;
only capture/permission specifics differ. No sandbox — would drive the
real desktop, so it needs its own safety gate before shipping.
"""
from .base import Driver

_MSG = (
    "Windows driver is not implemented in v1. "
    "Designed: pyautogui reusing the X11 code path. "
    "Use the X11 container driver instead."
)


class WindowsDriver(Driver):
    def __init__(self) -> None:
        raise NotImplementedError(_MSG)

    def screenshot(self) -> bytes:
        raise NotImplementedError(_MSG)

    def screen_size(self) -> tuple[int, int]:
        raise NotImplementedError(_MSG)

    def cursor_position(self) -> tuple[int, int]:
        raise NotImplementedError(_MSG)

    def move(self, x, y):
        raise NotImplementedError(_MSG)

    def click(self, x, y, button="left"):
        raise NotImplementedError(_MSG)

    def double_click(self, x, y):
        raise NotImplementedError(_MSG)

    def right_click(self, x, y):
        raise NotImplementedError(_MSG)

    def drag(self, x, y, button="left"):
        raise NotImplementedError(_MSG)

    def scroll(self, dx, dy):
        raise NotImplementedError(_MSG)

    def type(self, text):
        raise NotImplementedError(_MSG)

    def key(self, combo):
        raise NotImplementedError(_MSG)
```

- [x] **Step 5: Run tests to verify they pass**

Run: `cd ~/.claude/mcp/desktop && uv run pytest tests/test_factory.py -q`
Expected: PASS (3 passed).

- [x] **Step 6: Commit**

```bash
git add mcp/<mcp-client-1>/src/desktop_mcp/drivers/wayland.py mcp/<mcp-client-1>/src/desktop_mcp/drivers/windows.py mcp/<mcp-client-1>/tests/test_factory.py
git commit -m "feat(desktop-mcp): Wayland/Windows ABC-shaped stubs"
```

---

### Task 3: Driver factory (selection logic)

**Files:**
- Create: `src/desktop_mcp/factory.py`
- Test: `tests/test_factory.py` (extend)

**Interfaces:**
- Produces:
  - `select_driver_name(override: str | None, platform: str, session_type: str) -> str` — pure function. Precedence: explicit `override` → `"windows"` if `platform.startswith("win")` → `"wayland"` if `session_type == "wayland"` → else `"x11"`.
  - `make_driver(override: str | None = None) -> Driver` — resolves name from `override or $DESKTOP_MCP_DRIVER`, `sys.platform`, `$XDG_SESSION_TYPE`; lazily imports + instantiates the matching driver class; raises `ValueError` on unknown name. Lazy import keeps `pyautogui` (X11) out of the import graph until x11 is actually selected.

- [x] **Step 1: Write the failing test** (append to `tests/test_factory.py`)

```python
from desktop_mcp.factory import make_driver, select_driver_name


def test_select_override_wins():
    assert select_driver_name("wayland", "linux", "x11") == "wayland"


def test_select_windows_by_platform():
    assert select_driver_name(None, "win32", "") == "windows"


def test_select_wayland_by_session():
    assert select_driver_name(None, "linux", "wayland") == "wayland"


def test_select_defaults_to_x11():
    assert select_driver_name(None, "linux", "x11") == "x11"


def test_make_driver_unknown_raises():
    with pytest.raises(ValueError, match="Unknown driver"):
        make_driver("bogus")


def test_make_driver_wayland_propagates_notimplemented():
    with pytest.raises(NotImplementedError):
        make_driver("wayland")
```

- [x] **Step 2: Run to verify it fails**

Run: `cd ~/.claude/mcp/desktop && uv run pytest tests/test_factory.py -q`
Expected: FAIL — `ModuleNotFoundError: No module named 'desktop_mcp.factory'`.

- [x] **Step 3: Write `src/desktop_mcp/factory.py`**

```python
"""Driver selection — platform + env, overridable by DESKTOP_MCP_DRIVER."""
import os
import sys

from .drivers.base import Driver


def select_driver_name(override, platform, session_type):
    if override:
        return override
    if platform.startswith("win"):
        return "windows"
    if session_type == "wayland":
        return "wayland"
    return "x11"


def make_driver(override: str | None = None) -> Driver:
    name = select_driver_name(
        override or os.environ.get("DESKTOP_MCP_DRIVER"),
        sys.platform,
        os.environ.get("XDG_SESSION_TYPE", ""),
    )
    if name == "x11":
        from .drivers.x11 import X11Driver

        return X11Driver()
    if name == "wayland":
        from .drivers.wayland import WaylandDriver

        return WaylandDriver()
    if name == "windows":
        from .drivers.windows import WindowsDriver

        return WindowsDriver()
    raise ValueError(f"Unknown driver: {name}")
```

- [x] **Step 4: Run tests to verify they pass**

Run: `cd ~/.claude/mcp/desktop && uv run pytest tests/test_factory.py -q`
Expected: PASS (9 passed). `test_make_driver_unknown_raises` and the wayland one exercise `make_driver` without ever importing `pyautogui`.

- [x] **Step 5: Commit**

```bash
git add mcp/<mcp-client-1>/src/desktop_mcp/factory.py mcp/<mcp-client-1>/tests/test_factory.py
git commit -m "feat(desktop-mcp): driver factory with platform/env selection"
```

---

### Task 4: MCP server (11 tools) + `__main__` selftest

**Files:**
- Create: `src/desktop_mcp/server.py`, `src/desktop_mcp/__main__.py`
- Test: `tests/test_tool_mapping.py`

**Interfaces:**
- Consumes: `Driver` ABC (Task 1).
- Produces:
  - `desktop_mcp.server.mcp` — `FastMCP("desktop")` with 11 tools (names exactly: `screenshot`, `screen_size`, `cursor_position`, `move`, `click`, `double_click`, `right_click`, `drag`, `scroll`, `type`, `key`).
  - `server.set_driver(d)` / `server.get_driver()` — test seam + lazy default via `make_driver()`.
  - `__main__.main()` — `--selftest` lists tools against `EXPECTED_TOOLS` (display-free), else `mcp.run()`.

- [x] **Step 1: Write the failing test** (`tests/test_tool_mapping.py`)

```python
from mcp.server.fastmcp import Image

from desktop_mcp import server


class FakeDriver:
    def __init__(self):
        self.calls = []

    def screenshot(self):
        self.calls.append(("screenshot",))
        return b"\x89PNG\r\n\x1a\nFAKE"

    def screen_size(self):
        self.calls.append(("screen_size",))
        return (1280, 800)

    def cursor_position(self):
        self.calls.append(("cursor_position",))
        return (5, 6)

    def move(self, x, y):
        self.calls.append(("move", x, y))

    def click(self, x, y, button="left"):
        self.calls.append(("click", x, y, button))

    def double_click(self, x, y):
        self.calls.append(("double_click", x, y))

    def right_click(self, x, y):
        self.calls.append(("right_click", x, y))

    def drag(self, x, y, button="left"):
        self.calls.append(("drag", x, y, button))

    def scroll(self, dx, dy):
        self.calls.append(("scroll", dx, dy))

    def type(self, text):
        self.calls.append(("type", text))

    def key(self, combo):
        self.calls.append(("key", combo))


def setup_function(_):
    server.set_driver(FakeDriver())


def test_screenshot_returns_image_from_driver_bytes():
    img = server.screenshot()
    assert isinstance(img, Image)
    assert server.get_driver().calls == [("screenshot",)]


def test_screen_size_maps():
    assert server.screen_size() == {"width": 1280, "height": 800}


def test_cursor_position_maps():
    assert server.cursor_position() == {"x": 5, "y": 6}


def test_move_maps():
    server.move(10, 20)
    assert server.get_driver().calls == [("move", 10, 20)]


def test_click_default_button():
    server.click(30, 40)
    assert server.get_driver().calls == [("click", 30, 40, "left")]


def test_click_explicit_button():
    server.click(1, 2, "middle")
    assert server.get_driver().calls == [("click", 1, 2, "middle")]


def test_double_and_right_click():
    server.double_click(7, 8)
    server.right_click(9, 10)
    assert server.get_driver().calls == [("double_click", 7, 8), ("right_click", 9, 10)]


def test_drag_default_button():
    server.drag(50, 60)
    assert server.get_driver().calls == [("drag", 50, 60, "left")]


def test_scroll_maps():
    server.scroll(0, -3)
    assert server.get_driver().calls == [("scroll", 0, -3)]


def test_type_maps():
    server.type("hello")
    assert server.get_driver().calls == [("type", "hello")]


def test_key_maps():
    server.key("ctrl+c")
    assert server.get_driver().calls == [("key", "ctrl+c")]
```

- [x] **Step 2: Run to verify it fails**

Run: `cd ~/.claude/mcp/desktop && uv run pytest tests/test_tool_mapping.py -q`
Expected: FAIL — `ModuleNotFoundError` for `desktop_mcp.server`.

- [x] **Step 3: Write `src/desktop_mcp/server.py`**

```python
"""desktop-mcp server — FastMCP stdio, 11 computer-use tools."""
from mcp.server.fastmcp import FastMCP, Image

mcp = FastMCP("desktop")

_driver = None


def get_driver():
    global _driver
    if _driver is None:
        from .factory import make_driver

        _driver = make_driver()
    return _driver


def set_driver(d) -> None:
    """Test seam — inject a driver, bypassing factory/display."""
    global _driver
    _driver = d


@mcp.tool(description="Capture the virtual screen. Returns a PNG image.")
def screenshot() -> Image:
    return Image(data=get_driver().screenshot(), format="png")


@mcp.tool(description="Return the virtual screen size in pixels.")
def screen_size() -> dict:
    w, h = get_driver().screen_size()
    return {"width": w, "height": h}


@mcp.tool(description="Return the current cursor position.")
def cursor_position() -> dict:
    x, y = get_driver().cursor_position()
    return {"x": x, "y": y}


@mcp.tool(description="Move the cursor to absolute (x, y).")
def move(x: int, y: int) -> str:
    get_driver().move(x, y)
    return "ok"


@mcp.tool(description="Click at (x, y). button = left | middle | right.")
def click(x: int, y: int, button: str = "left") -> str:
    get_driver().click(x, y, button)
    return "ok"


@mcp.tool(description="Double-click at (x, y).")
def double_click(x: int, y: int) -> str:
    get_driver().double_click(x, y)
    return "ok"


@mcp.tool(description="Right-click at (x, y).")
def right_click(x: int, y: int) -> str:
    get_driver().right_click(x, y)
    return "ok"


@mcp.tool(description="Press-drag from current position to (x, y).")
def drag(x: int, y: int, button: str = "left") -> str:
    get_driver().drag(x, y, button)
    return "ok"


@mcp.tool(description="Scroll by (dx, dy) clicks. Positive dy scrolls up.")
def scroll(dx: int, dy: int) -> str:
    get_driver().scroll(dx, dy)
    return "ok"


@mcp.tool(description="Type literal text at the current focus.")
def type(text: str) -> str:
    get_driver().type(text)
    return "ok"


@mcp.tool(description="Press a key combo, e.g. 'ctrl+c', 'alt+Tab', 'Return'.")
def key(combo: str) -> str:
    get_driver().key(combo)
    return "ok"
```

> Note: `screen_size`, `move`, `drag` etc. take required `x,y` (no optional coords in v1 — the agent always supplies them; spec's `x?`/`y?` "click at current pos" is deferred, YAGNI). If the FakeDriver signatures above must accept optional coords, keep them required here for a tight contract.

- [x] **Step 4: Run tests to verify they pass**

Run: `cd ~/.claude/mcp/desktop && uv run pytest tests/test_tool_mapping.py -q`
Expected: PASS (11 passed).

- [x] **Step 5: Write `src/desktop_mcp/__main__.py`**

```python
import sys

from .server import mcp

EXPECTED_TOOLS = {
    "screenshot",
    "screen_size",
    "cursor_position",
    "move",
    "click",
    "double_click",
    "right_click",
    "drag",
    "scroll",
    "type",
    "key",
}


def main() -> None:
    if "--selftest" in sys.argv:
        import asyncio

        names = {t.name for t in asyncio.run(mcp.list_tools())}
        missing, extra = EXPECTED_TOOLS - names, names - EXPECTED_TOOLS
        if missing or extra:
            print(f"SELFTEST FAIL missing={missing} extra={extra}", file=sys.stderr)
            sys.exit(1)
        print(f"SELFTEST OK: {len(names)} tools")
        sys.exit(0)
    mcp.run()


if __name__ == "__main__":
    main()
```

- [x] **Step 6: Verify selftest is display-free**

Run: `cd ~/.claude/mcp/desktop && DESKTOP_MCP_DRIVER=x11 uv run python -m desktop_mcp --selftest`
Expected: `SELFTEST OK: 11 tools`, exit 0 — even with no `$DISPLAY`, because `list_tools()` never instantiates the driver.

- [x] **Step 7: Commit**

```bash
git add mcp/<mcp-client-1>/src/desktop_mcp/server.py mcp/<mcp-client-1>/src/desktop_mcp/__main__.py mcp/<mcp-client-1>/tests/test_tool_mapping.py
git commit -m "feat(desktop-mcp): 11 MCP tools + display-free --selftest"
```

---

### Task 5: X11Driver (real backend) + Xvfb integration test

**Files:**
- Create: `src/desktop_mcp/drivers/x11.py`
- Test: `tests/test_x11_integration.py`

**Interfaces:**
- Consumes: `Driver` ABC.
- Produces: `X11Driver(Driver)` — `pyautogui` for input/position/size, `mss` + Pillow for capture. `pyautogui` is imported at module top (so importing x11.py on a display-less host fails — that's why the factory imports it lazily and tests gate on it).

- [x] **Step 1: Write the Xvfb-gated integration test** (`tests/test_x11_integration.py`)

```python
import os
import shutil

import pytest

pytestmark = pytest.mark.skipif(
    not os.environ.get("DISPLAY") or shutil.which("Xvfb") is None,
    reason="needs an X display (run inside the container or under xvfb-run)",
)


def _driver():
    from desktop_mcp.drivers.x11 import X11Driver

    return X11Driver()


def test_screen_size_matches_xvfb():
    w, h = _driver().screen_size()
    assert (w, h) == (1280, 800)


def test_screenshot_is_png():
    data = _driver().screenshot()
    assert data.startswith(b"\x89PNG\r\n\x1a\n")
    assert len(data) > 100


def test_move_then_cursor_position():
    d = _driver()
    d.move(100, 120)
    assert d.cursor_position() == (100, 120)
```

- [x] **Step 2: Run to verify it fails (or skips without a display)**

Run (no display): `cd ~/.claude/mcp/desktop && uv run pytest tests/test_x11_integration.py -q`
Expected: `3 skipped` (no `$DISPLAY`).
Run (under xvfb): `xvfb-run -s "-screen 0 1280x800x24" uv run pytest tests/test_x11_integration.py -q`
Expected: FAIL — `ModuleNotFoundError: No module named 'desktop_mcp.drivers.x11'`.

- [x] **Step 3: Write `src/desktop_mcp/drivers/x11.py`**

```python
"""X11 driver — pyautogui for input, mss+Pillow for capture (DISPLAY=:99)."""
import io

import mss
import pyautogui
from PIL import Image as PILImage

from .base import Driver

pyautogui.FAILSAFE = False  # no corner-abort: the screen is virtual & sandboxed


class X11Driver(Driver):
    def screenshot(self) -> bytes:
        with mss.MSS() as sct:
            raw = sct.grab(sct.monitors[1])
        img = PILImage.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()

    def screen_size(self) -> tuple[int, int]:
        size = pyautogui.size()
        return (int(size.width), int(size.height))

    def cursor_position(self) -> tuple[int, int]:
        pos = pyautogui.position()
        return (int(pos.x), int(pos.y))

    def move(self, x: int, y: int) -> None:
        pyautogui.moveTo(x, y)

    def click(self, x: int, y: int, button: str = "left") -> None:
        pyautogui.click(x=x, y=y, button=button)

    def double_click(self, x: int, y: int) -> None:
        pyautogui.doubleClick(x=x, y=y)

    def right_click(self, x: int, y: int) -> None:
        pyautogui.rightClick(x=x, y=y)

    def drag(self, x: int, y: int, button: str = "left") -> None:
        pyautogui.dragTo(x, y, button=button)

    def scroll(self, dx: int, dy: int) -> None:
        if dy:
            pyautogui.scroll(dy)
        if dx:
            pyautogui.hscroll(dx)

    def type(self, text: str) -> None:
        pyautogui.write(text)

    def key(self, combo: str) -> None:
        pyautogui.hotkey(*combo.split("+"))
```

- [x] **Step 4: Run integration test under xvfb to verify it passes**

Run: `cd ~/.claude/mcp/desktop && xvfb-run -s "-screen 0 1280x800x24" uv run pytest tests/test_x11_integration.py -q`
Expected: PASS (3 passed). If `xvfb-run`/system X libs are missing on the host, this is validated inside the container in Task 6 instead — note that explicitly if so.

- [x] **Step 5: Commit**

```bash
git add mcp/<mcp-client-1>/src/desktop_mcp/drivers/x11.py mcp/<mcp-client-1>/tests/test_x11_integration.py
git commit -m "feat(desktop-mcp): X11Driver (pyautogui + mss) + Xvfb integration test"
```

---

### Task 6: Container + host wrapper (infra)

**Files:**
- Create: `Dockerfile`, `entrypoint.sh`, `desktop-mcp-wrapper.sh`
- Test: infra checks (`bash -n`, `shellcheck`, `hadolint`, `docker build`, container `--selftest`)

**Interfaces:**
- Produces: image `desktop-mcp:latest` whose entrypoint boots the X stack (background, logs to `/dev/null`) then `exec python -m desktop_mcp` on stdio; host wrapper `desktop-mcp-wrapper.sh` build-if-absent + `docker run -i --rm -p 6080:6080`.

- [x] **Step 1: Write `entrypoint.sh`** (use the Write tool — hadolint/shellcheck hooks must fire)

```bash
#!/usr/bin/env bash
# Container entrypoint: boot the virtual X stack, then exec the MCP on stdio.
set -euo pipefail

export DISPLAY=:99
Xvfb :99 -screen 0 1280x800x24 -nolisten tcp >/dev/null 2>&1 &

# Wait for X to accept connections (max ~5s).
for _ in $(seq 1 50); do
  xdpyinfo -display :99 >/dev/null 2>&1 && break
  sleep 0.1
done

fluxbox >/dev/null 2>&1 &
x11vnc -display :99 -forever -shared -nopw -quiet -bg >/dev/null 2>&1
websockify --web /usr/share/novnc 6080 localhost:5900 >/dev/null 2>&1 &

# stdout/stdin are the MCP JSON-RPC channel — nothing above wrote to stdout.
exec python3 -m desktop_mcp
```

- [x] **Step 2: Write `desktop-mcp-wrapper.sh`** (Write tool)

```bash
#!/usr/bin/env bash
# Host stdio entrypoint registered in ~/.claude.json. Builds the image on
# first run (to stderr — stdout is reserved for MCP JSON-RPC), then runs it.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IMAGE="desktop-mcp:latest"

if ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
  echo "[desktop-mcp] building $IMAGE (first run)..." >&2
  docker build -t "$IMAGE" "$DIR" >&2
fi

exec docker run -i --rm -p 6080:6080 "$IMAGE"
```

- [x] **Step 3: Write `Dockerfile`** (Write tool — hadolint hook fires)

```dockerfile
FROM ubuntu:24.04

ENV DEBIAN_FRONTEND=noninteractive
# hadolint ignore=DL3008
RUN apt-get update && apt-get install -y --no-install-recommends \
      xvfb fluxbox x11vnc novnc websockify x11-utils \
      python3 python3-tk python3-dev \
    && rm -rf /var/lib/apt/lists/*

COPY --from=ghcr.io/astral-sh/uv:latest /uv /usr/local/bin/uv

WORKDIR /app
COPY pyproject.toml ./
COPY src ./src
RUN uv pip install --system .

COPY entrypoint.sh /usr/local/bin/entrypoint.sh
RUN chmod +x /usr/local/bin/entrypoint.sh

EXPOSE 6080
ENV DISPLAY=:99 DESKTOP_MCP_DRIVER=x11
ENTRYPOINT ["/usr/local/bin/entrypoint.sh"]
```

- [x] **Step 4: Static infra checks**

Run:
```bash
cd ~/.claude/mcp/desktop
bash -n entrypoint.sh && bash -n desktop-mcp-wrapper.sh
shellcheck entrypoint.sh desktop-mcp-wrapper.sh
hadolint Dockerfile
```
Expected: `bash -n` silent (exit 0); shellcheck clean; hadolint clean (DL3008 suppressed by the inline ignore — apt pins are impractical for this dev sandbox image; note the suppression).

- [x] **Step 5: Build the image**

Run: `cd ~/.claude/mcp/desktop && docker build -t desktop-mcp:latest .`
Expected: build succeeds.

- [x] **Step 6: Container selftest + in-container integration**

Run:
```bash
docker run --rm --entrypoint python3 desktop-mcp:latest -m desktop_mcp --selftest
```
Expected: `SELFTEST OK: 11 tools`.
> NOTE: `--entrypoint python3` is REQUIRED. `entrypoint.sh` does `exec python3 -m desktop_mcp`
> without forwarding `"$@"`, so `docker run IMAGE python3 -m desktop_mcp --selftest` would
> ignore the command, boot the X stack, run the server, hit stdin-EOF and exit 0 — a false
> positive. Bypassing the entrypoint runs the real display-free selftest.
Then validate the real X path inside the image (covers Task 5 if the host lacked Xvfb):
```bash
docker run --rm --entrypoint bash desktop-mcp:latest -c \
  'Xvfb :99 -screen 0 1280x800x24 -nolisten tcp >/dev/null 2>&1 & sleep 1; DISPLAY=:99 python3 -m pytest /app/tests/test_x11_integration.py -q' \
  || echo "NOTE: integration test not bundled into image; validate via mounted tests"
```
> If `tests/` isn't copied into the image, either add `COPY tests ./tests` for this check or run the integration test against a host xvfb (Task 5 Step 4). Pick one and record which provided the integration evidence.

- [x] **Step 7: Commit**

```bash
git add mcp/<mcp-client-1>/Dockerfile mcp/<mcp-client-1>/entrypoint.sh mcp/<mcp-client-1>/desktop-mcp-wrapper.sh
git commit -m "feat(desktop-mcp): container (Xvfb+fluxbox+x11vnc+noVNC) + host wrapper"
```

---

### Task 7: Registration snippet + final verification

**Files:**
- Modify (manual `!` only): `~/.claude.json → mcpServers`
- No new source files.

- [x] **Step 1: Make the wrapper executable**

Run: `chmod +x ~/.claude/mcp/<mcp-client-1>/desktop-mcp-wrapper.sh`
(Note: `~/.claude` may track file mode — confirm `git diff` shows the mode bit or note it in the commit message, per the /path/to/your/project `core.fileMode` gotcha if it applies here.)

- [x] **Step 2: Present the `~/.claude.json` registration for manual execution**

`~/.claude.json` is classifier-blocked for autonomous edits. Present this snippet for the user to merge into `mcpServers` via `!` (e.g. with `jq` or an editor):

```json
"desktop": {
  "command": "/home/user/.claude/mcp/<mcp-client-1>/desktop-mcp-wrapper.sh",
  "args": [],
  "env": {}
}
```

- [x] **Step 3: Full suite + Completion Gate evidence**

Run: `cd ~/.claude/mcp/desktop && uv run pytest -q`
Expected: all unit tests pass; integration tests pass under xvfb/container or skip with reason on a display-less host. Paste the runner output as Coverage evidence.

- [x] **Step 4: Live smoke (optional, after registration)**

Restart Claude Code so it picks up the new MCP, then confirm the `desktop` server's tools list and call `screenshot` once; open `http://localhost:6080` to watch.

- [x] **Step 5: Commit any final docs touch-ups** (none expected — spec + plan already on disk).

---

## Self-Review

**Spec coverage:** §3 driver pattern → Tasks 1–5; §4 transport → Task 6 wrapper; §5 layout → all files present; §6 11-tool contract → Task 4 (names match exactly); §7 registration → Task 7; §8 testing (unit/integration/infra) → Tasks 4/5/6; §9 safety (container sandbox) → Task 6; §10 v1 scope (X11 real, Wayland/Windows stubs) → Tasks 2/5; §11 open items → resolved in Global Constraints (ubuntu:24.04 standalone, uv, CI-safe selftest, 1280×800 no-downscale). ✓

**Placeholder scan:** No TBD/TODO; every code step has complete code. The one conditional ("if host lacks Xvfb, validate in container") is an explicit either/or with a recorded-evidence instruction, not a gap. ✓

**Type consistency:** Tool names in Task 4 `EXPECTED_TOOLS` == `@mcp.tool` functions == spec §6 table == FakeDriver methods == ABC methods (11 each). `screenshot` returns `Image` (Task 4) sourced from `driver.screenshot() -> bytes` (ABC Task 1). `select_driver_name`/`make_driver` signatures consistent between Task 3 definition and Task 4 consumption. ✓

---

## Implementation Notes (post-build, 2026-06-20)

Deltas applied during execution — the shipped code reflects these, superseding the earlier snippets above where they differ:

- **Base image `ubuntu:26.04`** (was 24.04) — newest LTS; per user policy "pin images, never `:latest`, prefer newest".
- **uv image pinned to `ghcr.io/astral-sh/uv:0.11.23`** (was `:latest`) — live-verified current release; tag confirmed to exist.
- **Package floors bumped to current latest:** `mcp>=1.28`, `mss>=10.2`, `Pillow>=12` (pyautogui 0.9.54 already latest). PyPI-verified.
- **PEP 668 fix:** Ubuntu's system Python is externally-managed, so `uv pip install --system .` is refused. Shipped fix installs into an isolated `/opt/venv` (`uv venv /opt/venv --python python3 && uv pip install --python /opt/venv/bin/python .`; `ENV PATH="/opt/venv/bin:$PATH"`). No `--break-system-packages` bandaid. Added `python3-venv` to apt.
- **Wrapper uses `docker build --load`** — the active buildx builder uses the docker-container driver, which leaves images in the build cache, not the local store; `--load` forces them into the daemon image store (no-op on a plain docker driver, so portable).
- **entrypoint Xauthority fix:** pyautogui's python-xlib backend errors with `XauthError` when `~/.Xauthority` is absent (xvfb-run masked this on the host). Entrypoint now `export XAUTHORITY=$HOME/.Xauthority; touch "$XAUTHORITY"` and runs `Xvfb ... -ac` (access control off — the container is the sandbox, spec §9).
- **`mss.mss()` → `mss.MSS()`** in x11.py — the lowercase alias is deprecated in mss 10.
- **Validation evidence:** 23 unit/integration tests pass under xvfb; container `--selftest` OK (11 tools); in-container X11 smoke OK against the image's own Xvfb; full MCP `initialize`+`tools/list` handshake works end-to-end through `docker run -i`.
