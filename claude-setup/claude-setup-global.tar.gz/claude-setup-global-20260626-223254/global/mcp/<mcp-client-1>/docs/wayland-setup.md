# desktop-mcp — host modes & Wayland setup

`desktop-mcp` ships **three modes**, each a separately-registered MCP server
sharing one codebase. Mode is chosen by `DESKTOP_MCP_DRIVER` in the wrapper.

| Server | Namespace | Wrapper | Target | Sandbox? |
|--------|-----------|---------|--------|----------|
| `desktop` | `mcp__desktop__*` | `desktop-mcp-wrapper.sh` | container Xvfb `:99` | ✅ isolated |
| `desktop-x11` | `mcp__desktop_x11__*` | `desktop-x11-wrapper.sh` | real X11 `:0` | ❌ real screen |
| `desktop-wayland` | `mcp__desktop_wayland__*` | `desktop-wayland-wrapper.sh` | real GNOME/Wayland | ❌ real screen |

> ⚠️ **The two host modes drive your REAL machine.** Synthetic input goes to
> whatever window is focused; screenshots capture your actual screen. There is
> no sandbox. Use them deliberately.

---

## Mode capability matrix (verified on GNOME Shell 50.1 / Wayland, 2026-06-20)

| Capability | sandbox | x11 (on real X11) | x11 (on XWayland) | wayland |
|------------|---------|-------------------|-------------------|---------|
| screenshot | ✅ mss | ✅ mss | ⚠️ **black** (no native content) | ✅ portal/gnome-screenshot |
| input (move/click/type/key) | ✅ | ✅ | ⚠️ X11 apps only, not native Wayland | ✅ ydotool (needs setup) |
| cursor_position | ✅ | ✅ | ✅ (XWayland) | ❌ unsupported on Wayland |

**On a GNOME/Wayland session, use `desktop-wayland`.** The `desktop-x11` mode is
correct only on a genuine X11 login session; on XWayland it connects but
captures black and cannot reach native Wayland windows.

---

## Native Windows (non-WSL)

On **native Windows** — Python running as a Windows process, *not* under WSL —
the factory selects the `windows` driver, because `sys.platform` starts with
`win` (`factory.py` → `platform.startswith("win")`).

That driver is a **designed-but-unimplemented stub in v1**: `WindowsDriver`
raises `NotImplementedError` from its constructor and from every method
(`drivers/windows.py`). So there is currently **no working native-Windows
mode** — constructing it fails fast with a message pointing you at the
container driver.

Why a separate driver is needed at all: like `x11`/`wayland`, a Windows mode
would inject input and capture the **real** screen (no sandbox), so it needs
its own capture/permission path — planned as `pyautogui` reusing the X11 code
path — plus its own safety gate before it can ship.

**WSL is unaffected.** Under WSL `sys.platform` is `linux`, so the `windows`
driver never loads; the platform branch is skipped entirely. On WSL2 Ubuntu use
the sandbox **`desktop`** server (containerised, host-agnostic) — see
`wsl-setup.sh` in the project root. The `x11`/`wayland` host modes assume a real
Linux desktop session, which WSL does not provide.

---

## `desktop-x11` setup

No installs on a real X11 session — `~/.Xauthority` is used automatically.

On a GNOME/Wayland host (`:0` = XWayland) the wrapper auto-normalizes mutter's
auth cookie (`$XDG_RUNTIME_DIR/.mutter-Xwaylandauth.*`) into an explicit
`host/unix:0` entry, because python-xlib rejects mutter's empty-display entry.
No action needed — but expect the degraded behavior in the matrix above.

---

## `desktop-wayland` setup

### Capture (works today, no system install)
Uses, in order (first success wins):
1. **`org.freedesktop.portal.Screenshot`** via `jeepney` (pure-python, already a
   project dependency — `uv add jeepney` done). On first use GNOME *may* show a
   one-time screenshot-permission dialog; approve it. **This is the working path
   on GNOME 50.**
2. **`gnome-screenshot -f`** — only if you install it (below).
3. **`org.gnome.Shell.Screenshot`** — legacy, works < GNOME 41; `AccessDenied`
   on modern GNOME. Kept for older hosts.

Optional capture fallback:
```bash
sudo apt install gnome-screenshot
```

### Input (REQUIRES privileged setup — ydotool)
Wayland has no input-injection protocol; we inject at the kernel `uinput` layer
via **ydotool** (compositor-agnostic). All steps below are run by **you**.

**1. Install ydotool (need >= 1.0 for the syntax this driver emits):**
```bash
sudo apt install ydotool          # provides `ydotool` + `ydotoold`
ydotool --version                 # MUST be >= 1.0.0
```
If apt ships < 1.0 (older Ubuntu), build from source:
```bash
sudo apt install git cmake scdoc libudev-dev
git clone https://github.com/ReimuNotMoe/ydotool && cd ydotool
mkdir build && cd build && cmake .. && make && sudo make install
```

**2. Grant `/dev/uinput` access (so ydotoold needn't run as root):**
```bash
# load the module now + on every boot
sudo modprobe uinput
echo uinput | sudo tee /etc/modules-load.d/uinput.conf

# udev rule: uinput owned by the `input` group, mode 0660
echo 'KERNEL=="uinput", GROUP="input", MODE="0660", OPTIONS+="static_node=uinput"' \
  | sudo tee /etc/udev/rules.d/80-uinput.rules
sudo udevadm control --reload-rules && sudo udevadm trigger

# add yourself to the input group, then LOG OUT/IN (group change needs a new session)
sudo usermod -aG input "$USER"
```
Verify after re-login: `id -nG | grep input` and `test -w /dev/uinput && echo writable`.

**3. Run the ydotoold daemon (user systemd service, always on):**
```bash
mkdir -p ~/.config/systemd/user
cat > ~/.config/systemd/user/ydotoold.service <<'UNIT'
[Unit]
Description=ydotool daemon
[Service]
ExecStart=/usr/bin/ydotoold --socket-path=%t/.ydotool_socket --socket-perm=0600
Restart=always
[Install]
WantedBy=default.target
UNIT
systemctl --user daemon-reload
systemctl --user enable --now ydotoold
```
`%t` is `$XDG_RUNTIME_DIR`, so the socket lands at
`$XDG_RUNTIME_DIR/.ydotool_socket` — exactly what `desktop-wayland-wrapper.sh`
sets `YDOTOOL_SOCKET` to. Adjust the wrapper if you use a different path.

**4. Verify input live (the deferred smoke test):**
```bash
export YDOTOOL_SOCKET="$XDG_RUNTIME_DIR/.ydotool_socket"
ydotool mousemove --absolute -x 960 -y 540   # cursor jumps to centre
ydotool type "hello from ydotool"            # types into the focused window
```
If `mousemove`/`type` work, the `desktop-wayland` input tools work.

### Known limits (by design)
- **`cursor_position`** raises `NotImplementedError` — Wayland exposes no global
  pointer query.
- **`scroll`** emits `ydotool mousemove --wheel`; verify against your ydotool
  version (wheel flag changed across releases).
- **`key`** maps common names to evdev codes (see `_EVDEV` in `wayland.py`);
  exotic keys need their evdev code added there.

---

## Registration (`~/.claude.json` → `mcpServers`)
Add alongside the existing `desktop` entry (apply manually — `~/.claude.json`
has other pending edits):
```json
"desktop-x11": {
  "command": "/home/user/.claude/mcp/<mcp-client-1>/desktop-x11-wrapper.sh",
  "args": []
},
"desktop-wayland": {
  "command": "/home/user/.claude/mcp/<mcp-client-1>/desktop-wayland-wrapper.sh",
  "args": []
}
```
Restart Claude Code; the `mcp__desktop_x11__*` and `mcp__desktop_wayland__*`
tools appear. The `.venv` wrappers are `+x` (git `core.fileMode=false` here —
re-`chmod +x` after a fresh clone).
