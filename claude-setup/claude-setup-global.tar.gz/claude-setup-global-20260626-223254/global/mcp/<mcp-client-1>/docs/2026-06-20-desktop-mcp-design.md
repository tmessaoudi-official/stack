# desktop-mcp — Design Spec (v1)

> Date: 2026-06-20 · Status: Approved (design), pending implementation plan
> Location: `~/.claude/mcp/<mcp-client-1>/` (sibling to `~/.claude/mcp/<mcp-client-3>/`)
> This is **subsystem #1** of a 3-part effort. #2 = port the Trivy Node MCP to Python; #3 = wire MCPs into bundle/import/adapt-project/bootstrap. Each gets its own spec → plan → implement cycle. (A #4 — permission-gate bypass sentinel — was raised and is under challenge; not part of this spec.)

## 1. Purpose

A Model Context Protocol server that lets an AI agent (Claude) **control a real desktop** — see the screen and drive mouse/keyboard — i.e. local "computer use". v1 targets a **sandboxed virtual Linux desktop inside a container**; the architecture is designed so a Wayland-host driver and a Windows driver can be added later behind the same tool contract.

Non-goal for v1: human-mimicry / anti-detection (jitter, Bézier paths). An agent needs *accurate* coordinates, not human-looking ones. Explicitly out of scope (YAGNI).

## 2. Why a container (Approach A)

The target machine runs **GNOME + Wayland** (`XDG_SESSION_TYPE=wayland`, verified 2026-06-20). Wayland deliberately blocks global synthetic input and root-window capture; `xdotool`/XTEST can't drive native Wayland windows, `grim` doesn't work on mutter, and host control needs the fiddly `xdg-desktop-portal` route with a per-session permission dialog.

A container running **Xvfb (headless X11)** sidesteps all of that: inside pure X11, input (`pyautogui`) and capture (`mss`/`scrot`) "just work", the agent is sandboxed away from the user's real desktop, and the result is reproducible on any machine with Docker — Wayland host, X11 host, or a fresh install. This mirrors Anthropic's reference computer-use demo.

## 3. Architecture — driver pattern

```
┌──────────────────────────────────────────────┐
│  MCP server (Python, stdio JSON-RPC)           │
│  tools: screenshot, screen_size, cursor_position,
│         move, click, double_click, right_click, │
│         drag, scroll, type, key                 │
├──────────────────────────────────────────────┤
│  Driver ABC (drivers/base.py)                   │
│   screenshot() -> PNG bytes                      │
│   screen_size() -> (w,h)                         │
│   cursor_position() -> (x,y)                     │
│   move(x,y) click(x,y,button) double_click(...)  │
│   drag(x,y) scroll(dx,dy) type(text) key(combo)  │
├──────────┬───────────────┬──────────────────────┤
│ X11Driver│ WaylandDriver  │ WindowsDriver         │
│ pyautogui│ portal+ydotool │ pyautogui (shared)    │
│  on :99  │  NotImplemented│  NotImplemented        │
│  v1 ✅   │  (designed-for)│  (designed-for)        │
└──────────┴───────────────┴──────────────────────┘
```

The MCP tool layer is backend-agnostic. `factory.py` selects the driver at startup from `sys.platform` + `$XDG_SESSION_TYPE`, overridable by `DESKTOP_MCP_DRIVER=x11|wayland|windows`. v1 ships only `X11Driver`; the other two raise `NotImplementedError` with a clear message, and the ABC is shaped to fit them (e.g. `screenshot` returns raw PNG bytes so any backend can supply them).

`pyautogui` is cross-platform (X11 + Windows + macOS), so the future `WindowsDriver` largely reuses the `X11Driver` code path; only `WaylandDriver` (portal + `ydotool`) is genuinely separate.

## 4. Transport — `docker run -i` stdio (resolves portability)

Claude Code spawns the MCP as a stdio command pointing at a thin wrapper:

```bash
# desktop-mcp-wrapper.sh (entrypoint registered in ~/.claude.json)
exec docker run -i --rm -p 6080:6080 desktop-mcp:latest
```

- The container entrypoint boots `Xvfb :99` + `fluxbox` + `x11vnc` + `noVNC`, then launches `python -m desktop_mcp` speaking JSON-RPC on stdin/stdout.
- One **ephemeral** container per MCP session (`--rm`); state is not persisted across reconnects in v1.
- Live view at `http://localhost:6080` (noVNC) so the user can watch the agent operate — included in v1.
- First run builds the image if absent (wrapper: `docker image inspect desktop-mcp:latest >/dev/null 2>&1 || docker build -t desktop-mcp:latest "$DIR"`).
- No host display dependency, no published auth surface beyond the local noVNC port → works identically on Wayland/X11/fresh-install hosts. Only requirement: Docker.

## 5. Package layout

```
~/.claude/mcp/<mcp-client-1>/
  desktop-mcp-wrapper.sh        # stdio entrypoint: docker run -i (+ build-if-absent)
  Dockerfile                    # base + Xvfb + fluxbox + x11vnc + noVNC + python pkg
  pyproject.toml                # `desktop_mcp` package (pip/uv installable → Windows later)
  src/desktop_mcp/
    __main__.py                 # `python -m desktop_mcp` → server.run()
    server.py                   # MCP tool definitions, stdio transport
    drivers/base.py             # Driver ABC
    drivers/x11.py              # v1 — pyautogui against DISPLAY=:99
    drivers/wayland.py          # stub: NotImplementedError (portal+ydotool design noted)
    drivers/windows.py          # stub: NotImplementedError (pyautogui path)
    factory.py                  # driver selection (platform + DESKTOP_MCP_DRIVER)
  tests/
    test_tool_mapping.py        # FakeDriver: each MCP tool → correct driver call/args
    test_x11_integration.py     # Xvfb + xclock: screenshot → click coord → assert state
  docs/2026-06-20-desktop-mcp-design.md   # this spec
```

## 6. Tool contract (Anthropic computer-use shape)

| Tool | Args | Returns |
|------|------|---------|
| `screenshot` | — | base64 PNG of the virtual screen |
| `screen_size` | — | `{width, height}` |
| `cursor_position` | — | `{x, y}` |
| `move` | `x, y` | ok |
| `click` | `x?, y?, button=left` | ok |
| `double_click` | `x?, y?` | ok |
| `right_click` | `x?, y?` | ok |
| `drag` | `x, y, button=left` | ok (press→move→release from current pos) |
| `scroll` | `dx, dy` | ok |
| `type` | `text` | ok |
| `key` | `combo` e.g. `"ctrl+c"` | ok |

Coordinates absolute, top-left origin. Matching Anthropic's contract means Claude already "knows" how to use these tools.

## 7. Registration

Add to `~/.claude.json → mcpServers`:

```json
"desktop": {
  "command": "/home/user/.claude/mcp/<mcp-client-1>/desktop-mcp-wrapper.sh",
  "args": [],
  "env": {}
}
```

`~/.claude.json` writes may hit the Claude Code classifier → the exact edit will be presented for **manual `!`-prefixed execution**, not written autonomously.

## 8. Testing (CLAUDE.md Rule 7 — TDD)

- **Unit** (`test_tool_mapping.py`): inject a `FakeDriver`; assert each MCP tool invokes the right driver method with the right args. No real display.
- **Integration** (`test_x11_integration.py`): under `Xvfb :99`, launch `xclock`, call `screenshot`, `click` a known coordinate, assert observable state change (window focus / pixel delta). Runs in the container or any X11 CI.
- **Infra** (Rule 7 for infra): `bash -n desktop-mcp-wrapper.sh`; `docker build` succeeds; `python -m desktop_mcp --help` (or a `--selftest` that loads the driver and exits) parses.

## 9. Safety

The container sandbox is the v1 safety story — a misbehaving agent drives only the virtual screen, never the user's real desktop. The future Wayland host driver (subsystem-later) will require an explicit per-session allow-gate before it touches the real screen.

## 10. v1 scope

**In:** MCP core + stdio, Driver ABC, `X11Driver`, container (Xvfb+fluxbox+x11vnc+noVNC), the 11 tools, registration, unit + integration + infra tests.

**Designed-for, NOT built in v1:** `WaylandDriver`, `WindowsDriver`, macOS, human-jitter/Bézier, persistent-container/session state, bundle/bootstrap integration (= subsystem #3).

## 11. Open items to resolve in the plan

- Base image choice (Ubuntu vs a slim X11 base) and whether to layer on `00base` from /path/to/your/project or stay standalone (leaning standalone — this is not a /path/to/your/project tier image).
- `uv` vs `pip` for the in-container Python env.
- Exact `--selftest` contract for the infra test.
- Whether `screenshot` should auto-downscale large screens to keep token cost sane for the agent.
