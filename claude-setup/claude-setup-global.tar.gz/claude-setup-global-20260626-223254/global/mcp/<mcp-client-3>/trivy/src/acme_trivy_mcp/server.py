"""acme-trivy MCP server (Python port of index.js) — parity-first."""
import json

from mcp.server.fastmcp import FastMCP

from .sf_client import sf_fetch

mcp = FastMCP("acme-trivy")


def _coalesce(*vals):
    """JS `a ?? b ?? c` — first value that is not None (a real 0/"" is returned)."""
    for v in vals:
        if v is not None:
            return v
    return None


def _opt(obj, key):
    """JS optional chaining `obj?.key` — None unless obj is a dict."""
    return obj.get(key) if isinstance(obj, dict) else None


def _text(obj) -> str:
    return json.dumps(obj, indent=2, ensure_ascii=False)


@mcp.tool(
    description="List Trivy spaces (projects) with their vulnerability counts. "
    "Filter by domain, pole, criticality or search by name/IDA."
)
def list_spaces(
    page: int = 1,
    items_per_page: int = 20,
    search: str | None = None,
    domain: str | None = None,
    pole: str | None = None,
    criticality: str | None = None,
    deployment: str | None = None,
) -> str:
    params = {"page": page, "itemsPerPage": items_per_page, "pagination": True}
    if search:
        params["search"] = search
    if domain:
        params["domain.name"] = domain
    if pole:
        params["pole.name"] = pole
    if criticality:
        params["criticality"] = criticality
    if deployment:
        params["deployment.type"] = deployment
    data = sf_fetch("/api/v2/trivy/space", params)

    if isinstance(data, dict):
        items = _coalesce(data.get("hydra:member"), data.get("items"), data)
        total = _coalesce(data.get("hydra:totalItems"), data.get("total"), "?")
    else:
        items, total = data, "?"

    formatted = []
    for s in items:
        row = {
            "id": _coalesce(s.get("id"), s.get("@id")),
            "project": _coalesce(s.get("title"), s.get("name"), s.get("projectName")),
            "ida": _coalesce(s.get("ids"), s.get("ida"), s.get("code")),
            "domain": _coalesce(_opt(s.get("domain"), "name"), s.get("domainName"), s.get("domain")),
            "pole": _coalesce(_opt(s.get("pole"), "name"), s.get("poleName"), s.get("pole")),
            "deployment": _coalesce(_opt(s.get("deployment"), "type"), s.get("deploymentType"), s.get("deployment")),
            "critical": _coalesce(s.get("error_critical"), s.get("criticalCount"), s.get("critical"), 0),
            "high": _coalesce(s.get("error_high"), s.get("highCount"), s.get("high"), 0),
            "medium": _coalesce(s.get("error_medium"), s.get("mediumCount"), s.get("medium"), 0),
            "low": _coalesce(s.get("error_low"), s.get("lowCount"), s.get("low"), 0),
            "lastScan": _coalesce(s.get("scanned_at"), s.get("lastScanDate"), s.get("scanDate")),
        }
        formatted.append({k: v for k, v in row.items() if v is not None})  # JS omits undefined keys

    return _text({"total": total, "page": page, "itemsPerPage": items_per_page, "spaces": formatted})


@mcp.tool(
    description="Get global vulnerability counters across all ACME projects "
    "(total critical, high, medium, low counts visible at the top of the Console Trivy)."
)
def get_counters() -> str:
    return _text(sf_fetch("/api/v2/trivy/space/counters"))


@mcp.tool(description="List available departments/domains in the ACME Software Factory (useful for filtering).")
def get_departments() -> str:
    return _text(sf_fetch("/api/departments"))


@mcp.tool(
    description="Check the currently authenticated user on the ACME Software Factory. "
    "Useful to verify the cookie is still valid."
)
def whoami() -> str:
    return _text(sf_fetch("/api/whoami"))


@mcp.tool(description="Get detailed vulnerability information for a specific Trivy space/project by its IDA code.")
def get_space_detail(ida: str) -> str:
    try:
        data = sf_fetch("/api/v2/trivy/factory", {"space.ids": ida})
    except Exception:  # bare catch — intentional fallback (index.js:159), NOT a bug
        data = sf_fetch(
            "/api/v2/trivy/space",
            {"page": 1, "itemsPerPage": 1, "pagination": True, "search": ida},
        )
    return _text(data)


@mcp.tool(description="List individual vulnerabilities for a specific Trivy factory scan, grouped by severity.")
def get_vulnerabilities(
    factory_id: int, severity: str | None = None, page: int = 1, items_per_page: int = 50
) -> str:
    params = {"page": page, "itemsPerPage": items_per_page, "pagination": True}
    if severity:
        params["severity"] = severity
    data = sf_fetch(f"/api/v2/trivy/{factory_id}/vulnerabilities", params)
    if isinstance(data, dict):
        items = _coalesce(data.get("hydra:member"), data.get("items"), [])
        total = _coalesce(data.get("hydra:totalItems"), data.get("total"), len(items))
    else:
        items = data if isinstance(data, list) else []
        total = len(items)
    return _text({"total": total, "page": page, "itemsPerPage": items_per_page, "vulnerabilities": items})


@mcp.tool(description="Probe candidate API endpoints to discover which ones exist and return vulnerability data.")
def probe_api(factory_id: int, ida: str | None = None) -> str:
    candidates = [
        (f"/api/v2/trivy/{factory_id}/vulnerabilities", {"page": 1, "itemsPerPage": 5, "pagination": True}),
        (f"/api/v2/trivy/{factory_id}/vulnerabilities", {"severity": "CRITICAL"}),
    ]
    if ida:
        candidates += [
            ("/api/v2/trivy/vulnerability", {"space.ids": ida}),
            ("/api/v2/trivy/vulnerability", {"space": ida}),
        ]
    results = []
    for path, params in candidates:
        try:
            data = sf_fetch(path, params)
            if isinstance(data, dict):
                member = _coalesce(data.get("hydra:member"), data.get("items"), None)
                keys = list(data.keys())
            elif isinstance(data, list):
                member, keys = data, []
            else:
                member, keys = None, []
            results.append(
                {
                    "path": path,
                    "params": params,
                    "ok": True,
                    "count": len(member) if member is not None else None,
                    "sample": (member[0] if member else None) if member is not None else data,
                    "keys": keys,
                }
            )
        except Exception as e:
            results.append({"path": path, "params": params, "ok": False, "error": str(e)})
    return _text(results)
