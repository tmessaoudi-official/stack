"""Software Factory HTTP client — the single mockable seam (parity with index.js sfFetch)."""
import os

import httpx

BASE_URL = "https://internal-portal.cloud-acme.fr"


def _proxy() -> str | None:
    return (
        os.environ.get("HTTPS_PROXY")
        or os.environ.get("https_proxy")
        or os.environ.get("HTTP_PROXY")
        or os.environ.get("http_proxy")
        or None
    )


def get_cookie() -> str:
    cookie = os.environ.get("ACME_INTERNAL_PORTAL_COOKIE")
    if not cookie:
        raise RuntimeError(
            "ACME_INTERNAL_PORTAL_COOKIE environment variable is not set.\n"
            "Extract it from your browser DevTools (Application → Cookies) after logging in to:\n"
            f"{BASE_URL}/dashboard/transverse/trivy-spaces\n"
            "Look for AWSELBAuthSessionCookie-0 (and -1 if present)."
        )
    return cookie


def _client_get(url: httpx.URL, headers: dict, follow_redirects: bool):
    """Isolated network boundary so tests can monkeypatch it."""
    with httpx.Client(proxy=_proxy(), follow_redirects=follow_redirects, timeout=30.0) as c:
        return c.get(url, headers=headers)


def sf_fetch(path: str, params: dict | None = None):
    qp: dict[str, str] = {}
    for k, v in (params or {}).items():
        if v is not None and v != "":
            if v is True:
                qp[k] = "true"
            elif v is False:
                qp[k] = "false"
            else:
                qp[k] = str(v)
    url = httpx.URL(BASE_URL + path, params=qp)
    res = _client_get(url, {"Cookie": get_cookie(), "Accept": "application/json"}, False)
    if res.status_code in (301, 302):
        raise RuntimeError(
            "Session expired (redirected to SSO). Please renew your ACME_INTERNAL_PORTAL_COOKIE:\n"
            "1. Open https://internal-portal.cloud-acme.fr in your browser\n"
            "2. DevTools → Application → Cookies → copy AWSELBAuthSessionCookie-0\n"
            "3. Update ACME_INTERNAL_PORTAL_COOKIE in ~/.claude/mcp/acme-trivy.env and restart Claude Code"
        )
    if not (200 <= res.status_code < 300):
        raise RuntimeError(f"API error {res.status_code} {res.reason_phrase} for {url}")
    return res.json()
