import sys

from .server import mcp

EXPECTED_TOOLS = {
    "list_spaces",
    "get_counters",
    "get_space_detail",
    "get_departments",
    "whoami",
    "probe_api",
    "get_vulnerabilities",
}


def main() -> None:
    if "--selftest" in sys.argv:
        import asyncio

        names = {t.name for t in asyncio.run(mcp.list_tools())}
        missing, extra = EXPECTED_TOOLS - names, names - EXPECTED_TOOLS
        if missing or extra:
            print(f"SELFTEST FAIL missing={missing} extra={extra}", file=sys.stderr)
            sys.exit(1)
        print(f"SELFTEST OK: {len(names)} tools")
        sys.exit(0)
    mcp.run()


if __name__ == "__main__":
    main()
