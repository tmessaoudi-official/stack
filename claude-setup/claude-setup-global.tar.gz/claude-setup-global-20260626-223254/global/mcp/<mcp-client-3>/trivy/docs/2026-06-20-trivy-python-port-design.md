# trivy-mcp Python Port — Design Spec (v1)

> Date: 2026-06-20 · Status: Drafted (design), pending user review
> Target: `~/.claude/mcp/<mcp-client-3>/trivy/` (Python port, behavioral parity with current Node server)
> This is **subsystem #2** of a 3-part effort. #1 = a Python desktop-mcp (`~/.claude/mcp/<mcp-client-1>/docs/2026-06-20-desktop-mcp-design.md`); #3 = wire MCPs into bundle/import/adapt-project/bootstrap. This spec also **establishes the shared Python-MCP convention** that #1 and #3 reuse.

## 1. Purpose

Port the existing **ACME Software Factory Trivy MCP server** from Node.js to Python at **behavioral parity** — every tool keeps the same name, input schema, HTTP behavior, auth model, error text, and output shape. The port introduces no new capability; its value is establishing **the shared Python-MCP convention** (SDK + env/venv + wrapper contract) that the other Python MCPs in this effort adopt.

Non-goal for v1: changing tool behavior, adding tools, "improving" the heuristic field-mapping or `probe_api` endpoint guessing. Parity first — the Node server is the oracle.

## 2. Why

The current server is Node + `@modelcontextprotocol/sdk` + `zod` + `undici` [Verified: read `package.json` — those three deps, `"type":"module"`, `start: node index.js`]. Subsystem #1 (desktop-mcp) is Python, and #3 will template MCP packaging across the bundle. Maintaining one MCP toolchain (Python: `mcp` SDK + `uv`/venv + a thin bash wrapper) instead of two (Node + Python) reduces per-MCP boilerplate and lets bundle integration target a single packaging shape. [Speculative — consolidation rationale, not a measured benefit.]

The Node server is small and self-contained — 282 lines, one file, no build step, 7 tools, 6 distinct HTTP paths [Verified: read `index.js`]. That makes it a low-risk first parity port and a clean reference implementation for the convention.

## 3. The shared Python-MCP convention

This is the reusable contract subsystems #1 and #3 inherit. Three pillars:

| Pillar | Choice | Rationale |
|--------|--------|-----------|
| **SDK** | official `mcp` package (Python), `mcp.server.fastmcp.FastMCP` + stdio transport | Python equivalent of the Node `McpServer` + `StdioServerTransport` pair already in use [Verified: `index.js` imports `McpServer`, `StdioServerTransport`]. `FastMCP` gives the same decorator-per-tool ergonomics as `server.tool(...)`. |
| **Env / venv** | `uv` with a project-local `.venv`; `pyproject.toml` defines the package; deps pinned | `uv` is the current-best Python env manager (fast, lockfile, no global pollution) [Inferred: matches #1's leaning toward `uv` per the desktop spec open items]. Wrapper bootstraps `.venv` if absent, mirroring desktop-mcp's build-if-absent pattern. |
| **Wrapper** | thin bash `*-mcp-wrapper.sh` that loads the per-MCP `.env`, then `exec`s the Python module | Preserves the **existing** wrapper contract exactly (see §6); only the final `exec` line changes from `node …/index.js` to the venv python running `-m`. |

The convention is named **"the shared Python-MCP convention"** throughout the effort. A future MCP adopts it by copying the `pyproject.toml` + wrapper skeleton and renaming the package.

## 4. Architecture

```
┌───────────────────────────────────────────────┐
│  MCP server (Python, stdio JSON-RPC)            │
│  FastMCP("acme-trivy")                          │
│  tools: list_spaces, get_counters,             │
│         get_space_detail, get_departments,      │
│         whoami, probe_api, get_vulnerabilities  │
├───────────────────────────────────────────────┤
│  sf_client.py  — Software Factory HTTP client   │
│   get_cookie()  → reads ACME_INTERNAL_PORTAL_COOKIE          │
│   sf_fetch(path, params) → httpx GET,           │
│     Cookie + Accept headers, manual redirect,   │
│     302/301 → "session expired" error,          │
│     !ok → "API error <status>" error            │
│   proxy: HTTPS_PROXY/HTTP_PROXY auto-detect      │
└───────────────────────────────────────────────┘
```

`sf_fetch` is the single HTTP chokepoint — identical to the Node `sfFetch` — and the seam the parity tests mock. [Verified: `index.js` routes all 6 endpoints through `sfFetch`.]

**HTTP library:** `httpx` (sync client). It is the current-best Python HTTP client with first-class proxy support, manual-redirect control (`follow_redirects=False`), and is the closest analogue to Node's `undici`/`fetch` with `redirect:"manual"`. [Inferred: `undici` in Node was used for proxy dispatch + manual redirect; `httpx` covers both natively. Not deprecated.]

**Proxy:** Node auto-detects `HTTPS_PROXY/https_proxy/HTTP_PROXY/http_proxy` and installs a global dispatcher [Verified: `index.js` lines 17–19]. Python equivalent: pass `proxies=` to the `httpx.Client` from the same four env vars (or rely on httpx's built-in `trust_env`), preserving the precedence order HTTPS→HTTP.

## 5. Package layout

```
~/.claude/mcp/<mcp-client-3>/trivy/
  ../trivy-mcp-wrapper.sh         # UNCHANGED contract — only final exec line swaps node→python (§6)
  ../trivy.env                    # UNCHANGED — ACME_INTERNAL_PORTAL_COOKIE (NEVER read by Claude)
  pyproject.toml                  # `acme_trivy_mcp` package; deps: mcp, httpx (pinned)
  uv.lock                         # uv lockfile (committed)
  src/acme_trivy_mcp/
    __main__.py                   # `python -m acme_trivy_mcp` → mcp.run()
    server.py                     # FastMCP + 7 @mcp.tool() definitions (parity with index.js)
    sf_client.py                  # get_cookie() + sf_fetch() (the mockable HTTP seam)
  tests/
    test_parity.py                # per-tool: mocked sf_fetch → assert same shape as Node oracle
    test_sf_client.py             # auth missing, 302 redirect, non-ok status → error text parity
  docs/2026-06-20-trivy-python-port-design.md   # this spec
  index.js · package.json         # Node originals — KEPT until parity verified, then removed in the plan
```

`BASE_URL = "https://internal-portal.cloud-acme.fr"`, server name `acme-trivy`, version carried forward [Verified: `index.js` lines 21, 72–76].

## 6. Transport / wrapper (preserve the existing contract)

The launch wrapper `~/.claude/mcp/<mcp-client-3>/trivy-mcp-wrapper.sh` stays **functionally identical** [Verified: read wrapper — it `set -euo pipefail`, sources `log-helpers.sh` with a `log_obs` no-op fallback, hard-fails if `trivy.env` is missing with a 3-line DevTools hint, parses `KEY=VALUE` lines skipping blanks/`#`/non-`=`, `export`s each, then `exec node …/index.js`].

**Only change:** the final line

```bash
# BEFORE (Verified — wrapper line 21):
exec node "${HOME}/.claude/mcp/<mcp-client-3>/trivy/index.js"
# AFTER (the shared Python-MCP convention):
exec "${HOME}/.claude/mcp/<mcp-client-3>/trivy/.venv/bin/python" -m acme_trivy_mcp
```

Env-loading, the `trivy.env` requirement, the cookie-export loop, and `log_obs` observability are untouched. A venv-bootstrap line (mirroring desktop-mcp's build-if-absent) is added above the exec: `[[ -x .venv/bin/python ]] || uv sync` — finalized in the plan. The commented `npm ci` line is replaced by the commented `uv sync` equivalent.

**Auth:** `ACME_INTERNAL_PORTAL_COOKIE` (referred to by NAME only — never read, printed, or embedded). The Python `get_cookie()` reads it from the process env exactly as the wrapper exports it, raising the same multi-line "ACME_INTERNAL_PORTAL_COOKIE environment variable is not set / extract from DevTools" error when absent [Verified: `index.js` lines 25–36].

## 7. Tool contract / parity

All 7 tools confirmed against `index.js` [Verified: read all 7 `server.tool(...)` registrations]. Every tool returns MCP `content:[{type:"text", text: <pretty-JSON>}]` — the Python port returns the identical string for identical inputs.

| Tool | Input schema (parity) | Behavior |
|------|----------------------|----------|
| `list_spaces` | `page=1, itemsPerPage=20 (1–100), search?, domain?, pole?, criticality?, deployment?` | GET `/api/v2/trivy/space` with `pagination:true` + mapped filter keys (`domain.name`, `pole.name`, `criticality`, `deployment.type`); flattens each item via the multi-fallback field map (`hydra:member`→`items`→raw; `error_critical`→`criticalCount`→`critical`→0; etc.); returns `{total,page,itemsPerPage,spaces[]}`. |
| `get_counters` | _none_ | GET `/api/v2/trivy/space/counters`; returns raw JSON. |
| `get_space_detail` | `ida` (required) | GET `/api/v2/trivy/factory?space.ids=<ida>`; on **any** exception falls back to `/api/v2/trivy/space?search=<ida>&itemsPerPage=1`; returns raw JSON. |
| `get_departments` | _none_ | GET `/api/departments`; returns raw JSON. |
| `whoami` | _none_ | GET `/api/whoami`; returns raw JSON — used to verify the cookie is still valid. |
| `probe_api` | `factoryId` (int, required), `ida?` | Iterates 2 (+2 if `ida`) candidate endpoints, captures per-candidate `{path,params,ok,count,keys,sample}` or `{ok:false,error}`; returns the array. Discovery/debug tool — keep the heuristic verbatim. |
| `get_vulnerabilities` | `factoryId` (int, required), `severity?, page=1, itemsPerPage=50 (1–100)` | GET `/api/v2/trivy/<factoryId>/vulnerabilities` with `pagination:true` (+`severity`); extracts `hydra:member`→`items`→array; returns `{total,page,itemsPerPage,vulnerabilities[]}`. |

**Parity-critical details to replicate exactly:**
- `zod` schemas → `mcp`/`pydantic` arg models with **the same defaults, min/max, and required/optional flags** (e.g. `itemsPerPage` default 20 for `list_spaces` but **50** for `get_vulnerabilities`; both clamped 1–100) [Verified: lines 85, 260].
- Param-pruning: Node only sets a query param when the value is `!== undefined/null/""` [Verified: `sfFetch` lines 40–44]. Python `sf_fetch` must skip `None`/empty identically — a divergence here changes the URL and breaks parity.
- The field-fallback chains in `list_spaces` are **load-bearing** (the API shape is uncertain); port the exact `??` chains as Python `or`-with-`None`-awareness (careful: JS `??` only falls through on null/undefined, NOT on `0`/`""` — a naive Python `or` would wrongly skip a real `0` count). This is the #1 parity trap.
- `get_space_detail` swallows **all** errors in the try/catch before falling back [Verified: bare `catch {}` line 159] — Python must catch broadly (the fallback is intentional, not a bug to "fix").

## 8. Testing (CLAUDE.md Rule 7 — TDD) — PARITY-FIRST

The **Node server is the test oracle.** Tests are written **before** the Python implementation and assert the Python output equals the Node output for the same input. **No real ACME calls** — the `sf_fetch` HTTP layer is mocked with captured/synthetic JSON fixtures; `ACME_INTERNAL_PORTAL_COOKIE` is never needed in tests.

- **`test_parity.py`** — for each of the 7 tools: feed `sf_fetch` a fixture response (mock/monkeypatch), invoke the tool, assert the returned `content[0].text` matches the expected shape. Where practical, generate the expected value by running the Node tool against the **same fixture** (Node oracle harness) so the assertion is "Python == Node", not "Python == my hand-typed guess" (avoids the fixture-leakage trap in CLAUDE.md Phase 6). Cover the parity traps explicitly: a `0` critical count must survive the fallback chain; `itemsPerPage` defaults differ per tool; empty/None filters must be pruned from the URL.
- **`test_sf_client.py`** — auth/error parity: missing `ACME_INTERNAL_PORTAL_COOKIE` → exact multi-line error; mocked 302/301 → "Session expired (redirected to SSO)…" error; mocked non-2xx → `API error <status> <statusText> for <url>`; `get_space_detail` fallback fires on first-call exception.
- **Infra (Rule 7 for infra):** `bash -n trivy-mcp-wrapper.sh` + `shellcheck`; `uv sync` succeeds; `python -m acme_trivy_mcp` imports and registers 7 tools (a `--selftest`/dry import that lists tool names and exits, asserting the set == the 7 names — catches a dropped/renamed tool).
- **Evidence:** paste the test runner output (names + pass/fail counts) as Coverage evidence before declaring done. Tests must be **executed**, not merely written.

## 9. Registration

The MCP is registered in `~/.claude.json → mcpServers` under key **`acme-trivy-stdio`** as:

```json
"acme-trivy-stdio": {
  "command": "/home/user/.claude/mcp/<mcp-client-3>/trivy-mcp-wrapper.sh",
  "args": []
}
```
[Verified: extracted that key only via `python3 -c` — `command` points at the wrapper, `args` empty; no secrets in the entry.]

**Because the `command` is the wrapper path and the wrapper path does not change, the registration needs no edit.** The node→python swap happens entirely inside the wrapper (§6). This is the key blast-radius win.

> `~/.claude.json` and `settings.json` edits are **classifier-blocked** for the agent loop. If any registration change *were* needed, the exact edit would be **presented for manual `!`-prefixed execution**, never written autonomously. For this port, none is expected — flagged here only so the plan confirms it after the wrapper swap.

## 10. Blast radius

[Verified: `grep -rl` over `~/.claude` for `acme-trivy-stdio` / `trivy-mcp-wrapper` / `mcp/<mcp-client-3>/trivy` / `index.js` path.]

| Reference | Type | Action |
|-----------|------|--------|
| `~/.claude/mcp/<mcp-client-3>/trivy-mcp-wrapper.sh` | live launcher | **Change** — final `exec` line only (§6); contract preserved. |
| `~/.claude.json` `acme-trivy-stdio` | live registration | **Stays** — points at the unchanged wrapper path. No edit. |
| `~/.claude/mcp/<mcp-client-3>/trivy/index.js`, `package.json` | live Node impl | **Remove in the plan** — only after parity tests pass; kept meanwhile as the oracle. |
| `~/.claude/mcp/<mcp-client-3>/trivy.env` | secret env | **Untouched, never read.** |
| `projects/**/meta-reports`, `inspections`, `gaps`, `sleuth`, `audits`, `*.jsonl`, `logs/edits`, `file-history`, `paste-cache`, workflow JSON | historical logs/reports | **No action** — immutable history; not code references. |

No shell-profile, `settings.json`, or Makefile reference to the wrapper/node files exists. The functional change set is **1 file** (the wrapper line) plus new Python sources; the Node files are deleted last.

## 11. Scope

**In:** Python `acme_trivy_mcp` package (`mcp` SDK + `httpx`), `sf_client.py` parity port, all 7 tools at parity, `pyproject.toml` + `uv.lock`, wrapper final-line swap + venv bootstrap, parity + auth/error + infra tests, removal of Node files after green tests. Establishes the shared Python-MCP convention.

**Out:** any tool behavior change, new tools, "fixing" `probe_api` heuristics or the field-fallback chains, touching `trivy.env`/the cookie, registration edits (none needed), and subsystems #1/#3 (separate specs).

## 12. Open items for the plan

- `uv sync` vs `pip install -e .` for the wrapper bootstrap (leaning `uv`, consistent with #1) — and whether the `.venv` lives in the trivy dir or a shared MCP venv root.
- Exact `--selftest`/tool-count import check contract for the infra test.
- Whether to build a Node-oracle harness (run `index.js` tools against fixtures to auto-generate expected values) or capture expected JSON once and pin it — oracle harness is more robust against the field-fallback parity traps.
- Confirm `httpx` sync client proxy precedence matches Node's HTTPS→HTTP order before relying on `trust_env`.
- Pin exact `mcp` and `httpx` versions; run Rule 9 deprecation check at plan time.
- Confirm, post-swap, that `~/.claude.json` truly needs no edit (it shouldn't — wrapper path is stable).
