# Trivy MCP Python Port — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax.

**Goal:** Port `~/.claude/mcp/<mcp-client-3>/trivy/index.js` (Node MCP) to Python at behavioral parity, establishing the shared Python-MCP convention.

**Architecture:** `mcp` SDK (`FastMCP`, stdio) + `httpx` **sync** client. `sf_client.py` is the single mockable HTTP seam; `server.py` registers the 7 tools. The launch wrapper swaps only its final `exec` line. Node files stay as the parity oracle until tests are green, then are removed.

**Tech Stack:** Python 3.11+, `mcp`, `httpx`, `uv` (project-local `.venv`).

## Global Constraints

- Package name: `acme_trivy_mcp`; entry `python -m acme_trivy_mcp`. Server name `acme-trivy`, version `1.0.0` (carried from `index.js:73-74`).
- `BASE_URL = "https://internal-portal.cloud-acme.fr"` (verbatim, `index.js:21`).
- Auth env var `ACME_INTERNAL_PORTAL_COOKIE` — read from process env only; **never logged/printed/embedded**. `trivy.env` is never read by Claude.
- JSON output parity: `json.dumps(obj, indent=2, ensure_ascii=False)` (matches JS `JSON.stringify(obj, null, 2)`: same separators, unicode kept literal). Formatted dicts must **omit** keys whose value is `None` (JS omits `undefined` keys).
- **`??` parity (the #1 trap):** use `_coalesce()` (returns first non-`None`) — never Python `or` — so a real `0` count survives.
- Param pruning: `sf_fetch` sets a query param only when value is not `None` and not `""` (mirrors `index.js:41`).
- Tests mock `sf_fetch` — **no real ACME calls**, `ACME_INTERNAL_PORTAL_COOKIE` never needed in tests. Tests must be **executed**; paste runner output.
- Commits in `~/.claude` are classifier-blocked → stage + present commit for manual `!`. Wrapper edit preserves the existing contract (only final `exec` line changes).
- Registration: `~/.claude.json → acme-trivy-stdio.command` points at the unchanged wrapper path → **no `~/.claude.json` edit** needed.

---

### Task 1: Package scaffold + `sf_client.py` (the HTTP seam)

**Files:**
- Create: `~/.claude/mcp/<mcp-client-3>/trivy/pyproject.toml`
- Create: `~/.claude/mcp/<mcp-client-3>/trivy/src/acme_trivy_mcp/__init__.py` (empty)
- Create: `~/.claude/mcp/<mcp-client-3>/trivy/src/acme_trivy_mcp/sf_client.py`
- Test: `~/.claude/mcp/<mcp-client-3>/trivy/tests/test_sf_client.py`

**Interfaces:**
- Produces: `get_cookie() -> str`; `sf_fetch(path: str, params: dict | None = None) -> Any` (sync; raises `RuntimeError` with parity error text on missing cookie / 301-302 / non-2xx); module-level `BASE_URL`.

- [ ] **Step 1: `pyproject.toml`**

```toml
[project]
name = "acme-trivy-mcp"
version = "1.0.0"
description = "ACME Software Factory — Trivy MCP Server (Python)"
requires-python = ">=3.11"
dependencies = ["mcp>=1.2", "httpx>=0.27"]

[project.scripts]
acme-trivy-mcp = "acme_trivy_mcp.__main__:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/acme_trivy_mcp"]
```
(Run Rule 9 deprecation check on `mcp`/`httpx` pins at execution time; widen floors if a newer stable exists.)

- [ ] **Step 2: Write failing test `tests/test_sf_client.py`**

```python
import json, pytest
from acme_trivy_mcp import sf_client

class FakeResp:
    def __init__(self, status, payload=None, text=""):
        self.status_code = status; self._payload = payload; self.text = text
        self.reason_phrase = text
    def json(self): return self._payload

def test_get_cookie_missing(monkeypatch):
    monkeypatch.delenv("ACME_INTERNAL_PORTAL_COOKIE", raising=False)
    with pytest.raises(RuntimeError) as e:
        sf_client.get_cookie()
    assert "ACME_INTERNAL_PORTAL_COOKIE environment variable is not set" in str(e.value)
    assert "AWSELBAuthSessionCookie" in str(e.value)

def test_sf_fetch_prunes_empty_params(monkeypatch):
    monkeypatch.setenv("ACME_INTERNAL_PORTAL_COOKIE", "x")
    captured = {}
    def fake_get(url, headers, follow_redirects):
        captured["params"] = dict(url.params); return FakeResp(200, {"ok": True})
    monkeypatch.setattr(sf_client, "_client_get", fake_get)
    sf_client.sf_fetch("/p", {"a": 1, "b": None, "c": "", "d": "v"})
    assert captured["params"] == {"a": "1", "d": "v"}  # None + "" pruned

def test_sf_fetch_302_session_expired(monkeypatch):
    monkeypatch.setenv("ACME_INTERNAL_PORTAL_COOKIE", "x")
    monkeypatch.setattr(sf_client, "_client_get", lambda url, headers, follow_redirects: FakeResp(302))
    with pytest.raises(RuntimeError) as e: sf_client.sf_fetch("/p")
    assert "Session expired" in str(e.value)

def test_sf_fetch_non_ok(monkeypatch):
    monkeypatch.setenv("ACME_INTERNAL_PORTAL_COOKIE", "x")
    monkeypatch.setattr(sf_client, "_client_get", lambda url, headers, follow_redirects: FakeResp(500, text="Server Error"))
    with pytest.raises(RuntimeError) as e: sf_client.sf_fetch("/p")
    assert "API error 500" in str(e.value)
```

- [ ] **Step 3: Run → FAIL** — `cd ~/.claude/mcp/<mcp-client-3>/trivy && uv run pytest tests/test_sf_client.py -q` → ModuleNotFound / attribute errors.

- [ ] **Step 4: Implement `src/acme_trivy_mcp/sf_client.py`**

```python
"""Software Factory HTTP client — the single mockable seam (parity with index.js sfFetch)."""
import os
import httpx

BASE_URL = "https://internal-portal.cloud-acme.fr"

def _proxy() -> str | None:
    return (os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
            or os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy") or None)

def get_cookie() -> str:
    cookie = os.environ.get("ACME_INTERNAL_PORTAL_COOKIE")
    if not cookie:
        raise RuntimeError(
            "ACME_INTERNAL_PORTAL_COOKIE environment variable is not set.\n"
            "Extract it from your browser DevTools (Application → Cookies) after logging in to:\n"
            f"{BASE_URL}/dashboard/transverse/trivy-spaces\n"
            "Look for AWSELBAuthSessionCookie-0 (and -1 if present)."
        )
    return cookie

def _client_get(url: httpx.URL, headers: dict, follow_redirects: bool):
    # Isolated so tests can monkeypatch the network boundary.
    with httpx.Client(proxy=_proxy(), follow_redirects=follow_redirects, timeout=30.0) as c:
        return c.get(url, headers=headers)

def sf_fetch(path: str, params: dict | None = None):
    qp = {}
    for k, v in (params or {}).items():
        if v is not None and v != "":
            qp[k] = "true" if v is True else ("false" if v is False else str(v))
    url = httpx.URL(BASE_URL + path, params=qp)
    res = _client_get(url, {"Cookie": get_cookie(), "Accept": "application/json"}, False)
    if res.status_code in (301, 302):
        raise RuntimeError(
            "Session expired (redirected to SSO). Please renew your ACME_INTERNAL_PORTAL_COOKIE:\n"
            "1. Open https://internal-portal.cloud-acme.fr in your browser\n"
            "2. DevTools → Application → Cookies → copy AWSELBAuthSessionCookie-0\n"
            "3. Update ACME_INTERNAL_PORTAL_COOKIE in ~/.claude/mcp/acme-trivy.env and restart Claude Code"
        )
    if not (200 <= res.status_code < 300):
        raise RuntimeError(f"API error {res.status_code} {res.reason_phrase} for {url}")
    return res.json()
```
Note: `pagination: true` in JS becomes a real query param `pagination=true` — the bool→`"true"` mapping above preserves that (JS `String(true)` → `"true"`).

- [ ] **Step 5: Run → PASS**, then stage + present commit.
`cd ~/.claude/mcp/<mcp-client-3>/trivy && uv run pytest tests/test_sf_client.py -q` → all pass.
```bash
git -C ~ add .claude/mcp/<mcp-client-3>/trivy/pyproject.toml .claude/mcp/<mcp-client-3>/trivy/src .claude/mcp/<mcp-client-3>/trivy/tests/test_sf_client.py
# present: git -C ~ commit -m "feat(trivy-py): sf_client HTTP seam + package scaffold" -- <those paths>
```

---

### Task 2: `server.py` + helpers + the 4 raw-passthrough tools

**Files:**
- Create: `~/.claude/mcp/<mcp-client-3>/trivy/src/acme_trivy_mcp/server.py`
- Create: `~/.claude/mcp/<mcp-client-3>/trivy/src/acme_trivy_mcp/__main__.py`
- Test: `~/.claude/mcp/<mcp-client-3>/trivy/tests/test_parity.py`

**Interfaces:**
- Consumes: `sf_client.sf_fetch`.
- Produces: `mcp` (FastMCP instance); helpers `_coalesce(*vals)`, `_opt(obj, key)`, `_text(obj)`; tool fns `get_counters`, `get_departments`, `whoami`, `get_space_detail`. `main()` runs stdio.

- [ ] **Step 1: Failing test (raw-passthrough parity) in `tests/test_parity.py`**

```python
import json
from acme_trivy_mcp import server

def _patch(monkeypatch, payload):
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: payload)

def test_get_counters_raw(monkeypatch):
    _patch(monkeypatch, {"critical": 3, "high": 0})
    out = server.get_counters()
    assert json.loads(out) == {"critical": 3, "high": 0}

def test_whoami_raw(monkeypatch):
    _patch(monkeypatch, {"user": "dev"})
    assert json.loads(server.whoami()) == {"user": "dev"}

def test_get_space_detail_fallback_on_error(monkeypatch):
    calls = []
    def fake(path, params=None):
        calls.append(path)
        if path == "/api/v2/trivy/factory":
            raise RuntimeError("boom")
        return {"fallback": True}
    monkeypatch.setattr(server, "sf_fetch", fake)
    out = json.loads(server.get_space_detail(ida="pro"))
    assert out == {"fallback": True}
    assert calls == ["/api/v2/trivy/factory", "/api/v2/trivy/space"]  # factory then fallback
```

- [ ] **Step 2: Run → FAIL** (`server` not importable / fns missing).

- [ ] **Step 3: Implement `server.py` (helpers + 4 tools)**

```python
"""acme-trivy MCP server (Python port of index.js) — parity-first."""
import json
from mcp.server.fastmcp import FastMCP
from .sf_client import sf_fetch

mcp = FastMCP("acme-trivy")

def _coalesce(*vals):
    """JS `a ?? b ?? c` — first value that is not None (a real 0/"" is returned)."""
    for v in vals:
        if v is not None:
            return v
    return None

def _opt(obj, key):
    """JS optional chaining `obj?.key` — None unless obj is a dict."""
    return obj.get(key) if isinstance(obj, dict) else None

def _text(obj) -> str:
    return json.dumps(obj, indent=2, ensure_ascii=False)

@mcp.tool(description="Get global vulnerability counters across all ACME projects "
          "(total critical, high, medium, low counts visible at the top of the Console Trivy).")
def get_counters() -> str:
    return _text(sf_fetch("/api/v2/trivy/space/counters"))

@mcp.tool(description="List available departments/domains in the ACME Software Factory (useful for filtering).")
def get_departments() -> str:
    return _text(sf_fetch("/api/departments"))

@mcp.tool(description="Check the currently authenticated user on the ACME Software Factory. "
          "Useful to verify the cookie is still valid.")
def whoami() -> str:
    return _text(sf_fetch("/api/whoami"))

@mcp.tool(description="Get detailed vulnerability information for a specific Trivy space/project by its IDA code.")
def get_space_detail(ida: str) -> str:
    try:
        data = sf_fetch("/api/v2/trivy/factory", {"space.ids": ida})
    except Exception:  # bare catch — intentional fallback (index.js:159), NOT a bug
        data = sf_fetch("/api/v2/trivy/space", {"page": 1, "itemsPerPage": 1, "pagination": True, "search": ida})
    return _text(data)
```

`__main__.py`:
```python
from .server import mcp
def main() -> None:
    mcp.run()
if __name__ == "__main__":
    main()
```

- [ ] **Step 4: Run → PASS**. `cd ~/.claude/mcp/<mcp-client-3>/trivy && uv run pytest tests/test_parity.py -q`

- [ ] **Step 5: Stage + present commit** (paths: `src/acme_trivy_mcp/server.py __main__.py tests/test_parity.py`), message `feat(trivy-py): server scaffold + 4 raw-passthrough tools`.

---

### Task 3: `list_spaces` (field-fallback + the 0-trap)

**Files:**
- Modify: `~/.claude/mcp/<mcp-client-3>/trivy/src/acme_trivy_mcp/server.py`
- Test: `~/.claude/mcp/<mcp-client-3>/trivy/tests/test_parity.py`

**Interfaces:** Produces tool `list_spaces(page=1, items_per_page=20, search=None, domain=None, pole=None, criticality=None, deployment=None) -> str`.

- [ ] **Step 1: Failing tests — assert the 0-count survives + field fallbacks + None-omission**

```python
def test_list_spaces_zero_count_survives(monkeypatch):
    # error_critical present and == 0 → must stay 0 (the ?? vs or trap).
    payload = {"hydra:member": [{"id": 1, "title": "P", "ids": "pro", "error_critical": 0,
                                  "error_high": 5}], "hydra:totalItems": 1}
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: payload)
    out = json.loads(server.list_spaces())
    sp = out["spaces"][0]
    assert sp["critical"] == 0 and sp["high"] == 5 and out["total"] == 1

def test_list_spaces_field_fallbacks_and_omission(monkeypatch):
    # domain as nested dict; missing project/ida → omitted (JS undefined drops the key).
    payload = {"items": [{"id": 2, "domain": {"name": "SI RI"}}]}
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: payload)
    sp = json.loads(server.list_spaces())["spaces"][0]
    assert sp["domain"] == "SI RI"
    assert "project" not in sp and "ida" not in sp   # None-valued keys omitted
    assert sp["critical"] == 0                        # default 0 kept

def test_list_spaces_param_passthrough(monkeypatch):
    captured = {}
    def fake(path, params=None): captured.update(params or {}); return {"items": []}
    monkeypatch.setattr(server, "sf_fetch", fake)
    server.list_spaces(domain="SI RI", pole="GDI")
    assert captured["domain.name"] == "SI RI" and captured["pole.name"] == "GDI"
    assert captured["pagination"] is True
```

- [ ] **Step 2: Run → FAIL** (`list_spaces` missing).

- [ ] **Step 3: Implement `list_spaces` (append to `server.py`)**

```python
@mcp.tool(description="List Trivy spaces (projects) with their vulnerability counts. "
          "Filter by domain, pole, criticality or search by name/IDA.")
def list_spaces(page: int = 1, items_per_page: int = 20, search: str | None = None,
                domain: str | None = None, pole: str | None = None,
                criticality: str | None = None, deployment: str | None = None) -> str:
    params = {"page": page, "itemsPerPage": items_per_page, "pagination": True}
    if search:      params["search"] = search
    if domain:      params["domain.name"] = domain
    if pole:        params["pole.name"] = pole
    if criticality: params["criticality"] = criticality
    if deployment:  params["deployment.type"] = deployment
    data = sf_fetch("/api/v2/trivy/space", params)

    if isinstance(data, dict):
        items = _coalesce(data.get("hydra:member"), data.get("items"), data)
        total = _coalesce(data.get("hydra:totalItems"), data.get("total"), "?")
    else:
        items, total = data, "?"

    formatted = []
    for s in items:
        row = {
            "id":         _coalesce(s.get("id"), s.get("@id")),
            "project":    _coalesce(s.get("title"), s.get("name"), s.get("projectName")),
            "ida":        _coalesce(s.get("ids"), s.get("ida"), s.get("code")),
            "domain":     _coalesce(_opt(s.get("domain"), "name"), s.get("domainName"), s.get("domain")),
            "pole":       _coalesce(_opt(s.get("pole"), "name"), s.get("poleName"), s.get("pole")),
            "deployment": _coalesce(_opt(s.get("deployment"), "type"), s.get("deploymentType"), s.get("deployment")),
            "critical":   _coalesce(s.get("error_critical"), s.get("criticalCount"), s.get("critical"), 0),
            "high":       _coalesce(s.get("error_high"), s.get("highCount"), s.get("high"), 0),
            "medium":     _coalesce(s.get("error_medium"), s.get("mediumCount"), s.get("medium"), 0),
            "low":        _coalesce(s.get("error_low"), s.get("lowCount"), s.get("low"), 0),
            "lastScan":   _coalesce(s.get("scanned_at"), s.get("lastScanDate"), s.get("scanDate")),
        }
        formatted.append({k: v for k, v in row.items() if v is not None})  # JS omits undefined keys

    return _text({"total": total, "page": page, "itemsPerPage": items_per_page, "spaces": formatted})
```

- [ ] **Step 4: Run → PASS** (`uv run pytest tests/test_parity.py -q`).
- [ ] **Step 5: Stage + present commit** — `feat(trivy-py): list_spaces with parity field-fallbacks`.

---

### Task 4: `get_vulnerabilities` + `probe_api`

**Files:** Modify `server.py`; Test `tests/test_parity.py`.

**Interfaces:** Produces `get_vulnerabilities(factory_id, severity=None, page=1, items_per_page=50) -> str`; `probe_api(factory_id, ida=None) -> str`.

- [ ] **Step 1: Failing tests**

```python
def test_get_vulnerabilities_shape(monkeypatch):
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: {"hydra:member": [{"cve": "X"}], "hydra:totalItems": 1})
    out = json.loads(server.get_vulnerabilities(factory_id=41472))
    assert out == {"total": 1, "page": 1, "itemsPerPage": 50, "vulnerabilities": [{"cve": "X"}]}

def test_get_vulnerabilities_total_fallback_len(monkeypatch):
    # no hydra:totalItems / total → total == len(items)
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: {"items": [{"a": 1}, {"a": 2}]})
    assert json.loads(server.get_vulnerabilities(factory_id=1))["total"] == 2

def test_probe_api_candidate_count(monkeypatch):
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: {"hydra:member": [{"x": 1}]})
    res = json.loads(server.probe_api(factory_id=99))
    assert len(res) == 2                      # 2 candidates without ida
    assert res[0]["ok"] is True and res[0]["count"] == 1
    res2 = json.loads(server.probe_api(factory_id=99, ida="cdm"))
    assert len(res2) == 4                      # +2 candidates with ida
```

- [ ] **Step 2: Run → FAIL.**

- [ ] **Step 3: Implement (append to `server.py`)**

```python
@mcp.tool(description="List individual vulnerabilities for a specific Trivy factory scan, grouped by severity.")
def get_vulnerabilities(factory_id: int, severity: str | None = None,
                        page: int = 1, items_per_page: int = 50) -> str:
    params = {"page": page, "itemsPerPage": items_per_page, "pagination": True}
    if severity: params["severity"] = severity
    data = sf_fetch(f"/api/v2/trivy/{factory_id}/vulnerabilities", params)
    if isinstance(data, dict):
        items = _coalesce(data.get("hydra:member"), data.get("items"), [])
    else:
        items = data if isinstance(data, list) else []
    if isinstance(data, dict):
        total = _coalesce(data.get("hydra:totalItems"), data.get("total"), len(items))
    else:
        total = len(items)
    return _text({"total": total, "page": page, "itemsPerPage": items_per_page, "vulnerabilities": items})

@mcp.tool(description="Probe candidate API endpoints to discover which ones exist and return vulnerability data.")
def probe_api(factory_id: int, ida: str | None = None) -> str:
    candidates = [
        (f"/api/v2/trivy/{factory_id}/vulnerabilities", {"page": 1, "itemsPerPage": 5, "pagination": True}),
        (f"/api/v2/trivy/{factory_id}/vulnerabilities", {"severity": "CRITICAL"}),
    ]
    if ida:
        candidates += [
            ("/api/v2/trivy/vulnerability", {"space.ids": ida}),
            ("/api/v2/trivy/vulnerability", {"space": ida}),
        ]
    results = []
    for path, params in candidates:
        try:
            data = sf_fetch(path, params)
            if isinstance(data, dict):
                member = _coalesce(data.get("hydra:member"), data.get("items"), None)
                keys = list(data.keys())
            elif isinstance(data, list):
                member, keys = data, []
            else:
                member, keys = None, []
            results.append({
                "path": path, "params": params, "ok": True,
                "count": len(member) if member is not None else None,
                "keys": keys,
                "sample": (member[0] if member else None) if member is not None else data,
            })
        except Exception as e:
            results.append({"path": path, "params": params, "ok": False, "error": str(e)})
    return _text(results)
```

- [ ] **Step 4: Run full parity suite → PASS** (`uv run pytest tests/ -q`).
- [ ] **Step 5: Stage + present commit** — `feat(trivy-py): get_vulnerabilities + probe_api`.

---

### Task 5: Wrapper swap, selftest, remove Node files

**Files:** Modify `~/.claude/mcp/<mcp-client-3>/trivy-mcp-wrapper.sh`; Modify `__main__.py` (add `--selftest`); `git rm` `index.js`, `package.json`, `package-lock.json`, `node_modules/`.

- [ ] **Step 1: Add a `--selftest` that asserts the 7 tools register (failing test = wrong count)**

In `__main__.py`:
```python
import sys
from .server import mcp
EXPECTED_TOOLS = {"list_spaces","get_counters","get_space_detail","get_departments",
                  "whoami","probe_api","get_vulnerabilities"}
def main() -> None:
    if "--selftest" in sys.argv:
        import asyncio
        names = {t.name for t in asyncio.run(mcp.list_tools())}
        missing, extra = EXPECTED_TOOLS - names, names - EXPECTED_TOOLS
        if missing or extra:
            print(f"SELFTEST FAIL missing={missing} extra={extra}", file=sys.stderr); sys.exit(1)
        print(f"SELFTEST OK: {len(names)} tools"); sys.exit(0)
    mcp.run()
```
(Confirm the FastMCP introspection API at execution — `mcp.list_tools()` is the documented accessor; adjust to the installed SDK's method if the name differs. This is the one API to verify live.)

- [ ] **Step 2: Run → `uv run python -m acme_trivy_mcp --selftest`** → `SELFTEST OK: 7 tools`.

- [ ] **Step 3: Swap the wrapper's final line + add venv bootstrap**

In `trivy-mcp-wrapper.sh`, replace:
```bash
exec node "${HOME}/.claude/mcp/<mcp-client-3>/trivy/index.js"
```
with:
```bash
cd "${HOME}/.claude/mcp/<mcp-client-3>/trivy" || exit 1
[[ -x .venv/bin/python ]] || uv sync --frozen 2>/dev/null || uv sync
exec .venv/bin/python -m acme_trivy_mcp
```
Replace the commented `# … npm … ci` line with `# uv sync` note. Everything above (env-loading, `trivy.env` requirement, cookie export, `log_obs`) is untouched.

- [ ] **Step 4: Verify wrapper + parity before deleting Node**

```bash
bash -n ~/.claude/mcp/<mcp-client-3>/trivy-mcp-wrapper.sh && shellcheck ~/.claude/mcp/<mcp-client-3>/trivy-mcp-wrapper.sh
cd ~/.claude/mcp/<mcp-client-3>/trivy && uv run pytest tests/ -q   # all parity + sf_client tests green
```
Expected: shellcheck clean; all tests pass.

- [ ] **Step 5: Remove Node oracle + commit**

```bash
git -C ~ rm -r .claude/mcp/<mcp-client-3>/trivy/index.js .claude/mcp/<mcp-client-3>/trivy/package.json .claude/mcp/<mcp-client-3>/trivy/package-lock.json
rm -rf ~/.claude/mcp/<mcp-client-3>/trivy/node_modules
git -C ~ add .claude/mcp/<mcp-client-3>/trivy/trivy-mcp-wrapper.sh .claude/mcp/<mcp-client-3>/trivy/src .claude/mcp/<mcp-client-3>/trivy/tests
# present: git -C ~ commit -m "feat(trivy-py): swap wrapper to python, selftest, remove Node impl" -- <paths>
```

- [ ] **Step 6: Manual verification (real cookie)** — out of automated scope: with a live `ACME_INTERNAL_PORTAL_COOKIE`, restart Claude Code and call `whoami` via the MCP to confirm the live path works end-to-end. Note in the report that this requires the user (cookie is C2/sensitive, never handled by Claude).

---

## Self-Review

- **Spec coverage:** §3 convention → Tasks 1/2 + Task 5 (uv/wrapper); §6 wrapper → Task 5; §7 all 7 tools → Tasks 2-4; §8 parity-first tests → every task; §9 registration no-edit → Global Constraints + Task 5; §10 blast radius (remove Node last) → Task 5.
- **Placeholder scan:** none — every step has runnable code + exact commands + expected output. The two live-verify points (FastMCP `list_tools` API name; real-cookie end-to-end) are explicitly flagged, not hidden.
- **Type/name consistency:** `sf_fetch`, `_coalesce`, `_opt`, `_text`, the 7 tool fn names, and `EXPECTED_TOOLS` are identical across tasks and match `index.js`. `items_per_page` (snake) maps to `itemsPerPage` query param consistently.
- **Parity traps covered:** 0-count (`_coalesce` not `or`) — Task 3 test; `undefined`-key omission — Task 3 test; param pruning — Task 1 test; bare-catch fallback — Task 2 test; per-tool `itemsPerPage` defaults (20 vs 50) — Tasks 3/4.
