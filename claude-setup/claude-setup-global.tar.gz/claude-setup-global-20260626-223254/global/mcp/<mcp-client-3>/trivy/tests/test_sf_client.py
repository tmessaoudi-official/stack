import pytest
from acme_trivy_mcp import sf_client


class FakeResp:
    def __init__(self, status, payload=None, text=""):
        self.status_code = status
        self._payload = payload
        self.text = text
        self.reason_phrase = text

    def json(self):
        return self._payload


def test_get_cookie_missing(monkeypatch):
    monkeypatch.delenv("ACME_INTERNAL_PORTAL_COOKIE", raising=False)
    with pytest.raises(RuntimeError) as e:
        sf_client.get_cookie()
    assert "ACME_INTERNAL_PORTAL_COOKIE environment variable is not set" in str(e.value)
    assert "AWSELBAuthSessionCookie" in str(e.value)


def test_sf_fetch_prunes_empty_params(monkeypatch):
    monkeypatch.setenv("ACME_INTERNAL_PORTAL_COOKIE", "x")
    captured = {}

    def fake_get(url, headers, follow_redirects):
        captured["params"] = dict(url.params)
        return FakeResp(200, {"ok": True})

    monkeypatch.setattr(sf_client, "_client_get", fake_get)
    sf_client.sf_fetch("/p", {"a": 1, "b": None, "c": "", "d": "v"})
    assert captured["params"] == {"a": "1", "d": "v"}  # None + "" pruned


def test_sf_fetch_302_session_expired(monkeypatch):
    monkeypatch.setenv("ACME_INTERNAL_PORTAL_COOKIE", "x")
    monkeypatch.setattr(sf_client, "_client_get", lambda url, headers, follow_redirects: FakeResp(302))
    with pytest.raises(RuntimeError) as e:
        sf_client.sf_fetch("/p")
    assert "Session expired" in str(e.value)


def test_sf_fetch_non_ok(monkeypatch):
    monkeypatch.setenv("ACME_INTERNAL_PORTAL_COOKIE", "x")
    monkeypatch.setattr(sf_client, "_client_get", lambda url, headers, follow_redirects: FakeResp(500, text="Server Error"))
    with pytest.raises(RuntimeError) as e:
        sf_client.sf_fetch("/p")
    assert "API error 500" in str(e.value)
