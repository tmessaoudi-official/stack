import json

from acme_trivy_mcp import server


def _patch(monkeypatch, payload):
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: payload)


def test_get_counters_raw(monkeypatch):
    _patch(monkeypatch, {"critical": 3, "high": 0})
    assert json.loads(server.get_counters()) == {"critical": 3, "high": 0}


def test_whoami_raw(monkeypatch):
    _patch(monkeypatch, {"user": "dev"})
    assert json.loads(server.whoami()) == {"user": "dev"}


def test_get_departments_raw(monkeypatch):
    _patch(monkeypatch, [{"name": "SI RI"}])
    assert json.loads(server.get_departments()) == [{"name": "SI RI"}]


def test_get_space_detail_fallback_on_error(monkeypatch):
    calls = []

    def fake(path, params=None):
        calls.append(path)
        if path == "/api/v2/trivy/factory":
            raise RuntimeError("boom")
        return {"fallback": True}

    monkeypatch.setattr(server, "sf_fetch", fake)
    out = json.loads(server.get_space_detail(ida="pro"))
    assert out == {"fallback": True}
    assert calls == ["/api/v2/trivy/factory", "/api/v2/trivy/space"]


def test_list_spaces_zero_count_survives(monkeypatch):
    payload = {
        "hydra:member": [{"id": 1, "title": "P", "ids": "pro", "error_critical": 0, "error_high": 5}],
        "hydra:totalItems": 1,
    }
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: payload)
    out = json.loads(server.list_spaces())
    sp = out["spaces"][0]
    assert sp["critical"] == 0 and sp["high"] == 5 and out["total"] == 1


def test_list_spaces_field_fallbacks_and_omission(monkeypatch):
    payload = {"items": [{"id": 2, "domain": {"name": "SI RI"}}]}
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: payload)
    sp = json.loads(server.list_spaces())["spaces"][0]
    assert sp["domain"] == "SI RI"
    assert "project" not in sp and "ida" not in sp  # None-valued keys omitted
    assert sp["critical"] == 0  # default 0 kept


def test_list_spaces_param_passthrough(monkeypatch):
    captured = {}

    def fake(path, params=None):
        captured.update(params or {})
        return {"items": []}

    monkeypatch.setattr(server, "sf_fetch", fake)
    server.list_spaces(domain="SI RI", pole="GDI")
    assert captured["domain.name"] == "SI RI" and captured["pole.name"] == "GDI"
    assert captured["pagination"] is True


def test_get_vulnerabilities_shape(monkeypatch):
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: {"hydra:member": [{"cve": "X"}], "hydra:totalItems": 1})
    out = json.loads(server.get_vulnerabilities(factory_id=41472))
    assert out == {"total": 1, "page": 1, "itemsPerPage": 50, "vulnerabilities": [{"cve": "X"}]}


def test_get_vulnerabilities_total_fallback_len(monkeypatch):
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: {"items": [{"a": 1}, {"a": 2}]})
    assert json.loads(server.get_vulnerabilities(factory_id=1))["total"] == 2


def test_probe_api_candidate_count(monkeypatch):
    monkeypatch.setattr(server, "sf_fetch", lambda path, params=None: {"hydra:member": [{"x": 1}]})
    res = json.loads(server.probe_api(factory_id=99))
    assert len(res) == 2  # 2 candidates without ida
    assert res[0]["ok"] is True and res[0]["count"] == 1
    res2 = json.loads(server.probe_api(factory_id=99, ida="cdm"))
    assert len(res2) == 4  # +2 candidates with ida
