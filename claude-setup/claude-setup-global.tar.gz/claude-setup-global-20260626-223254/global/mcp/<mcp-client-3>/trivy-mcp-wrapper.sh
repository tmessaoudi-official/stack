#!/usr/bin/env bash
# ACME Trivy MCP wrapper — loads cookie from trivy.env then runs the server.
set -euo pipefail
source "${HOME}/.claude/hooks/log-helpers.sh" 2>/dev/null || log_obs() { :; }
ENV_FILE="${HOME}/.claude/mcp/<mcp-client-3>/trivy.env"
if [[ ! -f "$ENV_FILE" ]]; then
  log_obs ERROR trivy-mcp-wrapper.sh "ENV_FILE not found: $ENV_FILE" 2>/dev/null || true
  echo "[mcp-acme-trivy] ${ENV_FILE} not found." >&2
  echo "[mcp-acme-trivy] Create it with: ACME_INTERNAL_PORTAL_COOKIE=<AWSELBAuthSessionCookie value>" >&2
  echo "[mcp-acme-trivy] Get it from: DevTools → Application → Cookies after logging in to internal-portal.cloud-acme.fr" >&2
  exit 1
fi
while IFS= read -r line || [[ -n "${line:-}" ]]; do
  [[ -z "$line" || "$line" =~ ^# || ! "$line" =~ = ]] && continue
  key="${line%%=*}"; value="${line#*=}"
  export "${key}=${value}"
done < "$ENV_FILE"

# First-run bootstrap of the project venv (mirrors the old `npm ci` line):
# cd ${HOME}/.claude/mcp/<mcp-client-3>/trivy && uv sync

cd "${HOME}/.claude/mcp/<mcp-client-3>/trivy" || exit 1
[[ -x .venv/bin/python ]] || uv sync --frozen 2>/dev/null || uv sync
exec .venv/bin/python -m acme_trivy_mcp
