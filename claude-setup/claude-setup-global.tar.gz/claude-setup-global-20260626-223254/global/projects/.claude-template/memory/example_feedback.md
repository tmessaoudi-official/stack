---
name: Example feedback memory
description: How Claude should behave when collaborating with you
type: feedback
---
[Write preferences Claude should remember. Example:]
Prefer concise responses — skip summaries of what you just did.
**Why:** My workflow is fast-paced; re-reading what just happened slows me down.
**How to apply:** End responses with next steps, not summaries.
