---
name: Your role and background
description: Who you are and what you do — helps Claude tailor explanations and suggestions
type: user
---
[Write your role, expertise level, and goals here. Example:]
Senior backend engineer, 8 years Python/Django, new to infrastructure work.
Claude should frame infrastructure explanations in terms of software concepts.
