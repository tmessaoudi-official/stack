---
name: aggregate-findings
spotlight: true
description: Cross-stage synthesis of mega-analysis reports — deduplicates findings that appear across audit, skill-audit, inspect, sleuth, gaps, and vision stages. Produces a prioritized master list with cross-references and removes redundant noise. Use after a mega-analysis run to get one actionable summary instead of 10 separate reports.
user-invocable: true
args: "[--run=N] [--project=slug] [--top=N]"
side-effects: Writes consolidated report to ~/.claude/projects/<slug>/meta-reports/aggregate-<date>.md
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /aggregate-findings — Cross-stage synthesis of mega-analysis reports — deduplicates findings across audit, skill-audit, inspect, sleuth, gaps, and vision stages into one prioritized master list.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /aggregate-findings

## When to use
Run immediately after a `/mega-analysis` run to synthesize its 10 stage outputs into one deduplicated, prioritized master list. Also useful when manually reviewing reports across multiple runs.

## Flags
- `--run=N` — target run number (default: latest run in the most recent meta-reports date dir)
- `--project=slug` — project slug (default: derived from CLAUDE_PROJECT_DIR)
- `--top=N` — show only the top N unique findings (default: all)

## Step 0 — Locate reports

```bash
TODAY=$(date +%Y-%m-%d)
REPORT_DIR="$HOME/.claude/projects/meta-reports/$TODAY"
# If today has no run, find the most recent date dir
[[ -d "$REPORT_DIR" ]] || REPORT_DIR=$(ls -d "$HOME/.claude/projects/meta-reports"/*/  2>/dev/null | sort | tail -1)
# Derive project slug from CLAUDE_PROJECT_DIR
SLUG=$(echo "${CLAUDE_PROJECT_DIR:-/path/to/your/project}" | sed 's|/|-|g; s|^-||')
```

Load the full-analysis run report to identify which stage reports exist.

## Step 1 — Read all stage reports (parallel, max 5 at a time)

Identify the stage report paths from the run status table. For each stage with a ✅, read the full report. Batch into two groups of ≤5 files:

**Batch A** (analysis stages):
- audit report
- skill-audit report
- inspect (project)
- inspect (global)
- sleuth (project)

**Batch B** (gap + vision stages):
- sleuth (global)
- gaps (project)
- gaps (global)
- inspect --vision (project)
- inspect --vision (global)

Read each file and pass to Step 2.

## Step 2 — Spawn 3 synthesis agents (parallel)

Spawn exactly 3 agents with the full report content:

### Agent 1: Deduplication detector
Prompt: "You are given 10 stage reports from a mega-analysis pipeline. Your job is to identify findings that appear in 2 or more stage reports — these are the highest-confidence issues. For each cross-stage finding, list: the finding name/ID, which stages mention it, what each stage says (noting any contradictions), and a deduplicated one-sentence summary. Output as a markdown table. Only report findings that appear in ≥2 stages."

### Agent 2: Priority ranker
Prompt: "You are given 10 stage reports from a mega-analysis pipeline. Your job is to produce a single master priority list of ALL unique findings (not cross-stage-only), ranked by: (1) severity (P0/High before P1/Med), (2) fix cost (Quick before Long), (3) breadth of impact. Remove exact duplicates. Format: numbered list with severity badge, one-line description, estimated fix time, and which stage it came from. Cap at 50 entries."

### Agent 3: Quick wins extractor
Prompt: "You are given 10 stage reports from a mega-analysis pipeline. Your job is to extract all 'quick win' findings: severity P1 or higher AND fix cost ≤30 min. These are the highest-value, lowest-effort items. Output as a table: finding, stage, exact file/line, exact fix, minutes. Include at most 20 rows; rank by impact."

## Step 3 — Synthesize into consolidated report

Combine all 3 agent outputs into:

```markdown
# Aggregate Findings — <date> (run N)
Generated: <timestamp> | Stages: 10 | Raw findings: ~<N> | Unique after dedup: ~<N>

## Top 10 Cross-Stage Findings (appear in ≥2 stages — highest confidence)
[Agent 1 table]

## Quick Wins (P1+ / ≤30 min fix)
[Agent 3 table]

## Master Priority List (all unique findings, ranked)
[Agent 2 list]
```

## Step 4 — Save and report

Save to `~/.claude/projects/meta-reports/<date>/aggregate-<date>.md`.

Report to user:
- Total unique findings
- Cross-stage duplicates found and collapsed
- Top 5 quick wins
- Suggest: "Run `/aggregate-findings --top=10` to see just the highest priority items"

## Self-reflection
After saving, note any findings where the stages disagreed (e.g., one stage calls it P0, another calls it P2). Flag these as "conflicting severity" in the report.
