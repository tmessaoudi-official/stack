---
name: lean-block
description: Use when protecting a specific project from /lean on activations by adding it to the lean-blocklist.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /lean-block — Protect a specific project from /lean on activations by adding it to the lean-blocklist.
> ```
>
> Then output the complete flag table from the **"Parse flags"** section below. Then STOP.

| Flag | Value | Default | Description |
|------|-------|---------|-------------|
| `--list` | — | off | Show all currently blocked projects and exit |
| `[path]` | directory | auto-discovered via git / CLAUDE.md walk | Project path to block; defaults to current project if omitted |

---

# /lean-block [path]

Protect a project from `/lean on` activations. Adds the project slug to
`~/.claude/lean-blocklist`. When blocked, `/lean on` aborts before touching any files.

If no path is given, discovers the project via `git rev-parse --show-toplevel` then walks parents looking for `CLAUDE.md`.

Use `/lean-unblock` to remove. Use `/lean-block --list` to show all blocked projects.

---

## Routing

- Args contain `--list` → show all blocked projects and exit
- Otherwise → block the given/discovered project

## Parse flags

Set `LIST_MODE=true` if args contain `--list`.
Set `PATH_ARG` to the first non-flag argument if present, else empty.

## Run

```bash
LEAN_BLOCKLIST="$HOME/.claude/lean-blocklist"

# --list: show current blocklist
if [[ "${LIST_MODE:-false}" == "true" ]]; then
  if [[ ! -f "$LEAN_BLOCKLIST" ]]; then
    echo "Lean blocklist: empty (no projects blocked)"
  else
    COUNT=$(grep -c '^[^#[:space:]]' "$LEAN_BLOCKLIST" 2>/dev/null || echo 0)
    echo "Lean blocklist ($COUNT entries):"
    grep '^[^#[:space:]]' "$LEAN_BLOCKLIST" 2>/dev/null | while IFS= read -r slug; do
      echo "  $slug"
    done
  fi
  exit 0
fi

_discover_path() {
  local arg="$1"
  if [[ -n "$arg" ]]; then
    [[ -d "$arg" ]] || { echo "⛔ Path not found: $arg" >&2; return 1; }
    realpath "$arg"; return 0
  fi
  local g
  g=$(git rev-parse --show-toplevel 2>/dev/null) && { echo "$g"; return 0; }
  local d="$PWD"
  while [[ "$d" != "/" ]]; do
    [[ -f "$d/CLAUDE.md" ]] && { echo "$d"; return 0; }
    d=$(dirname "$d")
  done
  echo "⛔ Cannot determine project path. Provide path as argument." >&2
  return 1
}

PROJECT_PATH=$(_discover_path "${PATH_ARG:-}") || exit 1
PROJECT_SLUG=$(echo "$PROJECT_PATH" | sed 's|/|-|g')

if [[ -f "$LEAN_BLOCKLIST" ]] && grep -qxF "$PROJECT_SLUG" "$LEAN_BLOCKLIST" 2>/dev/null; then
  echo "Project $PROJECT_PATH is already lean-blocked."
  echo "  Slug: $PROJECT_SLUG"
  exit 0
fi

mkdir -p "$(dirname "$LEAN_BLOCKLIST")"
printf '%s\n' "$PROJECT_SLUG" >> "$LEAN_BLOCKLIST"

echo "✓ $PROJECT_PATH lean-blocked"
echo "  Slug: $PROJECT_SLUG"
echo "  /lean on will now abort for this project."
echo "  Remove with: /lean-unblock"
```
