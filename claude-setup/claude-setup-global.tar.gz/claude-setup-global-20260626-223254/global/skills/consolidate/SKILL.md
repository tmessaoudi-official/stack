---
name: consolidate
spotlight: true
description: Use when merging multiple .claude/ configuration directories from different projects or machines into a single canonical destination. Use after running on multiple machines or to unify diverged configs.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /consolidate — Use when merging multiple .claude/ configuration directories from different projects or machines into a single canonical destination. Use after running on multiple machines or to unify diverged configs.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /consolidate — Merge Multiple `.claude/` Configs Into One

Merge any number of `.claude/` configuration directories into a single canonical destination.
Deduplicates files and permission entries. Shows a plan before writing anything.
Safe to run anytime — source directories are never modified.

**Usage:**
```
# Scan one or more directory trees for .claude/ dirs, then merge
/consolidate --dir ~/projects --dir /work --into ~/.claude-merged

# Explicit sources
/consolidate --from /pathA/.claude --from /pathB/.claude --from /pathC/.claude --into /dest/.claude

# Mix --dir (auto-discover) and --from (explicit) freely
/consolidate --dir ~/projects --from /extra/.claude --into /final/.claude

# Merge into one of the sources (requires --in-place as confirmation)
/consolidate --dir ~/projects --into ~/projects/main/.claude --in-place
```

## Flags

| Flag | Behavior |
|------|----------|
| `--dir <path>` | Recursively find all `.claude/` dirs under `<path>`; repeatable |
| `--from <path>` | Add an explicit `.claude/` dir to the source pool; repeatable |
| `--into <path>` | Merge destination (created if absent) |
| `--in-place` | Required confirmation when `--into` equals any source path |

---

## Phase 0: Parse and Validate

Extract all arguments, discover sources from `--dir` entries, add explicit `--from` paths, validate pool size, check in-place safety gate.

Present discovered sources and destination. If entirely auto-discovered, invoke the `ask-human` skill: question 'Proceed with merge of these auto-discovered sources into `<dest>`?', options: 'Yes, proceed (Recommended)' / 'No, abort — I'll specify sources explicitly'.

---

## Phase 1: Inventory All Files

For every directory in the source pool AND the destination, list all files recursively using relative paths.

**Exclude these paths from the inventory** (runtime/state/machine-specific):
```
hooks/session-remember/.state/
hooks/session-remember/logs/
hooks/session-remember/buffer.md
hooks/session-remember/today.md
hooks/session-remember/history.md
hooks/session-remember/archive/
hooks/session-remember/DISABLED
hooks/session-remember/READONLY
hooks/session-remember/blacklist
settings.local.json
*.lock
*.bak.*
backups/
tasks/
plans/
agent-memory/
```

For each non-excluded file, compute its content fingerprint with `md5sum`.

Build a registry: `relative_path → { source_path: fingerprint, ... }`.

---

## Phase 2: Classify Every File

| Class | Condition | Default Action |
|-------|-----------|----------------|
| **MERGE** | `settings.json` at directory root | Deep-merge (Phase 4) |
| **IDENTICAL** | Same fingerprint in every source that has it | Deduplicate — keep one copy |
| **UNIQUE** | Present in exactly one source, absent from destination | Copy to destination |
| **PRESENT** | Absent from all sources, exists in destination only | Keep as-is |
| **CONFLICT** | Same relative path, different fingerprints across two or more sources | User resolves |

**Special case — `hooks/session-remember/` scripts:** Treat as a unit; pick winner by most recently modified `save.sh`.

---

## Phase 3: Present the Merge Plan

Print the full plan before touching anything:

```
CONSOLIDATE PLAN — <dest> (<date>)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Sources  : N directories
Dest     : <absolute path> [exists / new]

UNIQUE — add to destination (N files)
IDENTICAL — deduplicate (N files, keep 1 copy each)
CONFLICT — requires your decision (N items)
SETTINGS — deep merge (union + dedup)
SKIPPED — runtime/state (not listed, excluded by design)

Fixable automatically : UNIQUE, IDENTICAL, SETTINGS
Requires your input   : CONFLICT (N items)

```

Invoke the `ask-human` skill: question 'Proceed with the merge plan above?', options: 'Yes, apply all automatic fixes (Recommended)' / 'Resolve a conflict first — specify which in notes' / 'No, abort'.

---

## Phase 4: Resolve Conflicts

For each CONFLICT item: show which sources have it, show unified diff(s). Invoke the `ask-human` skill: question 'Which version of `<relative_path>` should be kept?', options: 'Source A — `<path>` (Recommended if most recent)' / 'Source B — `<path>`' / 'Skip — keep neither'. Record decisions without writing yet.

For `hooks/session-remember/` unit: show candidate. Invoke the `ask-human` skill: question 'Use this version of `hooks/session-remember/`?', options: 'Yes, use this candidate (Recommended)' / 'No, skip — keep existing'.
For `CLAUDE.md` specifically: show section headings from each version. Invoke the `ask-human` skill: question 'Which `CLAUDE.md` version should be kept?', options: 'Source A — `<path>`' / 'Source B — `<path>`' / 'Keep destination as-is'. Never attempt automated content merge.

---

## Phase 5: Merge `settings.json`

**Arrays** (`allow`, `deny`, `ask`, `enabledPlugins`): concatenate all entries, deduplicate by exact string match, preserve order.

**Scalars**: three-way merge — if all sources agree, use it; if all sources agree but differ from destination, prompt upgrade; if sources disagree, prompt choice.

---

## Phase 6: Apply

After all conflicts are resolved and user confirmed:

1. Backup destination if it exists
2. Create destination dirs if needed
3. Write UNIQUE, IDENTICAL, resolved CONFLICT files, merged `settings.json`, chosen `session-remember/` scripts
4. Never copy state files (buffer.md, today.md, .state/, logs/)

---

## Phase 7: Summary

```
CONSOLIDATE COMPLETE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Destination  : <dest>
Backup       : <dest>.bak.<ts>  (or "none — destination was empty")
Files added  : N  (UNIQUE + resolved CONFLICTs)
Deduplicated : N  (IDENTICAL files collapsed to 1 copy each)
Conflicts    : N resolved, K skipped
settings.json: merged N allow + N deny + N ask rules; N duplicates removed

Sources NOT modified or deleted.
Run /repair --check <dest> to verify the merged config is consistent.
```

---

## What is NEVER auto-merged

- `CLAUDE.md` — structural content requires human judgment; always a CONFLICT
- `settings.json` scalar conflicts — always prompted, never silently picked
- Runtime state files — excluded from inventory entirely
- `DISABLED` / `READONLY` / `blacklist` sentinels — never propagated
- `settings.local.json` — machine-specific, excluded
- Files matching `*.secret`, `*.key`, `*.pem`, `*.credentials*` — excluded with a warning
