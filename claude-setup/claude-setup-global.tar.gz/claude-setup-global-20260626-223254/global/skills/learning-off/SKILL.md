---
name: learning-off
description: Use when disabling the learning-output-style plugin to switch from explanatory mode to direct execution mode.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then STOP — do not execute any other steps.
>
> ```
> /learning-off — Disable the learning-output-style plugin to switch from explanatory mode to direct execution mode.
>
> No flags — invoked without arguments.
> ```

---

# /learning-off — Disable Learning + Explanatory Output Style

Disables the `learning-output-style` plugin for this machine's Claude Code sessions.

## Steps

1. Read `~/.claude/settings.json`.
2. Set `"learning-output-style@claude-plugins-official": false` in the `enabledPlugins` section.
3. Write the updated file.
4. Confirm: "Learning mode disabled. Restart Claude Code for the change to take effect."

## What this disables

- `★ Insight` blocks after code
- "Request contribution" prompts
- Explanatory commentary on trade-offs

## When to use

- Execution sessions: bug fixes, infra work, scripting, late-night sprints
- Any time you want fast, direct responses without educational overhead

Re-enable with `/learning-on` when you want explanatory mode back.
