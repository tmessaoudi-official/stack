---
name: skill-audit
spotlight: true
description: Use when performing an exhaustive 15-dimension quality audit of every skill file across global and project scopes. Use when skill quality, coverage, trigger design, or convergence-gate compliance needs a deep systematic review.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /skill-audit — Exhaustive 15-dimension quality audit of every skill file across global and project scopes.
>
> Flags:
>   --quick                   Run global batch A+B only (skip deep-dives)
>   --scope=global|project    Run one scope only (default: both)
>   --skill=<name>            Run audit for a single named skill
> ```

---

# /skill-audit — Per-Skill 15-Dimension Deep Report

Exhaustive quality audit of every skill file — global (`~/.claude/skills/`) AND project scope (`.claude/skills/`). Each skill gets a structured report across 15 dimensions. **Read-only — never auto-applies anything.**

Use `$ARGUMENTS` for flags: `--quick` (global batch A+B only, skip deep-dives), `--scope=global|project` (one scope only), `--skill=<name>` (single skill).

---

## Step 0: Setup

```bash
PROJECT_SLUG=$(echo "${CLAUDE_PROJECT_DIR:-$PWD}" | sed 's|^/|-|; s|/|-|g')
REPORT_DIR="$HOME/.claude/projects/$PROJECT_SLUG/audits"
mkdir -p "$REPORT_DIR"
TODAY=$(date +%Y-%m-%d)
RUN=1
REPORT_PATH="$REPORT_DIR/${TODAY}-skill-audit.md"
while [[ -f "$REPORT_PATH" ]]; do
  RUN=$(( RUN + 1 ))
  REPORT_PATH="$REPORT_DIR/skill-audit-${TODAY}-run${RUN}.md"
done
```

Announce: "Skill audit: `$CLAUDE_PROJECT_DIR` → saving to `$REPORT_PATH`"

---

## The 15 Dimensions

For **every skill file**, assess:

1. **Frontmatter completeness** — Does the SKILL.md have `name:`, `description:`, and `user-invocable:` in frontmatter? Is `user-invocable` set correctly (true = user types `/skill-name`; false = Claude invokes proactively)?

2. **Trigger specificity** — For `user-invocable: false` skills: is the proactive trigger pattern described and specific enough to avoid false positives? Would a cold-start Claude know when to invoke this? For `user-invocable: true`: is the invocation pattern and expected arguments documented?

3. **Purpose drift** — Compare the `description:` field to the CLAUDE.md slash-commands table entry (if present) to the actual skill content. Any divergence where they contradict each other?

4. **Coverage scope** — Enumerate explicitly what the skill actually checks, reads, or does — not what the description claims. What is the concrete execution path?

5. **Missing angles** — What a senior engineer would expect this skill to cover that it doesn't. Be specific: name the scenario, not the category.

6. **Output format consistency** — Does it produce a structured report? Where is output saved? Is the save location and filename consistent with the `$HOME/.claude/projects/$SLUG/<type>/YYYY-MM-DD[-runN].md` convention?

7. **Side effects** — Does it write files, call agents, modify state, create branches, or trigger external calls? Are all side effects documented in the skill header?

8. **Idempotency** — Safe to invoke twice in a row? Does re-running accumulate state, create duplicate files, or change behavior?

9. **Error handling** — What happens when preconditions aren't met: no git repo, no docker, dirty working tree, empty project, missing tools (jq, docker, shellcheck)? Are failures loud or silent?

10. **ask-human gate compliance** — For every question the skill asks the user: does it use `AskUserQuestion` via the `ask-human` skill? Is the recommended option first? No free-text questions? No numbered prose lists? Note: skills that complete work without any user questions are OK here.

11. **Convergence gate compliance** — For skills that do analysis or implementation work: does the skill explicitly invoke Phase 3C (pre-implementation) and Phase 6C (pre-completion) convergence loops as mandated by `~/.claude/CLAUDE.md`? N/A for read-only lookup/utility skills that produce no persistent artifacts.

12. **Composition safety** — Is this skill invoked by other skills (e.g., `mega-analysis`, `audit`)? Check for circular invocation paths. Are all parent callers documented? Would removing or renaming this skill break a pipeline?

13. **Cold-start readiness** — Can Claude execute this skill correctly with zero prior conversation context? Identify any instruction that assumes prior session knowledge, a prior tool call result, or a variable set earlier in the conversation.

14. **Token efficiency** — Is the skill lean and precise, or bloated with redundant instructions, repeated preambles, or content already in `~/.claude/CLAUDE.md`? Content duplicated from CLAUDE.md creates drift: future CLAUDE.md edits won't propagate.

15. **Generalizability verdict** — Classify:
    - **KEEP-GLOBAL**: generic, useful on any machine, no machine-specific content
    - **KEEP-PROJECT-ONLY**: has a hard project-specific dependency (docker compose, make, bin/env-*, .env)
    - **PROMOTE-CANDIDATE**: currently project-scoped but generic enough for global
    - **DUPLICATE-OF-OTHER**: functionally identical to another skill — merge or delete candidate

**Severity per dimension:**
- `OK` — no issue
- `P2` — minor gap, worth noting
- `P1` — meaningful gap that degrades usefulness
- `P0` — blocks correctness, causes wrong output, or creates security risk

---

## Step 1: Spawn parallel agents

Respect flags before spawning:
- `--quick`: spawn only agents 1 and 2 (skip 3 and 4)
- `--scope=global`: spawn only agents 1, 2 (skip 3 and 4)
- `--scope=project`: spawn only agent 3
- `--skill=<name>`: find the skill directory, spawn the right agent with that single skill
- Default: spawn all 4 in a single message (parallel)

Replace `<PROJECT>` with the actual `$CLAUDE_PROJECT_DIR` path.
Replace `<PROJECT_SLUG>` with the derived slug.

---

**Agent 1 — Global skills batch A**

> Read each of these skill files in `~/.claude/skills/`: `audit/SKILL.md`, `inspect/SKILL.md`, `sleuth/SKILL.md`, `gaps/SKILL.md`, `mega-analysis/SKILL.md`, `skill-audit/SKILL.md`, `command-audit/SKILL.md`, `memory-promote/SKILL.md`, `repair/SKILL.md`, `bootstrap/SKILL.md`. Also read `~/.claude/CLAUDE.md` — specifically the slash commands table and any skill-invocation rules — to understand the stated purpose of each skill.
>
> For EACH skill, produce a structured report across all 15 dimensions. For dimension 11 (convergence gate): check whether the skill explicitly calls the `expanding-context` skill or describes 3C/6C loop execution. For dimension 12 (composition safety): check whether this skill is referenced inside `mega-analysis/SKILL.md` or `audit/SKILL.md` as a pipeline step.
>
> Research only, no writes. Do not summarize — produce the full per-skill table for every skill in the list.

---

**Agent 2 — Global skills batch B**

> Read each of these skill files in `~/.claude/skills/`: `retrospective/SKILL.md`, `handoff/SKILL.md`, `loop/SKILL.md`, `recent/SKILL.md`, `consolidate/SKILL.md`, `bundle/SKILL.md`, `install/SKILL.md`, `adapt-project/SKILL.md`, `templatize/SKILL.md`, `expand/SKILL.md`, `cleanup/SKILL.md`, `sweep/SKILL.md`. Also read `~/.claude/CLAUDE.md` for stated descriptions.
>
> For EACH skill, produce the same structured 15-dimension table.
>
> Also cover these utility skills as a group in a condensed table (all 15 dims, one row per skill): `memory-off/SKILL.md`, `memory-on/SKILL.md`, `memory-readonly/SKILL.md`, `memory-status/SKILL.md`, `memory-block/SKILL.md`, `memory-unblock/SKILL.md`, `lean/SKILL.md`, `lean-block/SKILL.md`, `lean-unblock/SKILL.md`, `learning-off/SKILL.md`, `learning-on/SKILL.md`, `ask-human/SKILL.md`, `expanding-context/SKILL.md`.
>
> Research only, no writes.

---

**Agent 3 — Project skills** *(skipped with `--scope=global`)*

> Read each skill file in `<PROJECT>/.claude/skills/` (directories matching `*/SKILL.md`). If the directory doesn't exist or is empty, report "No project skills found" and exit.
>
> Read `<PROJECT>/CLAUDE.md` — the "Slash commands" or "Skills" section — for the stated description of each skill.
>
> For EACH skill, produce the 15-dimension table. For dimension 15 (Generalizability), use the full verdict:
> - **KEEP-PROJECT-ONLY**: hard project-specific dependency (docker compose, make, bin/env-*, .env)
> - **PROMOTE-CANDIDATE**: generic enough to work in any project with minor adaptation
> - **DUPLICATE-OF-GLOBAL**: functionally identical to a global skill — merge or delete
>
> Research only, no writes.

---

**Agent 4 — Deep-dives** *(skipped with `--quick`)*

> These skills are invoked as part of larger pipelines or have complex multi-agent orchestration that warrants extra scrutiny. Read each file fully: `mega-analysis/SKILL.md`, `audit/SKILL.md`, `inspect/SKILL.md`, `sleuth/SKILL.md`, `gaps/SKILL.md`, `repair/SKILL.md`.
>
> For each, produce the standard 15-dim table PLUS answers to these deep-dive questions:
>
> **Pipeline correctness**: Does the skill's agent-spawn sequence match what CLAUDE.md says the pipeline should do? Are there steps described in CLAUDE.md that the skill doesn't implement?
>
> **Flag completeness**: For every `--flag` documented in the skill header or CLAUDE.md: is it actually implemented in the skill's logic? Are flags checked via `$ARGUMENTS`?
>
> **Cold-start agent quality**: For every `Agent()` call inside the skill: is the subagent prompt fully self-contained for a cold-start agent (no assumed prior context)? Is `subagent_type` specified? Is `isolation: "worktree"` used where the agent modifies files?
>
> **Ask-human audit**: List every place the skill surfaces a question to the user. Confirm each uses the `ask-human` skill and `AskUserQuestion`, not free-text.
>
> Research only, no writes.

---

## Step 2: Synthesize

After all agents complete, produce a consolidated report:

```markdown
# /skill-audit Report — <DATE>
Generated: <DATE> | Project: <PROJECT_DIR> | Skills audited: N global + M project

## Health Summary
| Severity | Count | Skills affected |
|----------|-------|----------------|
| P0 | | |
| P1 | | |
| P2 | | |
| OK across all dims | | |

## Critical findings (P0)
[full detail for each]

## High-priority findings (P1)
[full detail for each]

## Generalizability verdicts
| Skill | Scope | Verdict |
|-------|-------|---------|
...

## Top 5 actions
1–5 ordered by impact

*Nothing in this report is auto-applied.*
```

Write the full per-skill tables + synthesis to `$REPORT_PATH`. Announce the path.

Also write a JSON sidecar `$REPORT_PATH.json` with this structure for pipeline consumption:
```json
{
  "generated": "<ISO date>",
  "skills_audited": { "global": N, "project": M },
  "findings": {
    "p0": [{ "skill": "...", "dim": N, "summary": "..." }],
    "p1": [{ "skill": "...", "dim": N, "summary": "..." }]
  },
  "generalizability": { "skill-name": "KEEP-GLOBAL|KEEP-PROJECT-ONLY|PROMOTE-CANDIDATE|DUPLICATE-OF-OTHER" }
}
```

## Step 3: Present

Show in conversation: health summary table + all P0 findings + P1 findings + top 5 actions. For P2: show count only. Then invoke the `ask-human` skill: question 'Would you like to see P2 findings?', options: 'Yes, show all P2 findings' / 'No, close the report (Recommended)'.
