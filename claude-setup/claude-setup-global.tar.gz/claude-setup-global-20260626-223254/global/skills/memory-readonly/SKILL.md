---
name: memory-readonly
description: Use when putting session-remember into read-only mode so prior context loads but this session will not be captured.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then STOP — do not execute any other steps.
>
> ```
> /memory-readonly — put session-remember into read-only mode so prior context loads but this session will not be captured
>
> No flags — invoked without arguments.
> ```

---

Put the session-remember memory system into read-only mode (load prior context, but don't capture new).

## Pre-check: lean mode session control

First run:
```bash
[ -f "$HOME/.claude/hooks/session-remember/DISABLED.lean" ] && echo "LEAN_DISABLED_EXISTS=true" || echo "LEAN_DISABLED_EXISTS=false"
[ -f "$HOME/.claude/hooks/session-remember/DISABLED" ] && echo "GLOBAL_DISABLED_EXISTS=true" || echo "GLOBAL_DISABLED_EXISTS=false"
```

If `LEAN_DISABLED_EXISTS=true`, stop and say exactly:

```
⛔ Session pipeline is controlled by lean mode (DISABLED.lean is active).
   Setting READONLY has no effect while lean mode disables the pipeline.

   Options:
     /lean --session on   → re-enable pipeline while keeping lean mode active
     /lean off            → exit lean mode entirely (restores all config)
```

Do not run any further commands. Nothing else.

If `LEAN_DISABLED_EXISTS=false` and `GLOBAL_DISABLED_EXISTS=true`, say exactly:

```
⚠ Session pipeline is globally disabled (DISABLED is present).
  Setting READONLY while DISABLED is active has no immediate effect — DISABLED wins.
  Proceeding to set READONLY for when DISABLED is removed...
```

Then continue to normal execution.

---

## Normal execution

Run:
```bash
touch ~/.claude/hooks/session-remember/READONLY
```

Then confirm by running:
```bash
ls -la ~/.claude/hooks/session-remember/DISABLED ~/.claude/hooks/session-remember/READONLY 2>&1
```

Say "Memory READONLY — prior context still loads, but this session will not be captured." Nothing else.

Note: if DISABLED is also present, it wins (full silence). Use `/memory-on` to clear both toggles.
