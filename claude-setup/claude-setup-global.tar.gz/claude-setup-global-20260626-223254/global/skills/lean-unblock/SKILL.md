---
name: lean-unblock
description: Use when removing a project from the lean-blocklist to re-enable /lean on for that project.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /lean-unblock — Remove a project from the lean-blocklist to re-enable /lean on for that project.
>
> No flags — accepts one optional positional argument: [path] (project directory to unblock).
> If no path is given, the project is discovered via git rev-parse --show-toplevel.
> ```

---

# /lean-unblock [path]

Remove a project from the lean-blocklist, re-enabling `/lean on` for that project.

If no path is given, discovers the project via `git rev-parse --show-toplevel` then walks parents for `CLAUDE.md`.

---

## Parse flags

Set `PATH_ARG` to the first non-flag argument if present, else empty.

## Run

```bash
LEAN_BLOCKLIST="$HOME/.claude/lean-blocklist"

_discover_path() {
  local arg="$1"
  if [[ -n "$arg" ]]; then
    [[ -d "$arg" ]] || { echo "⛔ Path not found: $arg" >&2; return 1; }
    realpath "$arg"; return 0
  fi
  local g
  g=$(git rev-parse --show-toplevel 2>/dev/null) && { echo "$g"; return 0; }
  local d="$PWD"
  while [[ "$d" != "/" ]]; do
    [[ -f "$d/CLAUDE.md" ]] && { echo "$d"; return 0; }
    d=$(dirname "$d")
  done
  echo "⛔ Cannot determine project path. Provide path as argument." >&2
  return 1
}

PROJECT_PATH=$(_discover_path "${PATH_ARG:-}") || exit 1
PROJECT_SLUG=$(echo "$PROJECT_PATH" | sed 's|/|-|g')

if [[ ! -f "$LEAN_BLOCKLIST" ]] || ! grep -qxF "$PROJECT_SLUG" "$LEAN_BLOCKLIST" 2>/dev/null; then
  echo "Project $PROJECT_PATH is not in the lean-blocklist."
  echo "  Slug: $PROJECT_SLUG"
  exit 0
fi

TMP=$(mktemp)
trap 'rm -f "$TMP"' EXIT
grep -vxF "$PROJECT_SLUG" "$LEAN_BLOCKLIST" > "$TMP" && mv "$TMP" "$LEAN_BLOCKLIST"

echo "✓ $PROJECT_PATH lean-unblocked"
echo "  Slug: $PROJECT_SLUG"
echo "  /lean on is now permitted for this project."
```
