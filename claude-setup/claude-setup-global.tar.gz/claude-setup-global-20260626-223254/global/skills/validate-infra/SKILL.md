---
name: validate-infra
description: Use after editing Dockerfiles, compose files, Makefile targets, shell scripts, or YAML config — runs bash -n / docker compose config -q / yamllint and produces the Coverage evidence row required by CLAUDE.md Rule 7 (TDD for infra tasks).
user-invocable: true
args: "[--scope=<path>] [--compose-file=<file>]"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /validate-infra — Syntax and config validation for pure infrastructure changes.
>
> Usage: /validate-infra [--scope=<path>] [--compose-file=<file>]
>
> Flags:
>   --scope=<path>          Directory to scan (default: current project root)
>   --compose-file=<file>   Specific compose file to validate (default: auto-detect docker-compose.yml / compose.yml)
>
> Produces the Coverage evidence row required by CLAUDE.md Rule 6/7 for infra tasks.
> ```

---

## Differentiation from related skills

| Skill | Scope | Use when |
|-------|-------|----------|
| `/inspect` | Broad architecture review — design, naming, patterns, cross-file consistency | You want an architectural assessment of a directory or module |
| `/validate-infra` | Syntax + config correctness — shells, compose, YAML | You changed infra files and need Coverage evidence (CLAUDE.md Rule 7 TDD for infra) before committing |

`/validate-infra` is the TDD equivalent for pure infra changes: first check identifies the gap, implementation fixes it, second check proves it. `/inspect` is a design-time review, not a correctness gate.

---

## Side effects

**None** — this skill is read-only. It runs linting and syntax-check commands but never modifies files. All commands are read-only (`bash -n`, `docker compose config -q`, `yamllint`).

**Critical**: `docker compose config` is intentionally run with `-q` (quiet mode) and its output is **never captured or logged**. `docker compose config` without `-q` expands `env_file` entries and prints live credentials to stdout — capturing that output would expose secrets. Only the exit code is used.

---

## Step 0 — Precondition checks

**Mandatory task gate**: invoke `ask-human` before Step 1 begins to confirm the scan should proceed (noting any optional tools absent from PATH). Do not proceed until the user confirms.

Determine scope:
- If `--scope=<path>` provided: use that path
- Otherwise: use `${CLAUDE_PROJECT_DIR:-$PWD}`

Check tool availability (run `command -v <tool>` for each):

| Tool | Used for | If absent |
|------|----------|----------|
| `bash` | `bash -n` shell syntax check | ERROR — bash required; stop |
| `docker` | `docker compose config -q` | WARN — compose validation will be skipped |
| `docker compose` | compose config check | WARN — compose validation will be skipped (check: `docker compose version`) |
| `yamllint` | YAML linting | WARN — YAML linting will be skipped; install with `pip install yamllint` |
| `hadolint` | Dockerfile linting | WARN — Dockerfile linting will be skipped; install with `brew install hadolint` or `apt-get install hadolint` |

Do NOT stop for missing optional tools — report them as SKIPPED in the results table.

---

## Step 1 — Discover files

Find all infra files in `$SCOPE`:

```bash
# Shell scripts
find "$SCOPE" -name "*.sh" -not -path "*/node_modules/*" -not -path "*/.git/*"

# Compose files (in priority order)
find "$SCOPE" -name "docker-compose.yml" -o -name "docker-compose.yaml" \
  -o -name "compose.yml" -o -name "compose.yaml" \
  -not -path "*/.git/*" | head -10

# YAML/YML files (non-compose)
find "$SCOPE" \( -name "*.yml" -o -name "*.yaml" \) \
  -not -name "docker-compose*" -not -name "compose.*" \
  -not -path "*/node_modules/*" -not -path "*/.git/*"

# Makefiles
find "$SCOPE" -maxdepth 2 \( -name "Makefile" -o -name "makefile" -o -name "GNUmakefile" \)

# Dockerfiles
find "$SCOPE" -name "Dockerfile" -o -name "Dockerfile.*" \
  -not -path "*/.git/*" -not -path "*/node_modules/*"
```

If `--compose-file=<file>` was provided, use that file instead of auto-detected compose files.

Report the discovered file counts: `Found: N shell scripts, M compose files, K YAML files, J Makefiles`.

---

## Step 2 — Shell script syntax check

For each `.sh` file discovered:

```bash
bash -n "<file>"
```

Record result: `PASS <file>` or `FAIL <file>: <error message from bash -n>`.

---

## Step 3 — Compose config validation

**Exit-code only — never capture stdout or stderr from this command.**

For each compose file discovered (or `--compose-file` if provided):

```bash
docker compose -f "<file>" config -q
echo "Exit: $?"
```

Record result by exit code only:
- Exit 0 → `PASS <file>: compose config valid`
- Non-zero → `FAIL <file>: docker compose config -q returned non-zero (compose file has errors — run manually to see details without secret exposure risk)`

Do NOT capture, display, log, or report any stdout/stderr output from `docker compose config`. The exit code is the only signal. This prevents env_file secrets from appearing in conversation or report output.

---

## Step 3b — Makefile syntax check

For each Makefile discovered:

```bash
make -n -f "<file>" 2>&1 | head -5
echo "Exit: $?"
```

`make -n` performs a dry-run parse of the first target. This catches: missing TAB indentation (spaces used instead), undefined variables referenced in the first target, and include errors.

Record: `PASS <file>` or `FAIL <file>: <make -n error>`.

Note: `make -n` only parses through the first default target. Deep target chains and conditional evaluation are not covered. If `make` is not installed: SKIP with WARN.

## Step 3c — Dockerfile lint

For each Dockerfile discovered:

If `hadolint` is available:
```bash
hadolint "<file>"
echo "Exit: $?"
```

Record: `PASS <file>` or `FAIL <file>: <hadolint warnings>`.

If `hadolint` is absent: record `SKIP <file>: hadolint not installed`.

## Step 4 — YAML lint

For each YAML file (excluding compose files already validated in Step 3):

```bash
yamllint -d "{extends: default, rules: {line-length: {max: 160}}}" "<file>"
```

Record: `PASS <file>` or `FAIL <file>: <yamllint output>`.

---

## Step 5 — Produce Coverage evidence row

Produce the Coverage dimension for CLAUDE.md Rule 6:

```
## Coverage Evidence (Rule 6 / Rule 7 — infra TDD)

| File | Check | Result |
|------|-------|--------|
| <file.sh> | bash -n | PASS / FAIL: <error> |
| <docker-compose.yml> | docker compose config -q | PASS / FAIL |
| <file.yml> | yamllint | PASS / FAIL: <error> |

Summary: N checks run | P pass | F fail | S skipped (tool absent)

Coverage row for evidence table:
| Coverage | <OK / INCOMPLETE> | bash -n: N/N pass; compose config -q: M/M pass; yamllint: K/K pass; make -n: J/J pass; hadolint: L/L pass (or SKIPPED: tool absent) |
```

If any check FAILS: Coverage row is **INCOMPLETE**. List the files that must be fixed before the Coverage row can be marked OK.

If a tool was absent and checks were SKIPPED: Coverage row notes the skipped checks and states "install <tool> for full coverage."

Output is displayed in conversation only — not persisted to disk; paste the Coverage row directly into your evidence table.

---

## Error handling summary

| Condition | Behaviour |
|-----------|----------|
| `bash` binary absent | ERROR + stop — `bash -n` is the core check |
| `docker` / `docker compose` absent | WARN — compose steps SKIPPED; continue |
| `yamllint` absent | WARN — YAML steps SKIPPED; continue |
| No infra files found in scope | Report "No infra files found in `$SCOPE`" and stop |
| `--compose-file=` path does not exist | ERROR — report invalid path; stop compose step |
| `docker compose config -q` non-zero | FAIL noted by exit code only — never expose output |
| `bash -n` reports syntax error | FAIL noted with the exact error message from bash -n |
| `make` binary absent | WARN — Makefile steps SKIPPED; continue |
| `make -n` fails | FAIL noted with first 5 lines of make output |
| `hadolint` absent | WARN — Dockerfile steps SKIPPED; continue |
| `hadolint` reports violations | FAIL noted with hadolint output |
