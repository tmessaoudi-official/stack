---
name: agent-def
description: Use when creating or reviewing agent definition files — two modes: --audit <path> flags sections that duplicate global CLAUDE.md content (per Rule 5); --new <name> scaffolds a domain-specific-only agent definition skeleton.
user-invocable: true
args: "--audit <path> | --new <name>"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /agent-def — Author and audit agent definition files per CLAUDE.md Rule 5.
>
> Usage:
>   /agent-def --audit <path>   Audit an existing agent def for inherited-rule duplication
>   /agent-def --new <name>     Scaffold a compliant domain-specific-only agent def skeleton
>
> Rule 5 principle: agent def files contain ONLY domain-specific content — the delta above what
> CLAUDE.md already provides. Generic sections (phase workflow, TDD, Completion Gate, security)
> are inherited automatically and must NOT be restated (restatement causes drift).
> ```

---

## Differentiation from related skills

| Skill | Scope | Use when |
|-------|-------|----------|
| `/audit` Agent B | Full CLAUDE.md health audit — checks ALL agent defs in one pass as part of a broader audit | You want a system-wide audit of all config and agent defs |
| `/agent-def --audit` | Single agent def, targeted, interactive | You are about to submit an agent def change and want a focused per-file check |
| `/agent-def --new` | Scaffold a new agent def from scratch | You are creating a new agent definition and want the correct skeleton |

`/audit` Agent B checks for duplication as part of a full-system run. `/agent-def --audit` is the targeted, per-file version — run it before creating a PR or committing an agent def change.

**Dual-implementation note**: Both `/audit` Agent B and `/agent-def --audit` independently implement Rule 5 duplication detection. The canonical list of "inherited sections" is defined in Step 1 of this file. When CLAUDE.md adds new rules or renames phases, update Step 1's classification list here AND audit/SKILL.md Agent B's duplication check. Failure to keep both in sync causes false-positive PASS results.

---

## Side effects

- **`--audit`**: **read-only** — reads the agent def file and CLAUDE.md; produces a duplication report in conversation only.
- **`--new`**: **creates one file** — writes the scaffolded skeleton to `.claude/agents/<name>.md` (project-local) or `~/.claude/agents/<name>.md` (global, if `--global` flag used). Presents the file for review before writing. Never auto-writes.

---

## Step 0 — Parse mode and preconditions

**Mandatory task gate**: invoke `ask-human` before Step 1 begins to confirm size and intent. Do not proceed until the user confirms.

Check that exactly one mode flag is present (`--audit` or `--new`). If neither or both: report usage error and stop.

**For `--audit <path>`**:
- Verify the file exists: `ls "<path>"` — if absent, report `ERROR: File not found: <path>` and stop.
- Verify it is an agent def file: check that it contains YAML/Markdown frontmatter or the path is under `.claude/agents/` or `~/.claude/agents/`. If neither, report `WARN: File does not appear to be an agent definition — proceeding anyway.`
- **Self-modification guard**: if `<path>` resolves to the agent definition file for the currently-executing agent context, emit `WARN: Auditing the agent def that may be your own execution context. CLAUDE.md Rule 5 notes that self-modification of agent defs while running inside that agent may be blocked. This audit is read-only and safe, but write operations on this file require explicit user confirmation.`

**For `--new <name>`**:
- Validate `<name>` is a valid kebab-case identifier (letters, numbers, hyphens only, starts with a letter).
- Determine target location via `ask-human`:
  - `~/.claude/agents/<name>.md` — global agent, available in all projects
  - `.claude/agents/<name>.md` — project-local agent, project-specific
- **Existing file guard** (before generating skeleton): run `ls "<target-path>"` — if the file already exists, emit `WARN: <target-path> already exists` and ask via `ask-human`: Overwrite / Choose a different name / Cancel. Do not proceed to Step 2 until the user resolves this.

---

## Step 1 — `--audit` mode: duplication analysis

Read:
1. The target agent def file at `<path>`
2. `~/.claude/CLAUDE.md` — the global framework

For each section in the agent def, determine whether it falls into:

**Domain-specific (KEEP)**: content describing the agent's unique toolchain, project conventions, domain knowledge, routing rules, or capabilities that differ from what CLAUDE.md provides. This is the intended content.

**Generic / inherited (FLAG)**: any section that restates content already in CLAUDE.md:
- Phase workflow (0–8 phase descriptions)
- Task categorization protocol (Small/Medium/Large table)
- TDD rules (test-driven by default)
- Completion Gate (Rule 6 four-dimension evidence table)
- Security rules (Rule 2)
- Communication style guidelines
- Evidence grade rules (Rule 18)
- Any CLAUDE.md rule cited by number AND reproduced in full

Produce a duplication report:

```
## Agent def audit: <path>
Rule 5 compliance: PASS / FAIL

### Domain-specific sections (KEEP)
- <section name>: <one-line rationale for keeping it>
...

### Inherited-rule duplications (REMOVE)
| Section | CLAUDE.md rule / section duplicated | Recommended action |
|---------|------------------------------------|--------------------|
| <section name> | Rule N / "Phase X" | Delete — inherited automatically |
...

### Recommended replacement for each removed section
For each removed section: add a single reference line such as:
`Global rules 1–18 apply without exception.` (or cite the specific rule)
```

If no duplications found: `Rule 5 compliance: PASS — no inherited-rule duplication detected.`

---

## Step 2 — `--new` mode: scaffold skeleton

Generate a minimal, compliant agent def skeleton containing **only** domain-specific content:

```markdown
---
name: <name>
description: <one-line description of this agent's domain — what it specialises in>
---

# <Name> Agent

## Domain

<One paragraph describing the specific domain, toolchain, or project this agent specialises in. 
What does this agent know that a generic Claude instance does not?>

## Routing

<When should Claude route work to this agent? State the specific patterns, file types, or task 
types that trigger delegation to this agent.>

## Domain-specific tools and conventions

<List only tools, scripts, commands, or conventions that are specific to this agent's domain — 
e.g. specific CLI tools, Docker images, make targets, environment variables, API endpoints.>
Do NOT list git, bash, grep, or other universally available tools here.

## Domain-specific constraints

<Any hard constraints unique to this domain — e.g. "never run migrations without a dry-run first",
"always run X before Y", "output format must match Z spec". 
Generic constraints (security, TDD, evidence gate) are inherited from global CLAUDE.md.>

<!--
Global rules 1–18 apply without exception.
Do not restate them here — restatement causes drift when CLAUDE.md is updated.
-->
```

Display the skeleton. Ask via `ask-human` to confirm before writing:
- Write to `<target-path>` (Recommended)
- Edit the skeleton first
- Cancel

If "Write": create the file. If the target directory does not exist, create it first: `mkdir -p "$(dirname <target-path>)"`.

After writing, display Rule 5 reminder: "This skeleton contains only the required structure. Fill in domain-specific content — do NOT copy any section from CLAUDE.md. Run `/agent-def --audit <target-path>` before committing to verify compliance."

---

## Error handling summary

| Condition | Behaviour |
|-----------|----------|
| Neither `--audit` nor `--new` provided | ERROR — show usage and stop |
| Both flags provided simultaneously | ERROR — modes are mutually exclusive; stop |
| `--audit <path>` file not found | ERROR + stop |
| `--new <name>` invalid characters | ERROR — show valid format (kebab-case) and stop |
| Target file already exists (`--new`) | WARN — ask user: overwrite / choose different name / cancel |
| `~/.claude/CLAUDE.md` not readable | ERROR — cannot perform duplication check without the reference; stop `--audit` mode |
| `mkdir -p` fails on target dir | ERROR — report the path and permission issue; stop |
