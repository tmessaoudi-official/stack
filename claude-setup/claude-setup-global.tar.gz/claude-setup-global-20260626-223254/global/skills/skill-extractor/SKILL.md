---
name: skill-extractor
spotlight: true
description: Analyze conversation history, memory buffer, and session context to detect repeated prompt patterns that could become reusable skills. Proposes SKILL.md drafts for each detected pattern. Every proposal requires explicit ask-human validation before any file is written. Use periodically or after long sessions to mine the interaction for automation opportunities.
user-invocable: true
args: "[--min-repeats=N] [--source=buffer|history|both] [--dry-run]"
side-effects: Writes new SKILL.md files to ~/.claude/skills/<name>/ only for patterns explicitly approved via ask-human.
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /skill-extractor — Analyze conversation history, memory buffer, and session context to detect repeated prompt patterns that could become reusable skills.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /skill-extractor — Pattern-to-Skill Mining

Scans your interaction history and memory for repeated prompt patterns, then proposes skills to automate them. Nothing is written until you explicitly approve each proposal.

## Flags

- `--min-repeats=N` — minimum times a pattern must appear to be proposed (default: **3**)
- `--source=buffer|history|both` — what to scan (default: `both`)
  - `buffer`: `~/.claude/projects/*/memory/sessions/buffer.md`
  - `history`: recent JSONL session files (last 20 sessions)
  - `both`: all of the above + memory files
- `--dry-run` — show detected patterns but do not propose or write any skill

---

## Step 0 — Approval gate (MANDATORY)

Invoke `ask-human` before scanning anything:

Question: "About to scan your interaction history for repeatable skill patterns."
Show config: sources, min-repeats, dry-run flag.

Options:
  1. "Yes, scan and propose (Recommended)"
  2. "Dry run only — show patterns, no proposals"
  3. "Skip"

---

## Step 1 — Collect sources

Read (respecting `--source` flag):
- Buffer: `~/.claude/projects/*/memory/sessions/buffer.md`
- History: last 20 save logs in `~/.claude/projects/*/memory/sessions/logs/save-<epoch>.log` (epoch-named, sort by name to get chronological order)
- Memory: all `~/.claude/projects/*/memory/*.md` files
- Current conversation context

Cap total input at 50KB.

---

## Step 2 — Detect repeated patterns

Spawn a single analysis agent with the collected text:

> "Analyze this Claude Code interaction history for repeated prompt patterns that could become reusable slash skills. A pattern qualifies if: (1) it appears >= N times, (2) it represents a repeatable action (not a one-off question), (3) it has clear inputs and outputs, (4) it is not already covered by existing skills (list provided).
>
> For each pattern output: name (kebab-case), trigger phrases, what it does (one sentence), inputs, outputs, estimated repeat count.
> Rank by repeat count. Output at most 10 patterns."

Include the list of existing skills from `ls ~/.claude/skills/` in the prompt.

---

## Step 3 — Filter

Remove patterns that:
- Are already covered by an existing skill
- Appear fewer than `--min-repeats` times
- Are too vague to define (e.g. "help me think")

If `--dry-run`: print ranked list and stop.

---

## Step 4 — Propose skills one by one (highest repeat count first)

For each pattern, draft a minimal SKILL.md and present via `ask-human`:

Show: pattern name, trigger phrase(s), repeat count, what it does, draft SKILL.md preview.

Options:
  1. "Accept — write this skill (Recommended)"
  2. "Accept with edits — describe changes in notes"
  3. "Skip this pattern"
  4. "Stop — done for this session"

**Hard rule**: never write any file until user selects Accept. For option 2: apply edits, show updated preview, ask again before writing.

---

## Step 5 — Write accepted skills

For each accepted skill:
1. `mkdir -p ~/.claude/skills/<name>/`
2. Write SKILL.md (with any user edits)
3. Report: `✓ Written: ~/.claude/skills/<name>/SKILL.md`

Final summary: patterns found / proposed / accepted / written / skipped.

Remind user: new skills appear in system-reminder at next session start automatically.

---

## Step 6 — Optional CLAUDE.md update

If any new skill has a non-obvious trigger, ask whether to add a routing note to CLAUDE.md.
If yes: read the `## Global Skills Reference` section of `~/.claude/CLAUDE.md` and propose the exact edit inline (the routing note format is: `/<skill-name> — <one-line description of when to invoke>`). Present the diff to the user and wait for confirmation. Never auto-apply.
