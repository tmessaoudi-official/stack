---
name: memory-off
description: Use when globally disabling the session-remember memory system so no context loads and no capture happens.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then STOP — do not execute any other steps.
>
> ```
> /memory-off — Globally disable the session-remember memory system so no context loads and no capture happens.
>
> No flags — invoked without arguments.
> ```

---

Disable the session-remember memory system globally (no load, no capture).

## Pre-check: lean mode session control

First run:
```bash
[ -f "$HOME/.claude/hooks/session-remember/DISABLED.lean" ] && echo "LEAN_DISABLED_EXISTS=true" || echo "LEAN_DISABLED_EXISTS=false"
```

If `LEAN_DISABLED_EXISTS=true`, say exactly:

```
⚠ Session pipeline is already disabled by lean mode (DISABLED.lean present).
  Running memory-off creates an independent DISABLED toggle that persists after lean mode ends.
  This means when you run /lean off, the pipeline stays off (your explicit choice).
  Proceeding anyway...
```

Then continue to normal execution regardless.

---

## Normal execution

Run:
```bash
touch ~/.claude/hooks/session-remember/DISABLED
```

Then confirm by running:
```bash
ls -la ~/.claude/hooks/session-remember/DISABLED ~/.claude/hooks/session-remember/READONLY 2>&1
```

Say "Memory DISABLED — no context will load and no capture will happen." Nothing else.

Precedence reminder: DISABLED > READONLY > blacklist > normal. Use `/memory-on` to re-enable.
