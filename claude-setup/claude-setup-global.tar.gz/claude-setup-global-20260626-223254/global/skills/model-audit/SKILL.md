---
name: model-audit
description: Use when checking Claude model IDs across ~/.claude/ for outdated or date-suffixed IDs. Mode 1 normalizes IDs, Mode 2 challenges outdated versions.
user-invocable: true
---

# /model-audit — Claude Model ID Health Check

Two-mode health check for Claude model IDs across `~/.claude/`.
Mode 1 normalizes date-suffixed IDs. Mode 2 challenges outdated model versions.

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps.
>
> ```
> /model-audit — Scan ~/.claude/ for stale or date-suffixed Claude model IDs.
>
> Modes:
>   (default)     Normalize: fix date-suffixed IDs (e.g. claude-haiku-4-5-20251001 → claude-haiku-4-5)
>   --currency    Challenge outdated model versions against ~/.claude/refs/MODELS.md
>   --apply       Apply proposed fixes (default is dry-run)
>   --init        Create ~/.claude/refs/MODELS.md with current canonical lineup (skip if exists)
  --init --force  Overwrite MODELS.md even if it already exists (refresh stale data)
>   --scope=<path>  Restrict scan to a specific path (default: ~/.claude/)
> ```

---

## Mode 1: Normalize (default)

Detect and optionally fix date-suffixed Claude model IDs across `~/.claude/`.

Date-suffix pattern: `claude-(opus|sonnet|haiku)-<M>-<m>-YYYYMMDD`
Canonical form: `claude-(family)-M-m` (no trailing date)

### Step 1: Scan

```bash
grep -rn 'claude-\(opus\|sonnet\|haiku\)-[0-9][0-9]*-[0-9][0-9]*-[0-9]\{8\}' \
  "${SCOPE:-$HOME/.claude}" \
  --include='*.sh' --include='*.md' --include='*.json' --include='*.yaml' \
  2>/dev/null
```

Also scan without extension filter for completeness:
```bash
grep -rn 'claude-\(opus\|sonnet\|haiku\)-[0-9]\+-[0-9]\+-[0-9]\{8\}' \
  "${SCOPE:-$HOME/.claude}" 2>/dev/null
```

### Step 2: Present plan

For each match, format as:

```
FILE: ~/.claude/hooks/session-remember/save.sh:224
  FOUND:      claude-haiku-4-5-20251001
  NORMALIZE → claude-haiku-4-5
```

If no matches: print "All model IDs are already in canonical form — no date suffixes found." and stop.

### Step 3: Apply (if `--apply`)

For each match, make the targeted replacement. Never touch model IDs that are already canonical.
Use `sed -i` targeted replacements, one per file, preserving surrounding context.

After applying: re-run the scan to confirm zero matches remain.

---

## Mode 2: Currency Check (`--currency`)

Challenge outdated Claude model versions using a user-maintained truth source.

**Prerequisite**: `~/.claude/refs/MODELS.md` must exist.
If not found: print "MODELS.md not found. Run `/model-audit --init` to create it." and stop.

### Step 1: Load canonical models

Read `~/.claude/refs/MODELS.md`. Extract rows with `Status = CURRENT`.
Build a map: `family → current_model_id` and `family → [superseded_ids]`.

### Step 2: Scan for all model ID references

```bash
grep -rn 'claude-\(opus\|sonnet\|haiku\)-[0-9]' \
  "${SCOPE:-$HOME/.claude}" \
  --include='*.sh' --include='*.md' --include='*.json' --include='*.yaml' \
  2>/dev/null
```

### Step 3: Classify each found model ID

For each match:
1. Strip any date suffix → `base_id`
2. Extract family (`opus` / `sonnet` / `haiku`) and version numbers
3. Compare `base_id` to MODELS.md CURRENT for that family:

| Result | Action |
|--------|--------|
| `base_id == CURRENT` | ✅ Print as up-to-date (verbose mode only) |
| `base_id` is older within same family | ⚠️ OUTDATED — challenge |
| `base_id` is a different tier/family | **SKIP** — never propose cross-family upgrades |
| `base_id` unknown | ❓ Flag as UNRECOGNIZED |

**Hard rule — cross-family upgrades are never proposed.** Haiku is often chosen for cost/latency reasons. Sonnet is chosen for balance. Opus is chosen for capability. Cross-family changes require human judgment — the skill must not second-guess tier choices.

### Step 4: Present findings

Group by file. For each OUTDATED entry:
```
FILE: ~/.claude/CLAUDE.md:142
  FOUND:   claude-opus-4-7 (Opus family)
  CURRENT: claude-opus-4-8
  CHALLENGE: You are using Opus 4.7 in this location — Opus 4.8 is available.
             Intentional choice, or needs updating?
```

For each UNRECOGNIZED entry:
```
FILE: ~/.claude/agents/my-agent.md:5
  FOUND:   claude-opus-4-5 (not in MODELS.md)
  STATUS:  UNRECOGNIZED — may be deprecated or a typo
```

If all entries are current: "All model IDs match current versions in MODELS.md ✅"

### Step 5: Apply (if `--apply`)

For each OUTDATED entry: present the proposed replacement and ask for per-entry confirmation before writing. Never batch-replace all — each replacement is a deliberate choice.

---

## --init flag

Creates `~/.claude/refs/MODELS.md` with the current canonical Claude lineup.

**Safe to rerun** — never overwrites if file already exists. Prints the path if it already exists.
Use `--force` to overwrite an existing MODELS.md with a refreshed canonical lineup.

```markdown
# Claude Models Reference
# Update this file when Anthropic releases new models.
# /model-audit --currency reads from here — keep it current.
# Format: | Model ID | Family | Version | Status | Supersedes |
# Status values: CURRENT | DEPRECATED | PREVIEW

## Current Canonical IDs

| Model ID | Family | Version | Status | Supersedes |
|----------|--------|---------|--------|------------|
| claude-opus-4-8 | opus | 4.8 | CURRENT | claude-opus-4-7 |
| claude-sonnet-4-6 | sonnet | 4.6 | CURRENT | claude-sonnet-4-5 |
| claude-haiku-4-5 | haiku | 4.5 | CURRENT | claude-haiku-3-5 |

## Deprecated (keep for reference — these may still appear in older configs)

| Model ID | Family | Superseded by |
|----------|--------|---------------|
| claude-opus-4-7 | opus | claude-opus-4-8 |
| claude-sonnet-4-5 | sonnet | claude-sonnet-4-6 |
| claude-haiku-3-5 | haiku | claude-haiku-4-5 |
```

---

## Combined run (both modes)

Running without `--currency` runs Mode 1 (normalize) only.
Running with `--currency` runs Mode 1 first (normalize), then Mode 2 (currency check).
Mode 1 results are applied before Mode 2 runs, so currency check always sees canonical base IDs.

---

## Usage examples

```bash
/model-audit                     # Normalize dry-run (show what would change)
/model-audit --apply             # Apply normalization fixes
/model-audit --init              # Create ~/.claude/refs/MODELS.md (skip if exists)
/model-audit --init --force     # Overwrite MODELS.md with refreshed data
/model-audit --currency          # Check currency against MODELS.md (dry-run)
/model-audit --currency --apply  # Normalize + propose currency upgrades
/model-audit --scope=~/.claude/hooks  # Restrict scan to hooks/ subdirectory
```
