---
name: memory-block
description: Use when disabling session-remember for a specific project path, either fully (blacklist) or in readonly mode (readonly-list).
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /memory-block — Disable session-remember for a specific project path, either fully (blacklist) or in readonly mode (readonly-list).
> ```
>
> Then output the complete flag table from the **"Parse flags"** section below. Then STOP.

---

# /memory-block [path] [--readonly]

Disable session-remember for a specific project path.

- Default: adds the project slug to `~/.claude/hooks/session-remember/blacklist` (full disable — no context loaded, no capture)
- `--readonly`: adds to `readonly-list` instead (context loads, capture skipped)

If no path is given, discovers the project via `git rev-parse --show-toplevel` then walks parents looking for `CLAUDE.md`.

---

## Pre-check: global pipeline state

Before modifying any block lists, run:
```bash
[ -f "$HOME/.claude/hooks/session-remember/DISABLED.lean" ] && echo "LEAN_DISABLED=true" || echo "LEAN_DISABLED=false"
[ -f "$HOME/.claude/hooks/session-remember/DISABLED" ] && echo "GLOBAL_DISABLED=true" || echo "GLOBAL_DISABLED=false"
```

If `LEAN_DISABLED=true`, warn:
```
⚠ Session pipeline is controlled by lean mode (DISABLED.lean present).
  Per-project block list changes will have no effect until lean mode ends.
  Proceeding anyway so the entry is ready when lean mode exits...
```

If `LEAN_DISABLED=false` and `GLOBAL_DISABLED=true`, warn:
```
⚠ Session pipeline is globally disabled (DISABLED is present).
  Per-project block list changes will have no effect until DISABLED is removed.
  Proceeding anyway so the entry is ready when global disable is lifted...
```

Then continue to normal execution regardless.

---

## Parse flags

Determine from args:
- `READONLY_MODE`: default `false`; set to `true` if args contain `--readonly`
- `PATH_ARG`: the path argument if provided, else empty string

## Run

```bash
# Discover project path
_discover_path() {
  local arg="$1"
  if [[ -n "$arg" ]]; then
    [[ -d "$arg" ]] || { echo "⛔ Path not found: $arg" >&2; return 1; }
    realpath "$arg"; return 0
  fi
  local g
  g=$(git rev-parse --show-toplevel 2>/dev/null) && { echo "$g"; return 0; }
  local d="$PWD"
  while [[ "$d" != "/" ]]; do
    [[ -f "$d/CLAUDE.md" ]] && { echo "$d"; return 0; }
    d=$(dirname "$d")
  done
  echo "⛔ Cannot determine project path. Provide path as argument." >&2
  return 1
}

PROJECT_PATH=$(_discover_path "${PATH_ARG}") || exit 1
PROJECT_SLUG=$(echo "$PROJECT_PATH" | sed 's|/|-|g')

SR_DIR="$HOME/.claude/hooks/session-remember"

if [[ "$READONLY_MODE" == "true" ]]; then
  TARGET_FILE="$SR_DIR/readonly-list"
  MODE_LABEL="readonly (load context, skip capture)"
else
  TARGET_FILE="$SR_DIR/blacklist"
  MODE_LABEL="blocked (no load, no capture)"
fi

# Check if already listed
if [[ -f "$TARGET_FILE" ]] && grep -qxF "$PROJECT_SLUG" "$TARGET_FILE" 2>/dev/null; then
  echo "Project $PROJECT_PATH is already in $(basename "$TARGET_FILE") ($MODE_LABEL)."
  exit 0
fi

# Check if in the OTHER list (warn about conflict)
if [[ "$READONLY_MODE" == "true" ]]; then
  OTHER_FILE="$SR_DIR/blacklist"
  OTHER_LABEL="blacklist (full disable)"
else
  OTHER_FILE="$SR_DIR/readonly-list"
  OTHER_LABEL="readonly-list"
fi
if [[ -f "$OTHER_FILE" ]] && grep -qxF "$PROJECT_SLUG" "$OTHER_FILE" 2>/dev/null; then
  echo "⚠ Project $PROJECT_PATH is already in $OTHER_LABEL."
  echo "  Remove it first with /memory-unblock, then re-block with desired mode."
  exit 0
fi

mkdir -p "$SR_DIR"
printf '%s\n' "$PROJECT_SLUG" >> "$TARGET_FILE"

echo "✓ $PROJECT_PATH → $MODE_LABEL"
echo "  Slug: $PROJECT_SLUG"
echo "  File: $TARGET_FILE"
echo "  Takes effect at next session start."
```
