---
name: recent
spotlight: true
description: Use when loading quick project context at a glance — recent commits, uncommitted changes, and changed file stats.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then STOP — do not execute any other steps.
>
> ```
> /recent — Load quick project context at a glance: recent commits, uncommitted changes, and changed file stats.
>
> No flags — invoked without arguments.
> ```

---

Quick context loader — show recent project state at a glance.

## Steps (run all, report together):
1. **Recent commits**: `git log --oneline -10`
2. **Uncommitted changes**: `git status --short` (if any)
3. **Changed files stats**: `git diff --stat` (if any uncommitted changes)

## Output:
- Compact summary in sections:
  - Last 10 commits (one line each)
  - Working tree status (clean or list of changes with line counts)
- Keep output concise — this is a context snapshot, not a deep analysis

$ARGUMENTS
