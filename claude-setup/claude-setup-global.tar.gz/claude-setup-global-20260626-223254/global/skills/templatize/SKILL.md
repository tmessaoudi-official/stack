---
name: templatize
spotlight: true
description: Use when applying bundle transformation rules to a single command, agent, or CLAUDE.md file to produce a portable template with ADAPT markers, without running the full /bundle pipeline.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /templatize — Apply bundle transformation rules to a single command, agent, or CLAUDE.md file to produce a portable template with ADAPT markers.
> ```
>
> Then output the complete flag table from the **"Step 1: Resolve file and type"** section below (the `Parse $ARGUMENTS` block). Then STOP.

---

# /templatize — Single-file portability tool

Apply bundle transformation rules to one file, producing a portable template with ADAPT
markers. Lighter-weight alternative to `/bundle --scope project` when you want to
templatize just one command, agent, or CLAUDE.md without running the full bundle pipeline.

Parse `$ARGUMENTS`:
- `<path>` — file to templatize (required; auto-detects type from path and content)
- `--output <path>` — explicit output path; default: `<same-dir>/<basename>.template.md`
- `--dry-run` — print templatized content to conversation only, no file written
- `--type command|agent|claude-md` — override auto-detection

---

## Step 1: Resolve file and type

Check `<path>` exists. If not: report error and stop.

Auto-detect type from path (in order):
1. Path contains `.claude/skills/` → `command`
2. Path contains `.claude/agents/` → `agent`
3. Basename is `CLAUDE.md` → `claude-md`

If type still unknown and `--type` was not provided: announce "Cannot auto-detect type for
`<path>` — pass `--type command|agent|claude-md`" and stop.

Announce: "Templatizing `<path>` as type `<type>`"

---

## Step 2: Read file and apply transformation rules

Read the file content. The transformation rules are defined in `~/.claude/skills/bundle/SKILL.md`.
Apply the matching rules via LLM (same process as `/bundle --scope project`):

### For type `command`

Apply the **Command Transformation Rules** from the bundle skill:
- **STRIP**: if the command queries project-specific services, wraps project-unique tooling
  (e.g. `env-update-v2`, service scaffolding), or hard-codes project-specific paths/names →
  announce "This command is too project-specific to templatize — it should be STRIPPED in a
  bundle. Templatized output not useful; aborting." and stop.
- **GENERALIZE**: if the command has a reusable purpose but project-specific content →
  keep purpose and structure, replace specifics with ADAPT markers.
- **EXCLUDE (global-resource)**: if the command manages `~/.claude/` state (memory toggles,
  session lifecycle) → announce "This is a global-resource command — already in the global
  bundle, does not need templatizing." and stop.

### For type `agent`

Apply the **Agent Transformation Rules** from the bundle skill:
Replace the entire content with the generic agent skeleton, preserving the agent's core
purpose in the ADAPT placeholders. Include the agent's name in the heading if it can be
extracted generically.

### For type `claude-md`

Apply the full **CLAUDE.md Transformation Rules** from the bundle skill:
- PREPEND the skeleton banner
- KEEP universal sections verbatim
- TRANSFORM project-description sections to ADAPT markers
- GENERALIZE tooling sections
- STRIP architecture tables, env annotation docs, key scripts with flag references,
  Makefile patterns, container/service-specific guides

Always apply PII scrubbing (names, email addresses, machine-specific paths) as defined in
`_CE_SCRUB_PATTERNS` in `~/.claude/bin/lib/claude-export/config/defaults.sh`.

---

## Step 3: Count ADAPT markers

After generating the output: count ADAPT markers:
```bash
echo "$OUTPUT_CONTENT" | grep -c 'ADAPT:' || echo 0
```

Report: "`<N>` ADAPT marker(s) will need filling."

---

## Step 4: Write or print

**`--dry-run`**: print the templatized content in a markdown code block. Report marker
count. Stop — do not write any file.

**Otherwise**:

1. Determine output path:
   - If `--output <path>`: use that path
   - Otherwise: `<same-dir-as-input>/<basename-without-ext>.template.md`
     (e.g. `inspect.md` → `inspect.template.md` in the same directory)

2. If the output file already exists: invoke the `ask-human` skill: question 'Output file `<output-path>` already exists. Overwrite it?', options: 'Yes, overwrite (Recommended)' / 'No, abort'. Wait for confirmation before writing.

3. Write the templatized content.

4. Announce: "Saved → `<output-path>` (`<N>` ADAPT markers to fill)"

---

## Notes

- Templatization is LLM-applied — review the output before using it as a template
- For a full project bundle (all commands + CLAUDE.md + agents): use `/bundle --scope project`
- `/templatize` + `/adapt-project` is the lightweight per-file workflow for iterative porting
