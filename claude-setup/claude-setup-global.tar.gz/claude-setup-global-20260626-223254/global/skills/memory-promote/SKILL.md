---
name: memory-promote
spotlight: true
description: Use when identifying memory entries (across ALL projects by default) that have graduated from session facts to standing rules and should be promoted to CLAUDE.md or an agent definition; groups similar patterns across projects with provenance and conflict detection.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /memory-promote — identify memory entries that have graduated to standing rules and promote them to CLAUDE.md or agent definitions
> ```
>
> Then output the complete flag table from the **"Flags"** list in the preamble below. Then STOP.

---

# /memory-promote

Analyzes all project memory files and identifies discoveries that have graduated from "session fact" to "standing rule." Proposes additions to ~/.claude/CLAUDE.md (global) or the project agent definition. Never auto-applies.

Flags:
- `--source=project|all` (default: `all`) — `all` scans ALL project memory directories (`~/.claude/projects/*/memory/`); `project` reads only current project (old behavior)
- `--scope=global|project|all` (default: `all`) — **destination**: `global` promotes to `~/.claude/CLAUDE.md` only; `project` promotes to project agent def only; `all` promotes to either based on entry type
- `--type=feedback|project|all` (default: `all`) — filter by memory entry type
- `--dry-run` — show proposals without writing anything

## Step 0: Setup

Parse flags from `$ARGUMENTS`:
- `--source=<value>` → `SOURCE` (default: `all`)
- `--scope=<value>` → `SCOPE` (default: `all`)
- `--type=<value>` → `TYPE_FILTER` (default: `all`)
- `--dry-run` → `DRY_RUN=1`

```bash
CURRENT_SLUG=$(echo "${CLAUDE_PROJECT_DIR:-$PWD}" | sed 's|^/|-|; s|/|-|g')
CURRENT_MEMORY_DIR="$HOME/.claude/projects/$CURRENT_SLUG/memory"
SOURCE="${SOURCE:-all}"

# Build scan target list based on --source
if [[ "$SOURCE" == "all" ]]; then
  SCAN_DIRS=(~/.claude/projects/*/memory/)  # all projects
else
  SCAN_DIRS=("$CURRENT_MEMORY_DIR")          # current project only
fi
```

Also read: `~/.claude/CLAUDE.md`, current project `CLAUDE.md`, `.claude/agents/*.md` (for dedup checking).

## Step 1: Multi-project memory scan (index-first)

**Phase 1a — Index scan (cheap)**: For each dir in `$SCAN_DIRS`, read its `MEMORY.md` index file. Record each entry line + its source project slug. Do NOT yet read individual memory files.

**Phase 1b — Drill-in (targeted)**: For each project, read the individual memory files listed in its MEMORY.md that match `--type` filter. Skip `user` and `reference` type entries (never promoted).

**Output**: a flat list of all memory entries across all projects, each annotated with:
- source slug (e.g. `stack`, `prsnl-pdf`, `home-dev`)
- type (`feedback`, `project`)
- name, description, body

## Step 2: Group, classify, and detect conflicts

**Grouping**: Identify entries across different projects that describe the same pattern (same rule, same behavior, same constraint). Group them — even if worded differently.

For each group:
- **Provenance**: list all source project slugs (`[3 projects: stack, pdf, home-dev]`)
- **Classification**:
  - `feedback` type + universal applicability → PROMOTE to `~/.claude/CLAUDE.md`
  - `feedback` type + project-specific → PROMOTE to project agent def
  - `project` type + clearly universal → PROMOTE; otherwise KEEP
  - `user`/`reference` → KEEP, never promote
  - Already expressed in destination file → ALREADY-COVERED
- **Conflict detection**: If the same pattern appears in ≥2 projects with contradictory wording (e.g. "always use X" vs. "use X except in Y context") → mark as CONFLICT; do NOT propose a merge; surface all variants.

LLM judgment guides PROMOTE vs. KEEP — frequency (provenance count) is a visible signal in the judgment, not a mechanical gate.

## Step 3: Build proposals table

```
| # | Entry | Provenance | Decision | Destination | Rationale |
|---|-------|-----------|----------|-------------|-----------|
| 1 | <name> | [3 projects: stack, pdf, home-dev] | PROMOTE | ~/.claude/CLAUDE.md | Universal feedback, confirmed across 3 projects |
| 2 | <name> | [1 project: stack] | KEEP | stack memory | Stack-specific; not universal |
| 3 | <name> | [2 projects: stack, home-dev] | CONFLICT | — | Contradictory wording — variants shown below |
| 4 | <name> | [2 projects: pdf, home-dev] | ALREADY-COVERED | — | Rule already in CLAUDE.md §X |
```

For each PROMOTE entry: draft the exact proposed text to insert, including provenance comment:
```
<!-- promoted from: stack, pdf, home-dev | 2026-06-06 -->
```

For each CONFLICT entry: show all variants side-by-side so the user can write a unified rule.

## Step 3b: Save report to disk (before presenting to user)

```bash
PROJECT_SLUG=$(echo "${CLAUDE_PROJECT_DIR:-$HOME}" | sed 's|^/|-|; s|/|-|g')
PROMOTE_DIR="$HOME/.claude/projects/$PROJECT_SLUG/promotions"
mkdir -p "$PROMOTE_DIR"
# Run-versioning (matches /audit, /repair): a 2nd same-day run never overwrites the first.
TODAY=$(date +%Y-%m-%d)
RUN=1; REPORT_PATH="$PROMOTE_DIR/$TODAY.md"
while [[ -f "$REPORT_PATH" ]]; do RUN=$((RUN+1)); REPORT_PATH="$PROMOTE_DIR/$TODAY-run${RUN}.md"; done
```

Write the full proposals table (from Step 3) to `$REPORT_PATH`. This ensures the analysis survives context compaction. Announce the saved path.

## Step 4: Hard stop — present and wait
Show proposals table and exact proposed additions. Invoke the `ask-human` skill: question 'Which promotions should be applied?', options: 'Apply all promotions (Recommended)' / 'Apply specific entries — list numbers in notes (e.g. 1, 3)' / 'Skip — apply nothing'.
Do NOT write any promotions to CLAUDE.md or agent definition files until user responds — only the Step 3b report file is pre-approved. CLAUDE.md and agent definition writes are gated on the user's answer here.

## Step 5: Apply confirmed promotions
For each confirmed entry: read destination file, make minimal surgical insertion, verify no CLAUDE.md duplication.

## Step 6: Report
Memories analyzed / Promoted / Already covered / Kept in memory — counts and file list.
