---
name: command-audit
description: RETIRED — all commands migrated to skills. Use /skill-audit instead.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then STOP — do not execute any other steps.
>
> ```
> /command-audit — RETIRED. All commands migrated to skills. Use /skill-audit instead.
>
> No flags — invoked without arguments.
> ```

---

# /command-audit — RETIRED

All slash commands were migrated to `~/.claude/skills/*/SKILL.md` on 2026-05-26. This skill scanned `~/.claude/commands/` which is now empty.

**Use `/skill-audit` instead** — it performs the same 15-dimension quality audit across all skill files (global and project scopes).

```
/skill-audit                    # full audit, all scopes
/skill-audit --scope=global     # global skills only
/skill-audit --scope=project    # project skills only
/skill-audit --skill=<name>     # single skill deep-dive
/skill-audit --quick            # batches A+B only, skip deep-dives
```
