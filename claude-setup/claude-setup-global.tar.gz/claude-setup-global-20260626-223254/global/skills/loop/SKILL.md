---
name: loop
spotlight: true
description: Use when executing a repeating task at a self-chosen pace using ScheduleWakeup between iterations, or running a scheduled pipeline maintenance loop.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /loop — Execute a repeating task at a self-chosen pace using ScheduleWakeup between iterations, or run a scheduled pipeline maintenance loop.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /loop — Autonomous Self-Paced Task Loop

Execute a repeating task at a self-chosen pace using `ScheduleWakeup` between iterations.
Invoke with a task description: `/loop check docker build status` or `/loop --pipeline` for sprint maintenance.

Parse `$ARGUMENTS` for: task description, optional `--iterations <N>` limit, optional `--interval <seconds>` to override self-pacing, optional `--pipeline` to run repair→audit cycle each iteration.

---

## Flags

| Flag | Behavior |
|------|----------|
| `--iterations <N>` | Limit the loop to N iterations total, then stop. |
| `--interval <seconds>` | Override self-pacing: use a fixed delay of this many seconds between iterations instead of the dynamic delay-picking rules. |
| `--pipeline` | Each iteration runs the repair→audit cycle: `/repair --check → /audit --quick → /handoff`. Recommended interval: ≥1800s. |

---

## Step 0: On first invocation

0. **ScheduleWakeup availability check** — ScheduleWakeup is a deferred tool that may not be loaded:
   - Run `ToolSearch({query: "select:ScheduleWakeup", max_results: 1})` to load its schema.
   - If ToolSearch returns the schema: proceed normally with ScheduleWakeup.
   - If ToolSearch fails or returns empty: **CronCreate fallback** — use `CronCreate` (load via ToolSearch similarly) to schedule a one-shot cron at the desired interval. Inform the user that loop state will be carried in the cron message string, and note that `/compact` may truncate the prompt if the session grows long. Advise them to `/handoff` before any expected compaction.
   - If neither ScheduleWakeup nor CronCreate is available: **stop and tell the user** — the loop skill requires at least one scheduling primitive. They can re-invoke manually or in a new session.

1. State what task will loop and at what estimated interval.
2. Check session-remember state:
   - If `~/.claude/hooks/session-remember/DISABLED` exists → note "session-remember off; handoff skips will be silent"
   - If `~/.claude/hooks/session-remember/READONLY` exists → note "READONLY: handoff will run but heavy analysis skipped"
3. Initialize iteration counter (track in the prompt passed to `ScheduleWakeup`).
4. Execute iteration 1 immediately (do not sleep first).
5. Apply handoff + scheduling rules below, then call `ScheduleWakeup`.

---

## Step 1: Each iteration

1. **State check** — what changed since last iteration? Is the task still relevant?
2. **Execute** — perform the work for this iteration.
3. **Assess** — did the task complete? Should the loop continue or stop?
4. **Handoff check** — if this is iteration N×5 (5, 10, 15…) or the last iteration: run `/handoff`. Long loops run overnight; state must be persisted before session-remember buffer fills.
5. **Schedule or stop** — see delay rules below.

---

## Delay Picking Rules

**Think about what you are actually waiting for — not how many minutes sound reasonable.**

| Scenario | Range | Rule |
|----------|-------|------|
| Active: checking a build, polling state about to change, watching a just-started process | 60–270s | Cache stays warm (< 5 min TTL). Repeat checks are cheap. |
| Waiting on something that genuinely takes minutes to change | 600–3600s | Pay the cache miss; amortize it with a longer wait. |
| Idle tick — no specific signal, just scheduled recurrence | 1200–1800s | 20–30 min default. User can interrupt any time. |

**Never pick 300s.** It is the worst of both worlds: you pay the full cache miss cost without getting a meaningful wait in return. Either stay warm (≤270s) or commit to a longer interval (≥600s).

**Never sleep in round-number minutes** — think in cache windows:
- ≤270s → stay warm
- 271–599s → avoid (unnecessary cache miss for a short wait)  
- 600–1199s → acceptable cache-miss range
- 1200–1800s → idle default, one cache miss per 20-30 min

---

## Scheduling

Pass the same `/loop` prompt back via `prompt` so the next wake re-enters this command:

```
ScheduleWakeup(
  delaySeconds: <chosen delay>,
  prompt: "<original /loop invocation with updated iteration count>",
  reason: "<what you're waiting for and why this delay>"
)
```

For autonomous loops with no user prompt, pass the sentinel `<<autonomous-loop-dynamic>>` as `prompt`.

To **end the loop**: omit the `ScheduleWakeup` call entirely. State clearly that the loop has ended and why.

---

## Pipeline Loop (--pipeline flag)

Each iteration runs:
```
/repair --check → /audit --quick → /handoff
```

Recommended interval: ≥1800s (30 min). Never run the full pipeline at <600s — `/audit --quick` spawns 3 agents (A, C, D); the cost does not amortize at short intervals.

The pipeline loop is designed for:
- Scheduled drift detection (daily or per-sprint)
- Post-deploy verification windows
- Background quality monitoring during long work sessions

---

## Session-Remember Awareness

| State | Behavior |
|-------|----------|
| Normal | Run `/handoff` every 5 iterations |
| DISABLED | Skip handoff silently; loop continues |
| READONLY | Run `/handoff` (read-only is fine); skip analysis-heavy steps |
| On failure | Always run `/handoff` before surfacing the error — never lose loop state |

---

## Examples

```bash
# Watch a docker build until healthy — cache-warm polling
/loop "check docker compose ps for 03node24; stop when healthy"

# Daily maintenance sweep
/loop --pipeline --interval 86400

# Self-paced autonomous background task
/loop <<autonomous-loop-dynamic>>

# Limited iterations
/loop --iterations 10 "run env-update-v2 --check and report new versions"
```
