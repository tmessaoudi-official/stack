# Session-Remember Pipeline — Tunable Knobs Reference

Env vars set before launching Claude Code. All defined in `~/.claude/hooks/session-remember/common.sh`.

| Variable | Default | Purpose |
|----------|---------|---------|
| `SR_SAVE_COOLDOWN` | `120` | Seconds between saves — lower for faster captures, higher to reduce LLM cost |
| `SR_NDC_COOLDOWN` | `3600` | Seconds between NDC (non-dialog compression) passes |
| `SR_MIN_HUMAN` | `3` | Minimum human turns in a session before first save fires |
| `SR_DELTA_THRESHOLD` | `50` | JSONL line delta required to trigger a save — reduces saves on low-activity turns |
| `SR_HISTORY_MAX_ENTRIES` | `10` | Maximum entries kept in the rolling `history.md` log |
| `SR_MODEL` | `claude-haiku-4-5` | Model used for all session-remember LLM calls — set `SR_MODEL=<model-id>` to override |
| `SR_TZ` | *(system TZ)* | Timezone for consolidation timestamps — set to `{{TZ}}` or `UTC` to override; defaults to `$TZ` env var |

**Kill switches** (file-presence toggles):

| File | Effect |
|------|--------|
| `~/.claude/hooks/session-remember/DISABLED` | Full silence — no context loaded, no capture |
| `~/.claude/hooks/session-remember/READONLY` | Load prior context but skip new capture |

**Precedence**: DISABLED > READONLY > per-project `blacklist` > normal operation.
