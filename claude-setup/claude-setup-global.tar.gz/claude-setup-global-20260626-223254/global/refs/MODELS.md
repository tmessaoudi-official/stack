# Claude Models Reference
# Update this file when Anthropic releases new models.
# /model-audit --currency reads from here — keep it current.
# Format: | Model ID | Family | Version | Status | Supersedes |
# Status values: CURRENT | DEPRECATED | PREVIEW

## Current Canonical IDs

| Model ID | Family | Version | Status | Supersedes |
|----------|--------|---------|--------|------------|
| claude-fable-5 | fable | 5 | CURRENT | — |
| claude-opus-4-8 | opus | 4.8 | CURRENT | claude-opus-4-7 |
| claude-sonnet-4-6 | sonnet | 4.6 | CURRENT | claude-sonnet-4-5 |
| claude-haiku-4-5 | haiku | 4.5 | CURRENT | claude-haiku-3-5 |

## Deprecated (keep for reference — these may still appear in older configs)

| Model ID | Family | Superseded by |
|----------|--------|---------------|
| claude-opus-4-7 | opus | claude-opus-4-8 |
| claude-sonnet-4-5 | sonnet | claude-sonnet-4-6 |
| claude-haiku-3-5 | haiku | claude-haiku-4-5 |

## Notes on date-suffixed variants

Some model IDs appear with a date suffix (e.g., `claude-haiku-4-5-20251001`).
These are NOT separate models — they are pinned snapshots of the same model.
The canonical form without the suffix is always preferred (forward-compatible, automatically
gets minor improvements). Use `/model-audit` to normalize date-suffixed IDs.

The session-remember pipeline uses `claude-haiku-4-5` (no suffix) by default via `SR_MODEL`.

## /model CLI shortcuts

Used with the `/model` slash command inside Claude Code sessions.

| Shortcut | Resolves to | Notes |
|----------|-------------|-------|
| `fable` | claude-fable-5 | Latest model |
| `opus` | claude-opus-4-8 | Most capable 4.x |
| `sonnet` | claude-sonnet-4-6 | Balanced |
| `haiku` | claude-haiku-4-5 | Fastest / cheapest |
| `opusplan` | Opus 4.8 (plan) + Sonnet (exec) | Plan-mode hybrid — confirmed working |
| `fableplan` | — | **Does not exist** in current build |

`/effort auto` sets extended thinking budget automatically.
