# Prerequisites — Machine Setup Reference

Tools required on this machine. Minimum versions reflect features actively used by hooks, scripts, and commands.

| Tool | Min version | Purpose |
|------|------------|---------|
| `jq` | 1.6 | JSON state tracking in session-remember pipeline (`common.sh`) |
| `git` | 2.25 | All version-control operations; `git restore` syntax |
| `shellcheck` | 0.8.0 | Hook linting on `.sh` writes; `/lint` command |
| `hadolint` | 2.8.0 | Dockerfile linting on write; `/lint` command |
| `make` | 4.0 | Stack automation (`eval`/`call` macros, double-colon targets) |
| `rtk` | 0.37.0 | Token-optimized CLI proxy (hook-rewritten commands) |
| `docker` | 24.0 | Compose v2 native, BuildX bake (`COMPOSE_BAKE=true`) |

Verify: `jq --version; git --version; shellcheck --version; hadolint --version; make --version; rtk --version; docker --version`
