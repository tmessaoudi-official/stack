#!/bin/bash
# Re-install Claude Code plugins from origin machine.
# Usage: bash ~/.claude/plugins-reinstall.sh [--reconcile]
#   default    : install all bundle plugins (idempotent)
#   --reconcile: also uninstall any plugins present locally but absent from this bundle

BUNDLE_PLUGINS=(
  "chrome-devtools-mcp@claude-plugins-official"
  "claude-md-management@claude-plugins-official"
  "code-review@claude-plugins-official"
  "code-simplifier@claude-plugins-official"
  "explanatory-output-style@claude-plugins-official"
  "feature-dev@claude-plugins-official"
  "learning-output-style@claude-plugins-official"
  "mcp-server-dev@claude-plugins-official"
  "playwright@claude-plugins-official"
  "plugin-dev@claude-plugins-official"
  "pr-review-toolkit@claude-plugins-official"
  "ralph-loop@claude-plugins-official"
  "security-guidance@claude-plugins-official"
  "session-report@claude-plugins-official"
  "skill-creator@claude-plugins-official"
  "superpowers@claude-plugins-official"
)

if [[ "${1:-}" == "--reconcile" ]]; then
  echo "Reconciling plugins: removing local plugins not in this bundle..."
  _installed_json="${HOME}/.claude/plugins/installed_plugins.json"
  if [[ -f "$_installed_json" ]]; then
    while IFS= read -r _installed_key; do
      _in_bundle=0
      for _bundle_key in "${BUNDLE_PLUGINS[@]}"; do
        [[ "$_installed_key" == "$_bundle_key" ]] && { _in_bundle=1; break; }
      done
      if [[ "$_in_bundle" -eq 0 ]]; then
        echo "  Removing: $_installed_key"
        claude plugin uninstall "$_installed_key" || true
      fi
    done < <(jq -r '.plugins | keys[]' "$_installed_json" 2>/dev/null)
  fi
  echo "Reconcile done."
  echo ""
fi

# Phase 1: register marketplaces
claude plugin marketplace add anthropics/claude-plugins-official || true

# Phase 2: install bundle plugins
for _plugin_key in "${BUNDLE_PLUGINS[@]}"; do
  claude plugin install "$_plugin_key"
done
