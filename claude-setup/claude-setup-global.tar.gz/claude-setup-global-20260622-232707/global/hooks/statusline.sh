#!/usr/bin/env bash
# statusLine hook: prints the status line below each assistant turn.
# Input: JSON payload on stdin (full schema in templates/tips/statusline.md).
# Output: one or two lines to stdout (Claude Code renders each as a separate status row).
# Line 1: model/context/cost/git/etc. Line 2 (self-hiding): mechanism/control state —
# gate bypasses, memory mode, plan-location, active plan file, autonomous-3C.
set -euo pipefail
source "${BASH_SOURCE[0]%/*}/log-helpers.sh" 2>/dev/null || log_obs() { :; }
trap 'log_obs ERROR statusline.sh "Unexpected error at line $LINENO" 2>/dev/null || true' ERR

payload=$(cat)

# Set STATUSLINE_PROBE=1 to dump payload: env STATUSLINE_PROBE=1 claude ...
[[ "${STATUSLINE_PROBE:-}" == "1" ]] && echo "$payload" > /tmp/statusline-probe.json

# --- Payload fields — single jq fork for all 17 fields ---
# cache_read_input_tokens is nested inside current_usage (null before first API call)
# rate_limits.{five_hour,seven_day}.used_percentage drive the session/weekly usage segments
# (same data /usage shows). Present only for Pro/Max auth, and only after the first API
# response — null/absent otherwise, so the segments self-hide.
model="unknown" thinking="false" effort_level="" cost_usd="0"
lines_added="0" lines_removed="0" cwd="" agent=""
cache_reads="0" total_ctx_tokens="0" ctx_pct="0" is_estimate="true" _ctx_window_size="200000"
_sess_id="" _transcript=""
sess_usage_pct="" week_usage_pct=""
if _jq_out=$(jq -r '
  .model.id // "unknown",
  (.thinking.enabled // false | tostring),
  (.effort.level // ""),
  (.cost.total_cost_usd // 0 | tostring),
  (.cost.total_lines_added // 0 | tostring),
  (.cost.total_lines_removed // 0 | tostring),
  (.workspace.current_dir // .cwd // ""),
  (.agent.name // ""),
  (.context_window.current_usage.cache_read_input_tokens // 0 | tostring),
  (.context_window.total_input_tokens // 0 | tostring),
  (if .context_window.used_percentage != null then .context_window.used_percentage
   elif (.context_window.total_input_tokens // 0) > 0 then
     (.context_window.total_input_tokens / .context_window.context_window_size * 100)
   else 0
   end | tostring),
  (if .context_window.used_percentage != null then "false" else "true" end),
  (.context_window.context_window_size // 200000 | tostring),
  (.session_id // ""),
  (.transcript_path // ""),
  (.rate_limits.five_hour.used_percentage // "" | tostring),
  (.rate_limits.seven_day.used_percentage // "" | tostring)
' <<< "$payload" 2>/dev/null); then
  mapfile -t _jq_fields <<< "$_jq_out"
  model="${_jq_fields[0]:-unknown}"
  thinking="${_jq_fields[1]:-false}"
  effort_level="${_jq_fields[2]:-}"
  cost_usd="${_jq_fields[3]:-0}"
  lines_added="${_jq_fields[4]:-0}"
  lines_removed="${_jq_fields[5]:-0}"
  cwd="${_jq_fields[6]:-}"
  agent="${_jq_fields[7]:-}"
  cache_reads="${_jq_fields[8]:-0}"
  total_ctx_tokens="${_jq_fields[9]:-0}"
  ctx_pct="${_jq_fields[10]:-0}"
  is_estimate="${_jq_fields[11]:-true}"
  _ctx_window_size="${_jq_fields[12]:-200000}"
  _sess_id="${_jq_fields[13]:-}"
  _transcript="${_jq_fields[14]:-}"
  sess_usage_pct="${_jq_fields[15]:-}"
  week_usage_pct="${_jq_fields[16]:-}"
fi

# --- Model short name ---
case "$model" in
  *opus*)   model_short="opus"   ;;
  *sonnet*) model_short="sonnet" ;;
  *haiku*)  model_short="haiku"  ;;
  *)        model_short="${model%%@*}" ;;
esac

# Mode prefix: 💭 think + optional effort suffix
mode_prefix=""
effort_suffix=""
if [[ "$thinking" == "true" ]]; then
  mode_prefix="💭 "
  case "$effort_level" in
    high)  effort_suffix=" [high]"  ;;
    max)   effort_suffix=" [max]"   ;;
    xhigh) effort_suffix=" [xhigh]" ;;
  esac
fi

# --- Status files written by SessionStart + Stop hooks ---
ctx_dir="$HOME/.claude/run"

kv() { grep -m1 "^${1}:" "${2}" 2>/dev/null | cut -d: -f2- | sed 's/^[[:space:]]*//' || echo ""; }

# P0-1: persist the authoritative context window size from the payload. The Stop and
# SessionStart hooks have no window field in their stdin (only session_id/transcript/cwd),
# so they otherwise guess it from the model string via ss_window_for_model() — which cannot
# tell a 1M window from 200K. Statusline is the only hook that receives context_window_size,
# so it writes it here for the others to read. (|| true: status-file IO is non-fatal by the
# same convention as every other state write — a full disk must never break the session.)
if [[ "${_ctx_window_size:-0}" =~ ^[0-9]+$ && "${_ctx_window_size:-0}" -gt 0 ]]; then
  mkdir -p "$ctx_dir" 2>/dev/null || true
  _win_tmp=$(mktemp "${ctx_dir}/.actual-window.XXXXXX" 2>/dev/null || mktemp)
  printf '%s\n' "${_ctx_window_size}" > "$_win_tmp" 2>/dev/null \
    && mv -f "$_win_tmp" "${ctx_dir}/actual-window.txt" 2>/dev/null || true
fi

# P0-2: per-session state files. statusline reads its OWN session's context/banner files
# so concurrent or stale sessions never show each other's data. Key by session_id; fall
# back to the transcript filename (named <session_id>.jsonl) when the payload omits it —
# the Stop/SessionStart hooks key by the same id. The global fixed-name files remain as a
# fallback for the first turn (before any per-session write) and for external readers.
_sess_key="$_sess_id"
[[ -z "$_sess_key" && -n "$_transcript" ]] && _sess_key=$(basename "$_transcript" .jsonl 2>/dev/null || true)
ctx_file="${ctx_dir}/status-context.txt"
banner_file="${ctx_dir}/status-banner.txt"
if [[ -n "$_sess_key" ]]; then
  [[ -f "${ctx_dir}/status-context-${_sess_key}.txt" ]] && ctx_file="${ctx_dir}/status-context-${_sess_key}.txt"
  [[ -f "${ctx_dir}/status-banner-${_sess_key}.txt" ]]  && banner_file="${ctx_dir}/status-banner-${_sess_key}.txt"
fi

# Context priority:
#   1. file IS_ESTIMATE:false  → transcript-confirmed real data, always wins
#   2. payload is_estimate=false (used_percentage present) → real API data beats stale file estimate
#   3. file IS_ESTIMATE:true + payload also estimate → file startup estimate (has size-aware baseline)
input_k="" urgency=""
if [[ -f "$ctx_file" ]]; then
  file_pct=$(kv PCT "$ctx_file")
  file_est=$(kv IS_ESTIMATE "$ctx_file")
  input_k=$(kv INPUT_K "$ctx_file")
  urgency=$(kv URGENCY "$ctx_file")
  if [[ -n "$file_pct" ]]; then
    if [[ "$is_estimate" == "false" ]]; then
      # Payload has real data (used_percentage present) — always authoritative.
      # Never override with file: file is shared across concurrent sessions.
      : # ctx_pct and is_estimate stay as-is from payload
    elif [[ "${file_est:-true}" == "false" ]]; then
      # Payload is an estimate; file has real data from a previous/stopped session.
      # Use it as a startup baseline — overridden by payload after first API turn.
      ctx_pct="$file_pct"; is_estimate="false"
    elif [[ "$is_estimate" == "true" && "${total_ctx_tokens:-0}" -eq 0 ]]; then
      # Both are startup estimates AND the payload has no token data yet (pre-first-API turn):
      # the file's size-aware startup baseline is the best we have, so prefer it.
      # P0-1: once the payload carries real tokens (total_ctx_tokens > 0), its percentage is
      # computed against the true context_window_size — do NOT override it with the file
      # estimate, which may have been written against the wrong (200K) window by a Stop hook.
      ctx_pct="$file_pct"
    fi
  fi
fi

# F5: Claude Code transcripts omit cache_read_input_tokens, so ss_parse_transcript gives only
# new non-cached tokens (~19K), not the full context (~131K). The payload's total_input_tokens
# field includes all categories. Override file's INPUT_K when payload has a larger value.
if [[ "${total_ctx_tokens:-0}" -gt 0 ]] 2>/dev/null; then
  _payload_k=$(( total_ctx_tokens / 1000 ))
  if [[ "$is_estimate" == "false" ]]; then
    input_k="$_payload_k"   # real payload data — always authoritative (multi-session safe)
  else
    _file_k="${input_k//[^0-9]/}"; _file_k="${_file_k:-0}"
    [[ "$_payload_k" -gt "$_file_k" ]] && input_k="$_payload_k"
  fi
fi

# F6: stop hook urgency is set from wrong token count (transcript omits cache reads →
# computed free ≈ 148K → no urgency). Recompute from real effective free space.
if [[ "$is_estimate" == "false" && -n "$input_k" ]] 2>/dev/null; then
  _eff_k_for_urg=$(kv EFF_K "$ctx_file")
  _eff_k_for_urg="${_eff_k_for_urg//[^0-9]/}"; _eff_k_for_urg="${_eff_k_for_urg:-167}"
  _input_k_num="${input_k//[^0-9]/}"; _input_k_num="${_input_k_num:-0}"
  _free_k_real=$(( _eff_k_for_urg - _input_k_num ))
  [[ $_free_k_real -lt 0 ]] && _free_k_real=0
  if   (( _free_k_real >= 30 && _free_k_real < 60 )); then urgency="🟡"
  elif (( _free_k_real <  30 && _free_k_real >= 10 )); then urgency="⚠"
  elif (( _free_k_real <  10 ));                        then urgency="🔴"
  else urgency=""
  fi
fi

ctx_int=$(LC_NUMERIC=C awk "BEGIN{printf \"%d\", ${ctx_pct}+0.5}" 2>/dev/null || echo "${ctx_pct%.*}")
ctx_tilde=""; [[ "$is_estimate" == "true" ]] && ctx_tilde="~"

# IMP-1: inline progress bar [████████░▒] — 9 content chars + 1 buffer char
_bar_width=9
_bar_used=$(( ctx_int * _bar_width / 100 ))
[[ $_bar_used -gt $_bar_width ]] && _bar_used=$_bar_width
_bar_free=$(( _bar_width - _bar_used ))
_used_str=""; _free_str=""
for (( _bi=0; _bi<_bar_used; _bi++ )); do _used_str+="█"; done
for (( _bi=0; _bi<_bar_free; _bi++ )); do _free_str+="░"; done
ctx_bar="[${_used_str}${_free_str}▒]"
ctx_str="${ctx_bar} ${ctx_tilde}${ctx_int}%"
[[ -n "$input_k" && "$input_k" != "0" ]] && ctx_str="${ctx_str} ${input_k}K"

# Urgency prefix (prepended to model name for maximum visibility)
# BUG-7: added 🟡 third level (30-60K free)
urgency_prefix=""
case "${urgency:-}" in
  *🔴*) urgency_prefix="🔴 " ;;
  *⚠*)  urgency_prefix="⚠ "  ;;
  *🟡*) urgency_prefix="🟡 " ;;
esac

# Window size tag — from batched jq parse above
win_tag=""
[[ "${_ctx_window_size:-200000}" -ge 900000 ]] 2>/dev/null && win_tag=" 1M"

# --- Git from stop-context-bar.sh / stop-git-status.sh status-banner.txt ---
branch="" git_dirty="" git_unpushed="" git_stash="" git_last=""
if [[ -f "$banner_file" ]]; then
  branch=$(kv GIT_BRANCH "$banner_file")
  dirty_val=$(kv GIT_DIRTY "$banner_file")
  unpushed_val=$(kv GIT_UNPUSHED "$banner_file")
  stash_val=$(kv GIT_STASHES "$banner_file")
  git_last=$(kv GIT_LAST "$banner_file")
  [[ "${dirty_val:-0}" -gt 0 ]]    2>/dev/null && git_dirty="✎ ${dirty_val}"
  [[ "${unpushed_val:-0}" -gt 0 ]] 2>/dev/null && git_unpushed="↑ ${unpushed_val}"
  [[ "${stash_val:-0}" -gt 0 ]]    2>/dev/null && git_stash="⚑ ${stash_val}"
fi
# Fallback: read branch directly from git when claux files absent
[[ -z "$branch" && -n "$cwd" ]] && branch=$(git -C "$cwd" rev-parse --abbrev-ref HEAD 2>/dev/null || echo "")

# Build git segment (space-separated tokens within the segment)
git_parts=()
[[ -n "$branch" ]]       && git_parts+=("$branch")
[[ -n "$git_dirty" ]]    && git_parts+=("$git_dirty")
[[ -n "$git_unpushed" ]] && git_parts+=("$git_unpushed")
[[ -n "$git_stash" ]]    && git_parts+=("$git_stash")
[[ -n "$git_last" ]]     && git_parts+=("$git_last")
git_seg="${git_parts[*]}"

# --- Session cost ---
cost_str="\$$(LC_NUMERIC=C awk "BEGIN{printf \"%.2f\", ${cost_usd}+0}" 2>/dev/null || echo "0.00")"

# --- Plan usage: session (5h block) + weekly (7d window) from rate_limits ---
# Same figures /usage shows. used_percentage may be a float (e.g. 23.5) → round via awk
# before any integer compare (bare $(( )) would crash on a float under set -e). Empty
# input → empty segment (self-hides), matching every other optional segment.
fmt_usage() {  # $1=label  $2=raw_percentage  → prints "<label> NN%" (⚠-prefixed if ≥80%) or nothing
  local label="$1" raw="$2" pct warn=""
  [[ -z "$raw" ]] && return 0
  pct=$(LC_NUMERIC=C awk "BEGIN{printf \"%d\", ${raw}+0.5}" 2>/dev/null || echo "")
  [[ -z "$pct" ]] && return 0
  [[ "$pct" -ge 80 ]] 2>/dev/null && warn="⚠"
  printf '%s%s %s%%' "$warn" "$label" "$pct"
}
sess_usage_str=$(fmt_usage "5h" "$sess_usage_pct")
week_usage_str=$(fmt_usage "wk" "$week_usage_pct")
# Group both into one "plan 5h NN%/wk NN%" segment placed beside context usage. Each window
# self-hides if its value is absent; the whole group self-hides if neither is present.
plan_usage_str=""
if [[ -n "$sess_usage_str" || -n "$week_usage_str" ]]; then
  plan_usage_str="plan ${sess_usage_str}"
  [[ -n "$sess_usage_str" && -n "$week_usage_str" ]] && plan_usage_str+="/"
  [[ -z "$sess_usage_str" ]] && plan_usage_str="plan "
  plan_usage_str+="${week_usage_str}"
fi

# --- Lines changed (only shown when nonzero) ---
lines_str=""
if [[ "${lines_added:-0}" -gt 0 || "${lines_removed:-0}" -gt 0 ]] 2>/dev/null; then
  [[ "${lines_added:-0}" -gt 0 ]] && lines_str="+${lines_added}"
  [[ "${lines_removed:-0}" -gt 0 ]] && lines_str="${lines_str:+${lines_str}/}-${lines_removed}"
fi

# --- Handoff age (from claux banner, falls back to direct file) ---
handoff_age=""
if [[ -f "$banner_file" ]]; then
  handoff_val=$(kv HANDOFF "$banner_file")
  [[ -n "$handoff_val" && "$handoff_val" != "none" ]] && handoff_age="⟳ ${handoff_val}"
fi
if [[ -z "$handoff_age" && -n "${CLAUDE_PROJECT_DIR:-}" ]]; then
  _proj="$CLAUDE_PROJECT_DIR"
  _slug=$(echo "$_proj" | sed 's|^/|-|; s|/|-|g')
  handoff_path="$HOME/.claude/projects/${_slug}/memory/sessions/handoff.md"
  if [[ -f "$handoff_path" && -s "$handoff_path" ]]; then
    now=$(date +%s)
    mtime=$(stat -c '%Y' "$handoff_path" 2>/dev/null || echo "$now")
    age_s=$(( now - mtime ))
    if   (( age_s < 3600   )); then handoff_age="⟳ $((age_s/60))m"
    elif (( age_s < 86400  )); then handoff_age="⟳ $((age_s/3600))h"
    else                            handoff_age="⟳ $((age_s/86400))d"
    fi
    # IMP-9: distinguish auto (precompact) vs manual (/handoff) — tag written by precompact-handoff.sh
    if [[ -n "$handoff_age" ]]; then
      grep -q "auto-generated by precompact" "$handoff_path" 2>/dev/null && handoff_age="${handoff_age/⟳/⟳ auto}"
    fi
  fi
fi

# --- Mega-analysis staleness (⚠ only when flagged stale by claux hooks) ---
ana_flag=""
if [[ -f "$banner_file" ]]; then
  analysis_val=$(kv ANALYSIS "$banner_file")
  [[ "$analysis_val" == *"⚠"* ]] && ana_flag="ana⚠"
fi

# --- CLAUDEMD staleness ---
md_flag=""
if [[ -f "$banner_file" ]]; then
  claudemd_val=$(kv CLAUDEMD "$banner_file")
  [[ "$claudemd_val" == *"⚠"* ]] && md_flag="md⚠"
fi

# --- Session uptime (from STARTED_AT in status-banner.txt) ---
uptime_str=""
if [[ -f "$banner_file" ]]; then
  started_at=$(kv STARTED_AT "$banner_file")
  if [[ -n "$started_at" && "$started_at" =~ ^[0-9]+$ ]]; then
    _now=$(date +%s)
    _elapsed=$(( _now - started_at ))
    if (( _elapsed > 60 )); then
      if (( _elapsed >= 3600 )); then
        _upt_h=$(( _elapsed / 3600 ))
        _upt_m=$(( (_elapsed % 3600) / 60 ))
        (( _upt_m > 0 )) && uptime_str="⏱ ${_upt_h}h${_upt_m}m" || uptime_str="⏱ ${_upt_h}h"
      else
        uptime_str="⏱ $(( _elapsed / 60 ))m"
      fi
    fi
  fi
fi

# --- IMP-2: Lifetime Σ accumulator (grows indefinitely; delete file to reset) ---
lifetime_str=""
_lt_raw=$(head -1 "${ctx_dir}/lifetime-output.txt" 2>/dev/null | tr -d '[:space:]' || true)
_lt_raw="${_lt_raw//[^0-9]/}"
[[ -n "$_lt_raw" && "$_lt_raw" -gt 0 ]] 2>/dev/null && lifetime_str="Σ ${_lt_raw}K"

# --- IMP-3: Cache hit rate ---
cache_pct_str=""
if [[ "${total_ctx_tokens:-0}" -gt 0 ]] 2>/dev/null; then
  _cpct=$(( cache_reads * 100 / total_ctx_tokens ))
  [[ "${_cpct:-0}" -gt 0 ]] 2>/dev/null && cache_pct_str="💾 ${_cpct}%"
fi

# --- IMP-4/5/10: turn counter, last turn duration, /clear indicator from status-context.txt ---
turns_str="" turn_dur_str="" clear_str=""
if [[ -f "$ctx_file" ]]; then
  _turns=$(kv TURNS    "$ctx_file")
  _tdur=$( kv TURN_DUR "$ctx_file")
  _clear_ctr=$(kv CLEAR_CTR "$ctx_file")
  _turns_total=0
  _tt_raw=$(head -1 "${ctx_dir}/turns-total.txt" 2>/dev/null | tr -d '[:space:]' || true)
  _tt_raw="${_tt_raw//[^0-9]/}"
  [[ -n "$_tt_raw" && "$_tt_raw" -gt 0 ]] 2>/dev/null && _turns_total="$_tt_raw"
  _turns_display=$(( ${_turns:-0} + ${_turns_total:-0} ))
  [[ "${_turns_display:-0}" -gt 0 ]] 2>/dev/null && turns_str="T:${_turns_display}"
  if [[ "${_tdur:-0}" -gt 3 ]]  2>/dev/null; then
    if (( _tdur >= 3600 )); then
      _tdur_h=$(( _tdur / 3600 ))
      _tdur_m=$(( (_tdur % 3600) / 60 ))
      (( _tdur_m > 0 )) && turn_dur_str="~${_tdur_h}h${_tdur_m}m" || turn_dur_str="~${_tdur_h}h"
    elif (( _tdur >= 60 )); then
      _tdur_s=$(( _tdur % 60 ))
      (( _tdur_s > 0 )) && turn_dur_str="~$(( _tdur / 60 ))m${_tdur_s}s" || turn_dur_str="~$(( _tdur / 60 ))m"
    else
      turn_dur_str="~${_tdur}s"
    fi
  fi
  [[ "${_clear_ctr:-0}" -gt 0 ]] 2>/dev/null && clear_str="↩"
fi

# --- IMP-6/7: token velocity and cost rate (after 10min uptime) ---
velocity_str="" cost_rate_str=""
if [[ -f "$banner_file" ]]; then
  _metric_started=$(kv STARTED_AT "$banner_file")
  if [[ -n "$_metric_started" && "$_metric_started" =~ ^[0-9]+$ ]]; then
    _metric_elapsed=$(( $(date +%s) - _metric_started ))
    if (( _metric_elapsed > 600 )); then
      if [[ -n "$input_k" && "${input_k:-0}" -gt 0 ]] 2>/dev/null; then
        _vh=$(LC_NUMERIC=C awk "BEGIN{printf \"%d\", ${input_k} * 3600 / ${_metric_elapsed}}" 2>/dev/null || echo 0)
        [[ "${_vh:-0}" -gt 0 ]] 2>/dev/null && velocity_str="↑${_vh}K/h"
      fi
      _rate=$(LC_NUMERIC=C awk "BEGIN{printf \"%.2f\", ${cost_usd} * 3600 / ${_metric_elapsed}}" 2>/dev/null || true)
      [[ -n "$_rate" && "$_rate" != "0.00" ]] && cost_rate_str="\$${_rate}/h"
    fi
  fi
fi

# --- CWD segment: tilde-collapsed, last 2 components for deep paths ---
cwd_str=""
if [[ -n "$cwd" ]]; then
  _d="${cwd/#$HOME/\~}"; _d="${_d%/}"
  _depth=$(awk -F'/' '{print NF-1}' <<< "$_d" 2>/dev/null || echo 0)
  if [[ "${_depth:-0}" -gt 2 ]] 2>/dev/null; then
    _b="${_d##*/}"; _p="${_d%/*}"; _p="${_p##*/}"
    cwd_str="…/${_p}/${_b}"
  else
    cwd_str="$_d"
  fi
fi

# --- Assemble ---
model_label="${urgency_prefix}${mode_prefix}${model_short}${win_tag}${effort_suffix}"
[[ -n "$cost_rate_str" ]] && cost_str="${cost_str} ${cost_rate_str}"
parts=("${model_label}" "${ctx_str}")
[[ -n "$plan_usage_str" ]]  && parts+=("${plan_usage_str}")
[[ -n "$clear_str" ]]       && parts+=("${clear_str}")
[[ -n "$cache_pct_str" ]]   && parts+=("${cache_pct_str}")
[[ -n "$cwd_str" ]]         && parts+=("${cwd_str}")
[[ -n "$git_seg" ]]         && parts+=("${git_seg}")
[[ -n "$agent" ]]           && parts+=("[${agent}]")
parts+=("${cost_str}")
[[ -n "$velocity_str" ]]    && parts+=("${velocity_str}")
[[ -n "$lifetime_str" ]]    && parts+=("${lifetime_str}")
[[ -n "$lines_str" ]]       && parts+=("${lines_str}")
[[ -n "$turn_dur_str" ]]    && parts+=("${turn_dur_str}")
[[ -n "$turns_str" ]]       && parts+=("${turns_str}")
[[ -n "$handoff_age" ]]     && parts+=("${handoff_age}")
[[ -n "$uptime_str" ]]      && parts+=("${uptime_str}")
[[ -n "$md_flag" ]]         && parts+=("${md_flag}")
[[ -n "$ana_flag" ]]        && parts+=("${ana_flag}")

printf '%s' "${parts[0]}"
for p in "${parts[@]:1}"; do printf '  ·  %s' "$p"; done
printf '\n'

# ── Line 2: mechanism / control state (self-hides when everything is default) ──
# Surfaces which safety guards are bypassed this session and other control state,
# so a relaxed gate is never invisible. Each segment self-hides when inactive.
line2_parts=()
_slug2=""
[[ -n "$cwd" ]] && _slug2=$(printf '%s' "$cwd" | tr '/' '-')
PB="$HOME/.claude/projects/${_slug2}"

# Gate bypasses — show only when bypassed, annotated by HOW (env var / global / per-project).
_gate_bypass() {  # $1=label $2=envval $3=globalfile $4=projfile → "label(how)" or nothing
  local label="$1" envv="$2" gfile="$3" pfile="$4" how=""
  if   [[ -n "$envv" ]];               then how="env"
  elif [[ -f "$gfile" ]];              then how="g"
  elif [[ -n "$pfile" && -f "$pfile" ]]; then how="proj"
  fi
  [[ -n "$how" ]] && printf '%s(%s)' "$label" "$how"
  return 0
}
_ahb=$(_gate_bypass "AH" "" "$HOME/.claude/state/ask-human-gate-bypass" "${_slug2:+$PB/state/ask-human-gate-bypass}")
_fwb=$(_gate_bypass "FW" "${CLAUDE_BASH_FIREWALL_OFF:-}" "$HOME/.claude/state/ask-bash-firewall-bypass" "${_slug2:+$PB/state/ask-bash-firewall-bypass}")
_qgb=$(_gate_bypass "QG" "${QGUARD_OFF:-}" "$HOME/.claude/state/ask-human-question-guard-bypass" "${_slug2:+$PB/state/ask-human-question-guard-bypass}")
_byp=()
[[ -n "$_ahb" ]] && _byp+=("$_ahb")
[[ -n "$_fwb" ]] && _byp+=("$_fwb")
[[ -n "$_qgb" ]] && _byp+=("$_qgb")
[[ ${#_byp[@]} -gt 0 ]] && line2_parts+=("⚠ bypass: ${_byp[*]}")

# Memory mode (session-remember). Mirrors common.sh precedence AND scope so a relaxed
# memory mode is never invisible — including the per-project lists, which were the gap:
#   OFF ← global DISABLED file        OR  this project in blacklist
#   RO  ← global READONLY file        OR  this project in readonly-list  OR  SR_READONLY=1 env
#   lean appended when DISABLED.lean exists.
# Annotated by HOW (g=global file · proj=per-project list · env=env var) for parity with the
# gate-bypass row above. The per-project lists key on CLAUDE_PROJECT_DIR — the SAME slug
# session-remember uses (common.sh:58) — which may differ from cwd; match it exactly, and only
# when CLAUDE_PROJECT_DIR is set (session-remember disables itself entirely when it is not).
_SR="$HOME/.claude/hooks/session-remember"
_sr_slug=""
[[ -n "${CLAUDE_PROJECT_DIR:-}" ]] && _sr_slug=$(printf '%s' "$CLAUDE_PROJECT_DIR" | tr '/' '-')
_sr_in_list() {  # $1=listfile → 0 if _sr_slug is a non-comment exact line (same parse as common.sh)
  local f="$1"
  [[ -n "$_sr_slug" && -f "$f" ]] || return 1
  # `--` terminates options: slugs start with '-' (path → tr '/' '-') and would otherwise
  # be parsed as grep flags.
  grep -vE '^[[:space:]]*(#|$)' "$f" 2>/dev/null | grep -qxF -- "$_sr_slug"
}
_mem=""
if   [[ -f "$_SR/DISABLED" ]];          then _mem="mem:OFF(g)"
elif _sr_in_list "$_SR/blacklist";       then _mem="mem:OFF(proj)"
elif [[ -f "$_SR/READONLY" ]];          then _mem="mem:RO(g)"
elif _sr_in_list "$_SR/readonly-list";   then _mem="mem:RO(proj)"
elif [[ "${SR_READONLY:-}" == "1" ]];   then _mem="mem:RO(env)"
fi
[[ -f "$_SR/DISABLED.lean" ]] && _mem="${_mem:+$_mem }lean"
[[ -n "$_mem" ]] && line2_parts+=("$_mem")

# Plan-location sentinel (repo|global) for this project.
if [[ -n "$_slug2" && -f "$PB/plan-location" ]]; then
  _ploc=$(head -1 "$PB/plan-location" 2>/dev/null | tr -d '[:space:]' || true)
  [[ -n "$_ploc" ]] && line2_parts+=("plan-loc:${_ploc}")
fi

# Active plan (Rule 17): per-session pointer at run/active-plan-<session>, holding the
# absolute path of the plan THIS session adopted (written at Phase 4, cleared at Phase 8,
# re-written on Phase 0 restore). "Current plan" is session state, NOT a globbable location:
# plan files live under many project slugs (and a session may switch cwd), and concurrent
# sessions each have their own active plan — so keying on the payload session_id (the same
# contract autonomous-3c relies on, below) is the only correct signal. No glob fallback; the
# target must still exist, which self-heals a stale pointer left by a deleted plan file.
_planf=""
if [[ -n "$_sess_key" && -f "${ctx_dir}/active-plan-${_sess_key}" ]]; then
  _pp=$(head -1 "${ctx_dir}/active-plan-${_sess_key}" 2>/dev/null || true)
  [[ -n "$_pp" && -f "$_pp" ]] && _planf=$(basename "$_pp" .plan.md)
fi
[[ -n "$_planf" ]] && line2_parts+=("▸plan:${_planf}")

# Autonomous-3C: safety gates suppressed. Persistent sentinels (state/, manual-removal,
# no expiry) outrank the per-session marker (run/, auto-cleared at Phase 8). Precedence
# g > proj > session — show the broadest active scope, double-warn for the sticky ones.
if   [[ -f "$HOME/.claude/state/autonomous-3c-bypass" ]];          then line2_parts+=("⚠⚠ AUTO-3C(g)")
elif [[ -n "$_slug2" && -f "$PB/state/autonomous-3c-bypass" ]];     then line2_parts+=("⚠⚠ AUTO-3C(proj)")
elif [[ -n "$_sess_key" && -f "${ctx_dir}/autonomous-3c-${_sess_key}" ]]; then line2_parts+=("⚠ AUTO-3C")
fi

if [[ ${#line2_parts[@]} -gt 0 ]]; then
  printf '%s' "${line2_parts[0]}"
  for p in "${line2_parts[@]:1}"; do printf '  ·  %s' "$p"; done
  printf '\n'
fi
