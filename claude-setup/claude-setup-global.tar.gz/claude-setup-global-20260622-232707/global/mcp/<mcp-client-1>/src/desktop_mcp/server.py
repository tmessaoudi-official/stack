"""desktop-mcp server — FastMCP stdio, 11 computer-use tools."""
from mcp.server.fastmcp import FastMCP, Image

mcp = FastMCP("desktop")

_driver = None


def get_driver():
    global _driver
    if _driver is None:
        from .factory import make_driver

        _driver = make_driver()
    return _driver


def set_driver(d) -> None:
    """Test seam — inject a driver, bypassing factory/display."""
    global _driver
    _driver = d


@mcp.tool(description="Capture the virtual screen. Returns a PNG image.")
def screenshot() -> Image:
    return Image(data=get_driver().screenshot(), format="png")


@mcp.tool(description="Return the virtual screen size in pixels.")
def screen_size() -> dict:
    w, h = get_driver().screen_size()
    return {"width": w, "height": h}


@mcp.tool(description="Return the current cursor position.")
def cursor_position() -> dict:
    x, y = get_driver().cursor_position()
    return {"x": x, "y": y}


@mcp.tool(description="Move the cursor to absolute (x, y).")
def move(x: int, y: int) -> str:
    get_driver().move(x, y)
    return "ok"


@mcp.tool(description="Click at (x, y). button = left | middle | right.")
def click(x: int, y: int, button: str = "left") -> str:
    get_driver().click(x, y, button)
    return "ok"


@mcp.tool(description="Double-click at (x, y).")
def double_click(x: int, y: int) -> str:
    get_driver().double_click(x, y)
    return "ok"


@mcp.tool(description="Right-click at (x, y).")
def right_click(x: int, y: int) -> str:
    get_driver().right_click(x, y)
    return "ok"


@mcp.tool(description="Press-drag from current position to (x, y).")
def drag(x: int, y: int, button: str = "left") -> str:
    get_driver().drag(x, y, button)
    return "ok"


@mcp.tool(description="Scroll by (dx, dy) clicks. Positive dy scrolls up.")
def scroll(dx: int, dy: int) -> str:
    get_driver().scroll(dx, dy)
    return "ok"


@mcp.tool(description="Type literal text at the current focus.")
def type(text: str) -> str:
    get_driver().type(text)
    return "ok"


@mcp.tool(description="Press a key combo, e.g. 'ctrl+c', 'alt+Tab', 'Return'.")
def key(combo: str) -> str:
    get_driver().key(combo)
    return "ok"
