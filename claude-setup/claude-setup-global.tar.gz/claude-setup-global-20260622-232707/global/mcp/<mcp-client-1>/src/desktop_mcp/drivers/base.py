"""Driver ABC — backend-agnostic desktop control contract."""
from abc import ABC, abstractmethod


class Driver(ABC):
    @abstractmethod
    def screenshot(self) -> bytes:
        """Return the virtual screen as PNG bytes."""

    @abstractmethod
    def screen_size(self) -> tuple[int, int]:
        """Return (width, height) in pixels."""

    @abstractmethod
    def cursor_position(self) -> tuple[int, int]:
        """Return current (x, y)."""

    @abstractmethod
    def move(self, x: int, y: int) -> None: ...

    @abstractmethod
    def click(self, x: int | None, y: int | None, button: str = "left") -> None: ...

    @abstractmethod
    def double_click(self, x: int | None, y: int | None) -> None: ...

    @abstractmethod
    def right_click(self, x: int | None, y: int | None) -> None: ...

    @abstractmethod
    def drag(self, x: int, y: int, button: str = "left") -> None: ...

    @abstractmethod
    def scroll(self, dx: int, dy: int) -> None: ...

    @abstractmethod
    def type(self, text: str) -> None: ...

    @abstractmethod
    def key(self, combo: str) -> None: ...
