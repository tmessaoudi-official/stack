"""Windows driver — designed-for, NOT implemented in v1.

Design: pyautogui (cross-platform) reusing the X11Driver code path;
only capture/permission specifics differ. No sandbox — would drive the
real desktop, so it needs its own safety gate before shipping.
"""
from .base import Driver

_MSG = (
    "Windows driver is not implemented in v1. "
    "Designed: pyautogui reusing the X11 code path. "
    "Use the X11 container driver instead."
)


class WindowsDriver(Driver):
    def __init__(self) -> None:
        raise NotImplementedError(_MSG)

    def screenshot(self) -> bytes:
        raise NotImplementedError(_MSG)

    def screen_size(self) -> tuple[int, int]:
        raise NotImplementedError(_MSG)

    def cursor_position(self) -> tuple[int, int]:
        raise NotImplementedError(_MSG)

    def move(self, x, y):
        raise NotImplementedError(_MSG)

    def click(self, x, y, button="left"):
        raise NotImplementedError(_MSG)

    def double_click(self, x, y):
        raise NotImplementedError(_MSG)

    def right_click(self, x, y):
        raise NotImplementedError(_MSG)

    def drag(self, x, y, button="left"):
        raise NotImplementedError(_MSG)

    def scroll(self, dx, dy):
        raise NotImplementedError(_MSG)

    def type(self, text):
        raise NotImplementedError(_MSG)

    def key(self, combo):
        raise NotImplementedError(_MSG)
