from mcp.server.fastmcp import Image

from desktop_mcp import server


class FakeDriver:
    def __init__(self):
        self.calls = []

    def screenshot(self):
        self.calls.append(("screenshot",))
        return b"\x89PNG\r\n\x1a\nFAKE"

    def screen_size(self):
        self.calls.append(("screen_size",))
        return (1280, 800)

    def cursor_position(self):
        self.calls.append(("cursor_position",))
        return (5, 6)

    def move(self, x, y):
        self.calls.append(("move", x, y))

    def click(self, x, y, button="left"):
        self.calls.append(("click", x, y, button))

    def double_click(self, x, y):
        self.calls.append(("double_click", x, y))

    def right_click(self, x, y):
        self.calls.append(("right_click", x, y))

    def drag(self, x, y, button="left"):
        self.calls.append(("drag", x, y, button))

    def scroll(self, dx, dy):
        self.calls.append(("scroll", dx, dy))

    def type(self, text):
        self.calls.append(("type", text))

    def key(self, combo):
        self.calls.append(("key", combo))


def setup_function(_):
    server.set_driver(FakeDriver())


def test_screenshot_returns_image_from_driver_bytes():
    img = server.screenshot()
    assert isinstance(img, Image)
    assert server.get_driver().calls == [("screenshot",)]


def test_screen_size_maps():
    assert server.screen_size() == {"width": 1280, "height": 800}


def test_cursor_position_maps():
    assert server.cursor_position() == {"x": 5, "y": 6}


def test_move_maps():
    server.move(10, 20)
    assert server.get_driver().calls == [("move", 10, 20)]


def test_click_default_button():
    server.click(30, 40)
    assert server.get_driver().calls == [("click", 30, 40, "left")]


def test_click_explicit_button():
    server.click(1, 2, "middle")
    assert server.get_driver().calls == [("click", 1, 2, "middle")]


def test_double_and_right_click():
    server.double_click(7, 8)
    server.right_click(9, 10)
    assert server.get_driver().calls == [("double_click", 7, 8), ("right_click", 9, 10)]


def test_drag_default_button():
    server.drag(50, 60)
    assert server.get_driver().calls == [("drag", 50, 60, "left")]


def test_scroll_maps():
    server.scroll(0, -3)
    assert server.get_driver().calls == [("scroll", 0, -3)]


def test_type_maps():
    server.type("hello")
    assert server.get_driver().calls == [("type", "hello")]


def test_key_maps():
    server.key("ctrl+c")
    assert server.get_driver().calls == [("key", "ctrl+c")]
