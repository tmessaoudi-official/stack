import pytest

from desktop_mcp.drivers.base import Driver
from desktop_mcp.drivers.wayland import WaylandDriver
from desktop_mcp.drivers.windows import WindowsDriver
from desktop_mcp.factory import make_driver, select_driver_name


def test_driver_is_abstract():
    with pytest.raises(TypeError):
        Driver()  # cannot instantiate an ABC with unimplemented abstractmethods


def test_wayland_driver_constructs():
    # WaylandDriver is now a real driver (GNOME D-Bus capture + ydotool input);
    # construction is cheap and must not raise. Methods fail loudly if tooling
    # is absent (covered in test_wayland_driver.py).
    assert isinstance(WaylandDriver(), Driver)


def test_windows_stub_raises():
    with pytest.raises(NotImplementedError, match="Windows"):
        WindowsDriver()


def test_select_override_wins():
    assert select_driver_name("wayland", "linux", "x11") == "wayland"


def test_select_windows_by_platform():
    assert select_driver_name(None, "win32", "") == "windows"


def test_select_wayland_by_session():
    assert select_driver_name(None, "linux", "wayland") == "wayland"


def test_select_defaults_to_x11():
    assert select_driver_name(None, "linux", "x11") == "x11"


def test_make_driver_unknown_raises():
    with pytest.raises(ValueError, match="Unknown driver"):
        make_driver("bogus")


def test_make_driver_wayland_returns_driver():
    from desktop_mcp.drivers.wayland import WaylandDriver as _W
    assert isinstance(make_driver("wayland"), _W)
