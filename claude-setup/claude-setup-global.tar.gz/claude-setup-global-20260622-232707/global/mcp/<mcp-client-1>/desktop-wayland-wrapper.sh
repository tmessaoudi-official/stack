#!/usr/bin/env bash
# Host stdio entrypoint for the REAL Wayland desktop — NOT sandboxed.
# Capture: org.gnome.Shell.Screenshot D-Bus (works out of the box on GNOME).
# Input:   ydotool -> ydotoold -> /dev/uinput (REQUIRES setup, see
#          docs/wayland-setup.md). Input goes to the focused window.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DESKTOP_MCP_DRIVER=wayland

# ydotoold listening socket (input path). Capture uses the session D-Bus,
# inherited from the environment — no socket needed for screenshots.
export YDOTOOL_SOCKET="${YDOTOOL_SOCKET:-${XDG_RUNTIME_DIR:-/run/user/$(id -u)}/.ydotool_socket}"

# stdout/stdin are the MCP JSON-RPC channel — write nothing to stdout above.
exec "$DIR/.venv/bin/python" -m desktop_mcp
