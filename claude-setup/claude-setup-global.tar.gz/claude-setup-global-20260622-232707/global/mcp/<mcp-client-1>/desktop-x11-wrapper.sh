#!/usr/bin/env bash
# Host stdio entrypoint for the REAL X11 display (DISPLAY=:0) — NOT sandboxed.
# Input goes to the focused window; capture grabs the X root.
#
# This mode is for a GENUINE X11 login session, where it works fully.
# On a GNOME/Wayland session :0 is XWayland: this wrapper still connects
# (see the cookie-normalization below), but capture is BLACK and input cannot
# reach native Wayland windows — use desktop-wayland-wrapper.sh instead.
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DESKTOP_MCP_DRIVER=x11
export DISPLAY="${DISPLAY:-:0}"

if [ -z "${XAUTHORITY:-}" ]; then
  if [ -f "$HOME/.Xauthority" ]; then
    export XAUTHORITY="$HOME/.Xauthority"          # real X11 session
  else
    # XWayland-under-Wayland: mutter writes its cookie with an EMPTY display
    # number (host/unix:), which C-Xlib accepts but python-xlib rejects.
    # Re-emit it as an explicit host/unix:<N> entry python-xlib can match.
    for c in "${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"/.mutter-Xwaylandauth.*; do
      [ -e "$c" ] || continue
      hex="$(xauth -f "$c" list 2>/dev/null | awk '/MIT-MAGIC-COOKIE/{print $3; exit}')"
      [ -n "$hex" ] || continue
      norm="${XDG_RUNTIME_DIR:-/tmp}/dmcp-x11-xauth"
      rm -f "$norm"
      xauth -f "$norm" add "$(hostname)/unix:${DISPLAY#:}" \
        MIT-MAGIC-COOKIE-1 "$hex" >/dev/null 2>&1 || true
      export XAUTHORITY="$norm"
      break
    done
  fi
fi

# stdout/stdin are the MCP JSON-RPC channel — write nothing to stdout above.
exec "$DIR/.venv/bin/python" -m desktop_mcp
