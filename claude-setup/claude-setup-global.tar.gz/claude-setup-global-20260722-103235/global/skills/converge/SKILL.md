---
name: converge
spotlight: true
description: Run a deep, explicit-user-control convergence sweep for exhaustive audits and migrations — configurable cycles/threshold, self-graded by default or advisor()-certified with --certify=advisor. Distinct from CLAUDE.md's automatic Phase 3C/6C gates (which run a lighter, non-configurable advisor()-certified check on every task) — reach for /converge when you deliberately want a deeper, tunable sweep (large audits, mega-analysis, custom scope checks). Always asks for explicit approval before starting and reports progress every cycle. Supports --auto for fully autonomous operation with a hard safety cap.
user-invocable: true
args: "[--cycles=N] [--converge=K] [--scope=3C|6C|custom] [--angles='angle1;angle2;angle3'] [--certify=self|advisor] [--auto] [--auto-cap=N]"
side-effects: None — read-only analysis loop; findings incorporated into conversation context only.
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /converge — Run a deep, explicit-user-control convergence sweep for exhaustive audits and migrations — configurable cycles/threshold, self-graded by default or advisor()-certified with --certify=advisor. Distinct from CLAUDE.md's automatic Phase 3C/6C gates (lighter, non-configurable, run on every task) — use this when you deliberately want a deeper, tunable sweep. Always asks for explicit approval before starting and reports progress every cycle. Supports --auto for fully autonomous operation with a hard safety cap.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /converge — Convergence Loop

Runs a structured multi-angle convergence loop with explicit user approval of parameters before any cycle executes. Reports progress after every cycle. In autonomous mode, runs silently to convergence or cap — inline output is always shown, only `ask-human` pauses are suppressed.

**Not the same thing as CLAUDE.md's Phase 3C/6C.** CLAUDE.md's automatic gates (every task, non-configurable, capped at 5 rounds, always advisor()-certified) exist to catch ordinary gaps on ordinary work. `/converge` is the tool to reach for when you explicitly want more than that — a deliberately deep, tunable sweep (a large audit, a migration, an exhaustive custom-scope check) — not something that runs by default.

## Flags

- `--cycles=N` — maximum total cycles before escalating (default: **30**, or **5** when `--certify=advisor`)
- `--converge=K` — consecutive fully-clean cycles required to declare convergence (default: **8**; ignored when `--certify=advisor` — one independent confirmation is sufficient, see `--certify` below)
- `--scope=3C|6C|custom` — which angle set to use (default: `3C`). Naming kept for continuity with the angle *content* (expanding-context / adversarial / blast-radius) — this does not invoke CLAUDE.md's Phase 3C/6C mechanism, which is a separate, non-configurable implementation.
  - `3C`: pre-implementation-style angles (expanding-context, adversarial, blast-radius)
  - `6C`: pre-completion-style angles (expanding-context on result, failure modes, callers/docs)
  - `custom`: angles provided via `--angles`
- `--angles='A;B;C'` — semicolon-separated angle descriptions when `--scope=custom`; for custom scope, at least one angle **must** be prefixed with `enumerate:` (e.g. `enumerate:list all image dirs`). See Angle Requirements below.
- `--certify=self|advisor` — how a cycle's findings get judged (default: `self`)
  - `self`: the original self-graded evaluation below (CLEAN/RESET/STUCK compared against the previous cycle), requiring `--converge=K` consecutive clean cycles. Self-certification has a known blind spot — the same model grading its own findings can't reliably audit itself — but remains available for cases where an external `advisor()` call isn't wanted or isn't available (e.g. a restricted subagent context).
  - `advisor`: after running the angles for a cycle, call `advisor()` with the findings instead of self-comparing. A clean verdict converges immediately — no K-in-a-row requirement, since an independent judge doesn't need repeated confirmation the way self-grading does. A finding from `advisor()` is treated as a RESET (see Step 3).
- `--auto` — start in autonomous mode immediately after Step 0 approval; no mid-loop ask-human calls
- `--auto-cap=N` — hard safety ceiling for autonomous mode (default: **30**, max: **30**); overrides `--cycles` when autonomous and N > auto-cap; prevents runaway token burn

---

## Angle Requirements

These rules apply to every angle in every cycle, regardless of scope.

### Evidence gate (all scopes)

Every angle result **must** include at least one of:
- A command and its actual output (grep, find, ls, read, wc — something that ran and produced text)
- An explicit enumerated list of items checked with a total count
- A file path + line number citation pointing to the specific location of the finding

**Pure prose reasoning fails the evidence gate.** "I believe X is covered" or "X looks correct" without a supporting command or citation is not a valid angle result. If an angle produces only prose, it must be re-run with concrete evidence before the cycle result is recorded.

### Enumeration angle (custom scope — mandatory)

When `--scope=custom`, at least one angle must be designated `enumerate:`. This angle:

1. **Runs an explicit enumeration command** (`ls`, `find`, `grep` on an index file, or equivalent) to list every member of the set being audited
2. **States the total count** — "N members found: [list]"
3. **Cross-checks coverage** — after all other angles complete, compares members visited this cycle against the total enumerated. Any member not visited by any angle is a scope gap.
4. **Scope gaps are findings** — an unvisited member triggers a RESET with the finding "scope gap: <member> not covered"

The enumeration angle cannot be satisfied by memory or assumption. It must show the command that produced the member list.

**Example** — for a dead-var audit across all compose files:
```
enumerate: run `ls docker/images/` to get full directory list (N dirs found),
           then cross-check which dirs were grep'd in other angles this cycle
```

---

## Step 0 — Approval gate (MANDATORY — never skip)

Parse flags. Determine defaults for any missing parameters — if `--certify=advisor`, default `--cycles` to 5 (not 30) and treat `--converge`/K as not applicable. If `--auto` was passed, note that autonomous mode will activate after approval. Then invoke `ask-human`:

```
Question: "About to run a convergence loop. Parameters:"
  • Scope:          <3C | 6C | custom angles>
  • Certify:        <self | advisor>
  • Max cycles:     N  (total attempts before escalating)
  • Converge after: K  consecutive fully-clean cycles (n/a if Certify=advisor)
  • Autonomous cap: <auto-cap value> cycles max if autonomous mode is active
  • Angles:
      1. <angle 1 description>
      2. <angle 2 description>
      3. <angle 3 description>

Options:
  1. "Proceed with these parameters (Recommended)"
  2. "Proceed autonomously — run silently to convergence or safety cap; no mid-loop interrupts"
  3. "Change parameters"   → follow up with AskUserQuestion for N, K, and Certify
  4. "Skip — do not run the loop"
```

If user selects "Proceed autonomously" OR `--auto` flag was passed: set `autonomous = true`. Proceed to Step 1.

If user selects "Change parameters": ask two follow-up questions (max cycles, convergence threshold), then re-display the updated config and confirm once more before proceeding.

If user selects "Skip": exit immediately, report "Convergence loop skipped by user."

---

## Step 1 — Initialize state

```
TOTAL_CYCLES  = N                          # from approved config (default 5 if certify=advisor)
CONVERGE_REQ  = K                          # from approved config (ignored if certify=advisor)
CERTIFY       = self | advisor             # from approved config
AUTO_CAP      = min(auto-cap, 30)          # hard safety ceiling for autonomous mode
autonomous    = <true if --auto or chosen> # autonomous mode flag
counter       = 0                          # consecutive clean cycles so far (self mode only)
cycle_num     = 0                          # total cycles run
prev_findings = []                         # findings from the immediately preceding cycle
```

---

## Step 2 — Run one cycle

Increment `cycle_num`.

**Autonomous safety cap check**: If `autonomous == true` AND `cycle_num > AUTO_CAP` → go to Step 5 (autonomous safety cap).

Run all angles against the current context. For each angle:
1. Execute the angle (grep, read, enumerate, or reason with evidence)
2. **Apply evidence gate**: confirm the result includes a command + output, enumerated list, or file citation. If not, re-run the angle with concrete evidence before proceeding.
3. List findings as bullet points. A finding is anything unresolved — a risk, gap, side-effect, inconsistency, or scope gap.

**If `--scope=custom` and an `enumerate:` angle is present:**
After all other angles complete, run the cross-check: compare the enumerated member list against members visited in this cycle. Any unvisited member → add as a scope gap finding before recording the cycle result.

**After running all angles, emit a progress line:**

```
[converge] Cycle cycle_num/TOTAL_CYCLES | counter/CONVERGE_REQ clean | <status>
```

Where `<status>` is one of:

- `CLEAN (counter/CONVERGE_REQ)` — no findings at all this cycle
- `RESET (counter → 0) — new: <one-line finding>` — something appeared that was not in prev_findings
- `STUCK — persistent: <one-line finding>` — findings identical to prev_findings, nothing new

*This progress line is always emitted, even in autonomous mode. Autonomous mode suppresses ask-human pauses, not output.*

---

## Step 3 — Evaluate and act

**If `CERTIFY == advisor`**: skip the self-comparison below. Instead, call `advisor()` stating the findings collected this cycle (or "no findings" if the angles turned up nothing) and ask it to judge them against the same angle set. Map its verdict onto the cases below:
- Advisor confirms nothing further → **Case A (CLEAN)**, but converge immediately: set `counter = CONVERGE_REQ` directly rather than incrementing by 1 — one independent confirmation is sufficient, unlike self-grading which needs K repeats to counteract self-bias.
- Advisor raises something new → **Case B (RESET)**.
- Advisor repeats the same point after a resolution attempt → **Case C (STUCK)**.
There is no self-graded CLEAN/RESET/STUCK comparison in this mode — `advisor()`'s verdict *is* the evaluation. `prev_findings` is still tracked (used to tell advisor what changed since last cycle) but is no longer what decides the case.

**If `CERTIFY == self`** (default): evaluate using the original self-graded comparison:

**Case A — CLEAN:**
- `counter += 1`
- `prev_findings = []`
- If `counter == CONVERGE_REQ` → go to Step 4 (converged)
- Else → go to Step 2 (next cycle)

**Case B — RESET (new finding appeared):**
- `counter = 0`
- `prev_findings = current_findings`
- Incorporate the new finding into context/plan

- **If `autonomous == true`**: emit one line and continue without pausing:
  ```
  [converge] ↺ RESET cycle_num — autonomous: <finding summary>. Incorporating and continuing.
  ```
  Go to Step 2.

- **If `autonomous == false`**: invoke `ask-human`:
  ```
  Question: "New finding detected in cycle cycle_num. Counter reset to 0.
             Finding: <description>
             Continue the loop or escalate now?"
  Options:
    1. "Continue — incorporate and retry (Recommended)"
    2. "Continue autonomously — run rest of loop silently (no more ask-human calls)"
    3. "Escalate — surface to user and stop"
  ```
  - If "Continue": go to Step 2
  - If "Continue autonomously": set `autonomous = true`, go to Step 2
  - If "Escalate": go to Step 5 (cap escalation)

**Case C — STUCK (same findings, nothing new):**
- `counter` unchanged (neither increments nor resets)
- `prev_findings` unchanged
- Attempt deeper resolution of the persistent finding
- Emit: `[converge] STUCK on cycle cycle_num — attempting deeper resolution`
- Go to Step 2
- *(No ask-human call for STUCK — deeper resolution is attempted automatically in both modes)*

**Case D — Cycle cap reached (`cycle_num == TOTAL_CYCLES` and `counter < CONVERGE_REQ`):**
- Go to Step 5 (cap escalation)

---

## Step 4 — Converged

Emit:
```
[converge] ✓ CONVERGED — cycle_num cycles total, counter/CONVERGE_REQ consecutive clean cycles.
```

Report a one-line summary of what was verified across all clean cycles. Exit.

---

## Step 5 — Cap escalation (could not converge)

**Determine cap type:**
- If reached via autonomous safety cap (`cycle_num > AUTO_CAP`): emit `[converge] ✗ AUTONOMOUS SAFETY CAP — {AUTO_CAP} cycles reached.`
- Otherwise: emit `[converge] ✗ CAP REACHED — cycle_num/TOTAL_CYCLES cycles, counter/CONVERGE_REQ clean.`

In both cases:
- List all remaining findings accumulated so far
- Exit autonomous mode: `autonomous = false`

Invoke `ask-human`:
```
Question: "Could not converge in cycle_num cycles (counter/CONVERGE_REQ clean).
           <If autonomous safety cap: 'Autonomous safety cap of AUTO_CAP cycles reached.'>
           Remaining findings:
             • <finding 1>
             • <finding 2>
           How do you want to proceed?"
Options:
  1. "Rerun — N more cycles (Recommended)"          → restart Step 1 with same K, new N
  2. "Rerun autonomously — N more cycles"           → restart Step 1 with autonomous = true
  3. "Decompose — split task and converge each part"
  4. "Escalate manually — I will review and decide"
```

Wait for direction. This is the only guaranteed ask-human call in autonomous mode.
