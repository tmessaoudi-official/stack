---
name: cross-check
spotlight: true
description: Use when you need to validate a spec against Jira tickets or perform standalone deep doc validation. Two modes: (A) /cross-check <spec-file> --jira <version|ticket|JQL> for spec-vs-Jira diff, (B) /cross-check <spec-file> for standalone contradiction/gap analysis. Both run a convergence gate using CLAUDE.md Phase 3C/6C defaults.
user-invocable: true
args: "<spec-file> [--jira <version|ticket|JQL>] [--dry-run]"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /cross-check — Use when you need to validate a spec against Jira tickets or perform standalone deep doc validation. Two modes: (A) /cross-check <spec-file> --jira <version|ticket|JQL> for spec-vs-Jira diff, (B) /cross-check <spec-file> for standalone contradiction/gap analysis. Both run a convergence gate using CLAUDE.md Phase 3C/6C defaults.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /cross-check — Spec Validation and Jira Alignment

Parse `$ARGUMENTS`:

## Flags

| Flag | Behavior |
|------|----------|
| `<spec-file>` | Path to spec/doc to validate (required) |
| `--jira <ref>` | Jira version label, ticket key, or JQL query — activates Mode A (spec vs Jira diff) |
| `--dry-run` | Print findings to conversation only; no output file written |

If `<spec-file>` not provided: report error and stop.

---

## Mode A — Spec vs Jira (`--jira` flag present)

### Step 1 — Exhaustive Jira extraction

Use ALL available Jira MCP tools to pull every data surface:

**Primary ticket data** (`mcp__acme-jira-http__jira_get_issue`):
- Description, summary, status, priority, acceptance criteria, story points

**Comments** (`mcp__acme-jira-http__jira_get_issue` or `jira_search`):
- Every comment thread — no skipping

**Attachments** (`mcp__acme-jira-http__jira_download_attachments`):
- `.docx` / `.xlsx` / `.pdf` → extract text content
- Images → visual inspection for diagrams, mockups, annotations

**Linked issues** (`mcp__acme-jira-http__jira_get_issue` → `issuelinks`):
- Follow all linked issues and sub-tasks recursively (max depth: 3)

**Changelog / history** (`mcp__acme-jira-http__jira_batch_get_changelogs`):
- Detect requirement changes over time — flag revised/reversed requirements

**If `--jira` is a version label or JQL**: use `mcp__acme-jira-http__jira_search` to get the full ticket list first, then repeat the above for each ticket.

### Step 2 — Read spec fully

Read `<spec-file>` completely. Enumerate every claim, requirement, and assumption.

### Step 3 — Independent check

Per **CLAUDE.md Phase 3C/6C** (investigate → `advisor()` loop, capped at 5 rounds, escalate via `ask-human` at the cap — no pre-loop parameter gate anymore): investigate the three angles yourself, then call `advisor()` to certify.

- **Angle 1** (expanding-context): Did any Jira data surface extend, contradict, or clarify the spec in a way not captured yet?
- **Angle 2** (adversarial): What requirement exists in Jira that the spec silently drops or contradicts?
- **Angle 3** (blast-radius): What spec claims have no Jira evidence and therefore risk scope creep?

Call `advisor()` stating the comparison so far; if it flags something new, resolve it and re-call. Repeat until it confirms the comparison is exhaustive.

### Step 4 — Emit diff table

```
| Status | Item | Jira ref | Spec section |
|---|---|---|---|
| MATCH | Feature X described correctly | JIRA-123 comment 3 | §2.1 |
| MISSING-IN-SPEC | Requirement Y from attachment | JIRA-456 doc.docx | — |
| MISSING-IN-JIRA | Spec claim Z with no ticket evidence | — | §3.2 |
| CONTRADICTS | Spec: async / Jira: sync | JIRA-789 | §4.1 |
| UNVERIFIED | Claim A — no Jira evidence found | — | §5.3 |
| CHANGED | Requirement B was revised | JIRA-234 changelog v3→v4 | §1.2 |
```

### Step 5 — Write output

- `--dry-run`: print table to conversation only, stop.
- Otherwise: write to `<spec-file>.cross-check.md`

---

## Mode B — Standalone validation (no `--jira` flag)

Deep doc validation with no external reference.

### Step 1 — Read spec fully

Read `<spec-file>` completely.

### Step 2 — Independent check

Per **CLAUDE.md Phase 3C/6C** (investigate → `advisor()` loop, capped at 5 rounds, escalate via `ask-human` at the cap — no pre-loop parameter gate anymore): investigate the three angles yourself, then call `advisor()` to certify.

- **Angle 1** (expanding-context): Are there implicit requirements not explicitly stated? Assumed context that a reader might not share?
- **Angle 2** (adversarial): What internal contradictions exist? What claim is made in one section that is contradicted in another?
- **Angle 3** (blast-radius): What is missing? What should be specified but isn't? What edge cases are unaddressed?

Call `advisor()` stating the analysis so far; if it flags something new, resolve it and re-call. Repeat until it confirms the analysis is exhaustive.

### Step 3 — Output findings

Findings categorized as:
- **CONTRADICTION** — claim in section A directly contradicts claim in section B
- **UNKNOWN** — term or concept used without definition or reference
- **ASSUMPTION** — implicit prerequisite not stated
- **MISSING** — section that should exist but doesn't (error handling, rollback, security, etc.)
- **AMBIGUOUS** — statement that can be interpreted multiple ways

### Step 4 — Write output

- `--dry-run`: print to conversation only, stop.
- Otherwise: write to `<spec-file>.validation.md`

---

## Jira MCP tools reference

- `mcp__acme-jira-http__jira_get_issue` — full ticket data including comments, links
- `mcp__acme-jira-http__jira_get_issue` with `fields` param — comments, issuelinks, attachment
- `mcp__acme-jira-http__jira_download_attachments` — download and read attachment content
- `mcp__acme-jira-http__jira_search` — JQL search for ticket sets
- `mcp__acme-jira-http__jira_batch_get_changelogs` — full changelog for requirement drift
