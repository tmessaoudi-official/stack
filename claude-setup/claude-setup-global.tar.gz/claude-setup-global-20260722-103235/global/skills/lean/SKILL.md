---
name: lean
description: Use when activating or deactivating lean mode to suspend CLAUDE.md context loading for zero-overhead sessions, or checking lean mode status.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /lean — Activate or deactivate lean mode to suspend CLAUDE.md context loading for zero-overhead sessions, or check lean mode status.
> ```
>
> Then output the complete flag table from the **"Quick reference"** section below. Then STOP.

| Subcommand / Flag | Description |
|-------------------|-------------|
| `on` | Activate lean mode |
| `on --scope=global` | Global CLAUDE.md only (~15k tokens saved) |
| `on --scope=project` | Project CLAUDE.md + agent def (~7.4k tokens saved) |
| `on --private` | Private-browsing: zero footprint on lean-off |
| `on --session=off` | Also disable session-remember pipeline |
| `on --dry-run` | Preview changes without applying them |
| `off` | Restore current project (auto-detect) |
| `off --all` | Restore ALL active lean sessions |
| `off --partial` | Skip missing backups, restore the rest |
| `off --recover` | Recover from a crashed lean-off |
| `off --project=<path>` | Target a specific project |
| `status` | Show all active lean sessions (default when no args) |
| `--help` | Show this help |

---

# /lean [on|off|status|--help] [FLAGS]

Lean mode: suspend context-loading files for zero-overhead sessions.
All file operations run through `~/.claude/bin/lean-swap.sh` (pre-approved).

**What gets suspended** (all backed up and 100% restored on `/lean off`):
- Global `CLAUDE.md` (+ its `@`-includes like `RTK.md`) and project `CLAUDE.md`
- Project `MEMORY.md` (memory index)
- **ALL** `.claude/agents/*.md` agent defs in the project (not just the first)
- **Non-whitelisted global skills** (`scope=all`/`global` only): every dir in
  `~/.claude/skills/` except the keep-whitelist — `lean`, `lean-block`,
  `lean-unblock`, `loop`, and the `memory-*` toggles — is moved aside so you can
  always `/lean off` and manage memory/loop. Skills are owned by the same session
  that owns global `CLAUDE.md` and restored when the last global lean session ends.
  (`scope=project` never touches skills — they are global.)

## Quick reference

```
/lean on                          scope=all, ~22.4k tokens saved
/lean on --scope=global           global CLAUDE.md only, ~15k
/lean on --scope=project          project CLAUDE.md + agent def, ~7.4k
/lean on --private                private-browsing: zero footprint on lean-off
/lean on --session=off            also disable session-remember pipeline
/lean on --dry-run                preview without changes

/lean off                         restore current project (auto-detect)
/lean off --all                   restore ALL active lean sessions
/lean off --partial               skip missing backups, restore the rest
/lean off --recover               recover from a crashed lean-off
/lean off --project=/path         target a specific project

/lean status                      show all active lean sessions (default)
/lean --help                      full flag documentation
```

Takes effect at NEXT session start.

---

## Pre-check: current lean state

Before routing, always show current state so the user knows what is active:

```bash
~/.claude/bin/lean-swap.sh status 2>/dev/null || echo "(lean-swap.sh not found or no active sessions)"
```

If the user is calling `/lean on` and the output shows active LEAN_MODE sessions for the same scope, say:
```
ℹ Lean mode is already active (see status above).
  Running /lean on again will be a no-op for already-active sessions.
  Use /lean off first if you want to change scope or flags.
```

Then continue to routing regardless — lean-swap.sh handles idempotency at the script level.

---

## Routing

- No args, or first arg is `status` → **STATUS**
- First arg is `on` → **ON**
- First arg is `off` → **OFF**
- `--help` anywhere in args → **HELP**
- `--session` without `on`/`off` → **SESSION TOGGLE**

---

## HELP

Run:
```bash
~/.claude/bin/lean-swap.sh help
```

---

## STATUS

Run:
```bash
~/.claude/bin/lean-swap.sh status
```

---

## ON

### Parse flags

Extract from user args:
- `SCOPE`: default `all`; `project` if `--scope=project`; `global` if `--scope=global`
- `SESSION_FLAG`: `--session=off` if user passed `--session off` or `--session=off`; else empty
- `PROJECT_FLAG`: `--project=/path` if user passed `--project /path` or `--project=/path`
- `DRY_RUN_FLAG`: `--dry-run` if user passed it
- `PRIVATE_FLAG`: `--private` if user passed it

### Execute

Run:
```bash
~/.claude/bin/lean-swap.sh on \
  --scope="${SCOPE}" \
  ${SESSION_FLAG:+"$SESSION_FLAG"} \
  ${PROJECT_FLAG:+"$PROJECT_FLAG"} \
  ${DRY_RUN_FLAG:+"$DRY_RUN_FLAG"} \
  ${PRIVATE_FLAG:+"$PRIVATE_FLAG"}
```

Report the output verbatim to the user.

---

## OFF

### Parse flags

Extract from user args:
- `ALL_FLAG`: `--all` if user passed `--all`
- `PARTIAL_FLAG`: `--partial` if user passed `--partial`
- `PROJECT_FLAG`: `--project=/path` if applicable
- `RECOVER_FLAG`: `--recover` or `--recover=/path` if applicable

### Execute

Run:
```bash
~/.claude/bin/lean-swap.sh off \
  ${ALL_FLAG:+"$ALL_FLAG"} \
  ${PARTIAL_FLAG:+"$PARTIAL_FLAG"} \
  ${PROJECT_FLAG:+"$PROJECT_FLAG"} \
  ${RECOVER_FLAG:+"$RECOVER_FLAG"}
```

Report the output verbatim to the user.

---

## SESSION TOGGLE (mid-lean, no on/off subcommand)

When user passes `--session off` or `--session on` without `on`/`off` subcommand
(i.e., toggling session pipeline while lean is already active):

Run:
```bash
LEAN_DISABLED="$HOME/.claude/hooks/session-remember/DISABLED.lean"

# Find the active sentinel (auto-detect from CWD or single active)
SENTINEL=""
for s in "$HOME/.claude"/LEAN_MODE.*; do
  [[ -f "$s" ]] && SENTINEL="$s" && break
done

if [[ -z "$SENTINEL" ]]; then
  echo "⛔ Lean mode is not active. Use '/lean on --session=off' to activate with session disabled."
else
  SESSION_DISABLED=$(jq -r '.session_disabled_by_lean' "$SENTINEL")
  TMP=$(mktemp)
  trap 'rm -f "$TMP"' EXIT

  if [[ "$ARGS" == *"--session off"* || "$ARGS" == *"--session=off"* ]]; then
    if [[ "$SESSION_DISABLED" == "true" ]]; then
      echo "Session pipeline is already disabled."
    else
      touch "$LEAN_DISABLED"
      jq '.session_mode = "off" | .session_disabled_by_lean = true' "$SENTINEL" > "$TMP" \
        && mv "$TMP" "$SENTINEL"
      echo "✓ Session pipeline disabled. Takes effect next session."
    fi
  else
    if [[ "$SESSION_DISABLED" == "false" ]]; then
      echo "Session pipeline is already active."
    else
      rm -f "$LEAN_DISABLED"
      jq '.session_mode = "on" | .session_disabled_by_lean = false' "$SENTINEL" > "$TMP" \
        && mv "$TMP" "$SENTINEL"
      echo "✓ Session pipeline re-enabled. Takes effect next session."
    fi
  fi
fi
```
