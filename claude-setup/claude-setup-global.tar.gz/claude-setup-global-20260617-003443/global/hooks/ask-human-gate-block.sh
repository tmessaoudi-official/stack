#!/usr/bin/env bash
# PreToolUse: Bash|Read|Edit|Write|Agent|Glob|Grep — hard-block if ask-human gate not cleared.
# Gate is enforced ONCE PER USER TURN (not once per session).
# Turn token written by ask-human-gate-arm.sh (UserPromptSubmit hook).
# Sentinel written by ask-human-gate-track.sh (PostToolUse: AskUserQuestion).
# Subagents have no UserPromptSubmit → no turn token → allowed through automatically.
# Emergency bypass: touch ~/.claude/tmp/ask-human-gate-bypass to disable globally.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

[[ -f "$HOME/.claude/tmp/ask-human-gate-bypass" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$SESSION_ID" ]] || exit 0

GATE_DIR="${GATE_DIR_OVERRIDE:-/tmp/ask-human-gate}"  # GATE_DIR_OVERRIDE: test-only injection point
SENTINEL="$GATE_DIR/${SESSION_ID}"
TURN_TOKEN="$GATE_DIR/turns/${SESSION_ID}"

# No turn token = not an interactive main session (subagent, tool runner) → allow through
if [[ ! -f "$TURN_TOKEN" ]]; then
  exit 0
fi

TURN_TIME=$(cat "$TURN_TOKEN" 2>/dev/null || echo 0)

if [[ -f "$SENTINEL" ]]; then
  SENTINEL_TIME=$(cat "$SENTINEL" 2>/dev/null || echo 0)
  if [[ $SENTINEL_TIME -ge $TURN_TIME ]]; then
    exit 0  # Sentinel is same second or newer than current turn → gate cleared for this turn
  fi
  # Sentinel exists but predates current turn → new request, needs re-clearing
  {
    echo "⛔ ASK-HUMAN GATE NOT CLEARED FOR THIS TURN"
    echo "   A new user message arrived since last ask-human invocation."
    echo "   State task size (Small/Medium/Large) + invoke ask-human skill FIRST."
    echo "   CLAUDE.md ⛔ STOP: auto-mode does NOT override. 'It looks small' is rationalization #1."
    echo "   Emergency bypass: touch ~/.claude/tmp/ask-human-gate-bypass"
  } >&2
  log_obs WARN ask-human-gate-block "gate STALE (new turn) session=${SESSION_ID}" || true
  exit 2
fi

# No sentinel at all for this session
{
  echo "⛔ ASK-HUMAN GATE NOT CLEARED"
  echo "   State task size (Small/Medium/Large) + invoke ask-human skill FIRST."
  echo "   CLAUDE.md ⛔ STOP: mandatory before Bash/Read/Edit/Write/Agent. Auto-mode does NOT override."
  echo "   Emergency bypass: touch ~/.claude/tmp/ask-human-gate-bypass"
} >&2
log_obs WARN ask-human-gate-block "gate NOT CLEARED session=${SESSION_ID}" || true
exit 2
