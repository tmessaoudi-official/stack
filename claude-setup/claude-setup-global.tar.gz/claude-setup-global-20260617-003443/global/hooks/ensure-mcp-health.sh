#!/usr/bin/env bash
# SessionStart health-check: warns if HTTP-backend MCPs (Jira, Confluence, etc.) are not reachable.
# Does NOT start containers — run once after install:
#   docker compose -f ~/.claude/mcp/<mcp-client-1>/docker-compose.yaml up -d
set -euo pipefail
# shellcheck source=log-helpers.sh
source "$(dirname "${BASH_SOURCE[0]}")/log-helpers.sh" 2>/dev/null || true

_warn_backend_down() {
  local name="$1" port="$2"
  local compose_file
  compose_file="$(find "$HOME/.claude/mcp" -name "docker-compose*.yaml" 2>/dev/null | head -1)"
  local start_hint="${compose_file:+docker compose -f $compose_file up -d}"
  local msg="MCP backend '${name}' not responding on port ${port}."
  [[ -n "$start_hint" ]] && msg+=" Start: ${start_hint}"
  echo "  [mcp-health] ${msg}" >&2
  log_obs "WARN" "ensure-mcp-health" "${msg}" 2>/dev/null || true
}

# curl without -f: exit 0 on any HTTP response, non-zero only on connection failure
_backend_up() {
  curl -s --connect-timeout 2 --max-time 3 -o /dev/null "http://127.0.0.1:${1}/" 2>/dev/null
}

# Skip entirely if no ACME compose file is present (stack not installed/active)
_acme_compose="$(find "$HOME/.claude/mcp" -name "docker-compose*.yaml" 2>/dev/null | head -1)"
[[ -z "$_acme_compose" ]] && exit 0

_backend_up "8569" || _warn_backend_down "jira-mcp"       "8569"
_backend_up "8570" || _warn_backend_down "confluence-mcp" "8570"
exit 0
