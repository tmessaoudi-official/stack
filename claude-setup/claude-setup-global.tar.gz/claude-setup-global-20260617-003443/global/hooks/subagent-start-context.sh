#!/usr/bin/env bash
# SubagentStart hook: inject project-specific context brief into subagent initial system-reminder.
# Claude Code delivers stdout to the subagent as a system-reminder block.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
AGENT=$(printf '%s' "$INPUT" | jq -r '.agent_name // empty' 2>/dev/null || true)
CWD=$(  printf '%s' "$INPUT" | jq -r '.cwd        // empty' 2>/dev/null || true)

log_obs INFO subagent-start-context "agent=${AGENT:-?} cwd=${CWD:-?}" 2>/dev/null || true

# /path/to/your/project-specific briefing (matches CLAUDE.md routing rule)
if [[ "$CWD" == "/path/to/your/project"* ]]; then
  cat <<'BRIEF'
/path/to/your/project subagent context (auto-injected by SubagentStart hook):
- shellcheck + hadolint + yamllint run automatically on every Edit/Write (PostToolUse hooks)
- Trailing ; in COMPOSE_FILE silently breaks the stack — always check after editing .env
- Port vars must end with : when set (e.g. 42708:); omitting : silently concatenates ports
- core.fileMode=false — chmod changes never appear in git diff/status; note them in commit msgs
- Tier 02 must be healthy before tier 03 can start (file-based health signaling via tools/successes/)
- Auto-commit is authorized for this project; git commit hook may block — present cmd for manual run if so
BRIEF
fi

# Global briefing for all subagents
cat <<'BRIEF'
Global rules (auto-injected by SubagentStart hook):
- Task categorization + ask-human gate apply in all agents — do not skip even for "small" tasks
- Phase 3C and 6C convergence gates are mandatory before implementation and before declaring done
- Rule 6 Completion Gate: Coverage, Docs, Config, Blast-radius evidence required for every task
- Never commit or push without explicit user request (Rule 10)
BRIEF
exit 0
