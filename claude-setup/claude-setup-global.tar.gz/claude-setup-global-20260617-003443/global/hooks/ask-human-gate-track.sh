#!/usr/bin/env bash
# PostToolUse: AskUserQuestion — write ask-human gate sentinel.
# Signals that user interaction occurred, clearing the gate for Edit/Write/Agent calls.
# Paired with ask-human-gate-block.sh (PreToolUse).
# Emergency bypass: if ~/.claude/tmp/ask-human-gate-bypass exists, gate is disabled globally.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$SESSION_ID" ]] || exit 0

GATE_DIR="${GATE_DIR_OVERRIDE:-/tmp/ask-human-gate}"  # GATE_DIR_OVERRIDE: test-only injection point
mkdir -p "$GATE_DIR" 2>/dev/null || true
printf '%s' "$(date +%s)" > "$GATE_DIR/${SESSION_ID}"
log_obs INFO ask-human-gate-track "sentinel written for session ${SESSION_ID}" || true

exit 0
