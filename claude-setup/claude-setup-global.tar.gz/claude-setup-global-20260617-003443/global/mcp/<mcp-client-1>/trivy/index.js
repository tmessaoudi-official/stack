#!/usr/bin/env node
/**
 * ACME Software Factory - Trivy MCP Server
 * Connects Claude Code to the internal Trivy Console at
 * https://internal-portal.cloud-acme.fr/dashboard/transverse/trivy-spaces
 *
 * Auth: AWS ALB session cookie (renew from browser when expired)
 * Usage: set ACME_SF_COOKIE env var with the AWSELBAuthSessionCookie value
 */

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { setGlobalDispatcher, ProxyAgent } from "undici";
import { z } from "zod";

// Auto-detect corporate proxy from standard env vars
const proxyUrl = process.env.HTTPS_PROXY ?? process.env.https_proxy
              ?? process.env.HTTP_PROXY  ?? process.env.http_proxy;
if (proxyUrl) setGlobalDispatcher(new ProxyAgent(proxyUrl));

const BASE_URL = "https://internal-portal.cloud-acme.fr";

// ─── HTTP helper ────────────────────────────────────────────────────────────

function getCookie() {
  const cookie = process.env.ACME_SF_COOKIE;
  if (!cookie) {
    throw new Error(
      "ACME_SF_COOKIE environment variable is not set.\n" +
      "Extract it from your browser DevTools (Application → Cookies) after logging in to:\n" +
      `${BASE_URL}/dashboard/transverse/trivy-spaces\n` +
      "Look for AWSELBAuthSessionCookie-0 (and -1 if present)."
    );
  }
  return cookie;
}

async function sfFetch(path, params = {}) {
  const url = new URL(BASE_URL + path);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") {
      url.searchParams.set(k, String(v));
    }
  });

  const res = await fetch(url.toString(), {
    headers: {
      Cookie: getCookie(),
      Accept: "application/json",
    },
    redirect: "manual", // detect SSO redirect = expired cookie
  });

  if (res.status === 302 || res.status === 301) {
    throw new Error(
      "Session expired (redirected to SSO). Please renew your ACME_SF_COOKIE:\n" +
      "1. Open https://internal-portal.cloud-acme.fr in your browser\n" +
      "2. DevTools → Application → Cookies → copy AWSELBAuthSessionCookie-0\n" +
      "3. Update ACME_SF_COOKIE in ~/.claude/mcp/acme-trivy.env and restart Claude Code"
    );
  }

  if (!res.ok) {
    throw new Error(`API error ${res.status} ${res.statusText} for ${url}`);
  }

  return res.json();
}

// ─── MCP Server ─────────────────────────────────────────────────────────────

const server = new McpServer({
  name: "acme-trivy",
  version: "1.0.0",
  description: "ACME Software Factory — Console Trivy",
});

// ── Tool: list_spaces ────────────────────────────────────────────────────────
server.tool(
  "list_spaces",
  "List Trivy spaces (projects) with their vulnerability counts. " +
  "Filter by domain, pole, criticality or search by name/IDA.",
  {
    page:          z.number().int().min(1).default(1).describe("Page number"),
    itemsPerPage:  z.number().int().min(1).max(100).default(20).describe("Items per page"),
    search:        z.string().optional().describe("Search by IDA or project name"),
    domain:        z.string().optional().describe("Filter by domain (e.g. 'SI RI')"),
    pole:          z.string().optional().describe("Filter by pole (e.g. 'PUSG', 'GDI', 'PTE')"),
    criticality:   z.string().optional().describe("Filter by criticality: CRITICAL, HIGH, MEDIUM, LOW"),
    deployment:    z.string().optional().describe("Filter by deployment type: ADA, Usine"),
  },
  async ({ page, itemsPerPage, search, domain, pole, criticality, deployment }) => {
    const data = await sfFetch("/api/v2/trivy/space", {
      page,
      itemsPerPage,
      pagination: true,
      ...(search      && { search }),
      ...(domain      && { "domain.name": domain }),
      ...(pole        && { "pole.name": pole }),
      ...(criticality && { criticality }),
      ...(deployment  && { "deployment.type": deployment }),
    });

    const items = data["hydra:member"] ?? data.items ?? data;
    const total = data["hydra:totalItems"] ?? data.total ?? "?";

    const formatted = items.map((s) => ({
      id:           s.id ?? s["@id"],
      project:      s.title ?? s.name ?? s.projectName,
      ida:          s.ids ?? s.ida ?? s.code,
      domain:       s.domain?.name ?? s.domainName ?? s.domain,
      pole:         s.pole?.name   ?? s.poleName   ?? s.pole,
      deployment:   s.deployment?.type ?? s.deploymentType ?? s.deployment,
      critical:     s.error_critical ?? s.criticalCount ?? s.critical ?? 0,
      high:         s.error_high     ?? s.highCount     ?? s.high     ?? 0,
      medium:       s.error_medium   ?? s.mediumCount   ?? s.medium   ?? 0,
      low:          s.error_low      ?? s.lowCount      ?? s.low      ?? 0,
      lastScan:     s.scanned_at ?? s.lastScanDate ?? s.scanDate,
    }));

    return {
      content: [{
        type: "text",
        text: JSON.stringify({ total, page, itemsPerPage, spaces: formatted }, null, 2),
      }],
    };
  }
);

// ── Tool: get_counters ───────────────────────────────────────────────────────
server.tool(
  "get_counters",
  "Get global vulnerability counters across all ACME projects " +
  "(total critical, high, medium, low counts visible at the top of the Console Trivy).",
  {},
  async () => {
    const data = await sfFetch("/api/v2/trivy/space/counters");
    return {
      content: [{
        type: "text",
        text: JSON.stringify(data, null, 2),
      }],
    };
  }
);

// ── Tool: get_space_detail ───────────────────────────────────────────────────
server.tool(
  "get_space_detail",
  "Get detailed vulnerability information for a specific Trivy space/project by its IDA code.",
  {
    ida: z.string().describe("Project IDA code (e.g. 'pro', 'tdr', 'ocg', 'rxm')"),
  },
  async ({ ida }) => {
    // Try the factory endpoint first (seen in DevTools often)
    let data;
    try {
      data = await sfFetch(`/api/v2/trivy/factory`, { "space.ids": ida });
    } catch {
      // Fallback: search by IDA in list
      data = await sfFetch("/api/v2/trivy/space", {
        page: 1,
        itemsPerPage: 1,
        pagination: true,
        search: ida,
      });
    }
    return {
      content: [{
        type: "text",
        text: JSON.stringify(data, null, 2),
      }],
    };
  }
);

// ── Tool: get_departments ────────────────────────────────────────────────────
server.tool(
  "get_departments",
  "List available departments/domains in the ACME Software Factory (useful for filtering).",
  {},
  async () => {
    const data = await sfFetch("/api/departments");
    return {
      content: [{
        type: "text",
        text: JSON.stringify(data, null, 2),
      }],
    };
  }
);

// ── Tool: whoami ─────────────────────────────────────────────────────────────
server.tool(
  "whoami",
  "Check the currently authenticated user on the ACME Software Factory. " +
  "Useful to verify the cookie is still valid.",
  {},
  async () => {
    const data = await sfFetch("/api/whoami");
    return {
      content: [{
        type: "text",
        text: JSON.stringify(data, null, 2),
      }],
    };
  }
);

// ── Tool: probe_api ──────────────────────────────────────────────────────────
server.tool(
  "probe_api",
  "Probe candidate API endpoints to discover which ones exist and return vulnerability data.",
  {
    factoryId: z.number().int().describe("Factory scan ID (e.g. 41472 from get_space_detail)"),
    ida:       z.string().optional().describe("Project IDA code (e.g. 'cdm')"),
  },
  async ({ factoryId, ida }) => {
    const candidates = [
      [`/api/v2/trivy/${factoryId}/vulnerabilities`, { page: 1, itemsPerPage: 5, pagination: true }],
      [`/api/v2/trivy/${factoryId}/vulnerabilities`, { severity: "CRITICAL" }],
      ...(ida ? [
        [`/api/v2/trivy/vulnerability`,              { "space.ids": ida }],
        [`/api/v2/trivy/vulnerability`,              { "space": ida }],
      ] : []),
    ];

    const results = [];
    for (const [path, params] of candidates) {
      try {
        const data = await sfFetch(path, params);
        const member = data["hydra:member"] ?? data.items ?? (Array.isArray(data) ? data : null);
        results.push({
          path,
          params,
          ok: true,
          count: member ? member.length : null,
          keys: Object.keys(data),
          sample: member ? member[0] : data,
        });
      } catch (e) {
        results.push({ path, params, ok: false, error: e.message });
      }
    }

    return {
      content: [{ type: "text", text: JSON.stringify(results, null, 2) }],
    };
  }
);

// ── Tool: get_vulnerabilities ─────────────────────────────────────────────────
server.tool(
  "get_vulnerabilities",
  "List individual vulnerabilities for a specific Trivy factory scan, grouped by severity.",
  {
    factoryId:   z.number().int().describe("Factory scan ID from get_space_detail (e.g. 41472)"),
    severity:    z.string().optional().describe("Filter by severity: CRITICAL, HIGH, MEDIUM, LOW"),
    page:        z.number().int().min(1).default(1).describe("Page number"),
    itemsPerPage: z.number().int().min(1).max(100).default(50).describe("Items per page"),
  },
  async ({ factoryId, severity, page, itemsPerPage }) => {
    const data = await sfFetch(`/api/v2/trivy/${factoryId}/vulnerabilities`, {
      page,
      itemsPerPage,
      pagination: true,
      ...(severity && { severity }),
    });

    const items = data["hydra:member"] ?? data.items ?? (Array.isArray(data) ? data : []);
    const total = data["hydra:totalItems"] ?? data.total ?? items.length;

    return {
      content: [{ type: "text", text: JSON.stringify({ total, page, itemsPerPage, vulnerabilities: items }, null, 2) }],
    };
  }
);

// ─── Start ───────────────────────────────────────────────────────────────────
const transport = new StdioServerTransport();
await server.connect(transport);
