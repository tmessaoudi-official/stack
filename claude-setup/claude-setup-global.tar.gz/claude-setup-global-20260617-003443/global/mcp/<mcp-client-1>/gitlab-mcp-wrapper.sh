#!/usr/bin/env bash
# GitLab MCP wrapper — sources token from gitlab.env then execs the MCP.
set -euo pipefail
source "${HOME}/.claude/hooks/log-helpers.sh" 2>/dev/null || log_obs() { :; }
ENV_FILE="${HOME}/.claude/mcp/<mcp-client-1>/gitlab.env"
if [[ ! -f "$ENV_FILE" ]]; then
  log_obs ERROR gitlab-mcp-wrapper.sh "ENV_FILE not found: $ENV_FILE" 2>/dev/null || true
  echo "[mcp-acme-gitlab] ${ENV_FILE} not found — create it with GITLAB_PERSONAL_ACCESS_TOKEN=<token>" >&2
  exit 1
fi
while IFS= read -r line || [[ -n "${line:-}" ]]; do
  [[ -z "$line" || "$line" =~ ^# || ! "$line" =~ = ]] && continue
  key="${line%%=*}"; value="${line#*=}"
  export "${key}=${value}"
done < "$ENV_FILE"

# cd ${HOME}/.claude/mcp/<mcp-client-1>/ && docker compose up -d

exec npx -y --registry https://registry.npmjs.org @zereight/mcp-gitlab@${GLOBAL_STACK_MCP_ZEREIGHT_MCP_GITLAB_VERSION:-2.1.19} "$@"
