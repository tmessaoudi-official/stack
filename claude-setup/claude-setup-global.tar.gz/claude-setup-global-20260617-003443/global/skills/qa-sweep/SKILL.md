---
name: qa-sweep
spotlight: true
description: Use when performing exhaustive systematic QA on a web application (browser target) or a command-line binary/script (CLI target). Two modes: /qa-sweep <url> for browser testing via Playwright MCP, /qa-sweep --target=cli <binary> for CLI testing via Bash. Both run a convergence gate using CLAUDE.md Phase 3C/6C defaults.
user-invocable: true
args: "[--target=browser|cli] <url-or-binary> [fixed-args...] [--allow-writes] [--depth N] [--max-urls N] [--design-review]"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /qa-sweep — Exhaustive systematic QA on a web application (browser) or CLI binary/script.
>
> Usage: /qa-sweep [--target=browser|cli] <url-or-binary> [fixed-args...] [--allow-writes] [--depth N] [--max-urls N] [--design-review]
>
> Flags:
>   --target=browser   Browser UI testing via Playwright MCP (default when URL given)
>   --target=cli       CLI/binary testing via Bash
>   --allow-writes     Enable state-mutating actions (destructive ops skipped by default)
>   --depth N          Max link depth from start URL (browser only; default: 3)
>   --max-urls N       Max URLs to visit (browser only; default: 200)
>   --design-review    Run visual design quality analysis via vision AI after QA crawl (browser target only)
> ```

---

# /qa-sweep — Exhaustive Systematic QA

Parse `$ARGUMENTS`:
- `--target=browser` — browser UI testing via Playwright MCP (default when URL given)
- `--target=cli` — CLI/binary testing via Bash
- `<url>` — start URL (required for browser target)
- `<binary> [fixed-args...]` — binary path and any mandatory args (required for CLI target)
- `--allow-writes` — enable state-mutating actions (destructive ops skipped by default)
- `--depth N` — max link depth from start URL (browser only; default: 3)
- `--max-urls N` — max URLs to visit (browser only; default: 200)
- `--design-review` — run visual design quality analysis via vision AI after QA crawl (browser target only; ignored for CLI target)

If neither URL nor `<binary>` provided: report error and stop.

---

## TARGET: browser (`--target=browser`, default for URLs)

Uses `@playwright/mcp` exclusively — navigation, clicks, forms, screenshots, console logs, network monitoring.

**Playwright MCP preflight** (mandatory, before Step 0): call `browser_snapshot` to verify the browser connection is live. If it returns an error or no response, report `ERROR: Playwright MCP not connected — cannot run browser QA` and stop. Do not proceed to Step 0.

### Step 0 — Auth detection (mandatory before any browsing)

Invoke `ask-human` to confirm auth method:
1. **None** — public app, no login needed
2. **Injected headers** — user provides Bearer token or API key (paste in notes)
3. **Cookie/session** — user logs in manually in the browser, then confirms ready
4. **SSO/OAuth/Keycloak** — open the login URL, wait for user to authenticate, then continue
5. **Other** — user describes the method in notes

Do NOT attempt to browse before auth is confirmed. If auth fails on the first page: stop and report.

### Step 1 — Crawl and test (exhaustive)

Starting from `<url>`, systematically:

1. **Discover**: follow every `<a href>`, `<button>`, `<form>`, `<input type=submit>`, SPA navigation triggers
2. **Per page**: screenshot, read all console messages, read all network requests
3. **Per form**: test with (a) valid data, (b) empty required fields, (c) boundary values, (d) invalid types
4. **Per interactive element**: click and observe — capture before+after screenshots
5. **Console monitoring**: flag any ERROR / uncaught exception / deprecation warning
6. **Network monitoring**: flag any 4xx/5xx, slow responses (>3s), CORS errors, failed assets

### Safety rules (browser)

```
DEFAULT MODE: read-only. --allow-writes to enable state-mutating actions.
NEVER click: [delete], [remove], [destroy], [reset], [sign-out], [logout] by default.
NEVER submit forms whose action URL contains DELETE/DESTROY/RESET.
MODAL GUARD: inspect element before clicking — if it triggers alert/confirm/prompt, SKIP with note.
MAX DEPTH: 3 levels from start URL (override: --depth N).
VISITED SET: track all URLs visited, never revisit. Stop at 200 URLs (override: --max-urls N).
DOMAIN GUARD: never follow external domain links.
AUTH GUARD: if a page redirects to login and auth method not confirmed, stop and ask.
```

### Playwright MCP tools used

`mcp__plugin_playwright_playwright__browser_*`: `browser_navigate`, `browser_click`, `browser_fill_form`, `browser_take_screenshot`, `browser_console_messages`, `browser_network_requests`, `browser_snapshot`.

---

## TARGET: CLI (`--target=cli <binary> [fixed-args...]`)

Tests a command-line binary exhaustively via Bash. No special tooling needed — Bash is the engine. The value is methodology: systematic flag matrix + convergence gate.

### Step 0 — Discovery

**Binary preflight**: verify the binary exists with `command -v <binary>`. If not found, report `ERROR: <binary> not found in PATH — cannot run CLI QA` and stop.

1. Run `<binary> --help` and `<binary> -h` — parse all flags, subcommands, positional args.
2. If `<binary>` is a shell script: read its source to find all flags not exposed via `--help`.
3. Build a test matrix: valid values, missing required args, invalid types, boundary values, conflicting flags, unrecognized flags, missing env vars.

### Step 1 — Systematic testing

Work through the matrix. For each scenario:

1. Run in a temp dir: `cd "$TMPDIR/qa-sweep-$(date +%s)/" && <binary> [args]`
2. Capture stdout, stderr, and exit code.
3. Verify: expected exit code, expected output pattern (if documented), no unexpected file creation.
4. **Stdin variants**: `echo "input" | <binary>`, empty stdin (`</dev/null`), binary stdin.
5. **Env var variants**: with/without expected vars, with invalid values.
6. **Signal handling**: `timeout 5 <binary> [args]; kill -SIGTERM $! 2>/dev/null` — verify clean exit.

### Safety rules (CLI)

```
DEFAULT MODE: read-only. --allow-writes to enable commands with destructive flags.
NEVER run flags containing: delete, destroy, remove, reset, drop, truncate, wipe by default.
DRY-RUN FIRST: if binary has --dry-run or --check, run that before the live command.
ISOLATION: run in $TMPDIR/<qa-sweep-timestamp>/ to contain side effects.
NO PRODUCTION TARGETS: never run against production DBs, APIs, or services without --allow-writes.
```

---

## Step 2 — Convergence sweep (both targets)

**Mandatory before entering the loop**: invoke `ask-human` showing the exact config — max cycles: 30, threshold: 8 consecutive clean cycles, angles: coverage / visual / network (browser) or flag-matrix / edge-cases / env-vars (CLI). Options: *Proceed with these defaults (Recommended)* / *Proceed fully autonomously* / *Change parameters* / *Skip gate*. This gate is required — CLAUDE.md Phase 3C: "always, no exceptions."

After the main test pass, run convergence gate using **CLAUDE.md Phase 3C/6C defaults** (do not hardcode cycle count or threshold — use current CLAUDE.md values so changes propagate):

- **Browser angle 1**: any page, form, or interaction missed? Auth-gated content not reached? Async state not awaited?
- **Browser angle 2**: any visual/layout defect not captured in screenshots?
- **Browser angle 3**: any network call that should have been made but wasn't (missing analytics, failed lazy load)?
- **Browser angle 4 (browser-a11y)**: inject axe-core via `browser_evaluate` on each page and audit: WCAG 2.1 AA contrast violations, ARIA landmark presence, keyboard tab-order and focus traps, skip-nav link, alt text on non-decorative images. Report each violation with element selector, WCAG rule ID, and impact severity (critical/serious/moderate/minor). If axe-core injection fails (e.g., strict CSP blocks eval), log `WARN: axe-core injection blocked — falling back to getComputedStyle contrast check only` and compute foreground/background contrast ratio manually for visible text elements.

- **CLI angle 1**: any flag combination not tested? Subcommand not exercised?
- **CLI angle 2**: any edge case in the test matrix not covered (empty args, very long strings, special chars)?
- **CLI angle 3**: any env var or config file interaction not tested?

Keep cycling until the threshold consecutive clean cycles confirm exhaustive coverage.

---

## Step 3 — Design Review (browser target, `--design-review` only)

**Skip entirely** if `--design-review` was not set, or if target is CLI.

For each page visited in Step 1:

1. **Viewport resize**: use `browser_resize` to set viewport to 375×812 (mobile). Take a screenshot. Then reset to 1440×900 (desktop) — Step 1 screenshots already captured desktop view.
2. **Vision analysis per page** (apply to both desktop and mobile screenshots): assess visual hierarchy (is there a clear primary action?), information density (too many elements competing for attention above fold?), spacing consistency (inconsistent gutters or padding?), color coherence (more than 4 distinct accent colors?), empty/loading/error state clarity (are non-data states visually distinct and informative?), mobile layout (any overflow, cut-off content, or touch targets < 44px?).
3. **Classify each finding**:
   - **DESIGN SYSTEMIC** — same issue appears on 3+ pages (e.g., inconsistent CTA color across all pages)
   - **DESIGN PAGE** — issue specific to one page
   - **DESIGN MOBILE** — only manifests on the 375×812 viewport
   - **DESIGN OK** — page passes all visual design checks

**Synthesis**: after all pages, identify systemic patterns vs. one-off issues. A finding that appears on 3+ pages is systemic — report once at the systemic level, not per-page.

---

## Output format (both targets)

```
QA-SWEEP REPORT
Target: browser <url> | Auth: <method> | Pages visited: N
  OR
Target: cli <binary> | Scenarios: N
─────────────────────────────────────────────────────────────────────────────
PASS  /home                   — 0 console errors, 0 network failures
PASS  --output file.json      — exit 0, valid JSON written
FAIL  /dashboard              — Console ERROR: "Uncaught TypeError at bundle.js:42"
FAIL  --input missing.txt     — exit 0 instead of 1 (missing required arg not rejected)
WARN  /settings               — Form submit empty required → 200 OK (silent failure)
WARN  --config invalid.yaml   — no error message on stderr
SKIP  /admin/delete           — Safety: destructive path (--allow-writes to include)
SKIP  --drop-table            — Safety: destructive flag name (--allow-writes to include)
A11Y  /home                   — axe-core: 2 violations [contrast:serious, missing-skip-nav:moderate]
A11Y  /dashboard              — axe-core: 0 violations
DESIGN SYSTEMIC               — CTA button color inconsistent across 5 pages (--design-review)
DESIGN PAGE  /settings        — information density: 18 form fields above fold, no grouping (--design-review)
DESIGN MOBILE /checkout       — form overflows viewport at 375px, touch targets < 44px (--design-review)
DESIGN OK    /home            — visual hierarchy clear, spacing consistent (--design-review)
─────────────────────────────────────────────────────────────────────────────
Summary: N scenarios | P pass | F fail | W warn | S skipped | A a11y issues
Design review (--design-review): DS systemic | DP page-specific | DM mobile-only | DO ok
GIF saved: qa-sweep-<timestamp>.gif  (browser target only)
```

For browser target: attempt to record a GIF using `mcp__claude-in-chrome__gif_creator`. If it fails or is unavailable, log `WARN: GIF recording failed — continuing without GIF` and proceed. Do not abort the QA run on GIF failure.

---

## Step 4 — Persist report (browser target)

After producing the output, save it to disk:

```bash
PROJECT_SLUG=$(echo "${CLAUDE_PROJECT_DIR:-$PWD}" | sed 's|^/|-|; s|/|-|g')
QA_DIR="$HOME/.claude/projects/$PROJECT_SLUG/qa-sweep"
mkdir -p "$QA_DIR"
TODAY=$(date +%Y-%m-%d)
RUN=1
REPORT_PATH="$QA_DIR/${TODAY}-qa-sweep.md"
while [[ -f "$REPORT_PATH" ]]; do
  RUN=$(( RUN + 1 ))
  REPORT_PATH="$QA_DIR/qa-sweep-${TODAY}-run${RUN}.md"
done
```

Write the full QA-SWEEP REPORT to `$REPORT_PATH`. If a GIF was recorded, move or copy it to `$QA_DIR/` and update the `GIF saved:` line with the full path.
Announce: "QA report saved: `$REPORT_PATH`"
