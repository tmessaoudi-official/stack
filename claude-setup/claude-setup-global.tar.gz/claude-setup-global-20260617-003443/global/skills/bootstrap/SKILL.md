---
name: bootstrap
spotlight: true
description: Use when a project has no CLAUDE.md and no .claude/ config and needs a full Claude Code setup written from scratch. Use with --force to overwrite an existing config after creating a backup.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /bootstrap — Probe the current project deeply and write a tailored Claude Code config from scratch.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

Probe the current project deeply and write a tailored Claude Code config from scratch.
Use when the project has no Claude config yet.
Safe to re-run with `--force` to overwrite an existing config (backup created first).

Use `$ARGUMENTS` for any flags:

## Flags

| Flag | Behavior |
|------|---------|
| `--target PATH` | Source project path to bootstrap (default: current working directory) |
| `--force` | Overwrite an existing CLAUDE.md and `.claude/` config — backup is created first |

---

## Phase 0: Guard — check existing state

```bash
grep -rn '<!-- ADAPT:' CLAUDE.md .claude/ 2>/dev/null | head -5
test -f CLAUDE.md && echo "exists" || echo "absent"
```

**If ADAPT markers found**: stop and reply —
> "This project has unresolved ADAPT markers — it looks like you installed a bundle template.
> Run `/adapt-project` instead to fill those markers."

**If CLAUDE.md exists but no ADAPT markers and `--force` not passed**: stop and reply —
> "CLAUDE.md already exists and appears adapted. Pass `--force` to overwrite (backup will
> be created), or run `/repair` to fix drift without overwriting."

**If `--force`**: note that a backup will be created before writing. Also show the diff first:
```bash
[[ -f CLAUDE.md ]] && diff CLAUDE.md /dev/null || true
```
Let the user review what will be replaced before proceeding. Remind them: hand-edited content in the existing CLAUDE.md will be lost — the backup is the only safety net.

**If CLAUDE.md absent**: proceed.

---

## Phase 1: Deep exploration — 4 parallel Explore agents

Launch all four simultaneously. Each returns a concise structured report.

**Agent 1 — Tech stack**
Probe: `package.json`, `composer.json`, `Gemfile`, `Cargo.toml`, `go.mod`, `pyproject.toml`,
`requirements.txt`, `*.csproj`, `.nvmrc`, `.ruby-version`, `.python-version`, `.tool-versions`,
`Dockerfile*`, `docker-compose*.yaml`.
Report: primary language + version, framework + version, package manager, notable dependencies.

**Agent 2 — Project structure**
Probe: top-level directory tree (2–3 levels), `README.md`, `docs/`, `CONTRIBUTING.md`,
main entry points, config files, key source dirs.
Report: what the project does (1 sentence), key directories with their purpose, main entry points.

**Agent 3 — CI/CD + scripts + workflows**
Probe: `.github/workflows/`, `.gitlab-ci.yml`, `Jenkinsfile`, `Makefile`, `bin/`, `scripts/`,
`.pre-commit-config.yaml`, `taskfile.yml`, `justfile`.
Report: build command, dev-server command, test command, deploy command, common one-liners.

**Agent 4 — Testing + quality**
Probe: test directories, `jest.config.*`, `pytest.ini`, `phpunit.xml`, `.rspec`, `go test`,
`.eslintrc*`, `.pylintrc`, `rubocop.yml`, `shellcheck` usage, `prettier.config.*`,
`black` config, `shfmt` usage, `rustfmt.toml`.
Report: test command(s), linter(s) with file extensions, formatter(s) with file extensions.

---

## Phase 2: Phase gate — mandatory stop

Synthesize the four agent reports into a one-screen summary:

```
BOOTSTRAP SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Detected stack:   [language+version] / [framework] / [package manager]
Test command:     [command]
Linter(s):        [tool] → [ext]
Formatter(s):     [tool] → [ext]

What will be created:
  CLAUDE.md                                  (full project config — all sections)
  .claude/settings.json                      (permissions scaffold)
  .claude/hooks/lint-on-write.sh             (if linter found)
  .claude/hooks/format-on-write.sh           (if formatter found)
  .claude/projects/.claude-template/memory/  (memory scaffold)
  docs/plans/                                (plan persistence — Rule 17 compliance)

```

Invoke the `ask-human` skill: question 'Proceed with bootstrap — create all files listed above?', options: 'Yes, create everything (Recommended)' / 'No, abort — exit without changes'.

**Hard stop** — do not write anything until the user confirms. If 'No': exit without changes.

---

## Phase 3: Write config from scratch

### Backup (if `--force` and existing files present)

```bash
ts=$(date '+%s')
[[ -f CLAUDE.md ]] && cp CLAUDE.md CLAUDE.md.bak.${ts}
[[ -d .claude ]]   && cp -a .claude .claude.bak.${ts}
```

Report the backup paths before writing anything. Then show a summary diff of what will be overwritten:
```bash
[[ -f CLAUDE.md ]] && diff CLAUDE.md /dev/null 2>/dev/null || echo "(no existing CLAUDE.md to diff)"
```

Pause and remind: any hand-edited content in the existing files exists only in the backup. Ask the user to confirm they've reviewed the backup before continuing.

### Directory structure

```bash
mkdir -p .claude/skills .claude/hooks .claude/agents
mkdir -p docs/plans
```

### CLAUDE.md — all sections filled from exploration

Write the full file. Use this section structure:

**`## What This Project Is`**
2–5 sentences: what it does, platform/runtime, key tech, single-dev vs team.
Source: README first paragraph + stack detection.

**`## Architecture`**
Key components and relationships — Markdown table or annotated list.
If microservices: map service → purpose. If monolith: top-level dirs → responsibility.
Source: structure probe.

**`## Common Workflows`**
5–10 most-used commands as bash one-liners with inline comments.
Source: CI/CD probe. Prefer Makefile targets > package.json scripts > bare CLI.

**`## Testing & Verification`**
How to run tests, what passing looks like, test types (unit/integration/E2E), coverage thresholds.
Source: test probe + CI YAML.

**`## File Layout Quick Reference`**
Annotated 2-level tree of non-obvious directories.
Omit `node_modules/`, `.git/`, build output dirs.
Source: structure probe.

**`## Gotchas & Pitfalls`**
3–8 project-specific traps. Look for README warnings, `.env.example` non-obvious keys,
CI retry/timeout hacks, known workarounds in commit history.

**`## Credentials & Stateful Data`**
Where credentials/keys/data live — `.env.example` key names, config file locations.
Source: `.env.example` + README setup sections.

**`## Debugging a Failed [X]`**
Fill `[X]` with the primary service or component name.
5–8 numbered steps from the project's actual debug surface (log locations, health-check commands).

**`## Claude Code Tooling`**
List slash commands, hook behaviors, and agents — exactly what is written in this session.

**`## Claude Code Configuration`**
Annotated file tree of `.claude/` contents.

### `.claude/settings.json`

Minimal permissions scaffold with detected tools added to the allow list.
Append detected linter/formatter/test-runner binaries to `allow` if not already present.

### Hooks

**If linter detected**: write `.claude/hooks/lint-on-write.sh` and add PostToolUse matcher.
**If formatter detected**: write `.claude/hooks/format-on-write.sh` and add PostToolUse matcher.

### Skills

New project-specific slash commands require a `SKILL.md` stub under `.claude/skills/<name>/SKILL.md`.
If the project's exploration reveals custom workflows worth capturing as skills, create the stub directory and a minimal `SKILL.md` with `name:`, `description:`, and `user-invocable:` frontmatter. Global skills live under `~/.claude/skills/<name>/SKILL.md`.

### Memory scaffold

Write:
- `.claude/projects/.claude-template/memory/MEMORY.md` — blank index
- `.claude/projects/.claude-template/memory/example_user.md` — user memory example
- `.claude/projects/.claude-template/memory/example_feedback.md` — feedback memory example

---

## Phase 4: Completion report

```
Bootstrap complete.

Created:
  CLAUDE.md                                  — all sections written from project exploration
  .claude/settings.json                      — permissions scaffold
  .claude/hooks/lint-on-write.sh             — [linter] on Edit/Write  (if applicable)
  .claude/hooks/format-on-write.sh           — [formatter] on Edit/Write  (if applicable)
  .claude/projects/.claude-template/memory/  — memory scaffold

Next steps:
  chmod +x .claude/hooks/*.sh    (activate hook scripts — required before they fire)
  /repair --check                (verify config coherence)
  /audit --quick                 (confirm coverage and hook wiring — ~2 min)
```

If `--force` was used, report backup paths.

Show final file tree and first 40 lines of CLAUDE.md:
```bash
find .claude -type f | sort
head -40 CLAUDE.md
```
