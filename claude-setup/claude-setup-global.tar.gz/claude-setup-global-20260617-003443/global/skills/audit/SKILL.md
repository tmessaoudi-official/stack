---
name: audit
spotlight: true
description: Use when auditing Claude Code setup for permission gaps, CLAUDE.md health, hook coverage, skill coverage, sprint backlog health, plugin efficiency, or session pipeline integrity. Use periodically or before major changes.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /audit — Read-only audit of the Claude Code setup for the current project. Produces a severity-rated report with drift detection vs. the prior audit. Never auto-applies anything.
>
> Flags:
>   --quick                       Run agents A+C+D only (~2 min)
>   --section=<A|B|C|D|E|F|G|H|I|J|K>  Run a single agent section
>   --compare=<YYYY-MM-DD>        Use a specific prior audit as the drift baseline
>   --scope=project|global|both   Scope of the audit (default: both)
> ```

---

# /audit — Configuration & Workflow Self-Reflection Audit

Read-only audit of the Claude Code setup for the current project. Produces a severity-rated report with drift detection vs. the prior audit. **Never auto-applies anything — this command only reads and reports.**

Use `$ARGUMENTS` for flags: `--quick` (agents A+C+D only, ~2 min), `--section=<A|B|C|D|E|F|G|H|I|J|K>` (single agent), `--compare=<YYYY-MM-DD>` (specific baseline), `--scope=project|global|both` (project: A–E analyze `$CLAUDE_PROJECT_DIR/.claude/` only, F–K skipped; global: A–K analyze `~/.claude/` only; both [default]: current behavior).

---

## Step 0: Setup

```bash
PROJECT_SLUG=$(echo "${CLAUDE_PROJECT_DIR:-$PWD}" | sed 's|^/|-|; s|/|-|g')
AUDIT_DIR="$HOME/.claude/projects/$PROJECT_SLUG/audits"
mkdir -p "$AUDIT_DIR"
TODAY=$(date +%Y-%m-%d)
# Run versioning: first run of the day = $TODAY.md; subsequent same-day runs = $TODAY-run2.md, etc.
RUN=1
REPORT_PATH="$AUDIT_DIR/$TODAY.md"
while [[ -f "$REPORT_PATH" ]]; do
  RUN=$(( RUN + 1 ))
  REPORT_PATH="$AUDIT_DIR/$TODAY-run${RUN}.md"
done

# Scope flag
SCOPE="both"
if [[ "$ARGUMENTS" =~ --scope=(project|global|both) ]]; then
  SCOPE="${BASH_REMATCH[1]}"
fi
```

Announce: "Auditing project: `$CLAUDE_PROJECT_DIR` | scope: `$SCOPE` → saving to `$REPORT_PATH`"

## Step 1: Load prior audit (drift baseline)

```bash
PRIOR_REPORT=$(ls "$AUDIT_DIR"/*.md 2>/dev/null | grep -vE "${TODAY}(-run[0-9]+)?\.md$" | sort -r | head -1 || true)
```

- If `$PRIOR_REPORT` is non-empty: load it as the drift baseline and note its date
- If empty: audit #1 — drift analysis section will be skipped
- If `--compare=<date>` provided in `$ARGUMENTS`: use `$AUDIT_DIR/<date>.md` as baseline instead

## Step 2: Spawn Analysis Agents (2 sequential batches of ≤5)

**Scope-aware spawning — determine which agents to run and what instruction prefix to prepend:**

| `$SCOPE` | Agents to spawn | Instruction prefix for A–E |
|----------|-----------------|---------------------------|
| `both` (default) | A–E (Batch 1) + F–K (Batch 2) | *(none — current behavior)* |
| `project` | A–E only (Batch 1); **skip F–K entirely** | Prepend: *"SCOPE: project only. Read ONLY `<PROJECT>/.claude/` directories. For any instruction to read `~/.claude/settings.json`, `~/.claude/CLAUDE.md`, `~/.claude/hooks/`, or `~/.claude/skills/` — read `<PROJECT>/.claude/settings.json`, `<PROJECT>/CLAUDE.md`, `<PROJECT>/.claude/hooks/`, `<PROJECT>/.claude/skills/` instead. Do NOT read any `~/.claude/` global paths."* |
| `global` | A–K (both batches) | Prepend: *"SCOPE: global only. Read ONLY `~/.claude/` directories. Treat any `$CLAUDE_PROJECT_DIR`-relative paths as out of scope — skip them."* |

Agents F–K analyze `~/.claude/` infrastructure exclusively (bundle coverage, plugin efficiency, MCP audit, session pipeline) — they are inherently global-concern tools and must be skipped in `--scope=project`.

Respect flags before spawning:
- `--quick`: spawn only A, C, D (skip B, E, F, G, H, I, J, K — those are slower or optional)
- `--section=<X>`: spawn only that agent
- Default: spawn in two sequential batches — **never exceed 5 concurrent LLM agents** (5 is the proven rate-limit ceiling; >5 causes ~50% failures):
  - **Batch 1**: spawn agents A–E in one message; wait for all 5 to complete before continuing
  - **Batch 2a**: spawn agents F–J in one message (5 agents); wait for all 5 to complete
  - **Batch 2b**: spawn agent K alone; wait for it to complete

Replace `<PROJECT>` with the actual `$CLAUDE_PROJECT_DIR` path. Replace `<PROJECT_SLUG>` with the derived slug from Step 0. Replace `CURRENT_DATE` with today's actual date.

---

**Agent A: Permissions Audit**

> Read `~/.claude/settings.json` (global permissions) and `<PROJECT>/.claude/settings.json` (project permissions). Find: (1) scripts, binaries, or commands referenced in `<PROJECT>/CLAUDE.md`, `<PROJECT>/.claude/skills/`, or `<PROJECT>/.claude/hooks/` that have NO matching permission entry in either settings file — pay special attention to `bin/env-update-v2.sh --apply` or similar write-mode scripts; (2) ask-tier entries that arguably should be in deny-tier — operations that are irreversible even with human confirmation; (3) allow-tier entries that arguably should be in ask-tier — network calls, file writes, or state mutations currently running silently; (4) count total allow/ask/deny rules and note any change from prior audit; (5) check whether `$HOME/.claude.json` and `<PROJECT>/.claude.json` exist — if so, report their contents and how they interact with `settings.json` (which wins on conflict, what fields they override). Report each finding with the specific missing or misclassified entry. Research only, no writes.

---

**Agent B: CLAUDE.md Health**

> Read `~/.claude/CLAUDE.md` (global), `<PROJECT>/CLAUDE.md` (project), and all agent definition files in `<PROJECT>/.claude/agents/`. Find: (1) measure total line count of each file; (2) find sections in any agent definition that conflict with or duplicate content already in the global CLAUDE.md — the agent inherits it automatically, so duplication wastes tokens and creates drift risk; (3) check `~/.claude/projects/<PROJECT_SLUG>/memory/MEMORY.md` line count vs. the 200-line truncation limit; (4) scan for any `@<filename>` inline-include references (e.g. `@THINKING.md`, `@RTK.md`) pointing to non-existent files — these silently load nothing without erroring; (5) check whether all skills documented in CLAUDE.md have matching `SKILL.md` files in `skills/<name>/` directories; (6) **Cross-reference integrity**: for every hook path in `settings.json` hooks entries — verify the script exists at that exact path (`ls` check); for every file path cited in CLAUDE.md "File Layout" / "Slash commands" tables — verify it exists on disk; for every memory file entry in `~/.claude/projects/<PROJECT_SLUG>/memory/MEMORY.md` index — verify the target `.md` file exists in the memory directory. Report broken references with the exact expected path. Research only, no writes.

---

**Agent C: Hook Coverage**

> Read `~/.claude/settings.json` (global hooks) and `<PROJECT>/.claude/settings.json` (project hooks). Then read all hook scripts in `~/.claude/hooks/` and `<PROJECT>/.claude/hooks/`. Find: (1) is there a Stop hook registered in global settings.json? (2) do the linting PostToolUse hooks (Edit|Write matcher) also cover files written via Bash commands — if not, what scenarios bypass them? (3) are any hook scripts referenced in settings.json but absent from disk? (4) are any hooks duplicated between global and project scope doing the same thing? (5) does `~/.claude/hooks/backup-before-write.sh` exist and is it registered in global settings.json PreToolUse? (6) do any hook scripts fail `bash -n` syntax check? (7) **SubagentStart gap**: is there a `SubagentStart` event registered in either settings.json? If not, flag as a potential gap — a pre-subagent briefing hook (injecting project context) could improve subagent cold-start quality; (8) **CLAUDE_PROJECT_DIR reliability**: examine all hook scripts that reference `"$CLAUDE_PROJECT_DIR"` — what happens if Claude Code is invoked from a directory that is not the registered project root? Is `$CLAUDE_PROJECT_DIR` guaranteed to be set, or can it be empty/wrong? Flag any hook that would break silently under this condition; (9) **Observability compliance (Rule 13)**: for each hook script, verify it sources `~/.claude/hooks/log-helpers.sh`, calls `log_obs()` on every state-changing action (file created/deleted, API called, session saved), stays fully silent on no-ops, and writes errors to `~/.claude/logs/hooks-errors.log` — flag any hook that is missing any of these four requirements; (10) **Exit code semantics**: PreToolUse hooks that should block an action — do they exit non-zero on failure? PostToolUse/Stop/SubagentStop hooks that should never block — do they always exit 0 even when an internal error occurs? A mis-matched exit code silently allows or blocks the wrong things; (11) **Idempotency**: for hooks that write files, append to logs, or mutate state — what happens if the hook fires twice in rapid succession (session restart, Claude Code crash+restart)? Flag any hook that writes without a check-first guard (e.g. missing `[[ -f ]]` before `>` or missing `>>` vs atomic-write pattern); (12) **Parallel-subagent safety**: hooks registered for SubagentStart/SubagentStop may fire concurrently from multiple subagents — do any of these hooks write to shared files using `>` (truncate) rather than `>>` or atomic temp+mv? Flag race-condition candidates; (13) **Error silencing audit**: for every `2>/dev/null`, `|| true`, or `set +e` block in any hook script — state what specific error it suppresses, whether that error has been diagnosed and confirmed as benign, and whether it meets the root-cause-before-bandaid standard (Rule 14). Flag any silencing construct that lacks a documented justification. Report each finding. Research only, no writes.

---

**Agent D: Skill Coverage**

> Skills live as subdirectories each containing a `SKILL.md` file (e.g. `skills/audit/SKILL.md`). Read every `SKILL.md` under `~/.claude/skills/` (global) and `<PROJECT>/.claude/skills/` (project) using `find ~/.claude/skills/ -name 'SKILL.md'` and `find <PROJECT>/.claude/skills/ -name 'SKILL.md'`. Also read the slash commands/skills sections of all CLAUDE.md files. Find: (1) skills with the same name in both global and project scope — describe what each does and whether they conflict (name collisions are bugs); (2) skills referenced in CLAUDE.md that are not present in either skills/ directory (i.e. no matching `skills/<name>/SKILL.md`); (3) skills that reference binaries or scripts that do not exist on disk; (4) `SKILL.md` files that are byte-for-byte identical in both scopes — check with `diff` or `md5sum` (redundant duplicates that create maintenance traps); (5) any skill whose description in CLAUDE.md is stale vs. its actual `SKILL.md` content. Report each finding. Research only, no writes.

---

**Agent E: Sprint Backlog Health**

> Find and read all relevant memory files in `~/.claude/projects/<PROJECT_SLUG>/memory/` — look for files whose names suggest improvement tracking, audit history, sprint backlogs, or expert analysis (e.g. files containing "improvement", "journey", "audit", "sprint", "backlog" in their names). Read MEMORY.md index first to find the right files. Today's date is CURRENT_DATE. Find: (1) list all items in pending/backlog sections with their status; (2) for each item, estimate how long it has been pending based on session dates documented in the files; (3) identify items that appear to already be implemented — check by looking at the actual config files and hooks/commands directories; (4) identify items whose rationale no longer applies; (5) flag items with no clear next-action defined; (6) scan ALL memory files in `~/.claude/projects/<PROJECT_SLUG>/memory/` for an `expires:` field in the frontmatter (format: `expires: YYYY-MM-DD`) — flag any file as `[EXPIRED]` if its date ≤ CURRENT_DATE, or `[EXPIRING-SOON]` if within 7 days of CURRENT_DATE. Produce a clean status table: Item | Status | Est. Age | Notes. List expired/expiring-soon memory files separately. Research only, no writes.

---

**Agent F: Plugin, MCP & Artifact-Type Efficiency Audit** *(skipped in --quick mode)*

> Perform a multi-layer efficiency audit of the Claude Code setup. Research only, no writes.
>
> **Token efficiency ranking** (best→worst): Hooks (0 tokens, automatic) > Skills/Commands (0 tokens, on-demand) > CLAUDE.md rules (always loaded every session) > Plugins (always loaded, highest per-session cost).
>
> **F1 — Plugin audit**: Read `~/.claude/settings.json` → `enabledPlugins`. For each enabled plugin: (a) describe what it does given this project context (bash/Docker/Linux infra, single developer, no web frontend, no team PRs); (b) classify as ESSENTIAL / USEFUL / LOW_VALUE / UNKNOWN; (c) flag any plugin that duplicates the functionality of another enabled plugin or of a custom command/hook already present.
>
> **F2 — MCP audit**: Check BOTH `settings.json.mcpServers` (explicit MCP servers) AND plugin-provided MCP tools visible in `permissions.allow` (pattern: `mcp__plugin_*` and `mcp__<server>__*`). For each MCP capability found: (a) does a native CLI tool exist? If yes → CLI-REPLACEABLE, name the CLI alternative; (b) is the capability unique with no CLI equivalent (browser automation, real-time subscriptions)? → JUSTIFIED MCP; (c) does another enabled plugin or server provide overlapping capability? → REDUNDANT. Flag: approximate token overhead per session turn for each active MCP tool set.
>
> **F3 — Token budget estimate**: Estimate tokens consumed before the user types anything. Count: (active enabled plugins × ~400 tokens avg schema) + (lines in `~/.claude/CLAUDE.md`) + (lines in each `@`-included file: THINKING.md, RTK.md, RTK-local.md) + (lines in `<PROJECT>/CLAUDE.md` if in a project). Hooks = 0 tokens. Flag if total estimated overhead exceeds 15,000 tokens.
>
> **F4 — Plugin usage frequency**: Read the most recent session-remember files (`~/.claude/projects/<PROJECT_SLUG>/memory/sessions/buffer.md`, `today.md`, `history.md`). Count occurrences of `subagent_type:`, `Skill(`, and plugin-specific agent/skill names. Flag plugins with zero invocations in visible session history as LOW_USAGE.
>
> **F5 — Artifact-type migration analysis**: For every artifact type below, apply the full "should this be something else?" matrix. Report each finding as: `[FROM_TYPE] "name" → [TO_TYPE]: reason (token impact: saves X tokens / reduces noise / automates Y)`.
>
> *For each skill* (`SKILL.md` files) in `~/.claude/skills/` and `<PROJECT>/.claude/skills/`:
> - → **Skill**: Should Claude invoke this proactively without user typing, based on detecting a context pattern? (proactive trigger > explicit invocation)
> - → **Hook**: Should this fire automatically on a Claude Code event (PostToolUse, PreToolUse, SessionStart, Stop) with no user involvement?
> - → **CLAUDE.md rule**: Is this command really just a standing instruction that applies to every session? (a 1-line rule costs 0 tokens on-demand vs an always-loaded file)
> - → **Obsolete**: Is this already fully covered by another command, skill, CLAUDE.md rule, or hook?
>
> *For each skill* (scan userSettings skills and any plugin-registered skills visible in session context):
> - → **Command**: Is this skill only useful when explicitly invoked? Does proactive triggering create noise or fire at wrong moments?
> - → **Hook**: Is this skill triggered by a specific event rather than a content/context pattern?
> - → **CLAUDE.md rule**: Is this skill simple enough (<10 lines of instruction) to embed directly — saving the on-demand load entirely?
> - → **Obsolete**: Does this skill never fire in practice? (check F4 session log scan)
>
> *For each hook* in `~/.claude/hooks/` and `<PROJECT>/.claude/hooks/`:
> - → **Command**: Is this hook firing too aggressively? Would the user prefer manual control?
> - → **Skill**: Is this hook attempting reasoning or judgment that bash cannot perform? (bash can run linters; it cannot evaluate code quality or make contextual decisions — that requires an LLM skill)
> - → **CLAUDE.md rule**: Is this hook enforcing something Claude should simply know from CLAUDE.md? (A hook reminding Claude to check git before editing = CLAUDE.md Rule 8 already exists)
> - → **Coverage gap**: Does this hook cover ALL write paths? PostToolUse Edit|Write does NOT fire for files written via Bash redirects (`cat >`, `sed -i`, heredocs, `tee`).
>
> *For each CLAUDE.md section* (read `~/.claude/CLAUDE.md` and `<PROJECT>/CLAUDE.md`):
> - → **Skill**: Is this section large (>30 lines) AND only relevant for specific task types? Extracting it to an on-demand skill saves those lines × every session.
> - → **Hook**: Does this section describe event-triggered behaviour that could be automated in bash without LLM reasoning?
>
> *For each agent definition* in `<PROJECT>/.claude/agents/` and `~/.claude/agents/`:
> - → **Command**: Is this agent invoked only when the user explicitly requests it? Could it fold into a slash command?
> - → **Redundant**: Does this agent's behaviour duplicate what global CLAUDE.md already instructs Claude to do?
>
> **F6 — Unused capabilities**: List capabilities available but NOT currently used: CronCreate, Monitor, PushNotification, ScheduleWakeup, `isolation: "worktree"` in Agent tool, `run_in_background` in Agent/Bash tool. For each, propose one concrete use case for this specific project.
>
> **F7 — Ecosystem check**: Check https://www.aitmpl.com for any new bash/infrastructure/Docker tools or plugins added since the prior audit baseline date (use CURRENT_DATE minus 30 days if no baseline exists). If fetch fails, note "ecosystem check skipped" and continue.
>
> Report all findings grouped by section: PLUGIN_AUDIT | MCP_AUDIT | TOKEN_BUDGET | USAGE_FREQUENCY | ARTIFACT_MIGRATION | UNUSED_CAPABILITIES | ECOSYSTEM. Research only, no writes.

---

**Agent G: Local Tools Inventory**

> Perform a complete inventory of `~/.claude/` — every directory and file. Check each of these specifically: `~/.claude/hooks/` (all files, including subdirectories), `~/.claude/skills/` (each a subdirectory with `SKILL.md`), `~/.claude/bin/` (if it exists — list all executables), `~/.claude/agents/` (if it exists — list all agent definitions), and any other non-standard directories you find. For each item found: (1) is it registered in `~/.claude/settings.json`? (if it should be — hooks and the backup script must be registered); (2) is it documented in `~/.claude/CLAUDE.md`? (commands and hooks should be); (3) does it still work — for shell scripts, does `bash -n` pass? (4) is there a duplicate in the project scope (`<PROJECT>/.claude/`) with identical content? Also report: total file count per directory, any orphaned files (present on disk but not referenced anywhere). **Dependency tracking** (Area AC): list every external tool used by hooks/commands/bin scripts (run `grep -rh 'command -v\|which \|type -p\|jq\|yq\|shellcheck\|hadolint\|shfmt\|yamllint\|yamlfmt\|rtk\|perl\|curl\|git\|docker\|make' ~/.claude/hooks/ ~/.claude/bin/ ~/.claude/skills/ 2>/dev/null | grep -oE '\b(jq|yq|shellcheck|hadolint|shfmt|yamllint|yamlfmt|rtk|perl|curl|git|docker|make|python3|bash)\b' | sort -u`). For each tool found: (a) verify it is installed (`command -v <tool>`); (b) note whether a minimum version is documented anywhere in CLAUDE.md or the script itself; (c) flag tools with no version guard as UNDOCUMENTED-MINIMUM (silent breakage risk if tool updates). Also check: `NO_COLOR` — is it implemented in ALL hooks and scripts that produce colored output, or only in some (inconsistency)? Research only, no writes.

---

**Agent H: Skill Suite Evolution** *(skipped in --quick mode)*

> Skills live as subdirectories each containing a `SKILL.md` file. Read every `SKILL.md` under `~/.claude/skills/` and `<PROJECT>/.claude/skills/` using `find ... -name 'SKILL.md'`. Audit the ENTIRE skill suite as a coherent system — not individual skills in isolation, but the suite as a whole. Find: (1) **Coverage matrix** — map which lifecycle moments (project start, daily dev, debugging, refactoring, pre-commit, sprint close, session end) each skill serves; flag any moment with no skill coverage; (2) **Redundancy** — pairs of skills with overlapping scope (e.g. `/inspect` and `/sleuth` both examine error handling — is the split clean? would merging serve better?); propose clearer differentiation or merging where warranted; (3) **Missing skills** — workflows a developer on this project does repeatedly that no skill automates; (4) **Stale skills** — skills referencing files, scripts, or tools that no longer exist at their documented paths (check with `ls` or `find`); (5) **Flag consistency** — skills that should have a `--quick` flag but don't; skills whose `--focus` letter scheme is inconsistent with peer skills; (6) **Output consistency** — skills saving reports to directories or using filename formats that differ from the established pattern (`$HOME/.claude/projects/$SLUG/<type>/<YYYY-MM-DD-HHMM>.md`); (7) **Pipeline composition gaps** — steps in the mega-analysis pipeline (repair → audit → inspect → sleuth → gaps → vision → retrospective → handoff) where one skill's saved output is not consumed as input by any subsequent skill, wasting potential cross-skill context. For each finding: skill name, issue type, specific evidence, proposed fix. Research only, no writes.

---

**Agent I: Bundle Coverage Audit** *(skipped in --quick mode)*

> Audit what is and isn't included in the portable bundle, and surface recommendations for the user to decide. Research only, no writes.
>
> **Step 1 — Read the current bundle spec:**
> Read `~/.claude/bin/lib/claude-export/config/defaults.sh`. Extract three arrays:
> - `_CE_GENERIC_SKILLS` — files that ARE shipped in the global bundle
> - `_CE_ORIGIN_ONLY_FILES` — files that exist only on the origin machine (never bundled)
> - `_CE_EXCLUDES` — patterns of files/dirs excluded from the bundle entirely
>
> Also read `~/.claude/bin/lib/claude-export/core/scope.sh` `_ce_collect_global()` to understand which additional files/dirs are bundled outside `_CE_GENERIC_SKILLS` (e.g. `hooks/session-remember/`, top-level `hooks/*.sh`, root `.md` files via `_CE_GLOBAL_ROOT_FILES`).
>
> **Step 2 — Inventory what exists:**
> List every `SKILL.md` under `~/.claude/skills/` (using `find ~/.claude/skills/ -name 'SKILL.md'`) and every file in `~/.claude/hooks/` (including subdirs). Also check `~/.claude/agents/` if it exists.
>
> **Step 3 — Find gaps (uncovered files):**
> A file is "uncovered" if it is NOT in `_CE_GENERIC_SKILLS`, NOT matched by `_CE_EXCLUDES`, NOT in `_CE_ORIGIN_ONLY_FILES`, and NOT already copied by `_ce_collect_global()` directly. These are the files that will be silently dropped when the bundle is created.
>
> **Step 4 — Find stale entries:**
> For each path in `_CE_GENERIC_SKILLS`: check with `ls` whether the file actually exists on disk. If not → STALE entry (bundler will silently skip a missing file).
>
> **Step 5 — Classify each uncovered file** using these heuristics:
>
> | Classification | When to assign | Action in defaults.sh |
> |---|---|---|
> | **INCLUDE** | Generic workflow tool — useful on any machine, no machine-specific content | Add to `_CE_GENERIC_SKILLS` |
> | **INCLUDE-WITH-ADAPT** | Generic but contains machine-specific paths, names, or config that a new machine needs to fill | Add to `_CE_GENERIC_SKILLS` + note what ADAPT markers to add |
> | **ORIGIN-ONLY** | The tool itself (bundler, importer) — only makes sense where the infrastructure lives | Add to `_CE_ORIGIN_ONLY_FILES` |
> | **EXCLUDE** | Runtime-generated, machine-specific state, or private data that should never leave this machine | Add pattern to `_CE_EXCLUDES` |
> | **SELF-DESTRUCT** | Installed to bootstrap a new project, serves no purpose after ADAPT markers are filled | INCLUDE in bundle + note: project-copy should delete itself after all markers resolved |
>
> **Step 6 — Output:**
>
> Produce two tables:
>
> **Table A — Stale entries to remove from `_CE_GENERIC_SKILLS`:**
> | Entry | Reason (file missing at path) |
>
> **Table B — Uncovered files with recommendations:**
> | File | Recommendation | Rationale | Required change in defaults.sh |
>
> Then write a one-paragraph summary: how many commands are currently bundled vs. how many exist, and whether the bundle coverage is adequate for a fresh-machine install. End with: *"These are proposals — nothing is auto-applied. Update `defaults.sh` to act on any recommendation."*

---

**Agent J: Context Economics & Workflow Coherence** *(skipped in --quick mode)*

> Analyze the token cost and coherence of the Claude Code setup. Research only, no writes.
>
> **J1 — Always-loaded token budget**: Estimate total tokens consumed before the user types anything in a project session. Count lines in: `~/.claude/CLAUDE.md` + each `@`-included file (`THINKING.md`, `RTK.md`, `RTK-local.md`) + `<PROJECT>/CLAUDE.md`. Each line ≈ 8 tokens. Also count: active enabled plugins × ~400 tokens avg schema overhead. Report: TOTAL estimated tokens, top 3 spenders by line count, and whether total exceeds 15,000 tokens (attention degradation risk).
>
> **J2 — Double-spend detection**: Read `~/.claude/CLAUDE.md` and the session-remember buffer (`~/.claude/projects/<PROJECT_SLUG>/memory/sessions/buffer.md` and `today.md`). Identify instructions or facts that appear in BOTH the always-loaded CLAUDE.md AND are injected per-session by session-remember. These are double-spending context budget — the instruction is already static, so re-injecting it on every session is waste.
>
> **J3 — Prompt caching opportunity**: Examine the structure of `~/.claude/CLAUDE.md`. For best cache hit rates, large static sections should be front-loaded (before any dynamic/variable content). Check: are there dynamic sections (today's date, project-specific content, per-session variables) mixed into the middle of the file? Flag if the structure undermines caching.
>
> **J4 — Implicit assumptions**: Scan CLAUDE.md for instructions that assume Claude knows something not spelled out. Example: "use the established backup pattern" — without defining what that pattern is. These create silent failure modes when the assumption is wrong. List each implicit assumption with its location and what it assumes.
>
> **J5 — Workflow coherence gaps**: Read the Phase definitions in `~/.claude/CLAUDE.md` (8-Phase Workflow). Check: (a) does TDD mandate (Rule 7) have clear meaning for infra tasks — what does "failing test first" mean for a Dockerfile or compose entry? Is this spelled out? (b) Completion Gate (Rule 6): are the 4 dimensions (Coverage/Docs/Config/Blast radius) right for infra tasks, or are "Coverage" and "Docs" awkward for pure bash/YAML changes? (c) Phase 3L: is its definition consistent between global CLAUDE.md and any agent definition that references it?
>
> Report each finding with file and approximate line. Research only, no writes.

---

**Agent K: Pipeline & Session Integrity** *(skipped in --quick mode)*

> Audit the session-remember pipeline, session lifecycle, RTK integration, and open security items. Research only, no writes.
>
> **K1 — Session-remember pipeline freshness**: Read all 7 scripts in `~/.claude/hooks/session-remember/`: `common.sh`, `save.sh`, `trigger.sh`, `start.sh`, `stop.sh`, `consolidate.sh`, `extract.py`. Check: (a) `SR_MODEL` default — is `claude-haiku-4-5` still the correct date-suffix-free model ID (no `20251001` suffix) as of CURRENT_DATE? (b) `SR_TZ` is set to `{{TZ}}` in `common.sh` — is this documented as machine-specific in `~/.claude/CLAUDE.md`? Would a bundle→install to a different timezone silently break timestamps? (c) Can both `DISABLED` and `READONLY` sentinels be set simultaneously? What happens — which takes precedence? Is this documented? (d) The heredoc injection risk in `consolidate.sh` (`<<EOF` with user content): is this still unfixed? (e) The `extract.py` + `save.sh` silent data loss composition: is this still unfixed? Report status for each.
>
> **K2 — Session lifecycle completeness**: Check: (a) is there a `Stop` hook registered? What happens on force-quit (SIGKILL) vs graceful stop? (b) Does the `SubagentStart` Claude Code event exist in the hook event types? If it does, is it used? Would a pre-subagent briefing hook (injecting project context) be valuable? (c) What is preserved between sessions (memory files, session-remember buffer) vs what is lost (conversation context, in-flight work)? Is this intentional and documented?
>
> **K3 — RTK integration depth**: Read `~/.claude/RTK-local.md`. Check: (a) are the 3 documented false-positive cases (`diff`, `git diff`, `grep --color`) still accurate? Any other commands that RTK might incorrectly rewrite (check recent session history for `rtk proxy` usage beyond the documented cases)? (b) RTK timeout behavior: what happens at the 5s timeout — does it block the hook or pass through? Is 5s enough for slow startup (cold Docker environments)? (c) Is `rtk` installed? Run `command -v rtk`. If not: which hooks will silently fail vs degrade gracefully? (d) Is the RTK version annotation in `.env` (if `/path/to/your/project` project) correct and current?
>
> **K4 — Open security items status**: Check current state of these two known issues: (a) `consolidate.sh` heredoc injection (`<<EOF` with `$HISTORY_CONTENT` / `$ARCHIVE_CONTENT` unquoted): read the file, find the heredoc, determine if it was fixed to `<<'EOF'`; (b) `extract.py` + `save.sh` silent data loss: read extract.py's error handling on JSONDecodeError, check if it exits non-zero when lines are skipped. Report OPEN or FIXED with evidence.
>
> Research only, no writes.

---

## Step 3: Synthesize findings

After all agents complete, synthesize into a structured report:

```markdown
# /audit Report — <DATE>
Generated: <DATE> | Project: <PROJECT_DIR> | Prior baseline: <PRIOR_DATE or "none (first audit)">

## Summary Table
| Severity | Count | New | Fixed | Chronic |
|----------|-------|-----|-------|---------|
| P0 — blocks correctness/security | | | | |
| P1 — high-impact quality | | | | |
| P2 — minor improvement | | | | |
| P3 — stylistic/optional | | | | |

## Findings

### [SEVERITY] — [Short title] [NEW] / [CHRONIC] / (no tag = persistent)
**Source**: Agent X
**Evidence**: [specific file, line, or command output]
**Impact**: [why it matters]
**Fix cost**: [Low/Medium/High — X min/hours]
---

[Repeat for all findings, grouped by severity descending]

## Drift Analysis
### ✓ Resolved since <PRIOR_DATE>
### ⚠ New since <PRIOR_DATE>
### [CHRONIC] Present in 2+ consecutive audits — escalated priority

## Top 3 Actions
1. **[Title]** — [1 sentence why] | [1 sentence how] (Est: X min)
2. **[Title]** — ...
3. **[Title]** — ...

*These are proposals. Nothing in this report is auto-applied.*
```

For chronic items: if they have appeared in 2 or more prior audits without being fixed, move them to the top of the P0/P1 section regardless of original severity and mark `[CHRONIC]`.

## Step 4: Save report

Write the synthesized report to `$REPORT_PATH`. Announce the full path.

## Step 5: Present findings

Show in conversation: the full summary table + all P0 and P1 findings in full detail + drift analysis + Top 3 Actions. For P2/P3 findings: show count only. Then invoke the `ask-human` skill: question 'Would you like to see P2/P3 findings?', options: 'Yes, show all P2/P3 findings' / 'No, close the report (Recommended)'.
