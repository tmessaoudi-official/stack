#!/usr/bin/env bash
[[ -n "${_CI_INSTALL_GLOBAL_SH_LOADED:-}" ]] && return 0
readonly _CI_INSTALL_GLOBAL_SH_LOADED=1
set -euo pipefail

_CI_GLOBAL_SKIPPED=0

# _ci_check_prereqs — warn (never fail) about missing host tools the installed config relies on.
# Surfaces PREREQUISITES.md rather than executing it. (P1: prereqs were silently assumed present,
# so a host without jq/python3/node got a degraded pipeline that failed later, not at install.)
_ci_check_prereqs() {
  local missing=()
  command -v jq      >/dev/null 2>&1 || missing+=("jq — session-remember + claude-cleanup JSON state")
  command -v python3 >/dev/null 2>&1 || missing+=("python3 — ask-bash-firewall.sh boundary gate (fails CLOSED: every Bash call prompts without it) + adapt banner-strip")
  command -v node    >/dev/null 2>&1 || missing+=("node/npm — node-backed MCP servers")
  command -v git     >/dev/null 2>&1 || missing+=("git — status banner + version tracking")
  [[ "${#missing[@]}" -eq 0 ]] && return 0
  echo "  [prereq] missing host tools — config will degrade until these are installed:" >&2
  local m; for m in "${missing[@]}"; do echo "           • $m" >&2; done
  echo "           see refs/PREREQUISITES.md (bundled / ~/.claude/refs/) for install hints" >&2
  return 0
}

# ci_install_global <bundle_dir>
ci_install_global() {
  local bundle_dir="$1"
  local global_src="$bundle_dir/global"

  [[ ! -d "$global_src" ]] && return 0

  _ci_check_prereqs

  if [[ -d "$HOME/.claude" ]] && \
     { [[ -f "$HOME/.claude/CLAUDE.md" ]] || [[ -d "$HOME/.claude/skills" ]] || [[ -f "$HOME/.claude/settings.json" ]]; }; then
    # Save bundle content to a permanent location before the EXIT trap deletes the staging dir.
    # Without this, every path in the merge guide becomes invalid the moment the installer exits.
    local merge_dir
    merge_dir="${HOME}/.claude-bundle-$(date '+%s')"
    cp -a "$global_src" "$merge_dir"
    ci_print_tutorial "$merge_dir"
    echo "  (merge source saved at: $merge_dir — delete when done)" >&2
    # Scrubbed bundles: tell the user which placeholders to refill in the staged merge source.
    ci_print_refill_guide "$merge_dir"
    _CI_GLOBAL_SKIPPED=1
    return 0
  fi

  mkdir -p "$HOME/.claude"
  mkdir -p "$HOME/.claude/llm-sandbox"

  # Copy everything EXCEPT .claude.json — it must land at $HOME/.claude.json, not inside .claude/
  find "$global_src" -mindepth 1 -maxdepth 1 -not -name ".claude.json" \
    -exec cp -a {} "$HOME/.claude/" \;

  # Handle .claude.json separately if bundled
  if [[ -f "$global_src/.claude.json" ]]; then
    _ci_handle_claude_json "$global_src/.claude.json" || return 1
  fi

  # Restore the executable bit on shipped entrypoint scripts. The exec bit can be lost in
  # transit (tar extracted onto a WSL/DrvFs-backed path strips Unix modes), so set it
  # explicitly rather than trusting cp -a to have preserved a bit that may already be gone.
  # A *.sh with a shebang is an entrypoint (wrappers, hooks, bin tools); sourced libs without
  # one are left untouched. Scoped to the dirs that actually hold runnables.
  _ci_restore_exec_bits

  cat >&2 <<'NEXT_STEPS'
Global config installed to ~/.claude/

Required next steps:
  1. Activate settings (review before applying):
       cp ~/.claude/settings.json.template ~/.claude/settings.json

  2. Hooks, MCP wrappers and bin scripts were made executable automatically
     (the installer restores +x on shipped *.sh — no manual chmod needed).

Then open a Claude Code session:
  /memory-status     — confirm session pipeline is active
  /handoff           — save session state
  /audit --quick     — (suggested) verify config and hook wiring (~2 min)

NEXT_STEPS
  _ci_resolve_mcp_stubs
  _ci_print_mcp_setup_guide
  # Scrubbed bundles: enumerate the placeholders the user must replace with real values.
  ci_print_refill_guide "$HOME/.claude"
}

# _ci_restore_exec_bits
# Set +x on every shipped *.sh entrypoint (shebang'd) under hooks/ , mcp/ , bin/.
# Idempotent; sourced libs (no shebang) and already-executable files are left as-is.
_ci_restore_exec_bits() {
  local count=0 sh firstline
  while IFS= read -r -d '' sh; do
    firstline=""
    IFS= read -r firstline < "$sh" 2>/dev/null || true
    if [[ "$firstline" == '#!'* ]] && [[ ! -x "$sh" ]]; then
      chmod +x "$sh" 2>/dev/null && count=$(( count + 1 )) || true
    fi
  done < <(find "$HOME/.claude/hooks" "$HOME/.claude/mcp" "$HOME/.claude/bin" \
             -type f -name "*.sh" -print0 2>/dev/null)
  [[ "$count" -gt 0 ]] && echo "  [chmod] restored +x on ${count} shipped script(s)" >&2
  return 0
}

# _ci_resolve_mcp_stubs
# Detect placeholder MCP client folders (mcp/<name>/) from a scrubbed bundle.
# Interactively prompts for the actual client name and renames the folder + updates paths.
# Safe no-op when no stubs are present (full-fidelity bundles never have stubs).
_ci_resolve_mcp_stubs() {
  local mcp_dir="${HOME}/.claude/mcp"
  [[ -d "$mcp_dir" ]] || return 0

  local found_stubs=()
  local stub_dir stub_name
  for stub_dir in "$mcp_dir"/*/; do
    [[ -d "$stub_dir" ]] || continue
    stub_name="$(basename "$stub_dir")"
    [[ "$stub_name" =~ ^\<.*\>$ ]] || continue
    found_stubs+=("$stub_name")
  done

  [[ "${#found_stubs[@]}" -eq 0 ]] && return 0

  echo "" >&2
  cat >&2 <<'STUB_HEADER'
  ┌─ MCP client stubs detected ──────────────────────────────────────────────┐
  │ This bundle used --scrub: MCP client folder names are placeholders.       │
  │ Enter the actual client/project name for each stub, or press Enter to     │
  │ keep the default (placeholder name without < > brackets).                 │
  └──────────────────────────────────────────────────────────────────────────┘
STUB_HEADER
  echo "" >&2

  for stub_name in "${found_stubs[@]}"; do
    stub_dir="${mcp_dir}/${stub_name}"
    local default_name="${stub_name//[<>]/}"
    local actual_name

    if [[ -t 0 ]]; then
      printf "  Rename '%s' → [%s]: " "$stub_name" "$default_name" >&2
      read -r actual_name </dev/tty
      actual_name="${actual_name:-${default_name}}"
    else
      echo "  [non-interactive] keeping stub '${stub_name}' — rename manually if needed" >&2
      continue
    fi

    if [[ "$actual_name" == "$stub_name" ]]; then
      echo "  [skip] keeping placeholder '${stub_name}'" >&2
      continue
    fi

    local actual_dir="${mcp_dir}/${actual_name}"
    mv "$stub_dir" "$actual_dir"
    local claude_json="${HOME}/.claude.json"
    if [[ -f "$claude_json" ]]; then
      sed -i "s|/mcp/${stub_name}/|/mcp/${actual_name}/|g" "$claude_json" 2>/dev/null || true
    fi
    find "$actual_dir" -name "*.sh" \
      -exec sed -i "s|/mcp/${stub_name}/|/mcp/${actual_name}/|g" {} \; 2>/dev/null || true
    echo "  [mcp] renamed: ${stub_name} → ${actual_name} (paths updated)" >&2
  done
  echo "" >&2
}

# _ci_print_mcp_setup_guide
# After fresh install: print actionable MCP setup instructions when mcp/ dir exists.
_ci_print_mcp_setup_guide() {
  local mcp_dir="${HOME}/.claude/mcp"
  [[ -d "$mcp_dir" ]] || return 0

  # Discover what's actually installed rather than hardcoding team-specific names.
  local env_files wrapper_scripts compose_files py_projects
  env_files=$(find "$mcp_dir" -maxdepth 2 -name "*.env" | sort)
  wrapper_scripts=$(find "$mcp_dir" -maxdepth 2 -name "*-wrapper.sh" | sort)
  compose_files=$(find "$mcp_dir" -maxdepth 2 -name "docker-compose*.yaml" | sort)
  py_projects=$(find "$mcp_dir" -maxdepth 3 -name "pyproject.toml" | sort)

  cat >&2 <<'MCP_GUIDE'

  ┌─ Post-install: MCP backends need configuration ─────────────────────────┐
  │ ~/.claude/mcp/ was installed. Fill in env-files before using MCPs.      │
  └─────────────────────────────────────────────────────────────────────────┘

MCP_GUIDE

  # Steps are numbered dynamically — only the ones that apply to this install print.
  local n=0

  if [[ -n "$env_files" ]]; then
    n=$(( n + 1 ))
    echo "  ${n}. Edit env-files (replace any CHANGE_ME_* values — scrubbed bundles only):" >&2
    while IFS= read -r f; do
      echo "       $f" >&2
    done <<< "$env_files"
    echo "" >&2
    n=$(( n + 1 ))
    echo "  ${n}. Lock down env-files (mode 600 — they contain credentials):" >&2
    echo "       find ~/.claude/mcp -maxdepth 2 -name \"*.env\" -exec chmod 600 {} +" >&2
    echo "" >&2
  fi

  n=$(( n + 1 ))
  echo "  ${n}. MCP server keys in ~/.claude.json were installed with the names from the bundle." >&2
  echo "     Rename them only if your team uses different naming conventions." >&2
  echo "" >&2

  if [[ -n "$py_projects" ]]; then
    n=$(( n + 1 ))
    echo "  ${n}. Python-backed MCPs rebuild their own venv on first launch (requires 'uv')." >&2
    if ! command -v uv >/dev/null 2>&1; then
      echo "     ⚠ 'uv' is NOT installed on this host — install it, or these MCPs will print" >&2
      echo "       manual steps and refuse to start:" >&2
      echo "         curl -LsSf https://astral.sh/uv/install.sh | sh" >&2
    fi
    echo "     To pre-build them now (optional — first launch does this too):" >&2
    while IFS= read -r f; do
      echo "       ( cd \"$(dirname "$f")\" && uv sync )" >&2
    done <<< "$py_projects"
    echo "" >&2
  fi

  if [[ -n "$compose_files" ]]; then
    n=$(( n + 1 ))
    echo "  ${n}. Start HTTP-backend MCPs (Jira/Confluence etc.):" >&2
    while IFS= read -r f; do
      echo "       docker compose -f $f up -d" >&2
    done <<< "$compose_files"
    echo "" >&2
  fi

  if [[ -n "$wrapper_scripts" ]]; then
    n=$(( n + 1 ))
    echo "  ${n}. Verify stdio MCP wrappers can find their tokens / build their venv:" >&2
    while IFS= read -r f; do
      echo "       bash $f --version 2>&1 | head -2" >&2
    done <<< "$wrapper_scripts"
    echo "" >&2
    n=$(( n + 1 ))
    echo "  ${n}. Register the stdio MCPs Claude Code should load (per-user, once):" >&2
    while IFS= read -r f; do
      local _name; _name="$(basename "$f")"; _name="${_name%-wrapper.sh}"
      echo "       claude mcp add ${_name} --scope user -- bash $f" >&2
    done <<< "$wrapper_scripts"
    echo "     (skip any whose driver can't run on this host — e.g. desktop-windows needs WSL→Windows)" >&2
    echo "" >&2
  fi
}

# _ci_handle_claude_json <src_path>
# Install ~/.claude.json from the bundle. On collision: stop with a manual merge guide.
_ci_handle_claude_json() {
  local src="$1"
  local dst="$HOME/.claude.json"

  if [[ -f "$dst" ]]; then
    local incoming="${dst}.imported"
    cp -a "$src" "$incoming"
    chmod 600 "$incoming"
    _ci_print_claude_json_migration_guide "$dst" "$incoming"
    return 1
  fi

  cp -a "$src" "$dst"
  chmod 600 "$dst"
  echo "  ~/.claude.json installed (mode 600)" >&2
}

# _ci_print_claude_json_migration_guide <existing> <incoming>
# Emit a copy-paste-ready manual merge guide and exit with error.
_ci_print_claude_json_migration_guide() {
  local existing="$1" incoming="$2"
  cat >&2 <<EOF

  ╔══════════════════════════════════════════════════════════════════╗
  ║  ~/.claude.json — manual merge required                         ║
  ╚══════════════════════════════════════════════════════════════════╝

  The bundle includes a ~/.claude.json but one already exists here.
  The incoming file has been saved at:

    ${incoming}

  Do NOT overwrite automatically — this file contains identity fields
  (OAuth tokens, userID, organization UUIDs) that are machine-specific.

  ── Step 1: Review the diff ────────────────────────────────────────
    jq -S . "${existing}" > /tmp/existing.json
    jq -S . "${incoming}" > /tmp/incoming.json
    diff -u /tmp/existing.json /tmp/incoming.json

  ── Step 2: Field classification ───────────────────────────────────
    KEEP from existing : oauthAccount, userID, accountUuid,
                         organizationUuid, projects
    TAKE from incoming : all other flags, toggles, preferences
    INSPECT manually   : anything else that differs

  ── Step 3: Merge (copy-paste-ready jq recipe) ─────────────────────
    jq -s '.[0] as \$t | .[1] as \$i
      | \$t * (\$i | del(.oauthAccount, .userID, .projects,
                          .accountUuid, .organizationUuid))' \\
      "${existing}" "${incoming}" > ~/.claude.json.new

  ── Step 4: Review and apply ───────────────────────────────────────
    # Inspect the merged result first:
    cat ~/.claude.json.new

    # If satisfied:
    mv ~/.claude.json.new ~/.claude.json
    rm "${incoming}"

  Global install is INCOMPLETE until you resolve this manually.

EOF
}
