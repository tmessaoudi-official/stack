#!/usr/bin/env bash
# Stop hook: backstop for CLAUDE.md Rule 6C (PRE-COMPLETION INDEPENDENT CHECK). If the assistant's
# turn contains the Rule 6 Completion Gate evidence-table signature (both "coverage" and "blast
# radius" present — the Medium/Large table or the Small inline-sentence form) but the turn shows no
# independent certification, block the stop with a reminder to call advisor() first.
# Certification = an `advisor` call OR a reviewer-panel `Agent` spawn. The panel arm exists because
# CLAUDE.md's certification ladder prescribes fresh-context reviewer subagents when advisor() is
# unavailable; keying on the literal tool name alone would block the very fallback it mandates.
# The panel match is loose (review|certif|adversarial|lens|audit|critique over subagent_type +
# description + prompt) but NOT blanket — an ordinary Explore/search Agent spawn still blocks,
# which is what keeps the widening from swallowing every turn that happens to spawn an agent.
# Conservative by design (false-NEGATIVE-leaning): fires only on this one well-defined, mechanical
# co-occurrence signal, not a fuzzy "sounds like done" heuristic. Does NOT trigger on a later
# "STATUS: Committed" confirmation turn (that's just reporting git state, not re-claiming
# completeness, and usually has no new advisor() call to make). Honors stop_hook_active (no loop);
# ACGUARD_OFF=1 disables. Transcript schema: one content-block per JSONL line, so a turn = all
# lines after the last 'user' entry. Mirrors ask-human-question-guard.sh.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

[[ "${ACGUARD_OFF:-}" == "1" ]] && exit 0
# Global sentinel bypass (parity with ask-human-question-guard.sh).
[[ -f "$HOME/.claude/state/advisor-completion-guard-bypass" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

# Per-project sentinel bypass: ~/.claude/projects/<slug>/state/advisor-completion-guard-bypass (slug = cwd, / -> -).
ACG_CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
if [[ -n "$ACG_CWD" ]]; then
  ACG_SLUG=$(printf '%s' "$ACG_CWD" | tr '/' '-')
  [[ -f "$HOME/.claude/projects/${ACG_SLUG}/state/advisor-completion-guard-bypass" ]] && exit 0
fi

# Per-session sentinel bypass (uniform /gates-bypass model, 2026-08-30): run/advisor-completion-guard-bypass-<sid>.
ACG_SID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$ACG_SID" && -f "$HOME/.claude/run/advisor-completion-guard-bypass-${ACG_SID}" ]] && exit 0

# Avoid loops: if we already blocked once this stop-cycle, let it through.
[[ "$(printf '%s' "$INPUT" | jq -r '.stop_hook_active // false' 2>/dev/null)" == "true" ]] && exit 0

TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
[[ -n "$TRANSCRIPT" && -f "$TRANSCRIPT" ]] || exit 0

# Parse the last turn (lines after the last 'user' entry): gather assistant text + tool names used.
FILTER='
  . as $a
  | ([range(0; ($a|length)) | select($a[.].type=="user"
       and (($a[.].message.content|type)=="string"
            or ([$a[.].message.content[]?|select(.type=="tool_result")]|length)==0))] | last) as $u0
  | (($u0 // -1) + 1) as $start
  | {
      used_advisor: ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="tool_use" or .type=="server_tool_use") ]
                   | any( .name == "advisor"
                          or ( .name == "Agent"
                               and ( ((.input.subagent_type // "") + " " + (.input.description // "")
                                      + " " + (.input.prompt // ""))
                                     | test("review|certif|adversarial|lens|audit|critique"; "i") ) ) )),
      text:     ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="text") | .text ] | join("\n"))
    }'
RES=$(tail -n 800 "$TRANSCRIPT" 2>/dev/null | jq -Rc 'fromjson? // empty' 2>/dev/null | jq -s "$FILTER" 2>/dev/null || true)
[[ -z "$RES" ]] && exit 0

USED_ADVISOR=$(printf '%s' "$RES" | jq -r '.used_advisor' 2>/dev/null || echo false)
TEXT=$(printf '%s' "$RES" | jq -r '.text' 2>/dev/null || echo "")

# If advisor() ran — or a reviewer panel was spawned — Phase 6C was honored → pass.
[[ "$USED_ADVISOR" == "true" ]] && exit 0
[[ -z "$TEXT" || "$TEXT" == "null" ]] && exit 0

# Completion Gate evidence-table signature: both "coverage" and "blast radius" present.
# Co-occurrence keeps false positives near zero; neither term alone is distinctive enough.
if printf '%s' "$TEXT" | grep -qi 'coverage' && printf '%s' "$TEXT" | grep -qi 'blast radius'; then
  {
    echo "⛔ COMPLETION GATE EVIDENCE PRESENTED WITHOUT advisor() CERTIFICATION"
    echo "   This turn looks like a Rule 6 Completion Gate claim (coverage + blast-radius evidence)"
    echo "   but the advisor tool was not called."
    echo "   CLAUDE.md Phase 6C (PRE-COMPLETION INDEPENDENT CHECK): call advisor() before declaring done."
    echo "   Disable backstop: ACGUARD_OFF=1"
  } >&2
  log_obs WARN advisor-completion-guard "blocked completion-gate claim without advisor() call" 2>/dev/null || true
  exit 2
fi
exit 0
