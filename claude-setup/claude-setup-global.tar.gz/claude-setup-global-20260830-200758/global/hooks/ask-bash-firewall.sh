#!/usr/bin/env bash
# PreToolUse: Bash — BOUNDARY GATE (v3, 2026-08-29; literal-var folding added 2026-08-30). Permission tier = blast radius; boundary = the
# project root. Every Bash command is tokenised (python3/shlex — quotes, redirects, `cd` tracking, one-level
# `bash -c`/`sh -c`/`eval`/`xargs`/`find -exec` unwrap, heredoc bodies stripped as DATA) and every MUTATE /
# READ / NET target is resolved to an absolute path, then tiered — highest tier wins (deny > ask > silent):
#   deny   host-critical targets (/, any top-level dir, $HOME itself, /etc /usr /bin /sbin /lib* /boot /var
#          /opt /root /proc /sys /dev≠/dev/null) and credential stores (~/.ssh ~/.gnupg ~/.aws ~/.kube ~/.netrc
#          ~/.git-credentials ~/.claude/.credentials.json ~/.claude/mcp/**/.env*, id_rsa|id_ed25519 anywhere,
#          *.pem|*.key OUTSIDE the root) — reads AND writes. A settings `allow` never lifts a deny.
#   ask    Claude self-mod paths (settings*.json, guard hooks, this hook, state/ sentinels, autonomous-3c
#          markers, session-remember toggles, ~/.claude.json, shell rc files, ~/.gitconfig) EVEN inside
#          ~/.claude; the .env matrix (write bare .env; read/write .env*prod*|*staging*); ROOT/.claude/
#          boundary.json `protected[]`; any mutate OUTSIDE the root and outside the SAFE zones; NET writes
#          (POST/PUT/PATCH/DELETE, -d/--data*/-F/-T) to non-local hosts; anything not statically resolvable
#          ($VAR, $(…), `…`, unknown cwd after `cd "$X"`, unbalanced quotes, missing python3) — fail closed.
#          (F-1.2, 2026-08-30: a same-command literal `VAR=value` assignment IS folded before this
#          check — e.g. `S=/tmp/x && rm "$S/y"`; a later non-literal reassignment of the same VAR
#          invalidates the fold, and a `bash -c`/`sh -c` child does NOT inherit a bare parent VAR.)
#   silent everything else: mutates inside ROOT or in SAFE zones (/tmp, $TMPDIR, ~/.claude/{projects,run,logs},
#          /dev/null, boundary.json `trusted_outside[]`), all other reads, local-host / GET network, git.
# ROOT = `git rev-parse --show-toplevel` of the tool's cwd, else cwd. CLAMP (advisor F-A): when that toplevel
# is $HOME (this machine's home directory is itself a git repo) ROOT = cwd; when cwd == $HOME the session is
# boundaryless (only SAFE zones + reads are silent).
# Evaluation order is load-bearing (F3): host-critical/credential → self-mod → .env/protected → SAFE → outside.
# Per mode: interactive sessions (default/acceptEdits/bypassPermissions) see `ask` as a prompt; auto-mode,
# headless (-p) and subagent sessions hard-deny an `ask` (Claude Code fails closed) — the reason text names
# the path, the tier and the escape (Edit tool for in-repo files; `!` for the user).
# `allow` rules in settings.json downgrade ask → silent only (F4), never deny. Decisions are appended to
# logs/firewall-suggestions.log. Off-switches (the user's escape, never set by Claude):
#   CLAUDE_BASH_FIREWALL_OFF=1 | ~/.claude/state/ask-bash-firewall-bypass |
#   ~/.claude/projects/<slug>/state/ask-bash-firewall-bypass
# HONEST: Bash is arbitrary code execution; this is best-effort supervision, NOT a sandbox.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

SETTINGS="${CLAUDE_BASH_FIREWALL_SETTINGS:-$HOME/.claude/settings.json}"   # test injection
SUG_LOG="${CLAUDE_BASH_FIREWALL_LOG:-$HOME/.claude/logs/firewall-suggestions.log}"

[[ "${CLAUDE_BASH_FIREWALL_OFF:-}" == "1" ]] && exit 0
# Global off-switch: sentinel disables the gate everywhere (defer to literal settings.json).
[[ -f "$HOME/.claude/state/ask-bash-firewall-bypass" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

# Per-project off-switch: sentinel at ~/.claude/projects/<slug>/state/ask-bash-firewall-bypass (slug = cwd, / → -).
CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
if [[ -n "$CWD" ]]; then
  PROJ_SLUG=$(printf '%s' "$CWD" | tr '/' '-')
  [[ -f "$HOME/.claude/projects/${PROJ_SLUG}/state/ask-bash-firewall-bypass" ]] && exit 0
fi
# Per-session off-switch (uniform /gates-bypass model, 2026-08-30): run/ask-bash-firewall-bypass-<sid>.
FW_SID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$FW_SID" && -f "$HOME/.claude/run/ask-bash-firewall-bypass-${FW_SID}" ]] && exit 0
CMD=$(printf '%s' "$INPUT" | jq -r '.tool_input.command // empty' 2>/dev/null || true)
[[ -z "$CMD" ]] && exit 0

log_flag() {  # $1=action  $2=reason  $3=suggestion
  local ts; ts=$(date -Is 2>/dev/null || date 2>/dev/null || echo '?')
  printf '%s | %s | %s | suggest: %s | cmd: %s\n' \
    "$ts" "$1" "$2" "$3" "${CMD:0:200}" >> "$SUG_LOG" 2>/dev/null || true
  log_obs INFO ask-bash-firewall "$1 ($2)" 2>/dev/null || true
}

emit() {  # $1=decision (ask|deny)  $2=reason (shown to USER / read by Claude as the block reason)  $3=suggestion (logged)
  jq -nc --arg d "$1" --arg r "$2" \
    '{hookSpecificOutput:{hookEventName:"PreToolUse",permissionDecision:$d,permissionDecisionReason:$r}}' \
    2>/dev/null || printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"%s","permissionDecisionReason":"bash firewall: review this command"}}' "$1"
  log_flag "${1^^}" "$2" "$3"
  exit 0
}

# python3: prefer the system interpreter (a pyenv shim on PATH costs ~0.5 s per call and may be absent from
# the hook's PATH); fall back to whatever PATH offers; none → fail closed.
PY="${CLAUDE_BASH_FIREWALL_PYTHON:-}"                                        # test injection
[[ -z "$PY" && -x /usr/bin/python3 ]] && PY=/usr/bin/python3
[[ -z "$PY" ]] && PY=$(command -v python3 2>/dev/null || true)
if [[ -z "$PY" || ! -x "$PY" ]]; then
  log_obs ERROR ask-bash-firewall "python3 not found — failing closed" 2>/dev/null || true
  emit ask "Bash firewall: python3 is unavailable, so the command's targets cannot be classified (fail closed). Approve, or run it yourself with \`!\`." "install python3 / set CLAUDE_BASH_FIREWALL_PYTHON"
fi

ERRF=$(mktemp 2>/dev/null || echo /dev/null)
RESULT=$("$PY" - "$CMD" "$CWD" "$SETTINGS" "$FW_SID" 2>"$ERRF" <<'PY'
import fnmatch, json, os, re, shlex, subprocess, sys
from urllib.parse import urlparse

CMD, CWD_IN, SETTINGS = sys.argv[1], sys.argv[2], sys.argv[3]
SESSION_ID = sys.argv[4] if len(sys.argv) > 4 else ''
R = lambda p: os.path.realpath(p)
HOME = R(os.environ.get('HOME') or os.path.expanduser('~'))
TMPDIR = os.environ.get('TMPDIR') or ''

# F-1.2 (2026-08-30): constant folding for same-command literal variable assignments.
# `S=/tmp/x && rm "$S/y"` is the mandated scratchpad idiom; only a value that is ITSELF already
# fully literal (no $, `, $(), MARK) at assignment time gets folded — never resolved any other way.
KNOWN_VARS = {}
if TMPDIR: KNOWN_VARS['TMPDIR'] = TMPDIR
if SESSION_ID: KNOWN_VARS['CLAUDE_CODE_SESSION_ID'] = SESSION_ID
ENV_SEEDED_VARS = dict(KNOWN_VARS)   # what a bash -c/sh -c CHILD actually inherits (real env only)

def under(p, d):
    d = d.rstrip('/') or '/'
    return p == d or p.startswith(d + '/')
def any_under(p, ds): return any(under(p, d) for d in ds if d)

# ── ROOT (with the home-repo clamp) ─────────────────────────────────────────────
def git_top(d):
    try:
        r = subprocess.run(['git', '-C', d, 'rev-parse', '--show-toplevel'], capture_output=True, text=True, timeout=3)
        return R(r.stdout.strip()) if r.returncode == 0 and r.stdout.strip() else None
    except Exception:
        return None
CWD = R(CWD_IN) if CWD_IN else None
ROOT = None
if CWD:
    top = git_top(CWD) or CWD
    if top == HOME or under(HOME, top):      # toplevel is $HOME or an ancestor of it → clamp to cwd
        top = CWD
    ROOT = None if top == HOME else top
BOUNDARYLESS = ROOT is None

PROTECTED, TRUSTED, BOUNDARY_BROKEN = [], [], False
if ROOT:
    bpath = os.path.join(ROOT, '.claude', 'boundary.json')
    if os.path.exists(bpath):
        try:
            with open(bpath) as fh:
                b = json.load(fh)
            for x in b.get('protected', []) or []:
                x = os.path.expanduser(x)
                PROTECTED.append(R(x) if os.path.isabs(x) else R(os.path.join(ROOT, x)))
            TRUSTED = [R(os.path.expanduser(x)) for x in (b.get('trusted_outside', []) or [])]
        except Exception:
            BOUNDARY_BROKEN = True          # present but unreadable → protected[] unknown → fail closed inside ROOT
SAFE = [x for x in (ROOT, '/tmp', R(TMPDIR) if TMPDIR else '', os.path.join(HOME, '.claude', 'projects'),
                    os.path.join(HOME, '.claude', 'run'), os.path.join(HOME, '.claude', 'logs')) if x] + TRUSTED

CRED_DIRS = [os.path.join(HOME, d) for d in ('.ssh', '.gnupg', '.aws', '.kube')]
CRED_FILES = [os.path.join(HOME, f) for f in ('.netrc', '.git-credentials', '.claude/.credentials.json')]
KEY_NAMES = ('id_rsa', 'id_ed25519', 'id_ecdsa', 'id_dsa')
HOST_DIRS = ['/etc', '/usr', '/bin', '/sbin', '/boot', '/var', '/opt', '/root', '/proc', '/sys', '/dev']
SELFMOD = ['.claude/settings*.json', '.claude/hooks/*guard*.sh', '.claude/hooks/ask-bash-firewall.sh',
           '.claude/hooks/ask-human-gate-*.sh', '.claude/state', '.claude/state/*', '.claude/projects/*/state',
           '.claude/projects/*/state/*', '.claude/run/*-bypass-*',
           '.claude/hooks/session-remember/DISABLED', '.claude/hooks/session-remember/DISABLED.lean',
           '.claude/hooks/session-remember/READONLY', '.claude/hooks/session-remember/blacklist',
           '.claude/hooks/session-remember/readonly-list',
           '.claude.json', '.bashrc', '.bash_profile', '.profile', '.zshrc', '.zprofile', '.gitconfig']
MUTATE_VERBS = {'rm', 'rmdir', 'unlink', 'shred', 'truncate', 'mv', 'cp', 'install', 'rsync', 'ln', 'touch',
                'tee', 'chmod', 'chown', 'chgrp', 'dd'}
READ_VERBS = {'cat', 'head', 'tail', 'less', 'more', 'grep', 'egrep', 'fgrep', 'rg', 'awk', 'cut', 'sort', 'uniq',
              'diff', 'stat', 'file', 'jq', 'yq', 'source', '.', 'wc', 'strings', 'xxd', 'od', 'base64', 'tac', 'nl'}
NET_VERBS = {'curl', 'wget', 'http', 'https', 'xh'}
WRAPPERS = {'env', 'command', 'nohup', 'time', 'nice', 'builtin', 'exec', 'sudo', 'doas',
            'rtk', 'timeout', 'setsid', 'stdbuf', 'ionice', 'chrt', 'unbuffer'}
# Options that consume the NEXT token, PER wrapper — a shared table cannot encode that `-p` takes an argument
# for sudo but none for `time`/`command`, or `-i` none for env but one for stdbuf (6C F-H). Unlisted wrappers
# (command, nohup, time, builtin, exec, setsid, unbuffer) have no argument-taking options.
WRAPPER_ARG_OPTS = {
    'env':     {'-u', '-C', '-S', '--unset', '--chdir', '--split-string'},
    'timeout': {'-s', '-k', '--signal', '--kill-after'},
    'nice':    {'-n', '--adjustment'},
    'ionice':  {'-c', '-n', '-p', '--class', '--classdata', '--pid'},
    'stdbuf':  {'-i', '-o', '-e', '--input', '--output', '--error'},
    'chrt':    {'-p', '--pid'},
    'sudo':    {'-u', '-g', '-h', '-p', '-C', '-D', '-r', '-t', '-T', '-U', '--user', '--group', '--host', '--prompt', '--chdir'},
    'doas':    {'-u', '-C'},
}
NUMERIC_POSITIONAL = {'timeout', 'chrt'}                                  # timeout DURATION cmd, chrt PRIO cmd
def strip_wrappers(words):
    """Pop leading VAR=x assignments and wrapper verbs WITH their options so the real verb is classified:
    `env -i HOME=x rm …`, `timeout 30 rm …`, `rtk proxy rm …`, `time -p rm …`, `sudo -u bob rm …` all reach `rm`."""
    while words:
        w = words[0]
        if re.fullmatch(r'[A-Za-z_]\w*=.*', w):
            words.pop(0); continue
        b = os.path.basename(w)
        if b not in WRAPPERS:
            break
        words.pop(0)
        if b == 'rtk':
            if words and words[0] in ('proxy', 'hook'): words.pop(0)      # `rtk proxy <cmd>`; `rtk <cmd>` is transparent
            continue
        argopts = WRAPPER_ARG_OPTS.get(b, set())
        while words and words[0].startswith('-'):
            opt = words.pop(0)
            if opt.split('=', 1)[0] in argopts and '=' not in opt and words:
                words.pop(0)
        if b in NUMERIC_POSITIONAL and words and re.fullmatch(r'\d+(\.\d+)?[smhd]?', words[0]):
            words.pop(0)
    return words

def is_cred(p):
    b = os.path.basename(p)
    if b in KEY_NAMES: return True
    if any_under(p, CRED_DIRS) or p in CRED_FILES: return True
    if under(p, os.path.join(HOME, '.claude', 'mcp')) and b.startswith('.env'): return True
    return False
def is_host_critical(p):
    if p == '/dev/null': return False
    if p == '/' or p == HOME: return True
    if p.count('/') == 1: return True                      # any top-level directory: /etc /home /tmp /path/to/your/project …
    return any_under(p, HOST_DIRS) or p.startswith('/lib')
def is_selfmod(p):
    if not under(p, HOME): return False
    rel = os.path.relpath(p, HOME)
    return any(fnmatch.fnmatchcase(rel, g) for g in SELFMOD)
def env_kind(p):
    b = os.path.basename(p)
    if not b.startswith('.env'): return None
    if re.search(r'prod|staging', b): return 'prod'
    return 'bare' if b == '.env' else 'other'

MARK = 'SUBSTMARK'
def mask_subst(text):
    """Replace every `…` and $(…) span with MARK so only the TARGETS that contain a substitution become
    unresolvable — not every target in a command that happens to contain one (`T=$(date)` is ubiquitous)."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c == '`':
            j = text.find('`', i + 1)
            out.append(MARK); i = n if j < 0 else j + 1; continue
        if c == '$' and i + 1 < n and text[i + 1] == '(':
            depth, j = 0, i + 1
            while j < n:
                if text[j] == '(': depth += 1
                elif text[j] == ')':
                    depth -= 1
                    if depth == 0: break
                j += 1
            out.append(MARK); i = j + 1; continue
        out.append(c); i += 1
    return ''.join(out)

def subst_known(text):
    """Fold $VAR / ${VAR} refs whose value was captured as a same-command literal assignment."""
    for var, val in KNOWN_VARS.items():
        text = re.sub(r'\$\{' + re.escape(var) + r'\}', lambda m: val, text)
        text = re.sub(r'\$' + re.escape(var) + r'(?![A-Za-z0-9_])', lambda m: val, text)
    return text

class Unresolvable(Exception): pass
def resolve(tok, cwd, subst):
    if subst or MARK in tok or '`' in tok or '$(' in tok or '{}' in tok: raise Unresolvable(tok)
    t = subst_known(tok)
    t = re.sub(r'^~(?=/|$)', HOME, t).replace('${HOME}', HOME).replace('$HOME', HOME)
    if '$' in t: raise Unresolvable(tok)
    m = re.search(r'[*?\[]', t)
    if m:                                                   # glob → the directory that contains it
        t = t[:m.start()]
        if not t.endswith('/'): t = os.path.dirname(t) or '.'
    if not os.path.isabs(t):
        if cwd is None: raise Unresolvable(tok)
        t = os.path.join(cwd, t)
    return R(os.path.normpath(t))

F = []   # findings: (tier, reason, suggestion[, boundary]) — boundary asks may be downgraded by a settings allow; policy asks never
def esc(): return "In-repo files: use the Edit tool. Otherwise run it yourself with `!`."
def tier(kind, verb, p):
    if p == '/dev/null': return
    if is_cred(p):
        F.append(('deny', f"`{verb}` targets a credential store ({p}) — denied regardless of project root; a settings allow does not lift this.", 'keep credential stores out of Bash')); return
    if kind == 'MUTATE':
        if is_host_critical(p):
            F.append(('deny', f"`{verb}` targets a host-critical path ({p}) — denied.", 'never'))
        elif is_selfmod(p):
            F.append(('ask', f"`{verb}` modifies a Claude self-mod path ({p}) — asks even inside ~/.claude. {esc()}", 'user applies guard/settings/sentinel changes'))
        elif env_kind(p) == 'prod':
            F.append(('ask', f"`{verb}` writes a production/staging env file ({p}). {esc()}", '.env matrix'))
        elif env_kind(p) == 'bare':
            F.append(('ask', f"`{verb}` writes the bare .env ({p}) — live secrets; .env.example/.env.local are silent. {esc()}", '.env matrix'))
        elif any_under(p, PROTECTED):
            F.append(('ask', f"`{verb}` targets a path listed in .claude/boundary.json protected[] ({p}). {esc()}", 'boundary.json'))
        elif BOUNDARY_BROKEN and ROOT and under(p, ROOT):
            F.append(('ask', f"`{verb}` targets {p} but {ROOT}/.claude/boundary.json is unreadable, so protected[] is unknown — fix the file. {esc()}", 'repair boundary.json'))
        elif any_under(p, SAFE):
            return
        elif BOUNDARYLESS:
            F.append(('ask', f"`{verb}` targets {p} and this session has no project root (cwd is $HOME) — only /tmp and ~/.claude/{{projects,run,logs}} are silent. {esc()}", 'launch claude inside a project', verb != 'redirect'))
        else:
            # a settings allow blesses the VERB, not a `>` target: redirect writes are never downgraded
            F.append(('ask', f"`{verb}` targets {p} — OUTSIDE the project root ({ROOT}). {esc()}", 'add to boundary.json trusted_outside[] if this is routine', verb != 'redirect'))
    else:
        if env_kind(p) == 'prod':
            F.append(('ask', f"`{verb}` reads a production/staging env file ({p}). {esc()}", '.env matrix'))
        elif (p.endswith('.pem') or p.endswith('.key')) and not (ROOT and under(p, ROOT)):
            F.append(('deny', f"`{verb}` reads a private key outside the project root ({p}) — denied.", 'keys stay outside Bash'))
def add_target(kind, verb, tok, cwd, subst):
    try:
        p = resolve(tok, cwd, subst)
    except Unresolvable:
        if kind == 'MUTATE':
            F.append(('ask', f"`{verb}` target `{tok}` is not statically resolvable (variable, command substitution, `{{}}` or unknown cwd) — fail closed. {esc()}", 'use literal paths', True))
        return
    tier(kind, verb, p)

# ── parsing ─────────────────────────────────────────────────────────────────────
HD_RE = re.compile(r"(?<!<)<<(?!<)(-?)\s*(?:'([^']*)'|\"([^\"]*)\"|\\?([\w.-]+))")
def strip_heredocs(cmd):
    out, tags = [], []
    for line in cmd.split('\n'):
        if tags:
            tag, dash = tags[0]
            if (line.lstrip('\t') if dash else line) == tag: tags.pop(0)
            continue                                        # heredoc body = data, never a command
        for m in HD_RE.finditer(line):
            tags.append((m.group(2) or m.group(3) or m.group(4), m.group(1) == '-'))
        out.append(HD_RE.sub(' ', line))
    return '\n'.join(out)
def tokenize(text):
    s = shlex.shlex(text, posix=True, punctuation_chars='();<>|&\n')
    s.whitespace = ' \t\r'; s.whitespace_split = True; s.commenters = ''
    return list(s)
SEP_RE = re.compile(r'^[;|&\n()]+$')
def is_sep(t): return bool(SEP_RE.match(t)) and t not in ('>&', '&>')
def positional(args): return [a for a in args if not (a.startswith('-') and a != '-')]

def analyze(cmd, cwd, depth):
    toks = tokenize(mask_subst(strip_heredocs(cmd)))
    segs, cur = [], []
    for t in toks:
        if is_sep(t):
            if cur: segs.append(cur); cur = []
        else:
            cur.append(t)
    if cur: segs.append(cur)
    for seg in segs:
        cwd = segment(seg, cwd, False, depth)    # substitutions are per-token MARKs, never command-wide
    return cwd

def segment(seg, cwd, subst, depth):
    words, i, n = [], 0, len(seg)
    while i < n:                                            # redirects first
        t = seg[i]
        if re.fullmatch(r'[<>&|]+', t):
            if words and re.fullmatch(r'\d+', words[-1]): words.pop()      # fd number (2>…)
            tgt = seg[i + 1] if i + 1 < n else None
            if tgt is None: i += 1; continue
            if tgt.startswith('&') or (t in ('>&', '&>') and re.fullmatch(r'\d+', tgt)): i += 2; continue
            add_target('MUTATE' if '>' in t else 'READ', 'redirect', tgt, cwd, subst)
            i += 2; continue
        words.append(t); i += 1
    words = [w.strip('()') for w in words]
    words = [w for w in words if w]
    if len(words) == 1:
        m = re.fullmatch(r'([A-Za-z_]\w*)=(.*)', words[0], re.S)
        if m:
            var, val = m.group(1), m.group(2)
            folded = subst_known(val)
            if MARK not in folded and not re.search(r'\$|`|\{\}', folded):
                KNOWN_VARS[var] = folded
            else:
                KNOWN_VARS.pop(var, None)   # non-literal reassignment invalidates any prior fold
            return cwd
    words = strip_wrappers(words)
    if not words: return cwd
    verb, args = words[0], words[1:]
    b = os.path.basename(verb)
    if b in ('cd', 'pushd'):
        if not args or args[0] == '~': return HOME
        if args[0] == '-': return None
        try: return resolve(args[0], cwd, subst)
        except Unresolvable: return None
    if b in ('bash', 'sh', 'zsh', 'dash', 'ksh') and '-c' in args:
        k = args.index('-c')
        inner = args[k + 1] if k + 1 < len(args) else ''
        if depth >= 1:
            F.append(('ask', f"nested `{b} -c` wrapper — cannot inspect beyond one level (fail closed). {esc()}", 'flatten the command')); return cwd
        # F-1.2: a child shell only inherits EXPORTED env (TMPDIR, CLAUDE_CODE_SESSION_ID), never a
        # bare `VAR=x` set in the parent — folding those in here would turn a correct fail-closed ask
        # into a false-negative silent-allow on the worst shape (`S=/tmp/x && bash -c 'rm "$S/"*'`
        # runs with $S EMPTY in the child → `rm -rf /*`). `eval` needs no such snapshot (same shell).
        _saved_vars = dict(KNOWN_VARS)
        KNOWN_VARS.clear(); KNOWN_VARS.update(ENV_SEEDED_VARS)
        try:
            analyze(inner, cwd, depth + 1)
        finally:
            KNOWN_VARS.clear(); KNOWN_VARS.update(_saved_vars)
        return cwd
    if b == 'eval':
        if depth >= 1:
            F.append(('ask', "nested `eval` — cannot inspect beyond one level (fail closed).", 'flatten')); return cwd
        analyze(' '.join(args), cwd, depth + 1); return cwd
    if b == 'xargs':
        rest = [a for a in args if not a.startswith('-')]
        if rest: verb_target(rest[0], rest[1:], cwd, subst, from_xargs=True)
        return cwd
    if b == 'find':
        paths, j = [], 0
        while j < len(args) and not args[j].startswith('-') and args[j] not in ('!', '('):
            paths.append(args[j]); j += 1
        paths = paths or ['.']
        opts = args[j:]
        if '-delete' in opts:
            for p in paths: add_target('MUTATE', 'find -delete', p, cwd, subst)
        for k in ('-exec', '-execdir', '-ok', '-okdir'):
            if k in opts:
                ex = opts[opts.index(k) + 1:]
                if ex and os.path.basename(ex[0]) in MUTATE_VERBS:
                    for p in paths: add_target('MUTATE', f'find {k} {os.path.basename(ex[0])}', p, cwd, subst)
        return cwd
    verb_target(verb, args, cwd, subst)
    return cwd

def verb_target(verb, args, cwd, subst, from_xargs=False):
    b = os.path.basename(verb)
    pos = positional(args)
    tg, kind = [], 'MUTATE'
    if b in ('rm', 'rmdir', 'unlink', 'shred', 'touch', 'tee', 'mv'):
        tg = pos
    elif b == 'truncate':
        skip = False
        for a in args:
            if skip: skip = False; continue
            if a in ('-s', '--size', '-r', '--reference'): skip = True; continue
            if a.startswith('-'): continue
            tg.append(a)
    elif b in ('chmod', 'chown', 'chgrp'):
        tg = pos[1:]
    elif b in ('cp', 'install', 'rsync', 'ln'):
        if '-t' in args and args.index('-t') + 1 < len(args): tg = [args[args.index('-t') + 1]]
        elif len(pos) >= 2: tg = pos[-1:]
    elif b == 'dd':
        tg = [a[3:] for a in args if a.startswith('of=')]
    elif b == 'sed':
        inplace = any(a == '-i' or (a.startswith('-i') and not a.startswith('--')) or a.startswith('--in-place') for a in args)
        explicit = any(a in ('-e', '-f', '--expression', '--file') or a.startswith(('-e', '--expression=', '--file=')) for a in args)
        tg = pos if explicit else pos[1:]
        kind = 'MUTATE' if inplace else 'READ'
    elif b == 'perl':
        if any(a.startswith('-i') for a in args): tg = pos[1:]
        else: return
    elif b in READ_VERBS:
        tg, kind = pos, 'READ'
    elif b in NET_VERBS:
        net(b, args); return
    else:
        return
    if kind == 'MUTATE' and from_xargs and not tg:
        F.append(('ask', f"`xargs {b}` takes its targets from stdin — not statically resolvable (fail closed). {esc()}", 'use find -exec or literal paths')); return
    for t in tg: add_target(kind, b, t, cwd, subst)

def local_host(h):
    return (not h) or h in ('localhost', '0.0.0.0', '::1') or h.startswith('127.') or h.endswith('.local') or '.' not in h
def net(b, args):
    W = ('POST', 'PUT', 'PATCH', 'DELETE')
    mutating = False
    for i, a in enumerate(args):
        if a in ('-X', '--request') and i + 1 < len(args) and args[i + 1].upper() in W: mutating = True
        elif a.startswith('-X') and len(a) > 2 and a[2:].upper() in W: mutating = True
        elif a.startswith('--request=') and a.split('=', 1)[1].upper() in W: mutating = True
        elif a in ('-d', '-F', '-T', '--json', '--form', '--upload-file', '--post-data', '--post-file', '--body-data', '--body-file') or a.startswith('--data'): mutating = True
        elif a.startswith('--method=') and a.split('=', 1)[1].upper() in W: mutating = True
    if b in ('http', 'https', 'xh') and any(a.upper() in W for a in args[:2]): mutating = True
    if not mutating: return
    urls = [a for a in args if re.match(r'^[a-z][a-z0-9+.-]*://', a, re.I)]
    if not urls:
        F.append(('ask', f"`{b}` write request with no literal URL — fail closed. {esc()}", 'literal URL')); return
    for u in urls:
        h = urlparse(u).hostname or ''
        if not local_host(h):
            F.append(('ask', f"`{b}` sends a write request to external host {h} ({u}). {esc()}", 'external writes ask'))

def allowed_by_settings():
    try:
        with open(SETTINGS) as fh: rules = json.load(fh).get('permissions', {}).get('allow', []) or []
    except Exception:
        return False
    for r in rules:
        if not (isinstance(r, str) and r.startswith('Bash(') and r.endswith(')')): continue
        pat = r[5:-1].replace(':*', '*')
        if fnmatch.fnmatchcase(CMD, pat) or CMD.startswith(pat + ' '): return True
    return False

try:
    analyze(CMD, CWD, 0)
except ValueError as e:                                     # unbalanced quotes etc.
    F.append(('ask', f"command could not be parsed ({e}) — fail closed. {esc()}", 'fix quoting'))

rank = {'deny': 2, 'ask': 1}
F.sort(key=lambda f: -rank[f[0]])
if F:
    d, reason, sug = F[0][:3]
    boundary_only = all(len(f) > 3 and f[3] for f in F)   # every finding is a boundary ask (none is a policy ask / deny)
    if d == 'ask' and boundary_only and allowed_by_settings():
        print('\t'.join(('defer', reason, sug)))            # F4: allow downgrades boundary asks → silent, never deny/policy
    else:
        print('\t'.join((d, reason, sug)))
PY
)
RC=$?
if [[ $RC -ne 0 ]]; then
  log_obs ERROR ask-bash-firewall "classifier exited $RC: $(head -c 300 "$ERRF" 2>/dev/null | tr '\n' ' ')" 2>/dev/null || true
  rm -f "$ERRF"
  emit ask "Bash firewall: the command classifier failed (exit $RC) — fail closed. Approve, or run it yourself with \`!\`." "see logs/hooks-errors.log"
fi
rm -f "$ERRF"

IFS=$'\t' read -r DECISION REASON SUGGEST <<< "${RESULT:-}"
case "${DECISION:-}" in
  deny)  emit deny "Bash firewall: DENIED — $REASON" "$SUGGEST" ;;
  ask)   emit ask  "Bash firewall: $REASON Approve?" "$SUGGEST" ;;
  defer) log_flag "DEFER(allowed)" "$REASON — settings.json ALLOWS this exact command" "review the allow rule; tighten it if unintended" ;;
esac

# Obfuscation present without a decision → log only (advisory), do not interrupt.
case "$CMD" in
  *'$('*|*'`'*) log_flag "NOTE" "command substitution present (can hide effects)" "informational — no action" ;;
esac

exit 0   # silent: no opinion → settings/auto + the rtk hook decide
