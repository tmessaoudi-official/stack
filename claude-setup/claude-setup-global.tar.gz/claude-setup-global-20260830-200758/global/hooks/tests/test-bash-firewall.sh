#!/usr/bin/env bash
# Tests for ask-bash-firewall.sh v3 — the BOUNDARY GATE.
# Contract: inside the project root → silent; outside → ask; host-critical / credential stores → deny;
# Claude self-mod paths (settings.json, guard hooks, sentinels) → ask even from the ~/.claude project.
# Everything runs under a FAKE HOME + a git-initialised fake project so path tiers are deterministic.
set -uo pipefail

HOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FW="$HOOKS_DIR/ask-bash-firewall.sh"
C_G='\033[0;32m'; C_R='\033[0;31m'; C_0='\033[0m'
PASS=0; FAIL=0; declare -a FAILS=()

TMP=$(mktemp -d "${XDG_RUNTIME_DIR:-$HOME/.cache}/fw-test.XXXXXX")   # NOT under /tmp (a SAFE zone)
FAKEHOME="$TMP/home"; PROJ="$FAKEHOME/work/proj"; HOMEPROJ="$FAKEHOME/.claude"
mkdir -p "$PROJ/api" "$PROJ/infra/prod" "$PROJ/.claude" "$HOMEPROJ/state" "$HOMEPROJ/run" "$HOMEPROJ/docs" \
         "$HOMEPROJ/projects/-proj/state" "$HOMEPROJ/hooks/session-remember" "$FAKEHOME/projects-other" \
         "$FAKEHOME/shared" "$FAKEHOME/.ssh"
git -C "$PROJ" init -q 2>/dev/null
MOCK="$TMP/settings.json"; LOG="$TMP/firewall.log"
# Production-realistic allow list: `Bash(cat *)` is allowed globally — must NOT defeat a deny-tier read.
printf '%s' '{"permissions":{"allow":["Bash(grep:*)","Bash(cat *)","Bash(rm -rf ~/projects-other/blessed)"]}}' > "$MOCK"

# run_fw <cmd> [cwd] — OUT = hook stdout ("ask"/"deny" JSON) or empty (silent/defer).
run_fw(){ OUT=$(jq -n --arg c "$1" --arg w "${2:-$PROJ}" '{cwd:$w,permission_mode:"bypassPermissions",tool_input:{command:$c}}' \
  | HOME="$FAKEHOME" CLAUDE_BASH_FIREWALL_SETTINGS="$MOCK" CLAUDE_BASH_FIREWALL_LOG="$LOG" bash "$FW" 2>/dev/null); }
ok(){ PASS=$((PASS+1)); printf "${C_G}✓${C_0} %s\n" "$1"; }
ko(){ FAIL=$((FAIL+1)); FAILS+=("$1"); printf "${C_R}✗${C_0} %s (expected %s, got: %.70s)\n" "$1" "$2" "${OUT:-<silent>}"; }
assert_silent(){ run_fw "$2" "${3:-}"; [[ -z "$OUT" ]] && ok "$1" || ko "$1" SILENT; }
assert_ask(){    run_fw "$2" "${3:-}"; [[ "$OUT" == *'"permissionDecision":"ask"'* ]]  && ok "$1" || ko "$1" ASK; }
assert_deny(){   run_fw "$2" "${3:-}"; [[ "$OUT" == *'"permissionDecision":"deny"'* ]] && ok "$1" || ko "$1" DENY; }

printf '\n=== SILENT: everything inside the project root ===\n'
assert_silent "read bare .env in-repo"              "cat .env"
assert_silent "read api/.env.example (was /.env FP)" "cat -n api/.env.example"
assert_silent "source docker/x/.env in-repo"        "set -a; . docker/twes/.env; set +a; docker exec db mysql -e 'select 1'"
assert_silent "write .env.local"                    "echo KEY=1 > .env.local"
assert_silent "write .env.example"                  "printf 'A=1\n' > .env.example"
assert_silent "rm -rf relative dir"                 "rm -rf build/"
assert_silent "rm -rf absolute path inside root"    "rm -rf $PROJ/node_modules"
assert_silent "cd subdir && rm -rf (cd tracked)"    "cd api && rm -rf vendor"
assert_silent "cd absolute inside && rm"            "cd $PROJ/api && rm -f cache.json"
assert_silent "find -delete inside"                 "find . -name '*.log' -delete"
assert_silent "find -exec rm inside"                "find . -name '*.pyc' -exec rm -f {} +"
assert_silent "jq .key field (was .key FP)"         "jq -r '.permissions | to_entries[] | .key as \$k | .value[]' settings.json"
assert_silent "grep for 'apikey' (was .key FP)"     "grep -rn 'apikey' src/"
assert_silent "cat certs/dev.pem inside root"       "cat certs/dev.pem"
assert_silent "truncate log inside"                 "truncate -s 0 logs/app.log"
assert_silent "sed -i inside"                       "sed -i 's/a/b/' src/x.py"
assert_silent "chmod +x inside"                     "chmod +x scripts/run.sh"
assert_silent "chown -R inside"                     "chown -R developer:developer storage/"
assert_silent "shred inside"                        "shred -u tmp/secret.txt"
assert_silent "mv inside → inside"                  "mv src/old.py src/new.py"
assert_silent "cp from outside INTO root (read)"    "cp $FAKEHOME/projects-other/a.txt ./a.txt"
assert_silent "tee inside"                          "echo x | tee out.txt"
assert_silent "git add"                             "git add docs/file.md"
assert_silent "git commit"                          "git commit -m wip"
assert_silent "git reset --hard (settings ask owns it, hook silent)" "git reset --hard origin/main"
assert_silent "npm run build"                       "npm run build"
assert_silent "docker compose up"                   "docker compose up -d"
assert_silent "curl POST to localhost"              "curl -X POST http://localhost:8000/api/login -d '{}'"
assert_silent "curl -d to 127.0.0.1"                "curl -d '{}' http://127.0.0.1:3000/x"
assert_silent "curl GET external"                   "curl -s https://api.github.com/repos/x"
assert_silent "ls /tmp"                             "ls -la /tmp"
assert_silent "pipe grep|head"                      "grep foo bar | head -5"
assert_silent "empty command"                       ""
assert_silent "rtk git status (wrapper, safe verb)"  "rtk git status"
assert_silent "timeout npm run build (wrapper, safe)" "timeout 30 npm run build"
assert_silent "rtk proxy rm inside root"             "rtk proxy rm -rf build/"
assert_silent "env -i wrapper, in-root target"       "env -i PATH=/usr/bin rm -f cache.json"
assert_silent "\$(…) elsewhere does not poison a literal /tmp target" "echo x > /tmp/f.txt && T=\$(date +%s) && echo \$T"
assert_silent "\$(…) elsewhere does not poison an in-root rm"      "rm -rf build/ && V=\$(git rev-parse HEAD)"
assert_silent "backticks elsewhere, literal in-root target"        "rm -f cache.json; echo \`date\`"
assert_ask    "cd \$(…) then relative rm → unresolvable cwd asks"  "cd \$(pwd)/api && rm -rf vendor"

printf '\n=== F-1.2: same-command literal variable folding (2026-08-30) ===\n'
FOLD1="S=$PROJ && rm -rf \"\$S/build\""
FOLD2="S=\$(pwd) && rm -rf \"\$S/build\""
FOLD3="S=$PROJ && S=\$(id) && rm -rf \"\$S/build\""
FOLD_INNER='rm -rf "$S/build"'
FOLD4="S=$PROJ && bash -c '$FOLD_INNER'"
FOLD5="S=$PROJ && W=\"\$S/wt\" && rm -rf \"\$W/x\""
FOLD6="FOO=$PROJ rm -rf \"\$FOO/build\""
FOLD7="S=/etc && rm -rf \"\$S/passwd\""
FOLD8="export S=$PROJ && rm -rf \"\$S/build\""
assert_silent "literal same-command var folds (the scratchpad idiom)" "$FOLD1"
assert_ask    "assignment from \$(...) stays unresolvable"           "$FOLD2"
assert_ask    "non-literal reassignment invalidates a prior fold"    "$FOLD3"
assert_ask    "bash -c child does NOT inherit a bare parent var (no leak)" "$FOLD4"
assert_silent "chained assignment folds (W=\"\$S/wt\")"               "$FOLD5"
assert_ask    "prefix-scoped assignment does NOT fold (correct — shell expands before it takes effect)" "$FOLD6"
assert_deny   "literal-var fold also strengthens to deny (host-critical)" "$FOLD7"
assert_ask    "export VAR=literal is not folded (documented gap, no leak either)" "$FOLD8"

printf '\n=== SILENT: safe zones outside the root ===\n'
assert_silent "write hand-off script to /tmp"       "cat > /tmp/apply-x-20260829.sh <<'S'\necho hi\nS"
assert_silent "rm -rf under /tmp"                   "rm -rf /tmp/claude-1000/-proj/abc/scratchpad/build"
assert_silent "truncate /tmp file (tmp is safe)"    "truncate -s 100 /tmp/f"
assert_silent "write plan under ~/.claude/projects" "cp x.md ~/.claude/projects/-proj/plans/x.plan.md"
assert_silent "write active-plan pointer (run/)"    "printf '%s\n' /x > ~/.claude/run/active-plan-abc"
assert_silent "append ~/.claude/logs"               "echo line >> ~/.claude/logs/hooks-errors.log"
assert_silent "redirect to /dev/null"               "make build > /dev/null 2>&1"
HD=$(printf "cat > /tmp/gen-x.sh <<'EOF'\nrm -rf /\necho x > ~/.claude/settings.json\nEOF\nbash -n /tmp/gen-x.sh")
assert_silent "heredoc body is DATA (write target /tmp)" "$HD"
HD2=$(printf "cat > ~/projects-other/gen.sh <<'EOF'\necho hi\nEOF")
assert_ask    "heredoc write target outside root still asks" "$HD2"

printf '\n=== SILENT: reads of protected names are NOT writes (verb-aware, kills the autonomous-3c/sentinel FPs) ===\n'
assert_silent "grep docs for sentinel name"         "grep -rn 'state/autonomous-3c-bypass' ~/.claude/docs" "$HOMEPROJ"
assert_silent "cat a sentinel"                      "cat ~/.claude/state/ask-human-gate-bypass" "$HOMEPROJ"
assert_silent "ls state/"                           "ls -la ~/.claude/state/" "$HOMEPROJ"
assert_silent "read settings.json with jq"          "jq '.permissions.deny|length' ~/.claude/settings.json" "$HOMEPROJ"
assert_silent "edit a normal file in the home project" "sed -i 's/a/b/' ~/.claude/skills/audit/SKILL.md" "$HOMEPROJ"

printf '\n=== ASK: outside the root (not host-critical) ===\n'
assert_ask "rm -rf another dir under HOME"          "rm -rf $FAKEHOME/projects-other/build"
assert_ask "rm -rf via ~ outside root"              "rm -rf ~/projects-other/build"
assert_ask "cd outside && rm -rf (cd tracked)"      "cd $FAKEHOME/projects-other && rm -rf build"
assert_ask "cd \$VAR && rm (unresolvable → fail closed)" "cd \"\$DIR\" && rm -rf build"
assert_ask "rm target with \$(…) (fail closed)"     "rm -rf \$(cat path.txt)/x"
assert_ask "mv inside → outside dest"               "mv src/x.py $FAKEHOME/Downloads/x.py"
assert_ask "cp inside → outside dest"               "cp a.txt ~/projects-other/a.txt"
assert_ask "find outside -delete"                   "find $FAKEHOME/projects-other -name '*.log' -delete"
assert_ask "xargs rm outside"                       "ls ~/projects-other | xargs rm -rf"
assert_ask "bash -c wrapper (one-level unwrap)"     "bash -c 'rm -rf ~/projects-other/x'"
assert_ask "rtk proxy wrapper"                      "rtk proxy rm -rf ~/projects-other/x"
assert_ask "rtk transparent wrapper"                "rtk rm -rf ~/projects-other/x"
assert_ask "timeout wrapper"                        "timeout 30 rm -rf ~/projects-other/x"
assert_ask "timeout -s KILL wrapper"                "timeout -s KILL 30 rm -rf ~/projects-other/x"
assert_ask "env -i VAR=x wrapper"                   "env -i HOME=/x rm -rf ~/projects-other/x"
assert_ask "nohup + nice -n wrapper"                "nohup nice -n 5 rm -rf ~/projects-other/x"
assert_ask "time -p wrapper (-p takes no arg)"      "time -p rm -rf ~/projects-other/x"
assert_ask "command -p wrapper (-p takes no arg)"   "command -p rm -rf ~/projects-other/x"
assert_ask "stdbuf -o0 wrapper (attached arg)"      "stdbuf -o0 rm -rf ~/projects-other/x"
assert_ask "stdbuf -o 0 wrapper (separate arg)"     "stdbuf -o 0 rm -rf ~/projects-other/x"
assert_ask "chrt -f PRIO wrapper"                   "chrt -f 10 rm -rf ~/projects-other/x"
assert_ask "sudo -u USER wrapper (hook tier; settings deny wins first)" "sudo -u bob rm -rf ~/projects-other/x"
assert_ask "chmod -R outside"                       "chmod -R 777 $FAKEHOME/projects-other"
assert_ask "truncate outside"                       "truncate -s 0 ~/projects-other/app.log"
assert_ask "tee outside"                            "echo x | tee ~/projects-other/out.txt"
assert_ask "redirect outside"                       "echo x > ~/projects-other/out.txt"
assert_ask "sed -i outside"                         "sed -i 's/a/b/' ~/projects-other/x.py"
assert_ask "curl POST external host"                "curl -X POST https://api.example.com/x -d '{}'"
assert_ask "curl --data external host"              "curl --data @payload.json https://hooks.slack.com/services/x"
assert_ask "curl -T upload external"                "curl -T file.tgz https://upload.example.com/"
assert_ask "unbalanced quote → parser fails closed"  "rm -rf 'x"
assert_ask "nested bash -c (one-level unwrap only)"  "bash -c \"sh -c 'echo hi'\""

printf '\n=== ASK: .env matrix inside the root ===\n'
assert_ask "write bare .env"                        "echo KEY=1 > .env"
assert_ask "append bare .env"                       "echo KEY=1 >> .env"
assert_ask "sed -i bare .env"                       "sed -i 's/A=1/A=2/' .env"
assert_ask "cp over bare .env"                      "cp .env.example .env"
assert_ask "read .env.production"                   "cat .env.production"
assert_ask "read .env.prod"                         "cat api/.env.prod"
assert_ask "read .env.staging"                      "cat .env.staging"
assert_ask "write .env.production"                  "echo X=1 > .env.production"
assert_ask "write .env.staging.local"               "echo X=1 > .env.staging.local"

printf '\n=== ASK: Claude self-mod — even when the project IS ~/.claude (order: self-mod before inside-root) ===\n'
assert_ask "redirect to settings.json from home project" "echo x > ~/.claude/settings.json" "$HOMEPROJ"
assert_ask "cp over settings.json"                  "cp /tmp/new.json ~/.claude/settings.json" "$HOMEPROJ"
assert_ask "sed -i a guard hook"                    "sed -i 's/exit 2/exit 0/' ~/.claude/hooks/advisor-prework-guard.sh" "$HOMEPROJ"
assert_ask "overwrite the firewall itself"          "cp /tmp/fw.sh ~/.claude/hooks/ask-bash-firewall.sh" "$HOMEPROJ"
assert_ask "rm a sentinel"                          "rm ~/.claude/state/ask-human-gate-bypass" "$HOMEPROJ"
assert_ask "redirect to bypass file"                "echo x > ~/.claude/state/ask-human-gate-bypass"
assert_ask "create firewall bypass"                 "echo x > ~/.claude/state/ask-bash-firewall-bypass"
assert_ask "create question-guard bypass"           "echo x > ~/.claude/state/ask-human-question-guard-bypass"
assert_ask "create completion-guard bypass"         "echo x > ~/.claude/state/advisor-completion-guard-bypass"
assert_ask "create prework-guard bypass"            "echo x > ~/.claude/state/advisor-prework-guard-bypass"
assert_ask "prework bypass via cp (per-project)"    "cp /dev/null ~/.claude/projects/-p/state/advisor-prework-guard-bypass"
assert_ask "enable persistent autonomous (echo >)"  "echo x > ~/.claude/state/autonomous-3c-bypass"
assert_ask "enable per-session autonomous (printf >)" "printf '' > ~/.claude/run/autonomous-3c-bypass-abc"
assert_ask "disable memory via blacklist (>>)"      "echo -proj >> ~/.claude/hooks/session-remember/blacklist"
assert_ask "edit memory readonly-list (>>)"         "echo -proj >> ~/.claude/hooks/session-remember/readonly-list"
assert_ask "touch SR DISABLED"                      "touch ~/.claude/hooks/session-remember/DISABLED"
assert_ask "touch SR READONLY"                      "touch ~/.claude/hooks/session-remember/READONLY"
assert_ask "touch SR DISABLED.lean"                 "touch ~/.claude/hooks/session-remember/DISABLED.lean"
assert_ask "overwrite ~/.claude.json"               "echo {} > ~/.claude.json"
assert_ask "append to ~/.bashrc"                    "echo 'alias x=y' >> ~/.bashrc"
assert_ask "write ~/.gitconfig"                     "git config --global user.name x > /dev/null; echo x > ~/.gitconfig"

printf '\n=== ASK: per-repo boundary.json (protected inside / trusted outside) ===\n'
printf '{"protected":["infra/prod"],"trusted_outside":["%s/shared"]}' "$FAKEHOME" > "$PROJ/.claude/boundary.json"
assert_ask    "protected path inside root asks"     "rm -rf infra/prod/x"
assert_ask    "protected path via redirect"         "echo x > infra/prod/vars.tf"
assert_silent "protected path READ is silent"       "cat infra/prod/vars.tf"
assert_silent "trusted_outside write is silent"     "cp dist/x.tgz $FAKEHOME/shared/x.tgz"
rm -f "$PROJ/.claude/boundary.json"
printf '{"protected": [' > "$PROJ/.claude/boundary.json"
assert_ask    "malformed boundary.json → in-root mutate asks (fail closed)" "rm -rf build/"
assert_silent "malformed boundary.json → reads still silent"               "cat README.md"
assert_silent "malformed boundary.json → /tmp still silent"                "echo x > /tmp/y.txt"
rm -f "$PROJ/.claude/boundary.json"
assert_silent "boundary.json absent again → in-root mutate silent"         "rm -rf build/"

printf '\n=== DENY: host-critical targets ===\n'
assert_deny "rm -rf /"                              "rm -rf /"
assert_deny "rm -rf /*"                             "rm -rf /*"
assert_deny "rm -rf /etc/x"                         "rm -rf /etc/nginx"
assert_deny "rm -rf /usr"                           "rm -rf /usr"
assert_deny "rm -rf ~ (home itself)"                "rm -rf ~"
assert_deny "rm -rf \$HOME/"                        "rm -rf \$HOME/"
assert_deny "rm -rf absolute home"                  "rm -rf $FAKEHOME"
assert_deny "chmod -R / "                           "chmod -R 777 /"
assert_deny "dd of=/dev/sda"                        "dd if=/dev/zero of=/dev/sda bs=1M"
assert_deny "redirect into /etc"                    "echo x > /etc/hosts"
assert_deny "rm inside ~/.ssh"                      "rm -f ~/.ssh/known_hosts"

printf '\n=== DENY: credential stores & private keys (reads) — Bash(cat *) allow must NOT defeat these ===\n'
assert_deny "cat ~/.ssh/id_rsa"                     "cat ~/.ssh/id_rsa"
assert_deny "cat abs-path real-home id_rsa (id_rsa anywhere)" "cat /home/user/.ssh/id_rsa"
assert_deny "cat id_ed25519 inside root"            "cat keys/id_ed25519"
assert_deny "cat \$HOME/.ssh/config"                "cat $FAKEHOME/.ssh/config"
assert_deny "cat ~/.aws/credentials"                "cat ~/.aws/credentials"
assert_deny "head ~/.gnupg/x"                       "head ~/.gnupg/secring.gpg"
assert_deny "cat ~/.netrc"                          "cat ~/.netrc"
assert_deny "cat ~/.git-credentials"                "cat ~/.git-credentials"
assert_deny "cat ~/.claude/.credentials.json"       "cat ~/.claude/.credentials.json" "$HOMEPROJ"
assert_deny "cat ~/.claude/mcp/x/.env (home project)" "cat ~/.claude/mcp/<mcp-client-3>/.env" "$HOMEPROJ"
assert_deny "cat *.pem OUTSIDE root"                "cat ~/projects-other/server.pem"
assert_deny "cat *.key OUTSIDE root"                "cat $FAKEHOME/projects-other/tls.key"
assert_deny "grep in ~/.ssh"                        "grep -r Host ~/.ssh/"

printf '\n=== DEFER: settings allow downgrades ASK → silent, never DENY ===\n'
assert_silent "outside rm blessed by exact allow"   "rm -rf ~/projects-other/blessed"
assert_deny   "cat ~/.ssh/id_rsa still denied despite Bash(cat *) allow" "cat ~/.ssh/id_rsa"

printf '\n=== ROOT clamp: cwd inside the HOME repo (git toplevel == $HOME) ===\n'
git -C "$FAKEHOME" init -q 2>/dev/null
assert_ask    "home repo: ~/.claude cwd does NOT whitelist all of HOME" "rm -rf ~/projects-other/x" "$HOMEPROJ"
assert_silent "home repo: ~/.claude cwd is still silent inside ~/.claude" "rm -rf ~/.claude/docs/old" "$HOMEPROJ"
assert_ask    "home repo: self-mod still asks from ~/.claude"  "echo x > ~/.claude/settings.json" "$HOMEPROJ"
assert_ask    "cwd == HOME is boundaryless: mutate asks"       "rm -rf projects-other/x" "$FAKEHOME"
assert_silent "cwd == HOME: SAFE zone still silent"            "echo line >> ~/.claude/logs/hooks-errors.log" "$FAKEHOME"
assert_silent "cwd == HOME: reads still silent"                "cat projects-other/a.txt" "$FAKEHOME"
rm -rf "$FAKEHOME/.git"

printf '\n=== OFF switches ===\n'
OUT=$(jq -n --arg c "rm -rf ~/projects-other/x" --arg w "$PROJ" '{cwd:$w,tool_input:{command:$c}}' | HOME="$FAKEHOME" CLAUDE_BASH_FIREWALL_OFF=1 CLAUDE_BASH_FIREWALL_SETTINGS="$MOCK" CLAUDE_BASH_FIREWALL_LOG="$LOG" bash "$FW" 2>/dev/null)
[[ -z "$OUT" ]] && ok "env off-switch defers" || ko "env off-switch" SILENT
OUT=$(jq -n --arg c "ls -la" --arg w "$PROJ" '{cwd:$w,tool_input:{command:$c}}' | HOME="$FAKEHOME" CLAUDE_BASH_FIREWALL_PYTHON=/nonexistent/python3 CLAUDE_BASH_FIREWALL_SETTINGS="$MOCK" CLAUDE_BASH_FIREWALL_LOG="$LOG" bash "$FW" 2>/dev/null)
[[ "$OUT" == *'"permissionDecision":"ask"'* ]] && ok "python3 missing → fail closed (ask)" || ko "python3 missing" ASK
touch "$FAKEHOME/.claude/state/ask-bash-firewall-bypass"; assert_silent "global sentinel defers" "rm -rf ~/projects-other/x"; rm -f "$FAKEHOME/.claude/state/ask-bash-firewall-bypass"
SLUG=$(printf '%s' "$PROJ" | tr '/' '-'); mkdir -p "$FAKEHOME/.claude/projects/$SLUG/state"; touch "$FAKEHOME/.claude/projects/$SLUG/state/ask-bash-firewall-bypass"
assert_silent "per-project sentinel (matching cwd) defers" "rm -rf ~/projects-other/x"
assert_ask    "per-project sentinel does NOT leak to other cwd" "rm -rf ~/projects-other/x" "$FAKEHOME/shared"
rm -f "$FAKEHOME/.claude/projects/$SLUG/state/ask-bash-firewall-bypass"

# ── per-session bypass (sentinel: $HOME/.claude/run/ask-bash-firewall-bypass-<sid>) ──
# Added 2026-08-30 for the /gates-bypass uniform sentinel model.
run_fw_sess(){ OUT=$(jq -n --arg c "$1" --arg w "${2:-$PROJ}" --arg s "$3" \
  '{cwd:$w,permission_mode:"bypassPermissions",session_id:$s,tool_input:{command:$c}}' \
  | HOME="$FAKEHOME" CLAUDE_BASH_FIREWALL_SETTINGS="$MOCK" CLAUDE_BASH_FIREWALL_LOG="$LOG" bash "$FW" 2>/dev/null); }
mkdir -p "$FAKEHOME/.claude/run"
touch "$FAKEHOME/.claude/run/ask-bash-firewall-bypass-sfw1"
run_fw_sess "rm -rf ~/projects-other/x" "$PROJ" sfw1
[[ -z "$OUT" ]] && ok "per-session sentinel (matching session_id) defers" || ko "per-session sentinel" SILENT
run_fw_sess "rm -rf ~/projects-other/x" "$PROJ" other-session
[[ "$OUT" == *'"permissionDecision":"ask"'* ]] && ok "per-session sentinel does NOT leak to other session_id" || ko "per-session leak" ASK
rm -f "$FAKEHOME/.claude/run/ask-bash-firewall-bypass-sfw1"

# ── F-1.2: seeded env vars (TMPDIR, CLAUDE_CODE_SESSION_ID) fold too, via run_fw_sess ──
run_fw_sess "rm ~/.claude/run/active-plan-\$CLAUDE_CODE_SESSION_ID" "$PROJ" seedtest1
[[ -z "$OUT" ]] && ok "seeded \$CLAUDE_CODE_SESSION_ID folds → resolves under run/ SAFE → silent" || ko "seeded session var fold (silent)" SILENT
run_fw_sess "touch ~/.claude/run/ask-human-gate-bypass-\$CLAUDE_CODE_SESSION_ID" "$PROJ" seedtest1
[[ "$OUT" == *'"permissionDecision":"ask"'* ]] && ok "seeded var folds but resolved path still hits *-bypass-* self-mod tier" || ko "seeded var fold → selfmod ask" ASK

# ── SELFMOD generalization: run/<family>-bypass-<sid> mutation asks, never silent ──
# SAFE marks ~/.claude/run silent by default; SELFMOD's *-bypass-* entry must override that for
# EVERY family's session sentinel, not just autonomous-3c (2026-08-30 /gates-bypass migration).
assert_ask "touch of a gate-bypass session sentinel under run/ is ask, not silent" \
  "touch ~/.claude/run/ask-human-question-guard-bypass-xyz123"

printf '\n=== output contract ===\n'
run_fw "rm -rf ~/projects-other/x"
printf '%s' "$OUT" | jq -e '.hookSpecificOutput.permissionDecision=="ask"' >/dev/null 2>&1 && ok "ask output is valid JSON" || ko "ask JSON" JSON
printf '%s' "$OUT" | jq -r '.hookSpecificOutput.permissionDecisionReason' 2>/dev/null | grep -q 'projects-other' && ok "reason names the offending path" || ko "reason names path" PATH
run_fw "cat ~/.ssh/id_rsa"
printf '%s' "$OUT" | jq -e '.hookSpecificOutput.permissionDecision=="deny"' >/dev/null 2>&1 && ok "deny output is valid JSON" || ko "deny JSON" JSON
grep -q ' | ASK | ' "$LOG" 2>/dev/null && ok "ask written to suggestions log" || ko "log ASK" LOG
grep -q ' | DENY | ' "$LOG" 2>/dev/null && ok "deny written to suggestions log" || ko "log DENY" LOG

rm -rf "$TMP"
printf '\n─────────────────────────────\n'
if [[ $FAIL -eq 0 ]]; then printf "${C_G}All %d boundary-gate tests passed${C_0}\n" "$PASS"
else printf "${C_R}%d/%d FAILED${C_0}\n" "$FAIL" "$((PASS+FAIL))"; for f in "${FAILS[@]}"; do printf '  • %s\n' "$f"; done; exit 1; fi
