#!/usr/bin/env bash
# Tests for ask-human-question-guard.sh (Stop-hook backstop)
set -uo pipefail

HOOK="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/ask-human-question-guard.sh"
C_G='\033[0;32m'; C_R='\033[0;31m'; C_0='\033[0m'
PASS=0; FAIL=0; declare -a FAILS=()
TMP=$(mktemp -d); TR="$TMP/t.jsonl"

U='{"type":"user","message":{"role":"user","content":[{"type":"text","text":"go"}]}}'
think='{"type":"assistant","message":{"role":"assistant","content":[{"type":"thinking","thinking":"hm"}]}}'
atext(){ jq -nc --arg t "$1" '{type:"assistant",message:{role:"assistant",content:[{type:"text",text:$t}]}}'; }
auq='{"type":"assistant","message":{"role":"assistant","content":[{"type":"tool_use","name":"AskUserQuestion","input":{}}]}}'

mk(){ : > "$TR"; for l in "$@"; do printf '%s\n' "$l" >> "$TR"; done; }
run(){ jq -n --arg t "$1" --argjson s "${2:-false}" '{transcript_path:$t,stop_hook_active:$s}' | bash "$HOOK" >/dev/null 2>&1; echo $?; }
ec(){ local d="$1" exp="$2" got="$3"; if [[ "$got" == "$exp" ]]; then PASS=$((PASS+1)); printf "${C_G}✓${C_0} %s\n" "$d"; else FAIL=$((FAIL+1)); FAILS+=("$d"); printf "${C_R}✗${C_0} %s (exp $exp got $got)\n" "$d"; fi; }

printf '\n=== BLOCK: free-text question, no AskUserQuestion ===\n'
mk "$U" "$(atext 'Shall I proceed?')";                         ec "trailing question → block (2)" 2 "$(run "$TR")"
mk "$U" "$(atext 'Some explanation here.\nWhich option do you want?')"; ec "multi-line ending in ? → block" 2 "$(run "$TR")"

printf '\n=== PASS: not a free-text question ===\n'
mk "$U" "$(atext 'Done. All 27 tests pass.')";                 ec "statement → pass (0)" 0 "$(run "$TR")"
mk "$U" "$(atext 'Pick one?')" "$auq";                          ec "AskUserQuestion used → pass" 0 "$(run "$TR")"
mk "$U" "$think" "$(atext 'ok.')";                              ec "thinking block ignored → pass" 0 "$(run "$TR")"
mk "$U" "$(atext 'See:\n```\nis this code?\n```')";             ec "last line code fence → pass" 0 "$(run "$TR")"
mk "$U" "$(atext '> a quoted question?')";                      ec "blockquote line → pass" 0 "$(run "$TR")"

printf '\n=== guards ===\n'
mk "$U" "$(atext 'proceed?')";                                  ec "stop_hook_active=true → pass (no loop)" 0 "$(run "$TR" true)"
ec "missing transcript → pass" 0 "$(run "$TMP/nope.jsonl")"

printf '\n=== OFF: sentinel bypass (parity with gate/firewall) ===\n'
FAKEHOME="$TMP/home"; mkdir -p "$FAKEHOME/.claude/state" "$FAKEHOME/.claude/projects/-proj/state"
run_home(){ jq -n --arg t "$1" --arg w "${2:-}" '{transcript_path:$t,stop_hook_active:false} + (if $w!="" then {cwd:$w} else {} end)' | HOME="$FAKEHOME" bash "$HOOK" >/dev/null 2>&1; echo $?; }
mk "$U" "$(atext 'proceed?')"
touch "$FAKEHOME/.claude/state/ask-human-question-guard-bypass"
ec "global sentinel -> pass (0)" 0 "$(run_home "$TR")"
rm -f "$FAKEHOME/.claude/state/ask-human-question-guard-bypass"
touch "$FAKEHOME/.claude/projects/-proj/state/ask-human-question-guard-bypass"
ec "per-project sentinel (matching cwd) -> pass" 0 "$(run_home "$TR" /proj)"
ec "per-project sentinel does NOT affect other cwd -> block" 2 "$(run_home "$TR" /other)"
rm -f "$FAKEHOME/.claude/projects/-proj/state/ask-human-question-guard-bypass"

# ── per-session bypass (sentinel: $HOME/.claude/run/ask-human-question-guard-bypass-<sid>) ──
# Added 2026-08-30 for the /gates-bypass uniform sentinel model.
mkdir -p "$FAKEHOME/.claude/run"
run_home_sess(){ jq -n --arg t "$1" --arg s "$2" '{transcript_path:$t,stop_hook_active:false,session_id:$s}' | HOME="$FAKEHOME" bash "$HOOK" >/dev/null 2>&1; echo $?; }
mk "$U" "$(atext 'proceed?')"
touch "$FAKEHOME/.claude/run/ask-human-question-guard-bypass-sqg1"
ec "per-session sentinel (matching session_id) -> pass" 0 "$(run_home_sess "$TR" sqg1)"
ec "per-session sentinel does NOT affect other session_id -> block" 2 "$(run_home_sess "$TR" other-session)"
rm -f "$FAKEHOME/.claude/run/ask-human-question-guard-bypass-sqg1"

rm -rf "$TMP"
printf '\n─────────────────────────────\n'
if [[ $FAIL -eq 0 ]]; then printf "${C_G}All %d question-guard tests passed${C_0}\n" "$PASS"
else printf "${C_R}%d/%d FAILED${C_0}\n" "$FAIL" "$((PASS+FAIL))"; for f in "${FAILS[@]}"; do printf '  • %s\n' "$f"; done; exit 1; fi
