#!/usr/bin/env bash
# Tests for ask-human-gate triplet: reset / track / block
# Requires GATE_DIR_OVERRIDE support in each gate script (patched via this TDD cycle).
set -uo pipefail

HOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESET_SH="$HOOKS_DIR/ask-human-gate-arm.sh"
TRACK_SH="$HOOKS_DIR/ask-human-gate-track.sh"
BLOCK_SH="$HOOKS_DIR/ask-human-gate-block.sh"

C_GREEN='\033[0;32m'; C_RED='\033[0;31m'; C_YELLOW='\033[1;33m'; C_RESET='\033[0m'
PASS=0; FAIL=0
declare -a FAILURES=()

pass()          { PASS=$((PASS+1)); printf "${C_GREEN}✓${C_RESET} %s\n" "$1"; }
fail()          { FAIL=$((FAIL+1)); FAILURES+=("$1: $2"); printf "${C_RED}✗${C_RESET} %s\n  ${C_YELLOW}→ %s${C_RESET}\n" "$1" "$2"; }
assert_equals() { [[ "$2" == "$3" ]] && pass "$1" || fail "$1" "expected='$2' got='$3'"; }
assert_contains() { printf '%s' "$3" | grep -qF "$2" && pass "$1" || fail "$1" "expected to contain '$2'"; }

mk_home() { local h; h=$(mktemp -d); mkdir -p "$h/.claude/state" "$h/.claude/logs"; echo "$h"; }

# ── ask-human-gate-arm.sh ────────────────────────────────────────────────────
printf '\n=== ask-human-gate-arm.sh ===\n'

# T1: basic — turn token written into the override gate dir (not real /tmp/ask-human-gate)
T1_G=$(mktemp -d); T1_H=$(mk_home)
printf '{"session_id":"t1"}' | HOME="$T1_H" GATE_DIR_OVERRIDE="$T1_G" bash "$RESET_SH"
assert_equals "T1: turn token written to override dir" "t1" "$(ls "$T1_G/turns/" 2>/dev/null)"
rm -rf "$T1_G" "$T1_H"

# T2: bypass file present — skip write
T2_G=$(mktemp -d); T2_H=$(mk_home)
touch "$T2_H/.claude/state/ask-human-gate-bypass"
printf '{"session_id":"t2"}' | HOME="$T2_H" GATE_DIR_OVERRIDE="$T2_G" bash "$RESET_SH"
assert_equals "T2: bypass skips write" "" "$(ls "$T2_G/turns/" 2>/dev/null)"
rm -rf "$T2_G" "$T2_H"

# T3: empty stdin — no write, exit 0
T3_G=$(mktemp -d); T3_H=$(mk_home)
printf '' | HOME="$T3_H" GATE_DIR_OVERRIDE="$T3_G" bash "$RESET_SH"
assert_equals "T3: empty input no write" "" "$(ls "$T3_G/turns/" 2>/dev/null)"
rm -rf "$T3_G" "$T3_H"

# T4: JSON with no session_id field — no write
T4_G=$(mktemp -d); T4_H=$(mk_home)
printf '{"other":"value"}' | HOME="$T4_H" GATE_DIR_OVERRIDE="$T4_G" bash "$RESET_SH"
assert_equals "T4: no session_id no write" "" "$(ls "$T4_G/turns/" 2>/dev/null)"
rm -rf "$T4_G" "$T4_H"

# ── ask-human-gate-track.sh ───────────────────────────────────────────────────
printf '\n=== ask-human-gate-track.sh ===\n'

# T5: basic — sentinel written into override dir
T5_G=$(mktemp -d); T5_H=$(mk_home)
printf '{"session_id":"t5"}' | HOME="$T5_H" GATE_DIR_OVERRIDE="$T5_G" bash "$TRACK_SH"
assert_equals "T5: sentinel written to override dir" "t5" "$(ls "$T5_G/" 2>/dev/null)"
rm -rf "$T5_G" "$T5_H"

# T6: empty stdin — no sentinel written
T6_G=$(mktemp -d); T6_H=$(mk_home)
printf '' | HOME="$T6_H" GATE_DIR_OVERRIDE="$T6_G" bash "$TRACK_SH"
assert_equals "T6: empty input no sentinel" "" "$(ls "$T6_G/" 2>/dev/null)"
rm -rf "$T6_G" "$T6_H"

# T7: JSON with no session_id — no sentinel written
T7_G=$(mktemp -d); T7_H=$(mk_home)
printf '{"other":"value"}' | HOME="$T7_H" GATE_DIR_OVERRIDE="$T7_G" bash "$TRACK_SH"
assert_equals "T7: no session_id no sentinel" "" "$(ls "$T7_G/" 2>/dev/null)"
rm -rf "$T7_G" "$T7_H"

# ── ask-human-gate-block.sh ───────────────────────────────────────────────────
# Timestamps are hardcoded integers to avoid same-second collisions with real date +%s.
printf '\n=== ask-human-gate-block.sh ===\n'

# T8: no turn token — exit 0 (subagent path)
T8_G=$(mktemp -d); T8_H=$(mk_home)
printf '{"session_id":"t8"}' | HOME="$T8_H" GATE_DIR_OVERRIDE="$T8_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T8: no turn token → exit 0 (subagent)" "0" "$?"
rm -rf "$T8_G" "$T8_H"

# T9: sentinel time = turn time (boundary: -ge) → exit 0 (gate cleared)
T9_G=$(mktemp -d); T9_H=$(mk_home)
mkdir -p "$T9_G/turns"
printf '100' > "$T9_G/turns/t9"
printf '100' > "$T9_G/t9"
printf '{"session_id":"t9"}' | HOME="$T9_H" GATE_DIR_OVERRIDE="$T9_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T9: sentinel=turn → exit 0 (cleared, boundary)" "0" "$?"
rm -rf "$T9_G" "$T9_H"

# T10: sentinel time < turn time → exit 2 (stale gate)
T10_G=$(mktemp -d); T10_H=$(mk_home)
mkdir -p "$T10_G/turns"
printf '100' > "$T10_G/turns/t10"
printf '50'  > "$T10_G/t10"
printf '{"session_id":"t10"}' | HOME="$T10_H" GATE_DIR_OVERRIDE="$T10_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T10: sentinel<turn → exit 2 (stale)" "2" "$?"
rm -rf "$T10_G" "$T10_H"

# T11: turn token exists, no sentinel → exit 2 (gate never cleared this turn)
T11_G=$(mktemp -d); T11_H=$(mk_home)
mkdir -p "$T11_G/turns"
printf '100' > "$T11_G/turns/t11"
printf '{"session_id":"t11"}' | HOME="$T11_H" GATE_DIR_OVERRIDE="$T11_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T11: no sentinel → exit 2 (never cleared)" "2" "$?"
rm -rf "$T11_G" "$T11_H"

# T12: bypass file → exit 0 even with stale gate
T12_G=$(mktemp -d); T12_H=$(mk_home)
touch "$T12_H/.claude/state/ask-human-gate-bypass"
mkdir -p "$T12_G/turns"
printf '100' > "$T12_G/turns/t12"
printf '{"session_id":"t12"}' | HOME="$T12_H" GATE_DIR_OVERRIDE="$T12_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T12: bypass → exit 0 despite stale gate" "0" "$?"
rm -rf "$T12_G" "$T12_H"

# T13: empty stdin → exit 0
T13_G=$(mktemp -d); T13_H=$(mk_home)
printf '' | HOME="$T13_H" GATE_DIR_OVERRIDE="$T13_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T13: empty input → exit 0" "0" "$?"
rm -rf "$T13_G" "$T13_H"

# T14: JSON with no session_id → exit 0
T14_G=$(mktemp -d); T14_H=$(mk_home)
printf '{"other":"val"}' | HOME="$T14_H" GATE_DIR_OVERRIDE="$T14_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T14: no session_id → exit 0" "0" "$?"
rm -rf "$T14_G" "$T14_H"

# ── per-project bypass (sentinel: $HOME/.claude/projects/<slug>/state/ask-human-gate-bypass) ──
printf '\n=== per-project bypass ===\n'

# T15 (arm): per-project sentinel present → skip turn token write
T15_G=$(mktemp -d); T15_H=$(mk_home)
mkdir -p "$T15_H/.claude/projects/-stack-projects-phorge/state"
touch "$T15_H/.claude/projects/-stack-projects-phorge/state/ask-human-gate-bypass"
printf '{"session_id":"t15","cwd":"/path/to/your/project/projects/phorge"}' | HOME="$T15_H" GATE_DIR_OVERRIDE="$T15_G" bash "$RESET_SH"
assert_equals "T15: per-project bypass skips turn token" "" "$(ls "$T15_G/turns/" 2>/dev/null)"
rm -rf "$T15_G" "$T15_H"

# T16 (block): per-project sentinel + stale gate → exit 0
T16_G=$(mktemp -d); T16_H=$(mk_home)
mkdir -p "$T16_H/.claude/projects/-stack-projects-phorge/state" "$T16_G/turns"
touch "$T16_H/.claude/projects/-stack-projects-phorge/state/ask-human-gate-bypass"
printf '100' > "$T16_G/turns/t16"
printf '50'  > "$T16_G/t16"
printf '{"session_id":"t16","cwd":"/path/to/your/project/projects/phorge"}' | HOME="$T16_H" GATE_DIR_OVERRIDE="$T16_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T16: per-project bypass → exit 0 despite stale gate" "0" "$?"
rm -rf "$T16_G" "$T16_H"

# T17 (block): sentinel for a DIFFERENT project → gate still enforces (exit 2)
T17_G=$(mktemp -d); T17_H=$(mk_home)
mkdir -p "$T17_H/.claude/projects/-stack-projects-other/state" "$T17_G/turns"
touch "$T17_H/.claude/projects/-stack-projects-other/state/ask-human-gate-bypass"
printf '100' > "$T17_G/turns/t17"   # turn token, no sentinel → would be exit 2
printf '{"session_id":"t17","cwd":"/path/to/your/project/projects/phorge"}' | HOME="$T17_H" GATE_DIR_OVERRIDE="$T17_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T17: bypass for other project → still enforces (exit 2)" "2" "$?"
rm -rf "$T17_G" "$T17_H"

# ── subagent-driven bypass (markers: $GATE_DIR/subagent/<sid>/<agent_id>) ──
printf '\n=== subagent-driven bypass ===\n'

# T18 (block): fresh subagent marker + stale gate → exit 0 (subagent active)
T18_G=$(mktemp -d); T18_H=$(mk_home)
mkdir -p "$T18_G/turns" "$T18_G/subagent/t18"
printf '100' > "$T18_G/turns/t18"; printf '50' > "$T18_G/t18"   # stale gate
: > "$T18_G/subagent/t18/agentA"                                 # fresh marker
printf '{"session_id":"t18","cwd":"/x"}' | HOME="$T18_H" GATE_DIR_OVERRIDE="$T18_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T18: fresh subagent marker → exit 0 despite stale gate" "0" "$?"
rm -rf "$T18_G" "$T18_H"

# T19 (block): STALE subagent marker (>120min) → gate still enforces (exit 2)
T19_G=$(mktemp -d); T19_H=$(mk_home)
mkdir -p "$T19_G/turns" "$T19_G/subagent/t19"
printf '100' > "$T19_G/turns/t19"; printf '50' > "$T19_G/t19"
: > "$T19_G/subagent/t19/agentStale"; touch -d '3 hours ago' "$T19_G/subagent/t19/agentStale"
printf '{"session_id":"t19","cwd":"/x"}' | HOME="$T19_H" GATE_DIR_OVERRIDE="$T19_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T19: stale marker (>120min) → still enforces (exit 2)" "2" "$?"
rm -rf "$T19_G" "$T19_H"

# T20 (block): two parallel markers, one removed, other still fresh → exit 0
T20_G=$(mktemp -d); T20_H=$(mk_home)
mkdir -p "$T20_G/turns" "$T20_G/subagent/t20"
printf '100' > "$T20_G/turns/t20"; printf '50' > "$T20_G/t20"
: > "$T20_G/subagent/t20/agentB"   # agentA already stopped/removed; agentB still active
printf '{"session_id":"t20","cwd":"/x"}' | HOME="$T20_H" GATE_DIR_OVERRIDE="$T20_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T20: one of two parallel markers still active → exit 0" "0" "$?"
rm -rf "$T20_G" "$T20_H"

# T21 (start): SubagentStart creates a marker keyed by session_id/agent_id
T21_G=$(mktemp -d); T21_H=$(mk_home)
printf '{"session_id":"t21","agent_id":"aid21","agent_type":"Explore","cwd":"/x"}' \
  | HOME="$T21_H" GATE_DIR_OVERRIDE="$T21_G" bash "$HOOKS_DIR/subagent-start-context.sh" >/dev/null 2>&1
assert_equals "T21: SubagentStart creates marker" "1" "$([[ -f "$T21_G/subagent/t21/aid21" ]] && echo 1 || echo 0)"
rm -rf "$T21_G" "$T21_H"

# T22 (stop): SubagentStop removes the marker even when transcript is missing
T22_G=$(mktemp -d); T22_H=$(mk_home)
mkdir -p "$T22_G/subagent/t22"; : > "$T22_G/subagent/t22/aid22"
printf '{"session_id":"t22","agent_id":"aid22","agent_type":"Explore","cwd":"/x"}' \
  | HOME="$T22_H" GATE_DIR_OVERRIDE="$T22_G" bash "$HOOKS_DIR/subagent-stop-status.sh" >/dev/null 2>&1
assert_equals "T22: SubagentStop removes marker (no transcript)" "0" "$([[ -f "$T22_G/subagent/t22/aid22" ]] && echo 1 || echo 0)"
rm -rf "$T22_G" "$T22_H"

# ── per-session bypass (sentinel: $HOME/.claude/run/ask-human-gate-bypass-<sid>) ──
# Added 2026-08-30 for the /gates-bypass uniform sentinel model.
printf '\n=== per-session bypass ===\n'

# T23 (arm): per-session sentinel present → skip turn token write
T23_G=$(mktemp -d); T23_H=$(mk_home)
mkdir -p "$T23_H/.claude/run"
touch "$T23_H/.claude/run/ask-human-gate-bypass-t23"
printf '{"session_id":"t23","cwd":"/x"}' | HOME="$T23_H" GATE_DIR_OVERRIDE="$T23_G" bash "$RESET_SH"
assert_equals "T23: per-session bypass skips turn token" "" "$(ls "$T23_G/turns/" 2>/dev/null)"
rm -rf "$T23_G" "$T23_H"

# T24 (block): per-session sentinel + stale gate → exit 0
T24_G=$(mktemp -d); T24_H=$(mk_home)
mkdir -p "$T24_H/.claude/run" "$T24_G/turns"
touch "$T24_H/.claude/run/ask-human-gate-bypass-t24"
printf '100' > "$T24_G/turns/t24"
printf '50'  > "$T24_G/t24"
printf '{"session_id":"t24","cwd":"/x"}' | HOME="$T24_H" GATE_DIR_OVERRIDE="$T24_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T24: per-session bypass → exit 0 despite stale gate" "0" "$?"
rm -rf "$T24_G" "$T24_H"

# T25 (block): sentinel for a DIFFERENT session id → gate still enforces (exit 2)
T25_G=$(mktemp -d); T25_H=$(mk_home)
mkdir -p "$T25_H/.claude/run" "$T25_G/turns"
touch "$T25_H/.claude/run/ask-human-gate-bypass-other-session"
printf '100' > "$T25_G/turns/t25"   # turn token, no sentinel for t25 → would be exit 2
printf '{"session_id":"t25","cwd":"/x"}' | HOME="$T25_H" GATE_DIR_OVERRIDE="$T25_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T25: bypass for other session → still enforces (exit 2)" "2" "$?"
rm -rf "$T25_G" "$T25_H"

# ── Summary ───────────────────────────────────────────────────────────────────
printf '\n─────────────────────────────────────────────\n'
TOTAL=$((PASS + FAIL))
if [[ $FAIL -eq 0 ]]; then
  printf "${C_GREEN}All %d tests passed${C_RESET}\n" "$TOTAL"
else
  printf "${C_RED}%d/%d tests FAILED${C_RESET}\n" "$FAIL" "$TOTAL"
  for f in "${FAILURES[@]}"; do printf '  • %s\n' "$f"; done
  exit 1
fi
