#!/usr/bin/env bash
# Stop hook: print context usage bar to stderr and write to status file.
# Reads stdin JSON: {session_id, transcript_path, cwd, hook_event_name}
# >&2 output: zero tokens (Claude never sees hook stderr).
# Status file (~/.claude/run/status-context.txt): read by cc/Screen status pane.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/log-helpers.sh"   2>/dev/null || true
# shellcheck disable=SC1091
source "$SCRIPT_DIR/session-status.sh" 2>/dev/null || {
  log_obs ERROR stop-context-bar "failed to source session-status.sh" 2>/dev/null || true
  exit 0
}

_RUN_DIR="${HOME}/.claude/run"

INPUT=$(cat 2>/dev/null || true)
TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
SESSION_ID_IN=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
CWD_IN=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)

# Persist the permission mode for the statusline (whose own payload has no such field — verified
# 2026-08-29). Written only when stdin actually carries a non-empty mode: an input without the
# field must never clobber a valid earlier value. Same file the PostToolUse trigger writes.
PMODE_IN=$(printf '%s' "$INPUT" | jq -r '.permission_mode // empty' 2>/dev/null || true)
if [[ -n "${SESSION_ID_IN:-}" && -n "${PMODE_IN:-}" ]]; then
  mkdir -p "$_RUN_DIR" 2>/dev/null || true
  printf '%s\n' "$PMODE_IN" > "${_RUN_DIR}/permission-mode-${SESSION_ID_IN}" 2>/dev/null || true
fi

# P0-2: this session's own context file (read for own /clear+baseline history, written as the
# source statusline reads). Dual-written with the global fixed-name file at the end of the
# script. Falls back to the global file when stdin carries no session id (backward compat).
if [[ -n "${SESSION_ID_IN:-}" ]]; then
  _CTX_PATH="${_RUN_DIR}/status-context-${SESSION_ID_IN}.txt"
else
  _CTX_PATH="${_RUN_DIR}/status-context.txt"
fi

if [[ -z "$TRANSCRIPT" || ! -f "$TRANSCRIPT" ]]; then
  log_obs WARN stop-context-bar "no transcript_path in stdin or file missing" 2>/dev/null || true
  exit 0
fi

# Session-ID guard removed: Claude Code assigns new session IDs to Skill sub-sessions
# (e.g. ask-human skill) within the same conversation, causing the old mismatch check
# to permanently block all updates after the first Skill invocation. The IS_ESTIMATE
# flag in the payload is sufficient for compaction handling without a guard here.
_STATUS_CTX_EARLY="$_CTX_PATH"

# Parse transcript
if ! ss_parse_transcript "$TRANSCRIPT"; then
  log_obs WARN stop-context-bar "transcript parse failed: $TRANSCRIPT" 2>/dev/null || true
  exit 0
fi

WINDOW=$(ss_window_from_state "$SS_MODEL" "$SESSION_ID_IN")
BUFFER=$(ss_buffer_size "$WINDOW")

# IMP-5: last turn duration (human→assistant timestamp diff; 0 when unavailable)
_TURN_DUR=0
_TURN_DUR=$(jq -Rs '
  split("\n") |
  map(select(length > 0) | try fromjson catch null) |
  map(select(. != null and (.timestamp? != null))) |
  . as $msgs |
  ([$msgs[] | select(.type? == "assistant")] | last | .timestamp? // null) as $ta |
  ([$msgs[] | select(.type? == "user")]      | last | .timestamp? // null) as $th |
  if ($ta != null and $th != null) then
    (($ta | split(".")[0] + "Z" | try fromdateiso8601 catch 0) -
     ($th | split(".")[0] + "Z" | try fromdateiso8601 catch 0)) |
    if . < 0 then 0 else . end
  else 0 end
' < "$TRANSCRIPT" 2>/dev/null || echo 0)
_TURN_DUR="${_TURN_DUR//[^0-9]/}"; _TURN_DUR="${_TURN_DUR:-0}"

ss_context_bar "$SS_INPUT_TOKENS" "$WINDOW" "$BUFFER" "$SS_OUTPUT_SUM" >&2 \
  || { log_obs WARN stop-context-bar "ss_context_bar failed (exit $?)" 2>/dev/null || true; exit 0; }

# Skip file write when tokens are 0 — avoids overwriting a valid display with blank state
[[ "$SS_INPUT_TOKENS" -eq 0 ]] && {
  log_obs INFO stop-context-bar "ctx=0 (skipping file write) model=${SS_MODEL}" 2>/dev/null || true
  exit 0
}

# ── Save startup baseline on first real ctx update ────────────────────────────
# When the session transitions from IS_ESTIMATE:true → real data, save the token
# count as a baseline for the next session's startup display. Accurate because it
# captures the actual startup ctx (system prompt + tools + memory) right after the
# first API call — before accumulated tool responses inflate the count.
# Cap at 55k: prevents a tool-heavy first turn from poisoning the baseline with
# a mid-session token count (the real startup ctx is ~38-42k on this machine).
_PREV_IS_ESTIMATE=$(grep "^IS_ESTIMATE:" "$_CTX_PATH" 2>/dev/null \
  | head -1 | cut -d: -f2- || true)
# Save startup baseline on first real ctx update (_PREV_IS_ESTIMATE guard ensures once per session).
# No token cap: sonnet startup is ~131K which exceeds the old 55K cap — cap removed so large
# models calibrate correctly. The guard is sufficient to prevent mid-session poisoning.
if [[ "$_PREV_IS_ESTIMATE" == "true" ]]; then
  printf '%s\n%s\n' "$SS_INPUT_TOKENS" "${SS_MODEL}" > "${_RUN_DIR}/startup-ctx-baseline.txt" 2>/dev/null || true
  log_obs INFO stop-context-bar "startup baseline saved: ${SS_INPUT_TOKENS} tokens (model=${SS_MODEL})" 2>/dev/null || true
fi

# Persist actual model so next session's banner shows the real model, not the settings.json alias
[[ -n "${SS_MODEL:-}" ]] && printf '%s\n' "$SS_MODEL" > "${_RUN_DIR}/actual-model.txt" 2>/dev/null || true

# ── Write KEY:VALUE data to status file (cc-status-pane.sh renders the box) ──
_STATUS_CTX="$_CTX_PATH"
_STATUS_TMP=$(mktemp "${_RUN_DIR}/.status-ctx.XXXXXX" 2>/dev/null || mktemp)

_EFFECTIVE=$(( WINDOW - BUFFER ))
[[ $_EFFECTIVE -le 0 ]] && _EFFECTIVE=1
_FREE=$(( _EFFECTIVE - SS_INPUT_TOKENS ))
[[ $_FREE -lt 0 ]] && _FREE=0
_PCT=$(( SS_INPUT_TOKENS * 100 / _EFFECTIVE ))
[[ $_PCT -gt 100 ]] && _PCT=100

_INPUT_K=$(( SS_INPUT_TOKENS / 1000 ))
_EFF_K=$(( _EFFECTIVE / 1000 ))
_FREE_K=$(( _FREE / 1000 ))
_BUF_K=$(( BUFFER / 1000 ))
_SUM_K=$(( SS_OUTPUT_SUM / 1000 ))

# BUG-7: compact URGENCY to emoji only; add yellow 🟡 third level (30-60K free)
_URGENCY=""
(( _FREE_K >= 30 && _FREE_K < 60 )) && _URGENCY="🟡"
(( _FREE_K < 30 && _FREE_K >= 10 )) && _URGENCY="⚠"
(( _FREE_K < 10 ))                   && _URGENCY="🔴"

# IMP-10: /clear indicator — count turns down from 3 when context drops >40 points
_STATUS_CTX="$_CTX_PATH"
_PREV_PCT=$(grep "^PCT:" "${_STATUS_CTX}" 2>/dev/null | head -1 | cut -d: -f2- | tr -d '[:space:]' || echo 0)
_PREV_PCT="${_PREV_PCT//[^0-9]/}"; _PREV_PCT="${_PREV_PCT:-0}"
_PREV_EST=$(grep "^IS_ESTIMATE:" "${_STATUS_CTX}" 2>/dev/null | head -1 | cut -d: -f2- | tr -d '[:space:]' || echo true)
_PREV_CLEAR_CTR=$(grep "^CLEAR_CTR:" "${_STATUS_CTX}" 2>/dev/null | head -1 | cut -d: -f2- | tr -d '[:space:]' || echo 0)
_PREV_CLEAR_CTR="${_PREV_CLEAR_CTR//[^0-9]/}"; _PREV_CLEAR_CTR="${_PREV_CLEAR_CTR:-0}"
_CLEAR_CTR=0
# F7: skip /clear detection when transitioning from startup estimate to real data —
# that PCT drop is an artifact of the estimate, not a genuine /clear or context reset.
if [[ "${_PREV_EST:-true}" != "true" ]] && (( (_PREV_PCT - _PCT) > 40 && _PREV_PCT > 40 )) 2>/dev/null; then
  _CLEAR_CTR=3
elif [[ "${_PREV_CLEAR_CTR:-0}" -gt 0 ]] 2>/dev/null; then
  _CLEAR_CTR=$(( _PREV_CLEAR_CTR - 1 ))
fi

{
  printf 'SESSION_ID:%s\n' "${SESSION_ID_IN}"
  printf 'PCT:%s\n'        "${_PCT}"
  printf 'INPUT_K:%s\n'    "${_INPUT_K}"
  printf 'EFF_K:%s\n'      "${_EFF_K}"
  printf 'FREE_K:%s\n'     "${_FREE_K}"
  printf 'BUF_K:%s\n'      "${_BUF_K}"
  printf 'SUM_K:%s\n'      "${_SUM_K}"
  printf 'URGENCY:%s\n'    "${_URGENCY}"
  printf 'IS_ESTIMATE:false\n'
  printf 'TURNS:%s\n'      "${SS_TURNS:-0}"
  printf 'TURN_DUR:%s\n'   "${_TURN_DUR}"
  printf 'CLEAR_CTR:%s\n'  "${_CLEAR_CTR}"
} > "$_STATUS_TMP"
mv -f "$_STATUS_TMP" "$_STATUS_CTX" 2>/dev/null || true
# P0-2 dual-write: also refresh the global fixed-name file for backward compat + external
# readers (best-effort foreground = last writer). Skipped when _CTX_PATH already is the global.
[[ "$_CTX_PATH" != "${_RUN_DIR}/status-context.txt" ]] \
  && cp -f "$_CTX_PATH" "${_RUN_DIR}/status-context.txt" 2>/dev/null || true
# Mark session as cleanly stopped (session-start-banner uses this to distinguish
# normal process exit from compaction — compaction fires SessionStart BEFORE Stop).
printf '%s\n' "${SESSION_ID_IN}" > "${_RUN_DIR}/last-stop-session.txt" 2>/dev/null || true

# Desktop notification at context thresholds (one-shot per level; level file reset on session
# start). Keyed per-session (falls back to the global file only when stdin carries no
# session_id): a shared file meant one session's notification suppressed another's, and
# genuinely-full sessions could go silent after a concurrent session's alarm already fired.
if command -v notify-send &>/dev/null; then
  if [[ -n "${SESSION_ID_IN:-}" ]]; then
    _NOTIF_FILE="${_RUN_DIR}/ctx-notified-${SESSION_ID_IN}.txt"
  else
    _NOTIF_FILE="${_RUN_DIR}/ctx-notified.txt"
  fi
  _NOTIF_LEVEL=$(cat "$_NOTIF_FILE" 2>/dev/null || true)
  _NOTIF_LEVEL="${_NOTIF_LEVEL//[^0-9]/}"
  _NOTIF_LEVEL="${_NOTIF_LEVEL:-0}"
  # Name the resolved window in the text itself: a bare "9K free" with no window stated is
  # exactly what makes a genuine 1M alarm read as a 200K false alarm from the outside — the
  # notification is now self-evidencing instead of requiring a statusline cross-check.
  _WIN_TAG="${_INPUT_K}K/${_EFF_K}K"
  (( WINDOW >= 900000 )) && _WIN_TAG="${_WIN_TAG} of 1M window" || _WIN_TAG="${_WIN_TAG} of $(( WINDOW / 1000 ))K window"
  if (( _FREE_K < 10 && _NOTIF_LEVEL < 2 )); then
    notify-send --urgency=critical "Claude Code — context critical" \
      "Context at ${_PCT}% — only ${_FREE_K}K free (${_WIN_TAG}). Run /handoff NOW." 2>/dev/null || true
    printf '2\n' > "$_NOTIF_FILE" 2>/dev/null || true
    log_obs INFO stop-context-bar "desktop notification: critical (free=${_FREE_K}K, window=${WINDOW})" 2>/dev/null || true
  elif (( _FREE_K < 30 && _NOTIF_LEVEL < 1 )); then
    notify-send --urgency=normal "Claude Code — context low" \
      "Context at ${_PCT}% — ${_FREE_K}K free (${_WIN_TAG}). Consider /handoff." 2>/dev/null || true
    printf '1\n' > "$_NOTIF_FILE" 2>/dev/null || true
    log_obs INFO stop-context-bar "desktop notification: warning (free=${_FREE_K}K, window=${WINDOW})" 2>/dev/null || true
  fi
fi

# ── Per-turn git refresh: update dirty count + last-commit age in status-banner.txt ──
# P0-2: target this session's per-session banner when present; dual-write the global file.
_GR_BNR_GLOBAL="${_RUN_DIR}/status-banner.txt"
if [[ -n "${SESSION_ID_IN:-}" && -f "${_RUN_DIR}/status-banner-${SESSION_ID_IN}.txt" ]]; then
  _GR_BNR="${_RUN_DIR}/status-banner-${SESSION_ID_IN}.txt"
else
  _GR_BNR="$_GR_BNR_GLOBAL"
fi
if [[ -n "$CWD_IN" && -f "$_GR_BNR" ]] \
  && command -v git &>/dev/null \
  && timeout 2 git -C "$CWD_IN" rev-parse --is-inside-work-tree &>/dev/null 2>&1; then
  _GR_DIRTY=$(timeout 2 git -C "$CWD_IN" status --porcelain 2>/dev/null | wc -l | tr -d ' ' || echo 0)
  _GR_DIRTY="${_GR_DIRTY//[^0-9]/}"; _GR_DIRTY="${_GR_DIRTY:-0}"
  _GR_LAST_CT=$(timeout 2 git -C "$CWD_IN" log -1 --format='%ct' 2>/dev/null || echo 0)
  _GR_LAST_CT="${_GR_LAST_CT//[^0-9]/}"; _GR_LAST_CT="${_GR_LAST_CT:-0}"
  _GR_LAST=""
  if [[ "${_GR_LAST_CT:-0}" -gt 0 ]] && type ss_age &>/dev/null; then
    _GR_LAST=$(ss_age $(( $(date +%s) - _GR_LAST_CT )))
  fi
  _GR_TMP=$(mktemp "${_RUN_DIR}/.status-banner.XXXXXX" 2>/dev/null || mktemp)
  sed -e "s|^GIT_DIRTY:.*|GIT_DIRTY:${_GR_DIRTY}|" \
      -e "s|^GIT_LAST:.*|GIT_LAST:${_GR_LAST}|" \
      "$_GR_BNR" > "$_GR_TMP" 2>/dev/null \
    && mv -f "$_GR_TMP" "$_GR_BNR" 2>/dev/null \
    || rm -f "$_GR_TMP" 2>/dev/null || true
  [[ "$_GR_BNR" != "$_GR_BNR_GLOBAL" ]] && cp -f "$_GR_BNR" "$_GR_BNR_GLOBAL" 2>/dev/null || true
  log_obs INFO stop-context-bar "git refresh: dirty=${_GR_DIRTY} last=${_GR_LAST}" 2>/dev/null || true
fi

# ── Auto-handoff: fire precompact-handoff.sh in background at session stop ────
# Guard: GS_NO_AUTO_HANDOFF=1 is set by precompact-handoff.sh before its claude -p
# call; its Stop event inherits the var, preventing a spawn→stop→spawn loop.
# Throttle: skip if a handoff was written within the last 5 min to avoid per-turn spam.
if [[ -z "${GS_NO_AUTO_HANDOFF:-}" && -n "$TRANSCRIPT" && -f "$TRANSCRIPT" && -n "$CWD_IN" ]]; then
  # Use session-start CWD anchor (written by session-start-banner.sh) so drift from
  # shell navigation or parallel sessions doesn't misroute the handoff.
  _HO_CWD="${CWD_IN}"
  if [[ -n "${SESSION_ID_IN:-}" && -f "${_RUN_DIR}/session-cwd-${SESSION_ID_IN}.txt" ]]; then
    _HO_ANCHOR=$(head -1 "${_RUN_DIR}/session-cwd-${SESSION_ID_IN}.txt" 2>/dev/null | tr -d '[:space:]' || true)
    [[ -n "$_HO_ANCHOR" ]] && _HO_CWD="$_HO_ANCHOR"
  fi
  _HO_SLUG=$(printf '%s' "$_HO_CWD" | sed 's|/|-|g')
  _HO_FILE="$HOME/.claude/projects/${_HO_SLUG}/memory/sessions/handoff.md"
  _HO_MTIME=0
  _HO_RECENT=false
  _HO_MANUAL=false
  if [[ -f "$_HO_FILE" ]]; then
    _HO_MTIME=$(stat -c '%Y' "$_HO_FILE" 2>/dev/null || echo 0)
    _HO_MTIME="${_HO_MTIME//[^0-9]/}"; _HO_MTIME="${_HO_MTIME:-0}"
    (( $(date +%s) - _HO_MTIME < 300 )) 2>/dev/null && _HO_RECENT=true
    # Manual marker: /handoff skill appends <!-- manual --> — respect human-curated state
    grep -q '<!-- manual -->' "$_HO_FILE" 2>/dev/null && { _HO_RECENT=true; _HO_MANUAL=true; }
  fi
  if [[ "$_HO_RECENT" != "true" ]]; then
    _HO_TMP=$(mktemp /tmp/stop-handoff-XXXXXX.json 2>/dev/null || true)
    if [[ -n "$_HO_TMP" ]]; then
      jq -n \
        --arg sid "${SESSION_ID_IN:-}" \
        --arg tp  "$TRANSCRIPT" \
        --arg cwd "$CWD_IN" \
        '{"session_id":$sid,"transcript_path":$tp,"cwd":$cwd,"hook_event_name":"Stop"}' \
        > "$_HO_TMP" 2>/dev/null || { rm -f "$_HO_TMP" 2>/dev/null || true; _HO_TMP=""; }
      if [[ -n "$_HO_TMP" && -s "$_HO_TMP" ]]; then
        (nohup bash "$SCRIPT_DIR/precompact-handoff.sh" \
            < "$_HO_TMP" \
            >> "${HOME}/.claude/logs/hooks-errors.log" 2>&1
          rm -f "$_HO_TMP" 2>/dev/null || true) &
        disown 2>/dev/null || true
        log_obs INFO stop-context-bar "auto-handoff fired (cwd=$CWD_IN)" 2>/dev/null || true
      else
        rm -f "$_HO_TMP" 2>/dev/null || true
      fi
    fi
  else
    if [[ "$_HO_MANUAL" == "true" ]]; then
      log_obs INFO stop-context-bar "auto-handoff skipped — manual handoff present" 2>/dev/null || true
    else
      _HO_AGE=$(( $(date +%s) - _HO_MTIME ))
      log_obs INFO stop-context-bar "auto-handoff skipped — recent (${_HO_AGE}s ago)" 2>/dev/null || true
    fi
  fi
fi

log_obs INFO stop-context-bar "ctx=${SS_INPUT_TOKENS} model=${SS_MODEL} window=${WINDOW}" 2>/dev/null || true
