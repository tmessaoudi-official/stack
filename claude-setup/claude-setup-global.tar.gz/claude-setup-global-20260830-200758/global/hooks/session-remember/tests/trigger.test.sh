#!/usr/bin/env bash
# trigger.test.sh — Tests for trigger.sh
# Run with: bash tests/trigger.test.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

_PASS=0; _FAIL=0

assert_equals() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n    expected: %q\n    actual:   %q\n' "$desc" "$expected" "$actual"
    (( _FAIL++ )) || true
  fi
}
assert_file_exists() {
  local desc="$1" path="$2"
  if [[ -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — not found: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}
assert_file_not_exists() {
  local desc="$1" path="$2"
  if [[ ! -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — unexpected: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}

_HOME="" _PROJ="" _SLUG="" _TRIG_DIR="" _STATE_DIR="" _SESSION_STORE="" _INVOKED=""

_setup() {
  _HOME=$(mktemp -d /tmp/sr-test-home-XXXXXX)
  _PROJ=$(mktemp -d /tmp/sr-test-proj-XXXXXX)
  _SLUG=$(echo "$_PROJ" | tr '/' '-')
  _TRIG_DIR=$(mktemp -d /tmp/sr-test-trig-XXXXXX)
  _STATE_DIR="$_HOME/.claude/projects/$_SLUG/memory/sessions/.state"
  _SESSION_STORE="$_HOME/.claude/projects/$_SLUG"
  mkdir -p "$_STATE_DIR" "$_SESSION_STORE"
  _INVOKED="$_TRIG_DIR/save-invoked"

  # Copy trigger.sh; symlink common.sh so SCRIPT_DIR=_TRIG_DIR finds it
  cp "$PIPELINE_DIR/trigger.sh" "$_TRIG_DIR/trigger.sh"
  ln -sf "$PIPELINE_DIR/common.sh" "$_TRIG_DIR/common.sh"

  # Default fake save.sh: fast, records invocation
  cat > "$_TRIG_DIR/save.sh" << EOF
#!/usr/bin/env bash
printf 'called\n' > "$_INVOKED"
EOF
  chmod +x "$_TRIG_DIR/save.sh"
}

_teardown() { rm -rf "$_HOME" "$_PROJ" "$_TRIG_DIR" 2>/dev/null || true; }

_write_jsonl() {
  local n="${1:-3}"
  local i
  {
    for (( i=1; i<=n; i++ )); do
      printf '{"type":"user","isMeta":false,"message":{"content":"msg %d"}}\n' "$i"
    done
  } > "$_SESSION_STORE/sid-test.jsonl"
}

_run() {
  echo '{}' | \
    HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" SR_DELTA_THRESHOLD=1 \
    bash "$_TRIG_DIR/trigger.sh" 2>/dev/null
}

# ── trig1: delta > threshold → save.sh launched ─────────────────────────────
echo "Section 1: Delta above threshold triggers save"
_setup
_write_jsonl 5   # 5 lines > threshold 1
rc=0; _run || rc=$?
assert_equals "trig1: exits 0" "0" "$rc"
sleep 0.5        # background nohup — allow fake save.sh to write marker
assert_file_exists "trig1: save.sh was invoked" "$_INVOKED"
assert_file_exists "trig1: PID file written" "$_STATE_DIR/save.pid"
_teardown

# ── trig2: PID file with alive process → save skipped ───────────────────────
echo "Section 2: Alive PID file → save skipped"
_setup
_write_jsonl 5
echo $$ > "$_STATE_DIR/save.pid"   # $$ is the current process — definitely alive
rc=0; _run || rc=$?
assert_equals "trig2: exits 0" "0" "$rc"
sleep 0.2
assert_file_not_exists "trig2: save.sh NOT invoked (PID alive)" "$_INVOKED"
_teardown

# ── trig3: PID file with dead process → save launched ───────────────────────
echo "Section 3: Dead PID file → save launched anyway"
_setup
_write_jsonl 5
echo 99999999 > "$_STATE_DIR/save.pid"   # very high PID, certainly not running
rc=0; _run || rc=$?
assert_equals "trig3: exits 0" "0" "$rc"
sleep 0.5
assert_file_exists "trig3: save.sh invoked despite dead PID" "$_INVOKED"
_teardown

# ── trig4: READONLY mode → save skipped ─────────────────────────────────────
echo "Section 4: READONLY mode — save skipped"
_setup
_write_jsonl 5
mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/READONLY"
rc=0; _run || rc=$?
assert_equals "trig4: READONLY → exits 0" "0" "$rc"
sleep 0.2
assert_file_not_exists "trig4: save.sh NOT invoked in READONLY mode" "$_INVOKED"
_teardown

# ── trig5: Log rotation keeps ≤ 20 files ────────────────────────────────────
echo "Section 5: Log rotation"
_setup
_write_jsonl 5
LOG_DIR="$_HOME/.claude/projects/$_SLUG/memory/sessions/logs"
mkdir -p "$LOG_DIR"
# Create 21 old log files with a past timestamp so ls -t sorts them as oldest
for i in $(seq 1 21); do
  f="$LOG_DIR/save-0000${i}.log"
  printf 'old\n' > "$f"
  touch -t 202001010000 "$f"   # 2020-01-01 00:00 — clearly in the past
done
rc=0; _run || rc=$?
assert_equals "trig5: exits 0" "0" "$rc"
# Check immediately after trigger.sh returns (before nohup writes the new file)
log_count=$(ls "$LOG_DIR"/save-*.log 2>/dev/null | wc -l | tr -d ' ')
# 21 old + 1 new (from nohup setup) = 22 → rotation removes 2 oldest → 20
assert_equals "trig5: log rotation keeps ≤ 20 files" "20" "$log_count"
_teardown

# ── trig6/trig7: permission_mode persisted BEFORE the kill-switches ─────────
# PostToolUse stdin carries permission_mode; trigger.sh writes it to run/permission-mode-<sid>
# ahead of the delta check (so it fires on every tool call, even below threshold) and never
# clobbers the file when stdin lacks the field (the pipeline's own '{}' probe input).
echo "Section 6: permission_mode persisted for the statusline"
_setup
_write_jsonl 1   # delta 1 ≤ threshold 1 → trigger exits early — the persist must precede that
rc=0
echo '{"session_id":"pm-6","permission_mode":"bypassPermissions"}' | \
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" SR_DELTA_THRESHOLD=1 \
  bash "$_TRIG_DIR/trigger.sh" 2>/dev/null || rc=$?
assert_equals "trig6: exits 0" "0" "$rc"
pm=$(cat "$_HOME/.claude/run/permission-mode-pm-6" 2>/dev/null || true)
assert_equals "trig6: permission_mode persisted to run/permission-mode-<sid>" "bypassPermissions" "$pm"

mkdir -p "$_HOME/.claude/run"
printf 'bypassPermissions\n' > "$_HOME/.claude/run/permission-mode-pm-6"
_run || true
pm=$(cat "$_HOME/.claude/run/permission-mode-pm-6" 2>/dev/null || true)
assert_equals "trig7: '{}' stdin leaves permission-mode file untouched" "bypassPermissions" "$pm"
_teardown

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo "Results: ${_PASS} passed, ${_FAIL} failed"
(( _FAIL == 0 )) && exit 0 || exit 1
