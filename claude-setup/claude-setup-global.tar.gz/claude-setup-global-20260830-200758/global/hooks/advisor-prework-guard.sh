#!/usr/bin/env bash
# PreToolUse: Edit|Write — backstop for CLAUDE.md Phase 3C (PRE-WORK INDEPENDENT CHECK).
# Phase 6C has advisor-completion-guard.sh; Phase 3C had NO mechanical enforcement at all until
# this hook (2026-08-22 audit finding). This closes that asymmetry.
#
# WHAT IT ENFORCES: visibility, not the advisor() call itself. The turn must show ONE of:
#   - the string "3C" anywhere in the assistant's text this turn (the Rule 16 sequence declaration
#     "Phases: 3C → 5 → …", a "── Phase 3C ──" marker, a "3C round N →" line, or an explicit
#     "Phase 3C — skipped (trivial single-line edit)"), or
#   - an `advisor` tool call, or
#   - a reviewer-panel `Agent` spawn (the certification-ladder fallback).
# Deliberately generous. CLAUDE.md already requires a visible phase marker for EVERY task including
# Small, so any turn following the workflow trips one of these without extra effort. The design
# target is not airtightness — it is that Phase 3C can no longer be omitted SILENTLY.
#
# WHY SO LOOSE: the 2026-08-22 audit found four projects running with all four gate families
# bypassed, because gates that nag get switched off. A per-edit blocker is the noisiest surface in
# this config; its realistic failure mode is abandonment, not evasion. Every knob below is tuned
# against that: main-session only, one verdict per turn, generous accept-check.
#
# Bypasses (three scopes, parity with the other guard families):
#   PREWORK_OFF=1 | ~/.claude/state/advisor-prework-guard-bypass
#                 | ~/.claude/projects/<cwd-slug>/state/advisor-prework-guard-bypass
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

[[ "${PREWORK_OFF:-}" == "1" ]] && exit 0
[[ -f "$HOME/.claude/state/advisor-prework-guard-bypass" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$SESSION_ID" ]] || exit 0

# Per-project sentinel bypass (slug = cwd, / -> -).
PW_CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
if [[ -n "$PW_CWD" ]]; then
  PW_SLUG=$(printf '%s' "$PW_CWD" | tr '/' '-')
  [[ -f "$HOME/.claude/projects/${PW_SLUG}/state/advisor-prework-guard-bypass" ]] && exit 0
fi

# Per-session sentinel bypass (uniform /gates-bypass model, 2026-08-30): run/advisor-prework-guard-bypass-<sid>.
[[ -f "$HOME/.claude/run/advisor-prework-guard-bypass-${SESSION_ID}" ]] && exit 0

GATE_DIR="${GATE_DIR_OVERRIDE:-/tmp/ask-human-gate}"  # GATE_DIR_OVERRIDE: test-only injection point
TURN_TOKEN="$GATE_DIR/turns/${SESSION_ID}"

# No turn token = not an interactive main session (subagent, tool runner) -> allow through.
# Same contract ask-human-gate-block.sh relies on.
[[ -f "$TURN_TOKEN" ]] || exit 0
TURN_TIME=$(cat "$TURN_TOKEN" 2>/dev/null || echo 0)

# Subagent carve-out: subagents share the parent session_id, so the turn token exists for them too,
# yet they run their own 3C internally and cannot emit markers into the parent transcript turn.
# While any FRESH SubagentStart marker exists for this session, allow through (mirrors gate-block).
SUBAGENT_MARK_DIR="$GATE_DIR/subagent/${SESSION_ID}"
if [[ -d "$SUBAGENT_MARK_DIR" ]] \
   && find "$SUBAGENT_MARK_DIR" -type f -mmin -120 -print -quit 2>/dev/null | grep -q .; then
  exit 0
fi

# One verdict per turn: re-parsing the transcript on every Edit of a long turn is pure waste.
# Cache holds the turn epoch that was cleared; only PASS verdicts are cached (a block must stay
# re-checkable, so the next Edit re-reads the transcript after the marker is emitted).
CACHE="$GATE_DIR/prework/${SESSION_ID}"
if [[ -f "$CACHE" ]]; then
  CACHED=$(cat "$CACHE" 2>/dev/null || echo 0)
  [[ "$CACHED" -ge "$TURN_TIME" ]] 2>/dev/null && exit 0
fi

TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
# Fail OPEN: no transcript means we cannot judge, and blocking on ignorance is the abandonment path.
[[ -n "$TRANSCRIPT" && -f "$TRANSCRIPT" ]] || exit 0

# Turn anchoring copied verbatim from advisor-completion-guard.sh — commit 5701e37b fixed exactly
# this ("guards could not see advisor() and mis-anchored the turn"); do not re-derive it.
FILTER='
  . as $a
  | ([range(0; ($a|length)) | select($a[.].type=="user"
       and (($a[.].message.content|type)=="string"
            or ([$a[.].message.content[]?|select(.type=="tool_result")]|length)==0))] | last) as $u0
  | (($u0 // -1) + 1) as $start
  | {
      certified: ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="tool_use" or .type=="server_tool_use") ]
                   | any( .name == "advisor"
                          or ( .name == "Agent"
                               and ( ((.input.subagent_type // "") + " " + (.input.description // "")
                                      + " " + (.input.prompt // ""))
                                     | test("review|certif|adversarial|lens|audit|critique"; "i") ) ) )),
      text:     ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="text") | .text ] | join("\n"))
    }'
RES=$(tail -n 800 "$TRANSCRIPT" 2>/dev/null | jq -Rc 'fromjson? // empty' 2>/dev/null | jq -s "$FILTER" 2>/dev/null || true)
[[ -z "$RES" ]] && exit 0

CERTIFIED=$(printf '%s' "$RES" | jq -r '.certified' 2>/dev/null || echo false)
TEXT=$(printf '%s' "$RES" | jq -r '.text' 2>/dev/null || echo "")

pass_turn() {
  mkdir -p "$GATE_DIR/prework" 2>/dev/null || true
  printf '%s' "$TURN_TIME" > "$CACHE" 2>/dev/null || true
  exit 0
}

[[ "$CERTIFIED" == "true" ]] && pass_turn
# A 3C marker anywhere in the turn text satisfies the gate — including an explicit skip marker.
printf '%s' "$TEXT" | grep -q '3C' && pass_turn

{
  echo "⛔ EDIT/WRITE BEFORE PHASE 3C"
  echo "   CLAUDE.md Phase 3C (PRE-WORK INDEPENDENT CHECK) runs before implementation."
  echo "   This turn shows no 3C marker, no advisor() call, and no reviewer-panel spawn."
  echo "   Satisfy it by doing ONE of:"
  echo "     • emit the Rule 16 sequence declaration / phase marker (any text containing '3C')"
  echo "     • call advisor() to certify the plan"
  echo "     • declare the skip: '── Phase 3C — skipped (trivial single-line edit) ──'"
  echo "   Bypass — env: PREWORK_OFF=1"
  echo "            global:       touch ~/.claude/state/advisor-prework-guard-bypass"
  echo "            this project: mkdir -p ~/.claude/projects/${PW_SLUG:-<slug>}/state && touch ~/.claude/projects/${PW_SLUG:-<slug>}/state/advisor-prework-guard-bypass"
} >&2
log_obs WARN advisor-prework-guard "blocked Edit/Write with no Phase 3C evidence session=${SESSION_ID}" 2>/dev/null || true
exit 2
