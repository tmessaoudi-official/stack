# Prerequisites — Machine Setup Reference

Tools required on this machine. Minimum versions reflect features actively used by hooks, scripts, and commands.

| Tool | Min version | Purpose |
|------|------------|---------|
| `jq` | 1.6 | JSON state tracking in session-remember pipeline (`common.sh`); every hook that parses its stdin payload |
| `python3` | 3.8 | **Bash firewall boundary gate** (`hooks/ask-bash-firewall.sh` v3 — `shlex` classifier; the hook fails CLOSED and asks on *every* Bash call when python3 is missing); `sanitize.sh` / `claude-adapt.sh` banner-strip; session-remember `extract.py`. Prefer `/usr/bin/python3` (the hook tries it first — a pyenv shim costs ~300 ms per Bash call vs ~25 ms) |
| `git` | 2.25 | All version-control operations; `git restore` syntax; firewall ROOT resolution (`git rev-parse --show-toplevel`) |
| `shellcheck` | 0.8.0 | Hook linting on `.sh` writes; `/lint` command |
| `hadolint` | 2.8.0 | Dockerfile linting on write; `/lint` command |
| `make` | 4.0 | Stack automation (`eval`/`call` macros, double-colon targets) |
| `rtk` | 0.37.0 | Token-optimized CLI proxy (hook-rewritten commands) |
| `docker` | 24.0 | Compose v2 native, BuildX bake (`COMPOSE_BAKE=true`) |

Verify: `jq --version; /usr/bin/python3 --version || python3 --version; git --version; shellcheck --version; hadolint --version; make --version; rtk --version; docker --version`

Firewall smoke (must print nothing — an `"ask"` JSON here means python3 is unresolvable and every Bash call will prompt):
`printf '{"cwd":"/tmp","tool_input":{"command":"ls"}}' | bash ~/.claude/hooks/ask-bash-firewall.sh`
