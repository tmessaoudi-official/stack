---
name: memory-unblock
description: Use when removing a project from the session-remember blacklist or readonly-list to re-enable memory capture.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /memory-unblock — remove a project from the session-remember blacklist or readonly-list to re-enable memory capture
>
> Usage: /memory-unblock [path]
>   [path]  Optional project path. Defaults to the current project (discovered via git root or CLAUDE.md walk).
> ```

---

# /memory-unblock [path]

Remove a project from the session-remember blacklist and/or readonly-list.
Removes from BOTH lists if the slug appears in either.

If no path is given, discovers the project via `git rev-parse --show-toplevel` then walks parents looking for `CLAUDE.md`.

---

## Pre-check: global pipeline state

Before modifying any block lists, run:
```bash
[ -f "$HOME/.claude/hooks/session-remember/DISABLED.lean" ] && echo "LEAN_DISABLED=true" || echo "LEAN_DISABLED=false"
[ -f "$HOME/.claude/hooks/session-remember/DISABLED" ] && echo "GLOBAL_DISABLED=true" || echo "GLOBAL_DISABLED=false"
```

If `LEAN_DISABLED=true`, warn:
```
⚠ Session pipeline is controlled by lean mode (DISABLED.lean present).
  Per-project block list changes will have no effect until lean mode ends.
  Proceeding anyway so the entry is removed for when lean mode exits...
```

If `LEAN_DISABLED=false` and `GLOBAL_DISABLED=true`, warn:
```
⚠ Session pipeline is globally disabled (DISABLED is present).
  Per-project block list changes will have no effect until DISABLED is removed.
  Proceeding anyway so the entry is removed for when global disable is lifted...
```

Then continue to normal execution regardless.

---

## Run

```bash
_discover_path() {
  local arg="$1"
  if [[ -n "$arg" ]]; then
    [[ -d "$arg" ]] || { echo "⛔ Path not found: $arg" >&2; return 1; }
    realpath "$arg"; return 0
  fi
  local g
  g=$(git rev-parse --show-toplevel 2>/dev/null) && { echo "$g"; return 0; }
  local d="$PWD"
  while [[ "$d" != "/" ]]; do
    [[ -f "$d/CLAUDE.md" ]] && { echo "$d"; return 0; }
    d=$(dirname "$d")
  done
  echo "⛔ Cannot determine project path. Provide path as argument." >&2
  return 1
}

# PATH_ARG is the first positional argument, or empty
PROJECT_PATH=$(_discover_path "${PATH_ARG:-}") || exit 1
PROJECT_SLUG=$(echo "$PROJECT_PATH" | sed 's|/|-|g')

SR_DIR="$HOME/.claude/hooks/session-remember"
BLACKLIST="$SR_DIR/blacklist"
READONLY_LIST="$SR_DIR/readonly-list"

REMOVED_FROM=()

_remove_from_list() {
  local file="$1" label="$2"
  [[ ! -f "$file" ]] && return 0
  if grep -qxF "$PROJECT_SLUG" "$file" 2>/dev/null; then
    TMP=$(mktemp)
    grep -vxF "$PROJECT_SLUG" "$file" > "$TMP" && mv "$TMP" "$file" || rm -f "$TMP"
    REMOVED_FROM+=("$label")
  fi
}

_remove_from_list "$BLACKLIST"   "blacklist"
_remove_from_list "$READONLY_LIST" "readonly-list"

if [[ ${#REMOVED_FROM[@]} -eq 0 ]]; then
  echo "Project $PROJECT_PATH is not in any block list."
  echo "  Slug: $PROJECT_SLUG"
  exit 0
fi

echo "✓ $PROJECT_PATH unblocked"
echo "  Removed from: ${REMOVED_FROM[*]}"
echo "  Takes effect at next session start."
```
