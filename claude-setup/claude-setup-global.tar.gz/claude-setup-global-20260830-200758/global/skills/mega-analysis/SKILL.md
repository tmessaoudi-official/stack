---
name: mega-analysis
spotlight: true
description: Use when running the full quality and health pipeline across both global and project scopes — repair, audit, skill-audit, inspect, sleuth, gaps, inspect --vision, retrospective, memory-promote, and handoff. Accepts --scope=project|global|both (default: both).
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /mega-analysis — Run the full quality and health pipeline across both global and project scopes — repair, audit, skill-audit, inspect, sleuth, gaps, inspect --vision, retrospective, memory-promote, and handoff. Accepts --scope=project|global|both (default: both).
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /mega-analysis — Full Stack Deep Analysis Pipeline

Run the complete quality and health pipeline across one or both scopes (**global** `~/.claude/` and/or **project** `$CLAUDE_PROJECT_DIR`).
Produces a versioned senior expert synthesis report with delta tracking against the prior run.

**Full sequence**: repair → audit → skill-audit → inspect × 2 → sleuth × 2 → gaps × 2 → inspect --vision × 2 → **aggregate-findings** → retrospective → memory-promote → handoff [→ skill-extract if `--skill-extract`]

**Report location**: `~/.claude/projects/meta-reports/YYYY-MM-DD/full-analysis.md`
First run of the day → `full-analysis.md`. Subsequent same-day runs → `full-analysis-run2.md`, `full-analysis-run3.md`, etc.

## Flags

- `--check` — pass to repair (drift report only, no fixes applied)
- `--quick` — repair + audit + inspect only (~30 min vs ~2 hr); skips skill-audit, sleuth, gaps, vision; memory-promote still runs
- `--skip=<stages>` — comma-separated stages to skip (e.g. `--skip=sleuth,vision`)
- `--new-only` — in step 11c, "Open Findings by Severity" shows **only NEW findings** (PERSISTS/STALE suppressed); **requires a baseline** (either `--baseline=<path>` or an auto-detected `$PRIOR_REPORT`); abort with error if neither available
- `--baseline=<path>` — override auto-detected `$PRIOR_REPORT` with this specific path; validate the file exists before proceeding (abort if not found); overrides the `ls meta-reports` auto-detection
- `--skill-extract` — after handoff, invoke `skill-extractor` to mine this session for repeatable prompt patterns; each proposed skill requires explicit ask-human approval before any file is written
- `--scope=project|global|both` — `project`: source code + project's `.claude/` only (requires `$CLAUDE_PROJECT_DIR`); `global`: `~/.claude/` only; `both` (default): full pipeline across both scopes

---

## Step 0: Setup

```bash
TODAY=$(date +%Y-%m-%d)
START_TIME=$(date +%H:%M)
RUN_START_TS=$(date +%s)   # used for metadata only — resume uses stub ✅/⏳ rows
REPORT_DIR="$HOME/.claude/projects/meta-reports/$TODAY"
mkdir -p "$REPORT_DIR"
REPORT_PATH="$REPORT_DIR/full-analysis.md"
RUN=2
while [[ -f "$REPORT_PATH" ]]; do
  REPORT_PATH="$REPORT_DIR/full-analysis-run${RUN}.md"
  RUN=$((RUN + 1))
done

# Find most recent prior report (any date, any run)
PRIOR_REPORT=$(ls "$HOME/.claude/projects/meta-reports"/*/full-analysis*.md 2>/dev/null \
  | grep -v "$REPORT_PATH" | sort -r | head -1 || true)

# --baseline override: supersedes auto-detected PRIOR_REPORT
if [[ "$ARGUMENTS" =~ --baseline=([^ ]+) ]]; then
  BASELINE_PATH="${BASH_REMATCH[1]}"
  if [[ ! -f "$BASELINE_PATH" ]]; then
    echo "ERROR: --baseline path not found: $BASELINE_PATH"
    exit 1
  fi
  PRIOR_REPORT="$BASELINE_PATH"
fi

# --new-only requires a baseline
_MA_NEW_ONLY=false
[[ "$ARGUMENTS" =~ --new-only ]] && _MA_NEW_ONLY=true
if [[ "$_MA_NEW_ONLY" == "true" && -z "${PRIOR_REPORT:-}" ]]; then
  echo "ERROR: --new-only requires a baseline. Pass --baseline=<path> or ensure a prior report exists."
  exit 1
fi

# --scope flag
SCOPE="both"
if [[ "$ARGUMENTS" =~ --scope=(project|global|both) ]]; then
  SCOPE="${BASH_REMATCH[1]}"
fi
if [[ "$SCOPE" == "project" && -z "${CLAUDE_PROJECT_DIR:-}" ]]; then
  echo "ERROR: --scope=project requires CLAUDE_PROJECT_DIR to be set (run from inside a project)."
  exit 1
fi
```

Announce:
- "Running mega-analysis → `$REPORT_PATH`"
- "Scope: `$SCOPE`"
- If `$PRIOR_REPORT` non-empty: "Prior report: `$PRIOR_REPORT` (will compute delta)"
- If `--baseline=<path>` was used: "Baseline override: `$PRIOR_REPORT`"
- If `--new-only`: "New-only mode: Open Findings will show only NEW items (PERSISTS suppressed)"
- If `--check`: "repair in --check mode (no fixes)"
- If `--quick`: "Quick mode: repair + audit + inspect only"

**Write an in-progress stub immediately** so the session is recoverable if it dies mid-pipeline.

First compute the scope label:
```bash
case "$SCOPE" in
  project) SCOPE_LABEL="Project only (\`$CLAUDE_PROJECT_DIR\`)" ;;
  global)  SCOPE_LABEL="Global only (\`~/.claude/\`)" ;;
  *)       SCOPE_LABEL="Global (\`~/.claude/\`) + Project (\`$CLAUDE_PROJECT_DIR\`)" ;;
esac
```

Write to `$REPORT_PATH`:
```markdown
# Full Analysis Report — <TODAY> (IN PROGRESS — started <START_TIME>)
**Scope**: <$SCOPE_LABEL>
**Run started**: <RUN_START_TS>
**Status**: 🚧 Pipeline running — do not use this report yet.

| Stage | Status |
|-------|--------|
| repair | ⏳ pending |
| audit | ⏳ pending |
| skill-audit | ⏳ pending |
| inspect (project) | ⏳ pending |
| inspect (global) | ⏳ pending |
| sleuth (project) | ⏳ pending |
| sleuth (global) | ⏳ pending |
| gaps (project) | ⏳ pending |
| gaps (global) | ⏳ pending |
| inspect --vision (project) | ⏳ pending |
| inspect --vision (global) | ⏳ pending |
| aggregate-findings | ⏳ pending |
| retrospective | ⏳ pending |
| memory-promote | ⏳ pending |
| handoff | ⏳ pending |
```

Write the pointer file:
```bash
printf '%s\n' "$REPORT_PATH" > "$REPORT_DIR/.current-run"
```

**Immediately pre-mark out-of-scope rows** (compaction-safe — resume guard reads ✅ and skips):
```bash
if [[ "$SCOPE" == "project" ]]; then
  for stage in "inspect (global)" "sleuth (global)" "gaps (global)" "inspect --vision (global)"; do
    stage_pat=$(printf '%s' "$stage" | sed 's/[()]/\\&/g')
    sed -i "s/| $stage_pat | ⏳ pending |/| $stage | ✅ (skipped — --scope=project) |/" "$REPORT_PATH"
  done
elif [[ "$SCOPE" == "global" ]]; then
  for stage in "inspect (project)" "sleuth (project)" "gaps (project)" "inspect --vision (project)"; do
    stage_pat=$(printf '%s' "$stage" | sed 's/[()]/\\&/g')
    sed -i "s/| $stage_pat | ⏳ pending |/| $stage | ✅ (skipped — --scope=global) |/" "$REPORT_PATH"
  done
fi
```

Update each remaining row to ✅ as stages complete.

---

## Step 0b: Compaction Recovery

**This step fires only when context was compacted mid-pipeline** (i.e., you are resuming and `$REPORT_PATH` is not in scope).

```bash
TODAY=$(date +%Y-%m-%d)
REPORT_DIR="$HOME/.claude/projects/meta-reports/$TODAY"
# Recover the active run's report path from the pointer file
REPORT_PATH=$(cat "$REPORT_DIR/.current-run" 2>/dev/null || \
  ls "$REPORT_DIR"/*.md 2>/dev/null | sort -r | head -1 || true)
# Re-derive SCOPE from $ARGUMENTS (compaction loses shell vars)
SCOPE="both"
[[ "$ARGUMENTS" =~ --scope=(project|global|both) ]] && SCOPE="${BASH_REMATCH[1]}"
case "$SCOPE" in
  project) SCOPE_LABEL="Project only (\`${CLAUDE_PROJECT_DIR:-unknown}\`)" ;;
  global)  SCOPE_LABEL="Global only (\`~/.claude/\`)" ;;
  *)       SCOPE_LABEL="Global (\`~/.claude/\`) + Project (\`${CLAUDE_PROJECT_DIR:-unknown}\`)" ;;
esac
```

Read `$REPORT_PATH`. The status table shows which stages already completed (✅) and which are still pending (⏳).

**Rule: skip every stage whose row shows ✅. Resume from the first ⏳ row.**

Log: "Resuming after compaction — scope: `$SCOPE`; skipping completed stages: [list ✅ stages]"

Each step below begins with a checkpoint line. Follow it.

---

## Step 1: Repair

**Checkpoint:** read the stub — if `repair` row shows ✅, skip this step entirely.

Invoke the `repair` skill. If `--check` is in `$ARGUMENTS`, pass `--check` to it.

After it completes:
- Record which items were **fixed** (these become RESOLVED entries in the final report)
- Record which items were **deferred** or **out of scope** (these persist as open)
- Update the stub: repair → ✅

**Context economy** — repair output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

If `--check` mode: note "repair ran in check-only mode — no fixes applied".

---

## Step 2: Audit

**Checkpoint:** read the stub — if `audit` row shows ✅, skip this step entirely.

Invoke the `audit` skill with `--scope=$SCOPE`.

Note: in `--scope=both` mode audit covers both `~/.claude/` and `$CLAUDE_PROJECT_DIR/.claude/` in a single pass; in `--scope=project` it restricts agents A–E to the project's `.claude/` only and skips global-concern agents F–K.

After it completes, update the stub: audit → ✅

**Context economy** — audit output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

---

## Step 2b: Skill Audit

**Checkpoint:** read the stub — if `skill-audit` row shows ✅, skip this step entirely.

*If `--quick` or `--skip=skill-audit` is set: mark skill-audit → ✅ (skipped) and skip this step.*

Invoke the `skill-audit` skill with `--scope=$SCOPE`.

After it completes, update the stub: skill-audit → ✅

**Context economy** — skill-audit output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

---

## Step 3: Inspect — Project Scope

**Checkpoint:** read the stub — if `inspect (project)` row shows ✅, skip this step entirely.
**Scope guard:** If `$SCOPE` == `global`, skip this step (stub row already pre-marked ✅ at Step 0).

Invoke the `inspect` skill with `--scope=project`.

After it completes, update the stub: inspect (project) → ✅

**Context economy** — inspect (project) output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

---

## Step 4: Inspect — Global Scope

**Checkpoint:** read the stub — if `inspect (global)` row shows ✅, skip this step entirely.
**Scope guard:** If `$SCOPE` == `project`, skip this step (stub row already pre-marked ✅ at Step 0).

Invoke the `inspect` skill with `--scope=global`.

After it completes, update the stub: inspect (global) → ✅

**Context economy** — inspect (global) output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

---

*If `--quick` or `--skip=sleuth` is set: skip Steps 5–6. If `--quick` or `--skip=gaps` is set: skip Steps 7–8. If `--quick` or `--skip=vision` is set: skip Steps 9–10.*

---

## Step 5: Sleuth — Project Scope

**Checkpoint:** read the stub — if `sleuth (project)` row shows ✅, skip this step entirely.
**Scope guard:** If `$SCOPE` == `global`, skip this step (stub row already pre-marked ✅ at Step 0).

Invoke the `sleuth` skill with `--scope=project`.
After it completes, update the stub: sleuth (project) → ✅

**Context economy** — sleuth (project) output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

## Step 6: Sleuth — Global Scope

**Checkpoint:** read the stub — if `sleuth (global)` row shows ✅, skip this step entirely.
**Scope guard:** If `$SCOPE` == `project`, skip this step (stub row already pre-marked ✅ at Step 0).

Invoke the `sleuth` skill with `--scope=global`.
After it completes, update the stub: sleuth (global) → ✅

**Context economy** — sleuth (global) output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

---

## Step 7: Gaps — Project Scope

**Checkpoint:** read the stub — if `gaps (project)` row shows ✅, skip this step entirely.
**Scope guard:** If `$SCOPE` == `global`, skip this step (stub row already pre-marked ✅ at Step 0).

Invoke the `gaps` skill with `--scope=project`.
After it completes, update the stub: gaps (project) → ✅

**Context economy** — gaps (project) output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

## Step 8: Gaps — Global Scope

**Checkpoint:** read the stub — if `gaps (global)` row shows ✅, skip this step entirely.
**Scope guard:** If `$SCOPE` == `project`, skip this step (stub row already pre-marked ✅ at Step 0).

Invoke the `gaps` skill with `--scope=global`.
After it completes, update the stub: gaps (global) → ✅

**Context economy** — gaps (global) output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

---

## Step 9: Inspect --vision — Project Scope

**Checkpoint:** read the stub — if `inspect --vision (project)` row shows ✅, skip this step entirely.
**Scope guard:** If `$SCOPE` == `global`, skip this step (stub row already pre-marked ✅ at Step 0).

Invoke the `inspect` skill with `--vision --scope=project`.
After it completes, update the stub: inspect --vision (project) → ✅

**Context economy** — inspect --vision (project) output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

## Step 10: Inspect --vision — Global Scope

**Checkpoint:** read the stub — if `inspect --vision (global)` row shows ✅, skip this step entirely.
**Scope guard:** If `$SCOPE` == `project`, skip this step (stub row already pre-marked ✅ at Step 0).

Invoke the `inspect` skill with `--vision --scope=global`.
After it completes, update the stub: inspect --vision (global) → ✅

**Context economy** — inspect --vision (global) output is on disk. Release all agent responses from this stage from working context; only `$REPORT_PATH` and the stub status table need to persist into the next step.

---

## Step 11: Synthesize Final Report

This step is the core value of the pipeline — do it carefully.

### 11a: Load stage reports

Collect the most recent output file from each stage (sorted by timestamp, both scopes):

```bash
PROJECT_SLUG=$(echo "${CLAUDE_PROJECT_DIR:-$PWD}" | sed 's|^/|-|; s|/|-|g')
GLOBAL_SLUG="$(echo "$HOME" | sed 's|^/|-|; s|/|-|g')"

# Stage report dirs
AUDIT_REPORT=$(ls "$HOME/.claude/projects/$PROJECT_SLUG/audits"/*.md 2>/dev/null | grep -v skill-audit | sort -r | head -1)
SKILL_AUDIT_REPORT=$(ls "$HOME/.claude/projects/$PROJECT_SLUG/audits"/*-skill-audit.md 2>/dev/null | sort -r | head -1)
# NOTE: SKILL_AUDIT_REPORT must be read and its P0/P1 findings included in section 3
# alongside audit/inspect/sleuth findings — not only in section 4b.
INSPECT_PROJECT=$(ls "$HOME/.claude/projects/$PROJECT_SLUG/inspections"/*.md 2>/dev/null | sort -r | head -1)
INSPECT_GLOBAL=$(ls "$HOME/.claude/projects/$GLOBAL_SLUG/inspections"/*.md 2>/dev/null | sort -r | head -1)
SLEUTH_PROJECT=$(ls "$HOME/.claude/projects/$PROJECT_SLUG/sleuth"/*.md 2>/dev/null | sort -r | head -1)
SLEUTH_GLOBAL=$(ls "$HOME/.claude/projects/$GLOBAL_SLUG/sleuth"/*.md 2>/dev/null | sort -r | head -1)
GAPS_PROJECT=$(ls "$HOME/.claude/projects/$PROJECT_SLUG/gaps"/*.md 2>/dev/null | sort -r | head -1)
GAPS_GLOBAL=$(ls "$HOME/.claude/projects/$GLOBAL_SLUG/gaps"/*.md 2>/dev/null | sort -r | head -1)
# Vision proposals are embedded in the inspect --vision reports (Steps 9/10);
# they appear in the Vision Proposals section of INSPECT_PROJECT / INSPECT_GLOBAL.
# Re-read the latest inspect reports (which supersede Steps 3/4 with --vision content).
INSPECT_PROJECT=$(ls "$HOME/.claude/projects/$PROJECT_SLUG/inspections"/*.md 2>/dev/null | sort -r | head -1)
INSPECT_GLOBAL=$(ls "$HOME/.claude/projects/$GLOBAL_SLUG/inspections"/*.md 2>/dev/null | sort -r | head -1)

# Scope isolation: null out opposite-scope vars to prevent stale cross-scope reports bleeding in.
# IMPORTANT: this block MUST appear AFTER the INSPECT_PROJECT/GLOBAL re-reads above.
if [[ "$SCOPE" == "project" ]]; then
  INSPECT_GLOBAL="" SLEUTH_GLOBAL="" GAPS_GLOBAL=""
elif [[ "$SCOPE" == "global" ]]; then
  INSPECT_PROJECT="" SLEUTH_PROJECT="" GAPS_PROJECT=""
fi
```

Read all non-empty paths. Read `$PRIOR_REPORT` if set.

### 11b: Delta analysis (only if $PRIOR_REPORT is set)

For each finding in the prior report, classify it as one of:
- **RESOLVED** — repair fixed it this session, OR it no longer appears in any current stage report
- **STALE** — was open in prior report but is no longer relevant (the context changed, the file was deleted, the feature was removed) — mark but do not count as open
- **PERSISTS** — still present and still valid — carry forward with original ID

For each finding in current stage reports NOT in the prior report: mark as **NEW**.

### 11c: Write the final report

Replace the in-progress stub at `$REPORT_PATH` with the full report in this structure:

```markdown
# Full Analysis Report — <TODAY> (<run label: "v1" or "run N">)
**Scope**: <$SCOPE_LABEL (computed at Step 0)>
**Stages run**: <list which stages ran; note any skipped>
**Prior report**: <path or "none — first run">
**Status**: ✅ Complete — finished <HH:MM>

---

## 0. Fixes Applied This Session (from repair)

| ID | What was fixed | File | Status |
|----|----------------|------|--------|
<one row per fix, or "No fixes applied (--check mode)" or "Nothing to fix">

---

## 1. Executive Summary

<3–5 sentence senior-expert framing>:
- Overall health: <one-word verdict + justification>
- Net change from prior run: N items resolved, N new items, N persisting
- Highest-impact open item in one sentence
- Recommended next action in one sentence
- *If `--new-only` mode: add "Running in `--new-only` mode — only NEW findings shown below; N persisting items suppressed."*

---

## 2. Delta from Prior Report

| ID | Finding | Prior status | This run |
|----|---------|--------------|----------|
<RESOLVED rows first, then PERSISTS, then STALE, then NEW>
<If no prior report: "First run — no delta available.">

---

## 3. Open Findings by Severity

*If `--new-only` is active: include only findings classified as **NEW** in step 11b. Suppress PERSISTS and STALE rows entirely. Begin this section with: "Showing N new findings — M persisting items suppressed (`--new-only` mode)" so the reader knows the total scope.*

### P0 — Blocks correctness or security
<findings or "None">

### P1 — High impact, act soon
<findings — include source stage, scope, file, line — include P1s from ALL stages: audit, skill-audit, inspect, sleuth, gaps>

### P2 — Moderate impact
<findings>

### P3 — Low / stylistic
<findings or omit if empty>

---

## 4. Audit Findings
<summarize key audit findings — permissions, CLAUDE.md health, skill coverage>

## 4b. Skill Audit Findings
<if skill-audit ran: summarize P0/P1 skill-level findings; otherwise "skipped (--quick mode)">

## 5. Inspect Findings
### Project scope
<key findings>
### Global scope
<key findings>

## 6. Sleuth Findings
### Project scope
### Global scope

## 7. Gaps Findings
### Project scope
### Global scope

## 8. Vision Proposals (from inspect --vision)

> **Expertise discriminator** — apply to every proposal before placing it:
> - **Expert Insight**: "Could the owner have caught this themselves, without outside expertise?" → **No** → Expert tier
>   *Examples: subtle architectural coupling invisible without cross-repo view; framework-specific anti-patterns (e.g. hook ordering hazards); concurrency issues only visible under load*
> - **Checklist Item**: "Could the owner have caught this themselves?" → **Yes** → Checklist tier
>   *Examples: missing null check a linter flags; TODO comment left in prod path; basic accessible alt text*

### Expert Insights
*Proposals requiring an outside specialist view — the owner would not see these without expertise beyond the codebase.*

#### Project scope
<Expert-tier proposals from INSPECT_PROJECT, grouped by effort (Quick / Medium / Large). Each entry: finding + one-sentence rationale for Expert classification.>

#### Global scope
<Expert-tier proposals from INSPECT_GLOBAL, grouped by effort (Quick / Medium / Large). Each entry: finding + one-sentence rationale for Expert classification.>

### Checklist Items
*Straightforward improvements any developer reviewing this code would notice. Cap at 10 per scope — if more exist, surface only the highest-value 10 and note "N additional checklist items omitted."*

#### Project scope
<Checklist-tier proposals from INSPECT_PROJECT — max 10 items.>

#### Global scope
<Checklist-tier proposals from INSPECT_GLOBAL — max 10 items.>

---

## 9. Recommended Action Plan

Ordered by impact / effort ratio — what to do NEXT, not everything:

| # | Action | Severity | Effort | Source |
|---|--------|----------|--------|--------|
| 1 | ... | P0/P1/P2 | S/M/L | stage+scope |
...
<max 10 rows; focus on P0/P1 items only unless very quick wins exist at P2>
```

Announce: "Report saved to `$REPORT_PATH`"

---

## Step 11.5: Aggregate Findings

**Checkpoint:** read the stub — if `aggregate-findings` row shows ✅, skip this step entirely.
*If `--quick` is set: skip this step.*

Invoke the `aggregate-findings` skill. It reads all stage report files from this run (audit, skill-audit, inspect×2, sleuth×2, gaps×2, vision×2) and produces a single deduplicated, prioritized finding list as a companion document.

After it completes, update the stub: aggregate-findings → ✅

**Context economy** — aggregate-findings output is on disk. Release stage report content from working context.

---

## Step 12: Retrospective

**Checkpoint:** read the stub — if `retrospective` row shows ✅, skip this step entirely.

Invoke the `retrospective` skill.
After it completes, update the stub progress table (it's already been replaced, but note "retrospective ✅" in conversation).

---

## Step 12b: Memory Promote

**Checkpoint:** read the stub — if `memory-promote` row shows ✅, skip this step entirely.

*If READONLY mode is active: mark memory-promote → ✅ (skipped, same rule as retrospective) and skip this step.*
*If `--skip=memory-promote` is set: same skip.*

Invoke the `memory-promote` skill. This step **pauses for user confirmation** via the `ask-human` skill — memory-promote will present its proposals and invoke `ask-human` before writing anything. Do not bypass this gate; it is intentional.

After the user responds and any applies complete, update the stub: memory-promote → ✅

---

## Step 12c: Skill Extract (optional — `--skill-extract` only)

**Checkpoint:** skip entirely unless `--skill-extract` flag was passed.

Invoke the `skill-extractor` skill. It scans this session's interaction history and memory buffer for repeated prompt patterns and proposes new skills. Each proposal requires explicit ask-human approval — the pipeline pauses here until the user responds to each proposal.

After user responds, update the stub if present: skill-extract (optional) → ✅

---

## Step 13: Handoff

**Checkpoint:** read the stub — if `handoff` row shows ✅, skip this step entirely.

Invoke the `handoff` skill.

In the handoff note, include the report path so the next session can find it immediately.

---

## Session-Remember Awareness

| State | Behavior |
|-------|----------|
| Normal | All stages run; retrospective + memory-promote + handoff write to memory/CLAUDE.md |
| DISABLED | Pipeline runs; retrospective + memory-promote run but memory capture is silent |
| READONLY | Pipeline runs; retrospective skipped (no new captures); memory-promote skipped; handoff runs |
| On failure mid-pipeline | Always run `/handoff` before surfacing the error — stub marks which stages completed |

---

## Compaction Resume — How It Works

When context is compacted mid-pipeline, the next execution reads `$REPORT_DIR/.current-run`
to find the active stub, scans the status table, and skips every ✅ row. This means:

- **Multiple runs per day**: each invocation writes a *new* report file (full-analysis.md,
  full-analysis-run2.md, …) with a fresh stub (all ⏳) and updates `.current-run`. Every
  stage runs — no stale skips from an earlier run.
- **Resume after compaction**: `.current-run` points to the in-progress stub. Completed
  stages show ✅ and are skipped. The pipeline picks up from the first ⏳ row.
- **The stub is the single source of truth** for resume state — not file timestamps,
  not report directory listings.
