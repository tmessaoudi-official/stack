---
name: sweep
spotlight: true
description: Use when running a Phase 6 second sweep on uncommitted changes before committing, or reviewing code written outside the standard agent workflow.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /sweep — Run a Phase 6 second sweep on uncommitted changes before committing, or review code written outside the standard agent workflow.
>
> No flags — invoked without arguments.
> ```

---

Run a Phase 6 Second Sweep on current uncommitted changes. **Never auto-applies anything — this command only reads and reports.** Use before committing or to review code written outside the standard agent workflow.

## Steps

1. **Assess the diff**:
   - `git diff --stat` — change footprint (files changed, lines added/removed)
   - `git diff` — full diff
   - `git diff --cached --stat` + `git diff --cached` — staged changes too

2. **Review each changed file** using the Phase 6 checklist:

   **All files**:
   - **Bug hunt**: logic errors, off-by-one, null/nil/undefined deref, unchecked error returns, unhandled edge cases
   - **Security**: credentials/secrets in code, injection risks (SQL, shell, template), missing input validation at system boundaries
   - **Contracts**: changed function signatures, changed CLI flags, changed API response shapes, changed config keys — flag every one as a potential breaking change
   - **Tests**: new behavior without a test? Modified behavior without updated tests?
   - **Docs**: changed public interface without updated documentation?

   **Shell scripts** (`.sh`):
   - Missing `set -euo pipefail` or equivalent
   - Unquoted variable expansions (`$VAR` instead of `"$VAR"`)
   - Missing error handling after commands that can fail silently
   - `rm -rf` on an unvalidated or unquoted path

   **Config / infra files** (`.yaml`, `.yml`, `Dockerfile`, `.env`):
   - Secrets or credentials committed directly
   - `ARG` without matching `ENV` if runtime access needed
   - Trailing `;` in list vars that would be silently swallowed

3. **Classify each finding** by severity:
   - **CRITICAL**: security hole, data loss risk, broken API contract, shell injection, unhandled error that will crash in production
   - **WARNING**: missing test, logic edge case, performance regression, missing error handling, unquoted variable
   - **NOTE**: style, naming, non-blocking improvement

4. **Output a structured findings table**:

```
## Sweep Results

| # | Severity | File:Line | Finding | Fix |
|---|----------|-----------|---------|-----|
| 1 | CRITICAL  | bin/deploy.sh:42      | Unquoted $DIR in rm -rf     | Quote: rm -rf "$DIR" |
| 2 | WARNING   | src/parser.sh:118     | Missing exit-code check     | Check return value of curl |
| 3 | NOTE      | docker-compose.yaml:9 | Unused ARG                  | Remove or document |

**Verdict**: PASS (safe to commit) or BLOCKED (N critical findings must be fixed first)
```

5. **Save the report**: Write findings to a timestamped file so they survive the session:

```bash
PROJECT_SLUG=$(echo "${CLAUDE_PROJECT_DIR:-$PWD}" | sed 's|^/|-|; s|/|-|g')
SWEEP_DIR="$HOME/.claude/projects/$PROJECT_SLUG/sweeps"
mkdir -p "$SWEEP_DIR"
SWEEP_PATH="$SWEEP_DIR/$(date +%Y-%m-%d-%H%M%S).md"
```

Write the full findings table (including verdict) to `$SWEEP_PATH`. Announce: "Sweep report saved to `$SWEEP_PATH`"

## Notes

- A single CRITICAL finding means verdict is BLOCKED
- Multiple WARNINGs with no CRITICAL = PASS with notes (your discretion)
- Apply **Kernighan's Law**: if the diff is hard to understand, that itself is a WARNING (complexity)
- Apply **Chesterton's Fence**: before flagging a removal as wrong, understand why the code existed (`git blame`, commit message)
- Apply **Hyrum's Law**: any changed public interface (CLI flag, function signature, config key, command output format) is a potential contract break — flag it
