---
name: gates-bypass
description: Use when reviewing or changing any safety-gate bypass sentinel (ask-human gate, bash firewall, question guard, completion guard, prework guard, autonomous-3c) at global, per-project, or per-session scope — shows current state and asks before applying or removing each one.
user-invocable: true
args: "[--status] [--scope=global|project|session] [--family=ah|fw|qg|ac|pw|auto3c] [--all-guards-off] [--all-guards-on] [--orphans]"
side-effects: Creates or removes bypass sentinel files under ~/.claude/state/, ~/.claude/projects/<slug>/state/, and ~/.claude/run/ — only for changes explicitly approved via AskUserQuestion (or named on the command line with --all-guards-off/--all-guards-on).
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /gates-bypass — Review or change any safety-gate bypass sentinel at global, per-project, or per-session scope; shows current state and asks before applying or removing each one.
> ```
>
> Then output the complete flag table below. Then STOP.

| Flag | Value | Default | Description |
|------|-------|---------|-------------|
| `--status` | — | off | Read-only: print the status grid and exit. No `AskUserQuestion`, no mutation. |
| `--scope` | `global`\|`project`\|`session` | all three | Restrict the walk to one scope |
| `--family` | `ah`\|`fw`\|`qg`\|`ac`\|`pw`\|`auto3c` | all six | Restrict the walk to one gate family |
| `--all-guards-off` | — | off | Skip the per-family questions and set a bypass at the given (or asked-for) scope for every guard family in one confirmed batch |
| `--all-guards-on` | — | off | Skip the per-family questions and remove every bypass at the given (or asked-for) scope in one confirmed batch |
| `--orphans` | — | off | List session-scoped sentinels whose session is over 24h old with the exact `rm` command for each; no mutation |

---

# /gates-bypass

One place to see and change every safety-gate bypass sentinel instead of asking Claude to
`touch`/`rm` them from memory, one family at a time.

**Six gate families**, each with three possible scopes:

| Family | Code | Sentinel filename | Guards |
|---|---|---|---|
| ask-human gate | `ah` | `ask-human-gate-bypass` | The mandatory task-categorization + AskUserQuestion gate |
| bash firewall | `fw` | `ask-bash-firewall-bypass` | The v3 boundary gate on every Bash command |
| question guard | `qg` | `ask-human-question-guard-bypass` | Stop-hook block on a free-text `?` without AskUserQuestion |
| completion guard | `ac` | `advisor-completion-guard-bypass` | Stop-hook Rule 6C `advisor()` certification requirement |
| prework guard | `pw` | `advisor-prework-guard-bypass` | PreToolUse Phase 3C `advisor()` certification requirement |
| autonomous-3c | `auto3c` | `autonomous-3c-bypass` | Suppresses the interactive 3C/6C gates for the whole session (protocol-level; see note below) |

Each family's sentinel lives at up to three scopes:

```
global   ~/.claude/state/<filename>
project  ~/.claude/projects/<cwd-slug>/state/<filename>
session  ~/.claude/run/<filename>-<session_id>
```

Precedence everywhere: **env override (fw/qg/ac/pw only) > global > project > session.**

**Session scope requires the guard-hook migration to be installed** for `ah`/`fw`/`qg`/`ac`/`pw`
(each hook must reference `run/<filename>-` — the session-id variable name differs per hook:
`SESSION_ID`, `FW_SID`, `QG_SID`, `ACG_SID`). Step 2 below detects this per family and
flags any family where a session sentinel would currently be inert. `auto3c` session scope has
always existed (`run/autonomous-3c-bypass-<sid>`, formerly `run/autonomous-3c-<sid>` before the
2026-08-30 rename) and needs no hook — it is honored at the protocol level, not mechanically.

**One permission prompt per mutation is the design, not friction.** Every `touch`/`rm` is its own
Bash call — this is intentional (CLAUDE.md: *"entering/leaving autonomous mode is never silent —
the prompt is the opt-in"*), and it applies to every family here, not just autonomous-3c. Never
batch mutations into one command to reduce prompts.

Memory (`session-remember`) and lean-mode toggles are **not** managed here — they have their own
skills (`/memory-off|on|readonly|status|block|unblock`, `/lean`, `/lean-block|unblock`). This skill
shows their status for context but always delegates the actual change.

---

## Step 1 — Resolve keys

```bash
CWD="$PWD"
SLUG=$(printf '%s' "$CWD" | tr '/' '-')
SID="${CLAUDE_CODE_SESSION_ID:-}"
echo "cwd:  $CWD"
echo "slug: $SLUG"
echo "sid:  ${SID:-<none — session-scope operations will be unavailable>}"
```

Use `$SLUG` (cwd-based), **never** a git-toplevel discovery — the guard hooks key on the payload's
raw `.cwd`, not on the repo root. If a session-scope operation is requested and `$SID` is empty,
stop with `⛔ No session id available — session-scope operations require an interactive session.`

## Step 2 — Status scan (read-only, always runs first)

Run this in one Bash call — it is read-only and never prompts:

```bash
STATE="$HOME/.claude/state"
PROJ="$HOME/.claude/projects/$SLUG/state"
RUN="$HOME/.claude/run"

declare -A NAME=( [ah]="ask-human-gate-bypass" [fw]="ask-bash-firewall-bypass"
  [qg]="ask-human-question-guard-bypass" [ac]="advisor-completion-guard-bypass"
  [pw]="advisor-prework-guard-bypass" [auto3c]="autonomous-3c-bypass" )
declare -A ENVVAR=( [ah]="" [fw]="CLAUDE_BASH_FIREWALL_OFF" [qg]="QGUARD_OFF"
  [ac]="ACGUARD_OFF" [pw]="PREWORK_OFF" [auto3c]="" )
declare -A HOOK=( [ah]="ask-human-gate-block.sh" [fw]="ask-bash-firewall.sh"
  [qg]="ask-human-question-guard.sh" [ac]="advisor-completion-guard.sh"
  [pw]="advisor-prework-guard.sh" [auto3c]="" )

printf '%-8s %-5s %-8s %-8s %-10s %s\n' "family" "env" "global" "project" "session" "session-honored?"
for f in ah fw qg ac pw auto3c; do
  fn="${NAME[$f]}"
  ev="${ENVVAR[$f]}"
  envset="–"; [[ -n "$ev" ]] && envset=$([[ -n "${!ev:-}" ]] && echo "●" || echo "○")
  g=$([[ -f "$STATE/$fn" ]] && echo "●" || echo "○")
  p=$([[ -f "$PROJ/$fn" ]] && echo "●" || echo "○")
  if [[ "$f" == "auto3c" ]]; then
    s=$([[ -n "$SID" && -f "$RUN/${fn}-$SID" ]] && echo "●" || echo "○")
    honored="protocol"
  else
    s=$([[ -n "$SID" && -f "$RUN/${fn}-$SID" ]] && echo "●" || echo "○")
    honored=$(grep -qF "run/${fn}-" "$HOME/.claude/hooks/${HOOK[$f]}" 2>/dev/null && echo "yes" || echo "NOT INSTALLED")
  fi
  printf '%-8s %-5s %-8s %-8s %-10s %s\n' "$f" "$envset" "$g" "$p" "$s" "$honored"
done
```

Report this grid verbatim to the user before anything else. If `--status` was passed, **stop here**
— no questions, no mutation.

## Step 3 — Decide (skipped when `--status` was passed)

Filter the six families by `--family` if given. For each remaining family, derive the offered
options **from the grid just printed** — never enumerate blindly (six families × three scopes ×
apply/remove exceeds the 4-option `AskUserQuestion` cap):

- A scope showing `○` (unset) → offer "apply a bypass at that scope"
- A scope showing `●` (set) → offer "remove it, restoring the guard"
- If `--scope=X` was given, only that scope's option appears for each family
- If a family's session column shows `NOT INSTALLED`, append a one-line note to that option's
  description: *"session bypass will have no effect until the guard-hook migration is applied"*

Batch ≤4 questions per `AskUserQuestion` call — six families is two rounds. **Safety inversion is
mandatory**: when the current state is "guard active" (all scopes `○`), the first/recommended
option is *"Keep the guard active"* — never lead with applying a bypass. When a bypass already
exists, the first/recommended option is *"Remove it, restore the guard"*.

`--all-guards-off <scope>` / `--all-guards-on <scope>` skip the per-family walk but still run one
`AskUserQuestion` batch confirmation before Step 4 — never mutate six files from a flag with zero
confirmation.

## Step 4 — Apply

For every change the user approved, run **exactly one** `touch` or `rm -f` per file, each as its
own Bash call:

```bash
# apply (global example — substitute the resolved path for the chosen scope/family)
touch "$HOME/.claude/state/<filename>"
# or, per-project
mkdir -p "$HOME/.claude/projects/$SLUG/state" && touch "$HOME/.claude/projects/$SLUG/state/<filename>"
# or, per-session
touch "$HOME/.claude/run/<filename>-$SID"

# remove
rm -f "$HOME/.claude/state/<filename>"
```

Do not combine multiple touches/removals with `&&`, `;`, or a heredoc — each is a distinct,
separately-prompted mutation by design.

## Step 5 — Report

Re-run the Step 2 grid and show the before/after diff. Then orphan-check:

```bash
find "$HOME/.claude/run" -maxdepth 1 -name '*-bypass-*' -mmin +1440 2>/dev/null | while read -r f; do
  echo "⚠ orphaned session sentinel (>24h old): $f"
  echo "    rm -f \"$f\""
done
```

List each with its exact `rm -f` command for the user to run by hand — this path is ask-gated by
design (matches how `claude-cleanup.sh --run-files` already treats stale `*-bypass-*` session
markers, across all 6 families: reported, never auto-deleted). `--orphans` alone runs only this
block and stops.

---

## Delegated families (status only — never mutated here)

Report these for context, then point at the owning skill; do not touch their files.

```bash
SR="$HOME/.claude/hooks/session-remember"
echo "memory: $([[ -f "$SR/DISABLED" ]] && echo OFF-global || [[ -f "$SR/READONLY" ]] && echo RO-global || echo on) — manage with /memory-off, /memory-on, /memory-readonly, /memory-block, /memory-unblock, /memory-status"
[[ -f "$HOME/.claude/LEAN_MODE.$SLUG" ]] && echo "lean: ON for this project" || echo "lean: off for this project"
echo "  — manage with /lean, /lean-block, /lean-unblock"
```
