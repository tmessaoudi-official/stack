---
name: learning-on
description: Use when enabling the learning-output-style plugin to add insight blocks, trade-off commentary, and educational explanations to responses.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /learning-on — Enable the learning-output-style plugin to add insight blocks, trade-off commentary, and educational explanations to responses.
>
> No flags — invoked without arguments.
> ```

---

# /learning-on — Enable Learning + Explanatory Output Style

Enables the `learning-output-style` plugin for this machine's Claude Code sessions.

## Steps

1. Read `~/.claude/settings.json`.
2. Set `"learning-output-style@claude-plugins-official": true` in the `enabledPlugins` section.
3. Write the updated file.
4. Confirm: "Learning mode enabled. Restart Claude Code for the change to take effect."

## What this enables

- `★ Insight` blocks after code — educational explanations of implementation choices specific to the codebase
- "Request contribution" prompts — Claude asks you to write meaningful business logic (5–10 lines) at key decision points rather than implementing everything itself
- Explanatory commentary on trade-offs and design choices

## When to use

- Exploring an unfamiliar codebase or technology area
- Deliberate learning sessions where you want explanations, not just execution
- Onboarding to a new project domain

Disable with `/learning-off` when switching back to execution mode.
