---
name: expand
spotlight: true
description: Use when a task input is narrow and you need structured full-picture coverage across 23 dimensions before committing to an approach. Use when you need to surface what you don't know you don't know.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /expand — Use when a task input is narrow and you need structured full-picture coverage across 23 dimensions before committing to an approach.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /expand — Context Widening Engine

Takes any narrow input (a bug, feature, scenario, system, decision, topic) and returns a
structured full-picture map — all dimensions, angles, and cases you couldn't see from
where you were standing. Pure output: no file writes, no code changes, no detection.

The value is guaranteed structural coverage across 23 dimensions, not just "Claude being
thorough." The questions section at the end is the most important output — it surfaces
what you didn't know you didn't know.

## Flags

- `<input>` — the narrow thing to expand (required; free text, any length)
- `--project` — domain-aware mode: probe the current codebase before expanding; answers
  grounded in actual files and behavior (default: domain-blind, first principles only)
- `--lens bug|feature|system|decision` — weight relevant dimensions (see below)
- `--depth shallow|deep` — output density (default: medium, max 3 bullets per dimension)
- `--dry-run` — print the expansion plan (which dimensions will be weighted) without running
- `--quick` — scan only 5 highest-signal dimensions (identity, scope, failure modes, dependencies, blind spots); skips all 23 for a fast 2-min pass

---

## Step 0: Parse and announce

Parse flags. If `--dry-run`: print the planned dimension weights for the chosen lens and
stop. Otherwise announce:
`"Expanding: <input>" [domain-aware | domain-blind] [lens: <lens> if set]`

If `--quick`: skip Steps 1–2 entirely. Run a 5-dimension fast pass only:
1. **Identity** — what is this really about?
2. **Scope** — what's in and what's out?
3. **Failure modes** — top 3 ways this breaks?
4. **Dependencies** — what does this touch?
5. **Blind spots** — what am I likely missing?

Output results for all 5, then jump to Step 3 (Questions) and stop.

---

## Step 1: Domain probe (only if `--project`)

Launch a single Explore subagent to probe the current project for relevant context:
- Find files, functions, configs, tests directly related to `<input>`
- Note: callers, dependents, recent changes, known issues, test coverage
- Time-box: return whatever is found in one pass — do not iterate

Use the probe findings to ground the expansion. Label each grounded claim with `[observed]`.
Claims made from first principles only: label `[inferred]`.

---

## Step 2: Expand across all 23 dimensions

Cover every dimension in every group. For each dimension:
- Medium depth (default): max 3 bullets — dense, specific, no filler
- Shallow (`--depth shallow`): 1 sentence
- Deep (`--depth deep`): full prose, no cap

If a dimension cannot be answered: write `[UNKNOWN — needs investigation]`. Never hallucinate.

### Lens weighting (mark weighted dimensions with ★)

| Dimension | bug ★ | feature ★ | system ★ | decision ★ |
|-----------|-------|-----------|----------|------------|
| Failure Modes | ★ | | | |
| Known Issues & Debt | ★ | | | |
| Observability & Evidence | ★ | | | |
| Contradictions & Tensions | ★ | | | |
| Scope & Boundaries | | ★ | | |
| Edge Cases & Boundaries | | ★ | | |
| Alternatives & Trade-offs | | ★ | ★ | ★ |
| Impact & Ripple Effects | | ★ | ★ | |
| Anatomy | | | ★ | |
| Dependencies | | | ★ | |
| Interfaces & Contracts | | | ★ | |
| Constraints & Forces | | | | ★ |
| Assumptions | | | | ★ |

★ dimensions: lead with them, go deeper, surface more bullets.

---

## Step 3: The 23 dimensions

### I — Identity *(what is it, really?)*
1. **Definition & Purpose** — What it is, what problem it solves, why it exists at all.
2. **Scope & Boundaries** — What's in, what's out, what it explicitly does NOT own.
3. **Mental Model** — The right way to think about it — core abstraction, key invariants, useful analogies.
4. **History & Evolution** — How we got here. What was tried before. What decisions shaped the current form.

### II — Structure *(how is it composed?)*
5. **Anatomy** — Internal components, layers, parts, data flows. How the pieces fit together.
6. **Dependencies** — What it needs to function — inputs, services, libraries, runtime assumptions.
7. **Dependents & Callers** — What relies on it. What breaks or changes if this changes. Blast radius.
8. **Interfaces & Contracts** — How the outside world communicates with it.

### III — Behavior *(how does it act?)*
9. **Happy Path** — Normal operation. The golden path. Expected inputs → expected outputs.
10. **Edge Cases & Boundaries** — Corner cases, boundary conditions, unusual but valid inputs.
11. **Failure Modes** — What can go wrong. How failure propagates. Degraded states.
12. **Performance & Scale** — Speed, memory, throughput. Where it degrades under load.

### IV — Quality *(how healthy is it?)*
13. **Known Issues & Debt** — Documented bugs, silent failures, workarounds, TODO markers.
14. **Security & Trust Surface** — Attack vectors, sensitive data paths, trust boundaries.
15. **Observability & Evidence** — What's visible: logs, traces, metrics. What's dark.
16. **Test Coverage** — What's tested, what's not. Where the safety net has holes.

### V — Context *(where does it sit?)*
17. **Alternatives & Trade-offs** — Other approaches considered or available. Why this one was chosen.
18. **Constraints & Forces** — What makes this design non-negotiable.
19. **Assumptions** — What's taken for granted. Implicit requirements.
20. **Impact & Ripple Effects** — What changes if this changes — upstream, downstream, sideways.

### VI — Discovery *(what don't we know?)*
21. **Gaps & Incomplete Areas** — Missing pieces, stubs, partial implementations.
22. **Risks & Unknown Unknowns** — Low-confidence areas. Things worth investigating before proceeding.
23. **Contradictions & Tensions** — Places where the design fights itself. Competing goals.

---

## Step 4: Questions *(always last, always present)*

Generate at minimum 2 questions per type. No maximum.

### Clarifying
Questions that would sharpen understanding if answered.

### Challenging
Questions that stress-test assumptions.

### Exploratory
Questions that might reveal surprises.

### Strategic
Questions whose answers would change the approach entirely. Go deeper here — minimum 3.

---

## Notes

- This command widens context — it does not detect bugs, write code, or propose fixes
- For bug hunting: use `/sleuth`; for health checks: use `/inspect`; for gap detection: use `/gaps`
- `/expand` is the "what am I not seeing?" tool; the others are "what's actually broken?" tools
- The `expanding-context` skill is the agent-facing version — invoked automatically in Phase 1 Brainstorm when the task input is narrow and specific
