---
name: sr-health
description: Use when diagnosing session-remember pipeline health — scripts, state files, settings registration, sentinel status, output quality, and known bug patterns.
user-invocable: true
---

# /sr-health — Session-Remember Pipeline Health Check

Deep health assessment of the session-remember pipeline — scripts, state files,
settings registration, sentinel status, output quality, and known bug patterns.

Complements `/pre-session-health` (broad, shallow) — this goes deep on one subsystem.

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /sr-health — Deep health check of the session-remember pipeline.
>
> Flags:
>   --project=<slug>  Check a specific project slug (default: current project)
>   --all             Check all known project slugs
>   --quiet           Suppress green (passing) lines
> ```

---

## Step 0: Resolve flags

Parse `$ARGUMENTS`:
- `--project=<slug>` — sets `PROJECT_SLUG` explicitly for this run. Takes precedence over the
  legacy positional form (`$1`) some older invocations still use — keep both working.
- `--all` — instead of running Checks 1–6 once, run the full Variables → Checks 1–6 → Output
  Summary sequence once per slug under `~/.claude/projects/` (`ls ~/.claude/projects/`), in
  turn. Print each project's own Output Summary block, then a one-line rollup:
  `N healthy / M with warnings / K with errors`.
- `--quiet` — print only lines starting with ❌, ⚠️, or ℹ️ from every check's output — omit ✅
  lines. In the Output Summary, ✅ lines are suppressed too; the `Status:` and `Remediation:`
  lines still always print.
- No flags: unchanged — auto-detect the current project via `$CLAUDE_PROJECT_DIR`/`$PWD`.

---

## Variables

```bash
SR_DIR="$HOME/.claude/hooks/session-remember"
GLOBAL_SETTINGS="$HOME/.claude/settings.json"
# PROJECT_SLUG resolution order: --project=<slug> > legacy positional $1 > auto-detect.
# Under --all, substitute each slug from `ls ~/.claude/projects/` here in turn instead.
PROJECT_SLUG="${1:-$(echo "${CLAUDE_PROJECT_DIR:-$PWD}" | sed 's|^/|-|; s|/|-|g')}"
STATE_DIR="$HOME/.claude/projects/$PROJECT_SLUG/memory/sessions/.state"
BUFFER="$HOME/.claude/projects/$PROJECT_SLUG/memory/sessions/buffer.md"
TODAY_FILE="$HOME/.claude/projects/$PROJECT_SLUG/memory/sessions/today.md"
```

---

## Check 1: Script inventory

Verify all pipeline scripts exist and are executable:

```bash
scripts=(save.sh trigger.sh consolidate.sh start.sh stop.sh common.sh extract.py)
for s in "${scripts[@]}"; do
  path="$SR_DIR/$s"
  if [[ ! -f "$path" ]]; then
    echo "❌ MISSING: $path"
  elif [[ "$s" == *.py ]]; then
    python3 -c "import ast; ast.parse(open('$path').read())" 2>/dev/null && echo "✅ $s (syntax OK)" || echo "❌ $s (syntax error)"
  else
    bash -n "$path" 2>/dev/null && echo "✅ $s (bash -n OK)" || echo "❌ $s (syntax error)"
    [[ -x "$path" ]] || echo "⚠️  $s — not executable (chmod +x needed)"
  fi
done
```

---

## Check 2: Settings registration

Confirm all required hooks are registered in `$GLOBAL_SETTINGS`:

Required hooks:
- `PostToolUse` with matcher `.*` → `session-remember/save.sh`
- `PreToolUse` or `UserPromptSubmit` → `session-remember/start.sh`  
- `Stop` → `session-remember/stop.sh`

```bash
jq -r '.hooks | to_entries[] | .key as $event | .value[] | {event: $event, cmd: .command}' \
  "$GLOBAL_SETTINGS" 2>/dev/null | grep session-remember
```

- **Green**: all three lifecycle hooks found
- **Red**: missing hooks — session context will not be captured

---

## Check 3: Sentinel status

```bash
[[ -f "$SR_DIR/DISABLED" ]] && echo "⛔ DISABLED sentinel active — pipeline is off" || echo "✅ No DISABLED sentinel"
[[ -f "$SR_DIR/READONLY" ]] && echo "⚠️  READONLY sentinel active — loading only, no capture" || echo "✅ No READONLY sentinel"
[[ -f "$SR_DIR/DISABLED.lean" ]] && echo "⚠️  DISABLED.lean — lean mode controls pipeline" || true
```

---

## Check 4: State file consistency

**4a — last-save.json exists and is recent**:
```bash
if [[ -f "$STATE_DIR/last-save.json" ]]; then
  ts=$(jq -r '.timestamp // 0' "$STATE_DIR/last-save.json" 2>/dev/null || echo 0)
  age=$(( ($(date +%s) - ts) / 3600 ))
  [[ $age -lt 48 ]] && echo "✅ last-save.json — ${age}h ago" || echo "⚠️  last-save.json — ${age}h ago (stale?)"
else
  echo "⚠️  last-save.json missing — no saves recorded for this project"
fi
```

**4b — last-ndc-ts seeded** (NDC bootstrap invariant):
```bash
if [[ -f "$STATE_DIR/last-ndc-ts" ]]; then
  val=$(cat "$STATE_DIR/last-ndc-ts")
  [[ "$val" -gt 0 ]] 2>/dev/null && echo "✅ last-ndc-ts seeded (epoch $val)" || echo "⚠️  last-ndc-ts contains 0 — NDC will never run (bootstrap invariant broken)"
else
  echo "⚠️  last-ndc-ts missing — NDC compression permanently disabled for this project"
  echo "   Fix: printf '%s\n' \"\$(( \$(date +%s) - 300 ))\" > \"$STATE_DIR/last-ndc-ts\""
fi
```

**4c — skip rate** (high skip rate = pipeline running but not capturing):
```bash
if [[ -f "$STATE_DIR/skipped.log" ]]; then
  total=$(wc -l < "$STATE_DIR/skipped.log" 2>/dev/null || echo 0)
  recent=$(grep -c "$(date -d '7 days ago' +%Y-%m-%d)" "$STATE_DIR/skipped.log" 2>/dev/null || echo 0)
  echo "ℹ️  Skipped sessions: $total total, ~$recent in last 7 days"
  [[ $total -gt 20 ]] && echo "⚠️  High skip count — check SR_MIN_EXCHANGES threshold"
fi
```

---

## Check 5: Output quality

**5a — buffer.md exists and is reasonable**:
```bash
if [[ -f "$BUFFER" ]]; then
  lines=$(wc -l < "$BUFFER")
  grep -q "^TRUNCATED" "$BUFFER" 2>/dev/null && echo "⚠️  buffer.md — truncation sentinel present (buffer was >2000 lines)" || true
  [[ $lines -gt 1500 ]] && echo "⚠️  buffer.md — $lines lines (near 2000-line guard limit)" || echo "✅ buffer.md — $lines lines"
else
  echo "⚠️  buffer.md missing — no buffer for this project"
fi
```

**5b — today.md freshness**:
```bash
if [[ -f "$TODAY_FILE" ]]; then
  age_days=$(( ($(date +%s) - $(stat -c %Y "$TODAY_FILE")) / 86400 ))
  [[ $age_days -le 1 ]] && echo "✅ today.md — updated ${age_days}d ago" || echo "⚠️  today.md — ${age_days}d old (consolidation may not be running)"
else
  echo "ℹ️  today.md missing — consolidation hasn't run yet for this project"
fi
```

---

## Check 6: Known bug pattern scan

**6a — grep -c || echo 0 arithmetic crash** (Sleuth E1, 2026-06-07):
```bash
if grep -rn 'grep -c.*|| echo 0' "$SR_DIR/" 2>/dev/null | grep -q .; then
  echo "❌ KNOWN BUG: grep -c || echo 0 pattern detected in pipeline scripts"
  echo "   This produces '0\\n0' under pipefail — crashes arithmetic evaluation"
  grep -rn 'grep -c.*|| echo 0' "$SR_DIR/" 2>/dev/null
else
  echo "✅ No grep -c || echo 0 patterns"
fi
```

**6b — consolidate.sh heredoc expansion bug** (<<'EOF' should be <<EOF):
```bash
if grep -n "<<'EOF'" "$SR_DIR/consolidate.sh" 2>/dev/null | head -3 | grep -q .; then
  echo "⚠️  consolidate.sh: <<'EOF' detected — may suppress needed variable expansion"
  echo "   Known issue: SR_HISTORY_MAX_ENTRIES sent as literal, not expanded to its value"
  grep -n "<<'EOF'" "$SR_DIR/consolidate.sh"
fi
```

**6c — source common.sh without || exit 0** (kill-switch bypass):
```bash
for script in "$SR_DIR"/*.sh; do
  if grep -q "source.*common.sh" "$script" 2>/dev/null && ! grep -q "source.*common.sh.*|| exit 0" "$script" 2>/dev/null; then
    echo "⚠️  $(basename $script): sources common.sh without || exit 0 (kill-switch bypass risk)"
  fi
done
```

---

## Output summary

Under `--quiet`, omit the ✅ lines below (keep ❌/⚠️/ℹ️ and the `Status:`/`Remediation:` lines).
Under `--all`, print one block like this per project slug, then a final rollup line.

```
Session-remember health — project: <slug> — 2026-06-07 23:55
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Script inventory      — 7/7 scripts present and syntax-clean
✅ Settings hooks        — all 3 lifecycle hooks registered
✅ Sentinel status       — no DISABLED or READONLY sentinels
✅ last-save.json        — 6h ago
⚠️  last-ndc-ts          — missing (NDC compression disabled)
✅ Buffer quality        — 341 lines, no truncation
✅ Known bug patterns    — none detected
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Status: HEALTHY (1 warning — see last-ndc-ts above)
Remediation: printf '%s\n' "$(( $(date +%s) - 300 ))" > ~/.claude/projects/<slug>/memory/sessions/.state/last-ndc-ts
```
