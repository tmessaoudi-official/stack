---
name: memory-on
description: Use when re-enabling the session-remember memory system after it was disabled with /memory-off or /memory-readonly.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /memory-on — Re-enable the session-remember memory system after it was disabled with /memory-off or /memory-readonly.
>
> No flags — invoked without arguments.
> ```

---

Re-enable the session-remember memory system (remove both DISABLED and READONLY toggles).

## Pre-check: lean mode session control

First run:
```bash
[ -f "$HOME/.claude/hooks/session-remember/DISABLED.lean" ] && echo "LEAN_DISABLED_EXISTS=true" || echo "LEAN_DISABLED_EXISTS=false"
```

If `LEAN_DISABLED_EXISTS=true`, stop and say exactly:

```
⛔ Session pipeline is controlled by lean mode (DISABLED.lean is active).
   Running memory-on would remove DISABLED but leave DISABLED.lean — pipeline stays off.

   Options:
     /lean --session on   → re-enable pipeline while keeping lean mode active
     /lean off            → exit lean mode entirely (restores all config)
```

Do not run any further commands. Nothing else.

---

## Normal execution (LEAN_DISABLED_EXISTS=false only)

Run:
```bash
rm -f ~/.claude/hooks/session-remember/DISABLED ~/.claude/hooks/session-remember/READONLY
```

Then confirm by running:
```bash
ls -la ~/.claude/hooks/session-remember/DISABLED ~/.claude/hooks/session-remember/READONLY 2>&1
```

Expected output: both files show "No such file or directory".

Say "Memory ON — normal operation restored (load + capture). Per-project blacklist still applies." Nothing else.
