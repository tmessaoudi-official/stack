---
name: memory-status
description: Use when checking the current state of the session-remember memory system — which toggles are active (DISABLED, READONLY, lean) and what the effective mode is.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /memory-status — report the current state of the session-remember memory system (DISABLED, READONLY, lean toggles, effective mode)
>
> No flags — invoked without arguments.
> ```

---

Report the current state of the session-remember memory system.

Run:
```bash
ls -la \
  ~/.claude/hooks/session-remember/DISABLED \
  ~/.claude/hooks/session-remember/DISABLED.lean \
  ~/.claude/hooks/session-remember/READONLY \
  ~/.claude/hooks/session-remember/blacklist \
  ~/.claude/LEAN_MODE \
  2>&1
```

Interpret the result and report in this exact format:

```
Memory status:
- DISABLED toggle      : <present|absent>
- DISABLED.lean toggle : <present|absent>  [← lean mode session control]
- READONLY toggle      : <present|absent>
- blacklist file       : <present|absent>
- LEAN_MODE sentinel   : <present (since <activated_at>)|absent>
Effective mode         : <DISABLED | DISABLED-LEAN | READONLY | BLACKLIST-ACTIVE | NORMAL>
```

Mode derivation (precedence: DISABLED > DISABLED.lean > READONLY > blacklist > normal):
- DISABLED present → `DISABLED` (memory-off owns this)
- else DISABLED.lean present → `DISABLED-LEAN` (lean mode owns this — use `/lean --session on` or `/lean off` to change)
- else READONLY present → `READONLY`
- else blacklist present → `BLACKLIST-ACTIVE`
- else → `NORMAL`

If LEAN_MODE is present, also run:
```bash
jq -r '"scope=\(.scope // "all") | v\(.version // 1) | project=\(.project_path // "n/a")"' \
  ~/.claude/LEAN_MODE 2>/dev/null || cat ~/.claude/LEAN_MODE
```
And append: `Lean mode active since <activated_at> (scope: <scope>) — run /lean status for full details.`

Also check for readonly-list:
```bash
ls -la ~/.claude/hooks/session-remember/readonly-list 2>&1
```
Add to report:
```
- readonly-list file   : <present|absent>
```
(readonly-list makes matching projects load context but skip capture, without full disable.)

Keep the report under 18 lines. No commentary beyond the table and lean note.
