---
name: new-hook
description: Use when creating a new Claude Code hook — scaffolds a compliant hook script (with log_obs() observability, correct exit codes, and error logging) and presents the settings.json registration snippet for manual application.
user-invocable: true
args: "[--event=<type>] [--name=<name>]"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /new-hook — Scaffold a compliant Claude Code hook script + settings.json registration snippet.
>
> Usage: /new-hook [--event=<type>] [--name=<name>]
>
> Flags:
>   --event=<type>   PreToolUse | PostToolUse | SessionStart | Stop | SubagentStart | SubagentStop
>   --name=<name>    Base name for the hook file (e.g. "lint-on-edit" → lint-on-edit.sh)
>
> If flags are omitted, /new-hook collects them interactively.
> ```

---

## Differentiation from related skills

| Skill | Scope | Use when |
|-------|-------|----------|
| `/new-hook` | Hook scaffold only — script + settings snippet | You want to create a new hook from scratch with correct log_obs() wiring and exit codes |
| `/audit` Agent C | Hook coverage audit across all existing hooks | You want to audit all existing hooks for observability, idempotency, and coverage gaps |

---

## Side effects

**Script created**: writes `~/.claude/hooks/<name>.sh` (after user confirmation). This is the only write operation — it does **not** touch `settings.json`. The settings.json registration snippet is presented for manual copy-paste.

**Why settings.json is not auto-written**: settings.json is a classifier-blocked file; a malformed hook registration entry triggers on every tool call and can break the entire session. Manual registration prevents this failure mode.

---

## Step 0 — Precondition checks

**Mandatory task gate**: invoke `ask-human` before Step 1 begins to confirm size and intent. Do not proceed until the user confirms.

Verify `~/.claude/hooks/` exists: `ls ~/.claude/hooks/` — if absent, report `WARN: ~/.claude/hooks/ does not exist — it will be created when the hook file is written.`

**Existing file guard** (for `--name=<name>` provided upfront): if `~/.claude/hooks/<name>.sh` already exists, emit `WARN: ~/.claude/hooks/<name>.sh already exists` and ask via `ask-human`: Overwrite / Choose a different name / Cancel. Do not generate a new script until the user resolves this.

Verify `log-helpers.sh` exists: `ls ~/.claude/hooks/log-helpers.sh` — if absent, report `WARN: ~/.claude/hooks/log-helpers.sh not found — the scaffolded script will still source it but observability calls will fail silently until the file exists.`

---

## Step 1 — Collect hook parameters

Parse `--event=` and `--name=` from args if provided. For any missing parameters, invoke `ask-human` to collect:

**Event type** (if not provided via `--event=`):

Use `ask-human` with these options:
- `PreToolUse` — runs before a tool call; can block by exiting non-zero
- `PostToolUse` — runs after a tool call; exit code MUST be 0 (non-zero blocks session)
- `SessionStart` — runs at session start; exit code MUST be 0
- `Stop` — runs at session end; exit code MUST be 0
- `SubagentStart` / `SubagentStop` — runs when a subagent is spawned/completed; exit code MUST be 0

**Matcher pattern** (for PreToolUse / PostToolUse):
- Use `ask-human` to collect the tool name pattern (e.g. `Edit`, `Write`, `Bash`, `Edit|Write`, `.*` for all tools)
- Note that pattern is a regex matched against the tool name

**Action description**:
- Collect a one-line description of what the hook does (used in the script comment and the log_obs() message)
- Ask whether the hook reads stdin (tool input JSON) and whether it uses `jq`

**Hook name** (if not provided via `--name=`):
- Derive from the action description: lower-case, hyphens for spaces (e.g. "backup before write" → `backup-before-write`)

---

## Step 2 — Generate hook script

Produce the hook script body applying CLAUDE.md Rule 13 (observability):

```bash
#!/usr/bin/env bash
# <action description>
# Event: <event-type> | Matcher: <matcher>
# Rule 13: uses log_obs() for all state-changing actions; silent on no-ops; errors to hooks-errors.log
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

# --- Action ---
# TODO: implement hook logic here
# Use log_obs "INFO" "action description" for state-changing actions
# Use log_obs "ERROR" "description" for failures (writes to ~/.claude/logs/hooks-errors.log)
# Stay silent (no output) for no-ops

# Example: log_obs "INFO" "<name>" "action completed: <target>"
```

**Exit code wiring** (apply based on event type):
- `PreToolUse`: the script may exit non-zero to block the tool call — this is intentional and correct. Include a comment: `# Exit 1 to block; exit 0 to allow`
- All other events (`PostToolUse`, `SessionStart`, `Stop`, `SubagentStart`, `SubagentStop`): the script MUST exit 0 even on internal error. Append: `|| true` to the final command, or wrap in a trap that forces exit 0.

If the hook reads stdin (tool input JSON):
```bash
INPUT=$(cat)
# Use jq to parse: TOOL=$(echo "$INPUT" | jq -r '.tool_name // empty')
```

---

## Step 3 — Present script for review

Display the generated script content. Ask the user via `ask-human` to confirm before writing:

Options:
- Looks good — write `~/.claude/hooks/<name>.sh` (Recommended)
- Edit first — show me what to change
- Cancel — do not write the file

If "Looks good": write the file and run `chmod +x ~/.claude/hooks/<name>.sh` and `bash -n ~/.claude/hooks/<name>.sh` to verify syntax.

---

## Step 4 — Present settings.json registration snippet

After the script is written, display the exact snippet to add to `~/.claude/settings.json` under the `hooks` key:

```json
{
  "hooks": {
    "<EventType>": [
      {
        "matcher": "<matcher-pattern>",
        "hooks": [
          {
            "type": "command",
            "command": "bash ~/.claude/hooks/<name>.sh"
          }
        ]
      }
    ]
  }
}
```

For events with no matcher (`SessionStart`, `Stop`, `SubagentStart`, `SubagentStop`):
```json
{
  "hooks": {
    "<EventType>": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "bash ~/.claude/hooks/<name>.sh"
          }
        ]
      }
    ]
  }
}
```

State explicitly: "Add this snippet to your `~/.claude/settings.json` manually — this skill does not edit settings.json."

**If the new hook is a GUARD (blocks or gates tool calls) — six registrations, not one** (2026-08-22 lesson: `advisor-completion-guard` shipped with zero of its defence layers because its name fell outside the `ask-*` glob everyone wrote against). Present this checklist with the snippet:

1. **Name it `*guard*.sh`** — `hooks/ask-bash-firewall.sh` v3 protects Claude self-mod paths by the `SELFMOD` fnmatch list (`.claude/hooks/*guard*.sh`, `ask-human-gate-*.sh`, `state/**`, `projects/*/state/**`…); a conforming name is covered automatically, any other name needs a `SELFMOD` entry (classifier-blocked → user-run).
2. **Off-switch = sentinel under `state/`**: `~/.claude/state/<name>-bypass` (global) and `~/.claude/projects/<slug>/state/<name>-bypass` (project) — never `tmp/`, never a bare env var alone. `state/**` is already `SELFMOD` (asks) and `claude-cleanup.sh` never deletes under `state/`.
3. **settings.json ask-rules** for the sentinel verbs: `Bash(touch *<name>-bypass*)`, `Bash(rm *<name>-bypass*)`, `Edit(~/.claude/state/<name>-bypass)`, `Edit(~/.claude/projects/*/state/<name>-bypass)` (user-run).
4. **Statusline line 2** segment in `hooks/statusline.sh` (`_gate_bypass "XX" …`) + a `test-statusline.sh` case — a bypassed guard must be visible.
5. **Bundle manifest**: add `hooks/<name>.sh` (and its test if `/install` should run it) to `_CE_GENERIC_SKILLS` in `bin/lib/claude-export/config/defaults.sh`.
6. **Docs**: CLAUDE.md's guard paragraph, `BLAST-RADIUS.md` "Protected paths", `skills/install/SKILL.md` hook table.

---

## Error handling summary

| Condition | Behaviour |
|-----------|----------|
| `~/.claude/hooks/` absent | WARN — note it will be created on write; continue |
| `log-helpers.sh` absent | WARN — observability calls will fail until the file exists; scaffold still generated |
| `bash -n` fails on generated script | ERROR — display the syntax error; do not mark as complete until fixed |
| User cancels at Step 3 | Report "Cancelled — no file written" and stop |
| `--event=` value not in the known list | ERROR + list valid event types; stop |
