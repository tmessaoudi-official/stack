---
name: cleanup
spotlight: true
description: Use when cleaning up ephemeral Claude Code temp files: session-remember artifacts, stale backups, old logs, orphaned project entries, old JSONLs, session UUID dirs, paste-cache files, plans, specs, bundles, raw analysis outputs, session-env dirs, file-history, tasks, IDE locks, run files, team session dirs, telemetry spool files, and daemon PID sessions.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /cleanup — Safe ephemeral-file cleanup for Claude Code config directories (session-remember artifacts, stale backups, old logs, orphaned project entries, old JSONLs, session UUID dirs, paste-cache files).
> ```
>
> Then output the complete flag table from the **"Safe defaults"** section below. Then STOP.

---

Safe ephemeral-file cleanup for Claude Code config directories.

Identifies and optionally removes:
- **sr-tmp**: `/tmp/sr-*` session-remember mktemp artifacts older than 60 minutes; `/tmp/claude-export-*` staging dirs left by interrupted bundle runs
- **snapshots**: `~/.claude/shell-snapshots/` files older than 7 days
- **backups**: `*.bak.<timestamp>` and `*.backup.<timestamp>` files, keeping the 10 newest per
  base file (`_CC_BACKUP_KEEP`); scans **both `~/.claude` and `/path/to/your/project`** at unbounded depth —
  intentional cross-project hygiene, not a scoping bug
- **logs** (opt-in with `--logs`): `~/.claude/logs/*.log` files larger than 500 KB are size-rotated (keeps 3 rotations: `hooks-errors.log`, `hooks-errors.log.1`, `hooks-errors.log.2`, oldest deleted); `~/.claude/logs/edits/YYYYMMDD.txt` daily files older than 30 days are deleted
- **reports** (opt-in with `--reports`): analysis report `.md` files in `inspections/`, `sleuth/`, `gaps/`, `visions/`, `audits/`, `repairs/`, and `meta-reports/`, scanned at **exactly 3 levels deep** under a project slug (deeper-nested report dirs are invisible to this flag); the **3 newest live reports per directory are always kept** (`_CC_REPORTS_KEEP`) — old ones are **moved to `<project>/archive/<type>/`** (not deleted) — preserves mega-analysis delta history; archive dirs themselves are pruned to 10 newest (`_CC_ARCHIVE_KEEP`) to prevent unbounded growth; add `--purge` to permanently delete instead
- **orphaned** (opt-in with `--orphaned`): `~/.claude/projects/` entries whose source dir is gone or was a temp path:
  - `test-artifact` (slug matches `-tmp-tmp.*`): entire dir deleted
  - `system-temp` (source-path in `/tmp/` or `/var/tmp/`, or slug starts with `-tmp-`): entire dir deleted
  - `orphaned` (source-path recorded but dir no longer exists): JSONLs deleted, `memory/` preserved
- **jsonl** (opt-in with `--jsonl`): old session transcript `.jsonl` files in live projects older than N days (default 30); active session is always protected
- **sessions** (opt-in with `--sessions`): per-conversation UUID artifact dirs (`~/.claude/projects/<slug>/<UUID>/`) older than N days (default 60); each dir contains `subagents/` and `tool-results/` from one conversation and can reach 75+ MB; active session protected via `last-save.json`
- **paste** (opt-in with `--paste`): files in `~/.claude/paste-cache/` older than N days (same threshold as `--sessions`, default 60); no native retention policy exists
- **plans** (opt-in with `--plans`): Rule 17 plan files in two locations — `~/docs/plans/*.plan.md` (repo-local) and `~/.claude/projects/*/plans/*.plan.md` (global, hybrid plan-location sentinel); always `--dry-run` first and confirm each task is complete before `--apply`
- **native-plans** (opt-in with `--native-plans`): Claude Code's OWN plan-mode artifacts in `~/.claude/plans/*.md` (codename files + agent variants) — distinct from Rule 17 `*.plan.md`; deletes files older than N days (default 30, tune with `--native-plans-days=N`)
- **specs** (opt-in with `--specs`): `~/.claude/docs/specs/*.md` design spec documents; review before deleting — specs often inform future decisions
- **bundles** (opt-in with `--bundles`): `claude-setup-*.tar.gz` archives (and `.sha256` sidecars) left by `/bundle` runs, scanned in `~/`, `~/.claude/`, **and `/path/to/your/project/claude-setup/`**; safe to delete (re-run `/bundle` to regenerate)
- **raw** (opt-in with `--raw`): pipeline-intermediate dirs named `raw`, `raw-*`, or `*-raw` anywhere 2–4 levels under a project slug — covers the canonical `*/sleuth/raw*/` `*/gaps/raw*/` `*/inspections/raw*/` `*/audits/raw*/` shapes as well as non-canonical producers (`forge/raw`, `visions/raw`, `parity-review/raw`, `feasibility-*/raw`, `meta-reports/*/raw`, `review-aggregate-raw`, `reviews/<date>-raw`) — the dir-name pattern itself is the guard, not a fixed path/producer whitelist
- **session-env** (opt-in with `--session-env`): `~/.claude/session-env/<UUID>/` **directories** (F-3.1, 2026-08-30 — was a dead `-type f` check against a directory-only tree, matched 0/3177 entries ever) — one per session (pid, cwd, status); accumulate unboundedly; prunes by `--session-days` threshold
- **file-history** (opt-in with `--file-history`): `~/.claude/file-history/<UUID>/` dirs — versioned file content per conversation; can reach 10-12MB per dir; prunes by `--session-days` threshold
- **tasks** (opt-in with `--tasks`): `~/.claude/tasks/session-<hex>/` dirs (F-3.2, 2026-08-30 — was a UUID regex against a `session-<hex>`-only tree, matched 0/93 entries ever) — TaskCreate/Update state per conversation; `pins.json` and non-`session-*` app dirs never touched; prunes by `--session-days` threshold
- **ide-locks** (opt-in with `--ide-locks`): `~/.claude/ide/*.lock` files — one per IDE connection; stale when IDE disconnects; removes only locks whose PID is no longer running
- **run-files** (opt-in with `--run-files`): six per-session families in `~/.claude/run/` — `session-cwd-<sid>.txt`, `status-context-<sid>.txt`, `status-banner-<sid>.txt`, `actual-window-<sid>.txt`, `ctx-notified-<sid>.txt` (banner/stop hooks) and the suffix-less `permission-mode-<sid>` (written every Stop/PostToolUse for the `⚠⚠⚠ BYPASS` statusline segment) — **plus** (F-3.4, 2026-08-30) four dot-prefixed mktemp leftovers from the statusline scripts that used a different naming convention entirely: `.actual-window.*`, `.status-banner.*`, `.status-agents.*`, `.status-ctx.*` (66 found on the machine that surfaced this, oldest 2+ months); accumulate unboundedly; threshold 1440min (24h) matches the banner's own self-clean of the six named families (a live session refreshes its files on every tool call); sessions idle >1440min will lose their CWD anchor (stop hook degrades gracefully). Stale `<family>-bypass-<sid>` gate-bypass markers (all 6 families — see `/gates-bypass`) are **reported `[protected]`, never deleted** (ask-gated self-mod path — `rm` them by hand); `active-plan-<sid>` pointers are left to the banner (reaped only when the target plan is gone)
- **history** (opt-in with `--history`): reports `~/.claude/history.jsonl` size and warns if it exceeds ~2MB; **informational only — never auto-deleted** (truncating breaks `--resume`); manual rotation command is printed when oversized
- **jobs** (opt-in with `--jobs`): reports `~/.claude/jobs/` directory size and warns if it exceeds ~100MB; **informational only — never auto-deleted**; review contents manually before removing
- **teams** (opt-in with `--teams`, new 2026-08-30): `~/.claude/teams/session-<hex>/` dirs — per-session team-mode config; no reaper existed before this; prunes by `--session-days` threshold
- **telemetry** (opt-in with `--telemetry`, new 2026-08-30): `~/.claude/telemetry/1p_failed_events.*.json` — failed analytics-event spool files; prunes by `--jsonl-days` threshold
- **pid-sessions** (opt-in with `--pid-sessions`, new 2026-08-30): `~/.claude/sessions/<pid>.json` and `<pid>.<sha>.key` — per-process daemon session state; PID-liveness check like `--ide-locks`, removes only entries whose PID is no longer running

**Default mode is `--dry-run`** — shows what would be changed without touching files.
Run with `--apply` to act (ask-tier permission, prompts in Claude Code).

```
~/.claude/bin/claude-cleanup.sh [--dry-run] [--apply] [--logs] [--reports] [--purge]
                                 [--orphaned] [--jsonl] [--jsonl-days=N]
                                 [--sessions] [--session-days=N] [--paste] [--verbose]
                                 [--plans] [--native-plans] [--native-plans-days=N]
                                 [--specs] [--bundles] [--raw] [--run-files]
                                 [--session-env] [--file-history] [--tasks] [--ide-locks]
                                 [--history] [--jobs] [--teams] [--telemetry] [--pid-sessions]
                                 [--scope=global|project|all] [--project=<slug>|all]
```

## What is NOT touched

- `~/.claude/projects/*/memory/` — session-remember summaries and handoff notes (unless `--orphaned` targets a temp/test-artifact entry)
- `~/.claude/settings.json`, `CLAUDE.md`, hooks, commands — config files
- Any `/tmp/sr-*` file written in the last 60 minutes (active session protection)
- `*.bak.php`, `*.bak.sh` etc. — non-timestamped `.bak.*` files (not cleanup backups)
- Active session JSONL (detected from `last-save.json` — always protected even with `--jsonl`)
- Active session UUID dir (detected from `last-save.json` — always protected even with `--sessions`)
- `~/.claude/run/{session-cwd-*.txt,status-context-*.txt,status-banner-*.txt,permission-mode-*}` written in the last 1440 minutes (24h); `--run-files` only targets files older than 1440min — matches banner self-clean threshold
- `~/.claude/run/*-bypass-*` per-session gate-bypass markers (all 6 families) and `active-plan-*` pointers — never deleted by `--run-files` (reported `[protected]` / left to the banner)
- `~/.claude/llm-sandbox/` — session-remember LLM call sandbox; its JSONLs are prunable with `--jsonl`
- Any path containing `/state/` — bypass/autonomous sentinels are a structural guard in `_cc_act`/`_cc_act_dir` (reported `[protected]`), independent of which flag would otherwise match it

## Usage in Claude Code

Ask Claude to run it:

```
Run ~/.claude/bin/claude-cleanup.sh --dry-run
Run ~/.claude/bin/claude-cleanup.sh --apply
Run ~/.claude/bin/claude-cleanup.sh --apply --logs
Run ~/.claude/bin/claude-cleanup.sh --apply --reports
Run ~/.claude/bin/claude-cleanup.sh --dry-run --orphaned --jsonl
Run ~/.claude/bin/claude-cleanup.sh --apply --orphaned --jsonl --jsonl-days=60
Run ~/.claude/bin/claude-cleanup.sh --dry-run --sessions --paste
Run ~/.claude/bin/claude-cleanup.sh --apply --sessions --session-days=90 --paste
Run ~/.claude/bin/claude-cleanup.sh --dry-run --plans --specs --bundles --raw
Run ~/.claude/bin/claude-cleanup.sh --apply --bundles --raw
```

Or ask directly: *"Clean up old Claude temp files"* — Claude will invoke `--dry-run` first
and show you the plan before asking to apply.

## Safe defaults

| Flag | Behavior |
|------|---------|
| (no flags) | Same as `--dry-run` — show what would change without touching files |
| `--dry-run` | Explicit dry-run (same as no flags; useful for scripting clarity) |
| `--apply` | Act on identified files |
| `--logs` | Size-rotate `~/.claude/logs/*.log` files >500KB (keep 3); prune `logs/edits/` files >30 days |
| `--reports` | Include analysis reports scan — archives old ones (off by default); also prunes archive dirs to 10 newest |
| `--purge` | With `--reports`: permanently delete instead of archiving |
| `--orphaned` | Delete temp/test-artifact project entries; delete JSONLs from orphaned entries |
| `--jsonl` | Prune old session transcripts from live projects (default: >30 days) |
| `--jsonl-days=N` | Age threshold for `--jsonl` (default: 30 days) |
| `--sessions` | Prune per-conversation UUID artifact dirs (default: >60 days); active session always protected |
| `--session-days=N` | Age threshold for `--sessions` (default: 60 days) |
| `--paste` | Prune `~/.claude/paste-cache/` files older than `--session-days` threshold |
| `--verbose` | Show every kept file alongside actions |
| `--plans` | List Rule 17 plan files from both `~/docs/plans/*.plan.md` (repo-local) and `~/.claude/projects/*/plans/*.plan.md` (global); always review before `--apply` |
| `--native-plans` | Prune Claude Code native plan-mode files `~/.claude/plans/*.md` older than N days (default 30) |
| `--native-plans-days=N` | Age threshold for `--native-plans` (default: 30 days) |
| `--specs` | List `~/.claude/docs/specs/*.md` — design spec documents |
| `--bundles` | List `~/claude-setup-*.tar.gz` bundle archives |
| `--raw` | List `raw`/`raw-*`/`*-raw` pipeline intermediate dirs, 2–4 levels under a project slug (canonical + non-canonical producers) |
| `--run-files` | Prune `~/.claude/run/` per-session files >1440 min (24h) old — `session-cwd-*.txt`, `status-context-*.txt`, `status-banner-*.txt`, `permission-mode-*` (mirrors banner self-clean); stale `*-bypass-*` gate-bypass markers (all 6 families) reported `[protected]`, never deleted |
| `--history` | Report `~/.claude/history.jsonl` size (warn if >~2MB); informational only — never auto-deleted (truncating breaks `--resume`) |
| `--jobs` | Report `~/.claude/jobs/` size (warn if >~100MB); informational only — never auto-deleted |
| `--session-env` | Prune `~/.claude/session-env/<UUID>` session metadata files older than `--session-days` |
| `--file-history` | Prune `~/.claude/file-history/<UUID>/` dirs older than `--session-days` |
| `--tasks` | Prune `~/.claude/tasks/<UUID>/` dirs older than `--session-days`; UUID dirs only |
| `--ide-locks` | Remove `~/.claude/ide/*.lock` files whose PID is no longer running |
| `--teams` | Prune `~/.claude/teams/session-<hex>/` dirs older than `--session-days` |
| `--telemetry` | Prune `~/.claude/telemetry/1p_failed_events.*.json` older than `--jsonl-days` |
| `--pid-sessions` | Remove `~/.claude/sessions/<pid>.{json,key}` whose PID is no longer running |
| `--scope=global\|project\|all` | Filter artifact layer: `global` = infra only (tmp/snapshots/backups/logs/paste/specs/bundles/plans/native-plans/history/jobs); `project` = per-slug data only (reports/orphaned/jsonl/sessions/raw); `all` (default) = both layers. Accept `both` as synonym for `all`. |
| `--project=<slug>\|all` | Restrict project-layer scans to a specific slug (e.g. `-stack-projects-foo`); only affects project-layer categories (reports/orphaned/jsonl/sessions/raw); `all` (default) = all slugs. Combines with `--scope=project` for targeted cleanup of one project's data. |

## Scope × project mapping

| Category | Layer | `--project` filterable |
|----------|-------|----------------------|
| tmp, snapshots, backups, logs, paste, specs, bundles, plans, native-plans, run-files, session-env, file-history, tasks, ide-locks, history, jobs, teams, telemetry, pid-sessions | `global` | no |
| reports, orphaned, jsonl, sessions, raw | `project` | yes |

## Tests

```bash
bash ~/.claude/bin/run-tests.sh
```
