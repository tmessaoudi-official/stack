---
paths:
  - "**/*.{sh,bash,zsh,py,php,js,mjs,cjs,ts,tsx,jsx,vue,svelte,rs,go,java,kt,c,h,cc,cpp,hpp,cs,rb,swift,zig,lua,pl,sql}"
  - "**/*.{yml,yaml,toml,ini,json,jsonc,xml,gradle,mk}"
  - "**/{Makefile,Dockerfile,Containerfile,Justfile,compose.yaml,compose.yml,docker-compose.yml,docker-compose.yaml}"
  - "**/Dockerfile.*"
---
<!-- L3 software method (domain-agnostic step 10, 2026-10-09): moved verbatim from ~/.claude/CLAUDE.md. A user rule:
     loads in ANY project when a code or build file is read; the gates it serves (Rule 7 hard rule, Rule 14, Rule 6) stay in CLAUDE.md. -->

## From CLAUDE.md Phase 6 — Semantic/coverage checklist

(The checklist's intro and item 2, full-set coverage, stay in CLAUDE.md Phase 6.)

1. **Context-shift scan**: If surrounding syntax changed (quoting, escaping, nesting, template boundaries) — re-read every affected line for characters whose role changed in the new context: `#` entering a quoted string, `$` crossing a template boundary, `:` becoming a YAML key, whitespace becoming significant.
3. **No fixture leakage**: When moving, generating, or templating code, no literal value may be taken from the current instance without reading it from the source. A test passing only because the fixture matches a hardcoded literal means both the test and the code are wrong.
4. **Downstream tool in a clean environment**: For any change to files consumed by a build or runtime tool (Docker Compose, Terraform, Make, webpack…), run that tool with `env -i HOME=$HOME PATH=$PATH <cmd>` before declaring success. Stale shell state is not verification.

## From CLAUDE.md Rule 7 — Procedure

   **Procedure:** `/bash-test-harness` isolates a bash script under test (HOME, logs, git, gpg, notifiers, collaborators, faults — `bin/tests/lib/isolate.sh`); `/sabotage-check` runs the mutation step.
 

## From CLAUDE.md Rule 7 — infra TDD + bash isolation

   **TDD for infra tasks**: Pure infrastructure changes (Dockerfile edits, compose config, Makefile targets, env var additions) have no unit-testable behavior — for these, TDD means: first write a `--dry-run` / `docker compose config` / `bash -n` check that *detects the gap*, verify it flags the problem, then implement the fix and verify the check passes.

   **Bash script isolation (scripts that call `$SCRIPT_DIR/x.sh`)**: When writing tests for a bash script that invokes collaborators via `"$SCRIPT_DIR/collaborator.sh"`, running from a different directory won't help — `SCRIPT_DIR` resolves from `BASH_SOURCE[0]` and always points to the original location. Pattern: (1) `cp script-under-test.sh "$TMPDIR/"`, (2) create fake collaborator at `"$TMPDIR/collaborator.sh"`, (3) symlink sourced deps (`ln -sf real/common.sh "$TMPDIR/common.sh"`), (4) run via `bash "$TMPDIR/script-under-test.sh"` — `SCRIPT_DIR` then resolves to `$TMPDIR`.
