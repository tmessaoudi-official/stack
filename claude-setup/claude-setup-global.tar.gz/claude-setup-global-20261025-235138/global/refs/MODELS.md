# Claude Models Reference
# Update this file when Anthropic releases new models.
# /model-audit --currency reads from here — keep it current.
# Format: | Model ID | Family | Version | Status | Context | Supersedes |
# Status values: CURRENT | SUPERSEDED (still valid, not retired) | PREVIEW
# Lineup last checked 2026-10-08 against platform.claude.com/docs/en/about-claude/models/overview (current: Fable 5.1, Opus 5.5,
# Sonnet 5.5, Haiku 5.5, all 1M; legacy list includes Opus 4.5 and Haiku 4.5). "unrecorded" = context window not checked. bin/tests/model-audit-registry.test.sh keeps
# this file and the /model-audit --init template identical.

## Current Canonical IDs

| Model ID | Family | Version | Status | Context | Supersedes |
|----------|--------|---------|--------|---------|------------|
| claude-fable-5-1 | fable | 5.1 | CURRENT | 1M | claude-fable-5 |
| claude-mythos-5 | mythos | 5 | CURRENT (Project Glasswing only) | 1M | mythos-preview |
| claude-opus-5-5 | opus | 5.5 | CURRENT | 1M | claude-opus-5 |
| claude-sonnet-5-5 | sonnet | 5.5 | CURRENT | 1M | claude-sonnet-5 |
| claude-haiku-5-5 | haiku | 5.5 | CURRENT | 1M | claude-haiku-4-5 |

## Superseded — still valid, live API models, not retired

| Model ID | Family | Context | Superseded by |
|----------|--------|---------|----------------|
| claude-fable-5 | fable | 1M | claude-fable-5-1 |
| claude-opus-5 | opus | 1M | claude-opus-5-5 |
| claude-sonnet-5 | sonnet | 1M | claude-sonnet-5-5 |
| claude-opus-4-8 | opus | 1M | claude-opus-5 |
| claude-opus-4-7 | opus | 1M | claude-opus-4-8 |
| claude-opus-4-6 | opus | 1M | claude-opus-4-8 |
| claude-sonnet-4-6 | sonnet | 1M | claude-sonnet-5 |
| claude-opus-4-5 | opus | 200K | claude-opus-4-6 |
| claude-haiku-4-5 | haiku | 200K | claude-haiku-5-5 |

## Notes on date-suffixed variants

Some model IDs appear with a date suffix (e.g., `claude-haiku-4-5-20251001`).
Before the 4.6 generation a dateless ID was an alias pointing at a dated snapshot; from 4.6 on the dateless ID IS the pinned
snapshot (models overview, checked 2026-10-08). Either way a dateless ID never moves to a NEWER model: bump it when one ships.
`/model-audit` still normalizes date-suffixed IDs to the dateless form (one spelling to grep and bump).

The session-remember pipeline picks a model per call class (no date suffix): `claude-haiku-5-5` for bulk save/NDC calls (`SR_MODEL_BULK`) and the daily rollup and weekly archive (`SR_MODEL_CONSOLIDATE`) since 2026-10-08 (A/B in the real call shape: same format, ~5-7x cheaper); the precompact handoff (`SR_MODEL_HANDOFF`) also `claude-haiku-5-5` since 2026-10-09, once its prompt was fixed (it had been the interactive /handoff skill, and 5.5 wrote the headless call's own plan mode and "nothing written" into the note: headless calls inherit settings.json `defaultMode: plan`); decision D12.3 reverted D6's sonnet. These calls run headless and cannot ask, so the default is the decision and each class knob raises one class; `SR_MODEL` still overrides any class without its own knob.

## Model policy v2 — how a component gets its model (2026-09-29, decisions D1–D27)

Full record: `docs/SPEC.md` §6-58; rules in `CLAUDE.md` § "Model policy v2". The levers that actually steer a model: `context: fork` +
`model:` in a skill, an agent file's `model:`, and the Agent call's `model` parameter. An inline skill's `model:` pin is inert.

| Where | What | Guard |
|---|---|---|
| Skill frontmatter | `wants-session-model: strong` — stopped on a session weaker than opus by `hooks/skill-model-notice.sh` | `hooks/tests/test-skill-model-notice.sh` |
| Skill frontmatter | `strong-when-args: --flag` — the stop applies only with that whole-token flag (`/loop --pipeline`; D24: plain `/loop` is never stopped, Rule 15 makes it mandatory for polling) | same |
| Skill frontmatter | `covers-skills: a b c` — an orchestrator's override also covers those stages (and `ask-human`) for the session | `bin/tests/model-profile.test.sh` D23 |
| Spawner skills | one canonical "Model ask" line + a `## Subagent models` table; orchestrators one "Orchestrator model ask" line | model-profile D12, D21 |
| Session model | `bin/session-model.sh`: the NEWER of the statusline's live file `run/session-model-<sid>` and the transcript's last assistant `message.model` / `/model` switch; a brand-new session uses `settings.json` `model` | `bin/tests/session-model.test.sh` |
| Hook state | `~/.claude/state/model-notice/<session id>` — hook-owned, pruned after 7 days (not the running session's file), gitignored | hook tests T22–T28, T45 |
| Your overrides | typed `/name --as-is` or `/name --model-override <model>` runs a stopped skill on the session's model for that call (TYPED prompts only — a model-invoked flag is ignored); `state/model-overrides.json` makes it standing (`skills`), sets the recommended model of a spawner skill's agent label (`agents`) or a headless call class (`hooks`), or forces a model per harness agent type on every Agent call (`agent-types`, applied by `hooks/agent-model-override.sh`). Neither changes WHICH model an inline skill runs on. Manage the table with `bin/model-override.sh get|list|lint|set|unset` | `bin/tests/model-override.test.sh`, `hooks/tests/test-skill-model-notice.sh` T60-T74 |
| Headless calls | session-remember / precompact cannot ask: haiku per class, knobs in `refs/SESSION-REMEMBER.md`; order: env class knob > `model-overrides.json` `hooks.*` > `SR_MODEL` > haiku | `hooks/session-remember/tests/model-knobs.test.sh` |

Run after touching any of it: `bash bin/tests/model-profile.test.sh` and `bash bin/tests/model-profile.test.sh --self`.

## /model CLI shortcuts

Used with the `/model` slash command inside Claude Code sessions.
**[Inferred]** from `settings.json` (`advisorModel: "fable"`, `teammateDefaultModel: "fable"`,
`model: "opusplan"`) and the runtime model ID observed this session (`claude-opus-5[1m]`) — not
read directly from the CLI binary's shortcut table. Verify live with `/model` in a session before
trusting for anything automated.

| Shortcut | Resolves to | Notes |
|----------|-------------|-------|
| `fable` | claude-fable-5-1 | Most capable widely released model ([Inferred] from the 2026-10-07 system-prompt lineup) |
| `opus` | claude-opus-5-5 | [Verified 2026-10-07: an `opus` session reports model ID `claude-opus-5-5`] |
| `sonnet` | claude-sonnet-5-5 | Balanced ([Inferred] from the 2026-10-07 system-prompt lineup) |
| `haiku` | **not** a Haiku in `claude -p` here | [Verified 2026-10-08, Claude Code 2.1.294: `claude -p --model haiku` ran `claude-sonnet-5-5` in 4 runs; every one in plan mode (settings.json `defaultMode: plan`), while `--model claude-haiku-5-5` in plan mode ran Haiku, so the alias may be swapped in plan mode only - Inferred; the Agent tool's `model: "haiku"` ran `claude-haiku-5-5` (verified, same day); interactive `/model haiku` unprobed] — in `claude -p`, name `claude-haiku-5-5` explicitly |
| `opusplan` | Opus (plan) + Sonnet (exec) | Plan-mode hybrid |
| `fableplan` | — | **Does not exist** in current build |

`/effort auto` sets extended thinking / effort automatically.
