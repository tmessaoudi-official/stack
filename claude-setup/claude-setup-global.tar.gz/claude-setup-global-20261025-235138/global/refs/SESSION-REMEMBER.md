# Session-Remember Pipeline — Tunable Knobs Reference

Env vars set before launching Claude Code. All defined in `~/.claude/hooks/session-remember/common.sh`.

| Variable | Default | Purpose |
|----------|---------|---------|
| `SR_SAVE_COOLDOWN` | `120` | Seconds between saves — lower for faster captures, higher to reduce LLM cost |
| `SR_NDC_COOLDOWN` | `3600` | Seconds between NDC (non-dialog compression) passes |
| `SR_MIN_HUMAN` | `3` | Minimum human turns in a session before first save fires |
| `SR_DELTA_THRESHOLD` | `50` | JSONL line delta required to trigger a save — reduces saves on low-activity turns |
| `SR_SKIP_BACKOFF` | `300` | Seconds `trigger.sh` waits before dispatching again after `save.sh` skipped a session (fewer than `SR_MIN_HUMAN` human turns, or 0 exchanges). Those skips leave the position unchanged so no line is lost, which kept the delta above the threshold: before this knob every tool call dispatched another `save.sh` (7,309 for one keep-going session on 2026-10-07). The skip is recorded in `.state/skip-ts.<sid>`; a save that gets past the skips clears it. Bounds capture latency after the qualifying human turn to this value; the session-end `stop.sh --force` flush ignores it. Non-numeric values fall back to 300 |
| `SR_HISTORY_MAX_ENTRIES` | `10` | Newest entries kept in the rolling `history.md` log. Weeks that end before the oldest kept entry are summarised into `archive.md` (complete Mon-Sun weeks only, appended, never rewritten; a week still in progress stays, so history can hold up to about this number + 6 entries). A week that already has a heading gets `## Week of YYYY-MM-DD (continued)`. Decisions D15, D17, D18 |
| `SR_MODEL_BULK` | `claude-haiku-5-5` | Model for the high-volume calls (Haiku 5.5 since 2026-10-08): `save.sh` summaries and NDC compress (84-126 calls/day, measured 2026-09-25..29 from `logs/session-remember.log`: `calling Haiku` plus `running NDC` lines) |
| `SR_MODEL_CONSOLIDATE` | `claude-haiku-5-5` | (Haiku 5.5 since 2026-10-08, one A/B run: same format) Model for the daily rollup (rewrites `history.md`) and the weekly archive (only appends to `archive.md`). Haiku by decision D12.3; the D6 A/B (daily rollup, N=2) found haiku equal to sonnet apart from sort order. Raise this one class if summaries lose detail |
| `SR_MODEL_HANDOFF` | `claude-haiku-5-5` | Model for `precompact-handoff.sh` (the `handoff.md` the next session resumes from). Haiku by decision D12.3; the handoff was never A/B tested against sonnet, so raise this one knob if handoffs start losing state. 5.5 since 2026-10-09, after the prompt fix (only the skill's Format..Rules slice, an output sanitiser, an excerpt of the last 40 TEXT turns): A/B on a real transcript, 5.5 18 specific lines with no fence/"Saved."/marker/plan-mode text, 4.5 12 lines in a fence |
| `SR_MODEL` | *(unset)* | Global override: when set, it replaces the default of every class that has no knob of its own. Precedence: class knob > `SR_MODEL` > class default. These calls are headless and cannot ask, so the default is the decision. Rationale: model-assignment-audit plan, decisions D6 and D12 |
| `SR_TZ` | `{{TZ}}` | Timezone for consolidation timestamps — set to `UTC` or another zone to override. Reads `$TZ` first (`common.sh:115` = `${SR_TZ:-${TZ:-{{TZ}}}}`); if `$TZ` is unset the fallback is a hardcoded `{{TZ}}`, **not the system timezone** — required on any machine not on Paris time, or daily consolidation fires at the wrong hour and every session timestamp is offset |

## Kill switches

Five file-presence toggles (`hooks/session-remember/common.sh`, sourced by start/stop/save/consolidate/trigger):

| File | Effect |
|------|--------|
| `~/.claude/hooks/session-remember/DISABLED` | Full silence — no context loaded, no capture |
| `~/.claude/hooks/session-remember/READONLY` | Load prior context but skip new capture |
| `~/.claude/hooks/session-remember/DISABLED.lean` | Lean mode's own kill switch (set by `bin/lean-swap.sh --session=off`) — same effect as `DISABLED`, but toggled by `/lean` rather than `/memory-off` |
| `~/.claude/hooks/session-remember/blacklist` | Per-project full disable (one slug per line; `/memory-block`) — session-remember aborts for listed projects (`common.sh:98-99`) |
| `~/.claude/hooks/session-remember/readonly-list` | Per-project readonly list (used by `/memory-readonly` and `/memory-block`) — same effect as `READONLY`, scoped to listed projects only |

**Precedence** (as the code runs it): `DISABLED` ≡ `DISABLED.lean` (full off, `common.sh:36-42`) > per-project `blacklist` (aborts, `:98-99`) > `READONLY` ≡ per-project `readonly-list` (load, no capture) > normal. A blacklisted project stays fully off even when `READONLY` is set.

**The project key and the list edits** go through one tested helper, `bin/slug-list.sh` (`slug [PATH]`, `has|add|remove FILE SLUG`;
`bin/tests/slug-list.test.sh`). The key is `tr '/' '-'` of the session's project directory (`CLAUDE_PROJECT_DIR`, else the
SessionStart banner's `run/session-cwd-<sid>.txt`), never the git toplevel. It matches lines exactly as `common.sh` does.
The memory and lean block/unblock skills, `/memory-status` and `/retrospective` use it. Before 2026-10-07 their inline
`grep -qxF "$slug"` read a slug's leading `-` as flags, so unblock never removed anything, and `grep -vxF … && mv` could
not remove a list's last line.
