---
name: pre-commit
description: Use before every git commit — fixes the commit's path set (never a bare commit: the index may hold other tools' staged files), analyses exactly the diff that commit will record, produces the four-dimension evidence table (CLAUDE.md Rule 6), then commits by pathspec (autonomous mode) or hands over one `git commit -F <msgfile> -- <paths>` line (spec mode), and verifies the new sha is on HEAD.
user-invocable: true
args: "[--message=<draft-message>]"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /pre-commit — Commit gate: pathspec set + blast-radius analysis + four-dimension evidence table + commit (mode-dependent) + HEAD check.
>
> Usage: /pre-commit [--message=<draft-message>]
>
> Flags:
>   --message=<text>   Seed the commit message with a draft (Claude will refine it)
> ```

---

## Differentiation from related skills

| Skill | Scope | Use when |
|-------|-------|----------|
| `/sweep` | Uncommitted diff (staged + unstaged), read-only smell review | You want a Phase 6 review before committing; it never commits |
| `/pre-commit` | The diff the commit will record (intended paths vs HEAD), commit ritual gate | You are about to commit — need a safe path set + blast-radius check + evidence table + the commit itself |

It stops at the commit and its HEAD check. **Pushing is the caller's**: `/long-run` (a pre-push gate over ~9 min goes through `bin/detach-run.sh`), then `/ci-watch`.

---

## Side effects

**Depends on the mode** (CLAUDE.md § Mode, Rule 10):
- **Spec** (`ah` armed): read-only apart from `git add` of untracked intended paths and the commit-message file in `/tmp`. It hands over one `! git commit -F … -- <paths>` line and never commits itself.
- **Autonomous** (`ah` bypassed): it also runs that commit — by pathspec, never bare — and the temp-index recipe when a path is being untracked.

Either way it never pushes, amends or rewrites history. The report is shown in conversation only; the commit is the durable artifact.

---

## Step 0 — Precondition checks

**The mode is already in context** — the SessionStart banner's `▸ MODE:` line, every subagent brief, and
`/next`. Read it from there; do NOT open with a Bash probe: in spec mode the `ah` gate is armed and blocks
a skill's first Bash call, so a probe meant to *discover* spec mode cannot run in it.

**Task gate**: spec mode → invoke `ask-human` before any git command to confirm size and intent, and wait.
Autonomous mode → announce the size and the path set, then run.

**Git checks** (in order; stop at first failure):
1. Verify `git` is installed: `command -v git` — if not found, report `ERROR: git not found in PATH — cannot run /pre-commit` and stop.
2. Verify inside a git repo: `git rev-parse --is-inside-work-tree 2>/dev/null` — if fails, report `ERROR: Not inside a git repository` and stop.
3. **No merge, rebase or cherry-pick in progress** — before anything writes the index. Resolve through
   git, not by `.git/` paths (from `~/.claude` the git dir is `$HOME/.git`):
   `git rev-parse -q --verify MERGE_HEAD`, `git rev-parse -q --verify CHERRY_PICK_HEAD`, and
   `[ -d "$(git rev-parse --git-path rebase-merge)" ]` / `rebase-apply`. Any hit → the evidence table
   may still be produced, but no commit is made or handed over. A pathspec commit refuses on its own
   during a merge; the Step 5 temp-index recipe does NOT (it writes a one-parent commit and leaves
   `MERGE_HEAD` set — measured 2026-09-27).
4. **Fix the path set `PATHS`** — the files this commit is for. The index is NOT the commit: on this
   machine it routinely holds hundreds of paths other tools staged (a bare `git commit` once swept 298
   files in). Never commit bare.
   - The caller named paths → those.
   - Otherwise → the paths **this session edited** (the transcript knows), in both modes. Foreign
     staged paths are simply left out — the pathspec guarantees they are not recorded — and are
     listed in the report. Only when the session cannot tell which paths it edited: stop and ask.
   - **Every name/status listing in this skill uses `--no-renames`.** Rename detection is on by
     default, so a `git mv a b` lists only `b`: committing `PATHS=(b)` records a COPY and leaves
     `D a` staged for the next bare commit. A rename needs BOTH names in `PATHS`.
   - Untracked paths in `PATHS` → `git add -- <them>` first: a pathspec cannot reach an untracked
     file (`did not match any file(s) known to git`). If the run stops later, undo exactly those
     with `git reset -q -- <them>` so they do not linger as someone else's pre-staged paths.
5. **Untrack branch**: any path in `git diff --cached --no-renames --name-status -- "${PATHS[@]}"`
   showing `D` while the file still exists on disk was `git rm --cached`. (Without `--no-renames` an
   identical file added alongside turns the `D` into an `R100` and hides it.) A pathspec commit
   silently records nothing for it (it takes the working tree, where the file is present) → those
   paths use the temp-index recipe in Step 5, never a pathspec.
6. **Something to commit**: `git --no-pager diff --no-ext-diff --no-renames --name-only HEAD -- "${PATHS[@]}"`
   — if empty, report `ERROR: none of the intended paths differs from HEAD` and stop. Drop from
   `PATHS` any named path not in this list. (No commits yet — `git rev-parse -q --verify HEAD`
   fails: use `git diff --cached`, and the untrack recipe does not apply.)
7. **Someone else's edits**: the pathspec commit records every change on `PATHS` — staged or not,
   yours or not. Read every hunk of `git --no-pager diff --no-ext-diff HEAD -- "${PATHS[@]}"`; a hunk
   this session did not write (another session's staged or unstaged work in the same file) → stop
   and report (CLAUDE.md Rule 8). Checking file NAMES is not enough: a foreign staged hunk in a file
   you also edited passes a name check and gets committed (measured 2026-09-27).

---

## Step 1 — Inventory the diff the commit will record

The diff under review is the one the commit will record — **`git --no-pager diff --no-ext-diff HEAD -- "${PATHS[@]}"`**
(add `--stat` / `--no-renames --name-status` for the summary). Measured 2026-09-27: it hashes identically to the
committed diff even with staged + unstaged edits on one path, and it leaves foreign staged paths out.
For untrack-branch paths, the deletion shows here too (`git diff HEAD` compares HEAD with the
index-tracked working tree).

`--no-ext-diff` is required whenever you read the patch: `diff.external` on this machine routes
`git diff` through difftastic, which prints no `+`/`-`/`@@` prefixes, so a `grep '^+'` over it
counts 0 (measured: 0 vs 2 on the same edit). `--stat`/`--name-only` are unaffected. For each file, record:
- Status: Added / Modified / Deleted / Renamed
- File path and extension
- Lines changed summary

Classify each file:
- **Public interface** — CLI flags, env vars, public functions, documented commands, API contracts, hook behaviour, SKILL.md
- **Internal implementation** — logic, business rules, private helpers
- **Tests** — test files, fixtures, test helpers
- **Config/infra** — Dockerfiles, compose files, Makefile, shell scripts, YAML config
- **Docs** — CLAUDE.md, README, agent definitions, refs/SKILLS.md

---

## Step 2 — Blast-radius analysis

For each file in the **Public interface** or **Config/infra** categories:
1. Extract the changed symbol, flag, function name, or path from the diff
2. Search all references with the **Grep tool** (files-with-matches), rooted at the repo:
   `git rev-parse --show-toplevel` — or at cwd when that toplevel is `$HOME` (it is, for `~/.claude`).
   Not a recursive shell `grep` over `~/.claude`: the firewall refuses a recursive read of a tree
   holding a credential store. This is a global skill, so the repo root is the right scope anyway.
   Where the Grep tool is not available (some subagents lack it), use a shell `grep -rln` scoped to
   named subdirectories — e.g. `skills refs docs bin hooks` from `~/.claude` — never `~/.claude` or `~` itself.
3. For each hit, read the relevant line and determine if it is a caller, doc reference, or config entry that may need updating
4. Flag any reference NOT already present in the commit's diff (Step 1) as a **potential blast-radius item**

If a file in the diff is a deletion: note that all remaining callers are blast-radius items.

---

## Step 3 — Four-dimension evidence table

Produce the completion gate table from CLAUDE.md Rule 6:

```
| Dimension    | Status | Evidence |
|--------------|--------|---------|
| Coverage     | OK / INCOMPLETE | <test files in PATHS, OR bash -n / exit-code checks if infra, OR "no test suite — N/A with reason"> |
| Docs         | OK / INCOMPLETE | <SKILL.md / README / help text in PATHS, OR "no public interface changed"> |
| Config       | OK / INCOMPLETE | <CLAUDE.md / agent def / SKILLS.md in PATHS, OR "no config impact — <reason>"> |
| Blast radius | OK / INCOMPLETE | <grep hits accounted for, OR list of unresolved references> |
```

**INCOMPLETE** rows block the commit in Step 5. List exactly which paths must be changed or added to `PATHS` to resolve each INCOMPLETE row.

Output is displayed in conversation only — not persisted to disk; the git commit is the durable artifact.

---

## Step 4 — Commit message

Parse `--message=<text>` from args if provided. Otherwise derive a draft from the Step 1 diff:
- One imperative-mood subject line (≤72 chars): what changed and the functional reason
- Optionally 1-3 short bullet lines for non-obvious context

**Never append `Co-Authored-By: Claude`** or any Claude attribution (CLAUDE.md Rule 10).

---

## Step 5 — Commit (autonomous) or hand over one line (spec)

If any row is **INCOMPLETE**: list what is missing; no commit is made or handed over. Resolve and re-run `/pre-commit`.

If all four rows are **OK**, write the message to a stable file — `/tmp/commit-<topic>-<YYYYMMDD>.msg`
(a multiline `-m` breaks on paste, CLAUDE.md § Communication) — and use exactly one command shape:

```
git commit -F /tmp/commit-<topic>-<YYYYMMDD>.msg -- <PATHS…>
```

`-F` goes **before** `--`: everything after `--` is a pathspec, so a trailing `-m 'msg'` becomes two paths.

- **Spec mode**: hand over `! git commit -F /tmp/… -- <paths>` and stop.
- **Autonomous mode**: run it. On a classifier block, hand over that same line once — never retry or reword.
- **Untrack-branch paths** (Step 0.5) — **one Bash call** (`export GIT_INDEX_FILE` does not survive
  between calls), in a `set -e` subshell so a failed step stops everything after it — the second half
  must never run when HEAD did not move (measured: a missing message file failed `commit-tree`, and the
  unguarded `git reset` still dropped `OTHER`'s staged content):
  ```bash
  ( set -euo pipefail
    UNTRACK=( <paths being untracked> ); OTHER=( <the rest of PATHS> )   # OTHER=() when none
    OLD=$(git rev-parse HEAD); TMPIDX=$(mktemp -u); trap 'rm -f "$TMPIDX"' EXIT
    export GIT_INDEX_FILE=$TMPIDX; git read-tree "$OLD"
    git rm -q --cached --ignore-unmatch -- "${UNTRACK[@]}"
    if (( ${#OTHER[@]} )); then git add -- "${OTHER[@]}"; fi
    TREE=$(git write-tree); unset GIT_INDEX_FILE
    NEW=$(git commit-tree "$TREE" -p "$OLD" -F /tmp/commit-<topic>-<YYYYMMDD>.msg)
    git update-ref HEAD "$NEW" "$OLD"     # refuses if HEAD moved since OLD was read
    # REQUIRED second half — the real index was never touched: it still lists UNTRACK, and holds
    # OTHER's PRE-commit content, which reads as a staged revert that the next bare commit would record.
    # -f: HEAD has moved, so a PRE-STAGED copy of an UNTRACK path (differing from both file and HEAD)
    # is exactly what must go; without -f git refuses it, and the path stays staged as a re-add
    # (2026-10-09, WS4.4: daemon/roster.json). --cached keeps the working tree untouched either way.
    git rm -q --cached -f --ignore-unmatch -- "${UNTRACK[@]}"
    if (( ${#OTHER[@]} )); then git reset -q -- "${OTHER[@]}"; fi
    echo "committed $NEW" )
  ```
  It touches neither the working tree nor foreign staged paths (measured 2026-09-27 in a throwaway repo:
  afterwards `git diff --cached` lists only the foreign paths it listed before). `commit-tree` runs no
  commit hooks — run by hand whatever pre-commit hook the repo has. It does not sign either: with
  `commit.gpgsign=true` the commit still comes out unsigned (`%G?` = `N`, b86c1b92 on 2026-10-09);
  add `-S` to the `commit-tree` line where the repo signs.
  Spec mode: write it to `/tmp/commit-<topic>-<YYYYMMDD>.sh` and hand over `! bash /tmp/….sh`.

---

## Step 6 — Verify the commit landed

After ANY commit — yours, the user's hand-over, or one a subagent reports:
`git merge-base --is-ancestor <sha> HEAD` must succeed, and `git show --no-renames --name-only --format= HEAD`
must list exactly `PATHS` as fixed by Step 0.6 (both names of a rename). A subagent's commit has been left dangling before (reported sha, HEAD unmoved) —
`git show <sha>` still resolves a dangling object, so it proves nothing. `git diff --cached --name-only`
afterwards should still show the foreign paths it showed before: they were never yours to commit.

---

## Error handling summary

| Condition | Behaviour |
|-----------|----------|
| `git` binary not in PATH | ERROR + stop immediately |
| Not inside a git repo | ERROR + stop immediately |
| No intended path differs from HEAD | ERROR + stop immediately |
| Foreign staged paths | Left out (pathspec); listed in the report. Stop and ask only if the session cannot tell which paths it edited |
| A hunk on `PATHS` this session did not write (staged or unstaged) | Stop and report (Rule 8) |
| `git mv` in the change | Both names in `PATHS`; every listing uses `--no-renames` |
| Reported sha not an ancestor of HEAD | Report dangling commit; do not claim it landed |
| Merge, rebase or cherry-pick in progress (Step 0.3) | Evidence table only — no commit made or handed over |
| `grep` unavailable or returns non-zero | Skip that symbol; note in blast-radius row as "grep unavailable for `<symbol>`" |
| Deletion in the diff | Note that all remaining callers of the deleted item are blast-radius items |
| Binary file in the diff | Note in coverage row as "binary file — no diff available; verify manually" |
