---
name: certify
description: Use at a 3C/6C gate or a milestone boundary once work needs certifying, or to set/change this project's certification schedule. Resolves the tier from the mode (spec → ask; autonomous → the schedule file), then runs advisor(), the three-lens reviewer panel, or both — unnamed agents, disk reports, frozen commit, Stop-guard-safe report.
user-invocable: true
args: "[--gate 3c|6c|milestone] [--set <schedule text>]"
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /certify — run the certification tier the mode and project schedule call for.
>
> Usage: /certify [--gate 3c|6c|milestone] [--set <schedule text>]
>   --gate   which certification moment this is (default: infer from the phase you are in)
>   --set    write/replace this project's certification-schedule (only on the user's explicit request)
> ```

---

The *gate* — that certification happens at 3C, 6C and the milestone end — is passive CLAUDE.md text
and stays there (§ Per-task gate vs milestone panel, § Mode). This skill is the *execution* once the
moment has come: which tier, and how to run it so that it survives this machine. The mechanics below
were each re-learned in 7 projects (2026-08-19 → 2026-09-23).

## 1. Resolve the tier — three states

**The mode is already in context** — the SessionStart banner's `▸ MODE:` line, every subagent brief,
and `/next`. Read it from there; do NOT open with a Bash probe: in spec mode the `ah` gate is armed
and blocks a skill's first Bash call, so a probe meant to *discover* spec mode cannot run in it.
Only in autonomous mode (no gate) fetch the schedule details:

```bash
bash ~/.claude/bin/project-state.sh --tier 0 | jq '.identity | {mode, certification_schedule}'
```

| `mode` | schedule `value` | Do |
|---|---|---|
| `spec` | (ignored) | ask the tier question via `AskUserQuestion` at THIS gate — advisor / panel / both, recommended first, with the visible "challenge the premise" escape. A previous answer is never carried forward. |
| `autonomous` | set | apply it without asking. **Print the `file` it came from** — the lookup takes the NEAREST schedule walking up from cwd, so a stale subdirectory file can shadow the root one. |
| `autonomous` | empty | ask ONCE (recommended: `advisor()` at every 3C/6C gate + one three-lens panel at the milestone end on a frozen commit), then write the answer to `certification_schedule.write_to`. |

`--set`: write `write_to` with the user's words as the first line — only when the user asked to set or
change it. Show the old and new line.

## 2. advisor tier

State in one sentence what the task asks and your read, then call `advisor()`. Loop: a finding → go
check it for real (grep, run) → re-call noting what changed. Output `3C round N → advisor: …` /
`6C round N → …`. Cap 5 rounds → `ask-human` with: resolve manually / narrow scope / proceed with
documented risk / escalate. The cap asks even in autonomous mode.

## 3. panel tier

1. **Freeze first.** Commit everything the round covers; the reviewers read one sha. One panel per
   milestone — land all commits, then one round, not a round per commit.
1b. **Reviewer model** (model-assignment audit, decisions D3/D3b, 2026-09-29). Resolve it before spawning — a call-level `model` beats an agent file's pin (verified by probe). Strength: haiku < sonnet < opus < fable.
   - `resolved` = the first line of the `reviewer-model` file beside the certification schedule (`dirname "$(bash ~/.claude/bin/project-state.sh --tier 0 | jq -r '.identity.certification_schedule.write_to')"`) when it exists, else `opus`.
   - `session` = `bash ~/.claude/bin/session-model.sh` — the latest real assistant model in THIS session's transcript; never ask the model what it is. `session-model.sh --rank <alias>` gives the strength rank; `unknown` ranks 0.
   - **every mode** (D12/D13): this step runs only after Panel or Both was chosen, never on an advisor-only gate. It IS this skill's Model ask (the canonical line under `## Subagent models`) — one question, not two. **Autonomous mode** (user ruling 2026-09-30, plan model-policy-bypass): do NOT ask — reviewers run on the override (`bash ~/.claude/bin/model-override.sh get agent reviewer`; `as-is` = the session model), else `resolved`; record one `ASSUMED (review): reviewers run on <model> - source <override|reviewer-model>` in the active plan and skip to the print below. **Spec mode:** `resolved` is only the pre-selected option, never a silent answer. Ask one `AskUserQuestion`: "Reviewers run on <resolved> (session: <session>). Keep or change?" Options: keep `<resolved>` (Recommended), the other aliases among opus / sonnet / fable / haiku, and the visible challenge escape. Any option ranked below the session model says "weaker than the session model — a reviewer should not be weaker than the author". Write the answer to the `reviewer-model` file.
   - Every run prints `Reviewers: <model> (session: <session>)`.
   - Pass `model: "<that alias>"` on every reviewer Agent call (step 3).
2. **Lenses** come from the project's `*-lenses` skill when it has one; otherwise the default three:
   correctness + regression · security + safety promises · completeness + blast radius.
3. **Spawn ≤3 reviewer agents UNNAMED**, each with `model:` = the reviewer model from step 1b (a `name:` makes a teammate whose report only returns via
   `SendMessage`). `general-purpose` when they must write; read-only lenses may use `Explore`.
   Each prompt: the frozen sha, its lens, "read the diff/code/tests yourself — not the author's
   summary", "write findings incrementally to `<repo>/var/claude/raw/<round>-<lens>.md` (or the
   scratchpad when the repo has no `var/`) and return ONE line". A reviewer that MUTATES code gets
   `isolation: "worktree"`.
4. **Announce the wait**: "~4–6 min, the session will look idle". Do not edit the tree during a round.
5. **Blocked reviewers**: a reviewer that could not read files (a gate hook in the subagent) returns
   abstentions — detect them and verify those items inline, do not count them as clean. A lens the
   safety classifier stops is declared **uncertified**; do not reword it a third time.
6. **Synthesis**: diff every synthesized finding against its raw file — IDs alone prove nothing (17 of
   220 rows once carried another ID's content).
7. **Convergence**: clean = zero new findings. Finding → fix → re-round. Cap 5 → `ask-human`.

## 4. both

`advisor()` first, then the panel; the panel prompt includes the advisor's verdict.

## 5. Report

- State which dimensions were **certified by execution** (a test ran, a sabotage went red) and which
  were **not** — name each unverified one; a clean verdict hiding one is a false certification.
- **Stop-guard shape** (`advisor-completion-guard.sh` matches the turn's FINAL message for the Rule 6
  evidence words): put the evidence table in a message that ENDS with the `advisor()` call, then close
  the turn with a one-line pointer (`6C → advisor: clean`) that avoids those words and makes no tool call.
- After the milestone panel: a one-line `/compact` hint.

$ARGUMENTS

## Subagent models

**Model ask (policy v2, every run):** resolve the mode first with `bash ~/.claude/bin/project-state.sh --tier 0 | jq -r .identity.mode` (autonomous = the ask-human gate is bypassed for this tree, else spec); with no shell, `Read` `~/.claude/state/gates-bypass-rules.json` and call it autonomous only when an unexpired rule whose `guards` include `ah` covers this directory (`global`, or `path` equal to / a recursive ancestor of it), else spec. **Spec mode:** before the first Agent call of a run, ask ONE `AskUserQuestion` that shows the whole table below in the question text, with each stored value as the recommended choice (for reviewers, the `reviewer-model` file value; in spec mode a stored value is only ever the recommended option). Shape: AskUserQuestion takes 2-4 options and cannot pre-select, so the options are keep-the-table (Recommended), one uniform alias for every agent, and a challenge escape. **Autonomous mode** (user ruling 2026-09-30, plan model-policy-bypass): do NOT ask. For each agent read its override from `~/.claude/state/model-overrides.json` (`Read` it; key = the table's Agent label as a slug: lowercase, spaces to hyphens, under `agents`, falling back to `agents."*"`; or `bash ~/.claude/bin/model-override.sh get agent <slug>`, which applies the same fallback) and use it when present (an `as-is` override means the session's model: `bash ~/.claude/bin/session-model.sh` prints its alias), else the table value below (reviewers: the `reviewer-model` file); an invalid or absent table means no overrides. Record one `ASSUMED (review): <agent> runs on <model> - source <override|table>` per agent in the active plan's Decisions Log (`bash ~/.claude/bin/project-state.sh --append-decision <active plan> ASSUMED "..."`, or edit the plan file directly when there is no shell). Both modes: pass `model:` on every Agent call, set to the answer. An orchestrator (`/mega-analysis`, `/loop --pipeline`) which already asked for this run and named the models replaces it.

Set by the model-assignment audit (decision D5, 2026-09-29; source table `projects/-home-user-.claude/model-audit/classified-all.tsv`). **Pass `model:` on every Agent call** — an omitted model inherits the session, so quality and cost would follow the `/model` choice. `opus` = judgment work, `sonnet` = detection and mapping (rubric ruled 2026-09-29).

| Agent | model | why |
|---|---|---|
| the reviewers (up to 3 lenses) | the reviewer model — `opus` by default | certification is judgment work; a reviewer is never weaker than the author |
