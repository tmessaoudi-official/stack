---
name: dockerize-project
description: Use when a project must run ALL its stages, commands and gates in Docker instead of host-installed tools ("dockerize", "run everything in docker", "migrate off local php/node/composer", "containerise the toolchain"). Inventories every host-tool call site (tests, scripts, git and Claude hooks, CI, docs), maps each to a compose service, builds wrappers, proves parity against the host result, rewires consumers and writes a "Run everything in Docker" table into the project's own CLAUDE.md. Not for /path/to/your/project itself.
user-invocable: true
args: "[--dry-run] [--inventory-only]"
side-effects: Writes compose/Dockerfile/wrapper files and edits CI, hooks, scripts and docs INSIDE the target project only. Never touches ~/.claude. Never deletes a host-version workaround without asking. Commits follow the mode (CLAUDE.md Rule 10).
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then STOP.
>
> ```
> /dockerize-project — migrate one project so every stage, command and gate runs in Docker.
>   --inventory-only   stages 0-2 only: the call-site table and the mapping, no files written
>   --dry-run          stages 0-3 as a plan: show every file that would change, write none
> The rule it applies: the host needs Docker and nothing else. /path/to/your/project is exempt.
> ```

# /dockerize-project

Policy (user ruling, 2026-10-02): every project except `/path/to/your/project` runs its stages, commands and gates in Docker, never on host-installed `php`, `composer`, `node`, `npm` or equivalents. The rule lives in each project's own `CLAUDE.md` (always loaded there); this skill is the generic procedure that produces it. It is software-domain knowledge, so it is a skill and NOT part of the global CLAUDE.md body.

## Stage 0 — gate
Refuse only if the cwd is the `/path/to/your/project` project itself (cwd is `/path/to/your/project`); projects under `/path/to/your/project/projects/*` are in scope. Require a clean git tree (`git status --porcelain`; Rule 8) and say which branch. Read the project's `CLAUDE.md`, `.claude/rules/`, any `Makefile`/`package.json` scripts and the existing `Dockerfile`/`compose*.y*ml`.

## Stage 1 — inventory, both sides (bidirectional rule)
- **A, every host-tool call site** (grep, state the count): tests, `scripts/`, `tools/`, git hooks, Claude hooks, CI workflows (`setup-php`, `setup-node`, bare `run:` lines), Makefile targets, package scripts, docs and rules that tell a human or Claude to run a host command.
- **B, what Docker already provides**: services, Dockerfile targets, volumes, env files.
Print both lists, then the delta. A call site with no service is a finding; so is a service nothing calls.

## Stage 2 — map
One row per call site: `command | today (host) | service | docker command | notes`. Decide image reuse (an existing dev/test target beats a new image), the user/uid mapping so bind-mounted files stay owned by the developer, and where dependency caches live (named volumes, not the working tree, unless the project already bind-mounts them).

## Stage 3 — build (skipped under `--inventory-only`)
Compose services for test, lint, console and dependency install; one wrapper per project idiom (Makefile target or `scripts/` shim, whichever the project already uses; do not impose a new one). Pin image versions. Use `-T` / no TTY in CI. Never print `docker compose config` output (it expands env files and leaks secrets): check its exit code only.

## Stage 4 — parity (the evidence)
Run each gate on the host BEFORE changing anything and record the result (pass counts, exit codes, timing). After the change run the same gates in Docker from a clean environment (`env -i HOME=$HOME PATH=$PATH <cmd>`) and compare. Any difference is reported, never smoothed over. Tests must actually be executed; paste the runner output. A gate that cannot run in a container is listed as such, with the reason.

## Stage 5 — rewire consumers
CI, git hooks, Claude hooks, scripts, test harnesses and docs now call the Docker commands. A host-version workaround (a pinned local build, an ini hack, a PATH shim) is FLAGGED with the evidence that it is obsolete; delete it only after the user agrees.

## Stage 6 — document
Add a "Run everything in Docker" table to the project's `CLAUDE.md` (command, service, what it replaces). Fix every rule, agent charter and skill that names a host tool. Add a verification step to the project's drift or doc gate if it has one. Keep counts out of prose; give the command that produces them.

## Stage 7 — report
The four-row evidence table (coverage, docs, config, affected surfaces) plus: gates proven in Docker, gates not coverable, files changed, and what the user must do by hand (`!` commands). End with the commit state.

## Traps seen on this machine
- `docker compose config` leaks live tokens (exit code only).
- `docker compose ps` omits a non-running service without `-a`.
- Long jobs: run detached and wait for completion; a polling Bash call that times out kills the whole process group.
- Detached waiters lack the login PATH; a container removes that dependency, which is a point in favour.
- uutils `ls`/`rm` parse leading-dash paths as flags; use `--` or `./`.
