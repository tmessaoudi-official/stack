---
name: memory-block
description: Use when disabling session-remember for a specific project path, either fully (blacklist) or in readonly mode (readonly-list).
user-invocable: true
disable-model-invocation: true
---

**Front door:** `/gates-bypass memory block [path] [--readonly]` routes here; this skill is the implementation (framework-health 4.5).

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /memory-block — Disable session-remember for a specific project path, either fully (blacklist) or in readonly mode (readonly-list).
> ```
>
> Then output the complete flag table from the **"Parse flags"** section below. Then STOP.

---

# /memory-block [path] [--readonly]

Disable session-remember for a specific project path.

- Default: adds the project slug to `~/.claude/hooks/session-remember/blacklist` (full disable — no context loaded, no capture)
- `--readonly`: adds to `readonly-list` instead (context loads, capture skipped)

If no path is given, the project is this session's project directory (`CLAUDE_PROJECT_DIR`, else the session-cwd anchor the SessionStart banner writes; `bin/slug-list.sh slug`), the same key session-remember matches. It is never the git toplevel, which from `~/.claude` would be `$HOME`.

---

## Pre-check: global pipeline state

Before modifying any block lists, run:
```bash
[ -f "$HOME/.claude/hooks/session-remember/DISABLED.lean" ] && echo "LEAN_DISABLED=true" || echo "LEAN_DISABLED=false"
[ -f "$HOME/.claude/hooks/session-remember/DISABLED" ] && echo "GLOBAL_DISABLED=true" || echo "GLOBAL_DISABLED=false"
```

If `LEAN_DISABLED=true`, warn:
```
⚠ Session pipeline is controlled by lean mode (DISABLED.lean present).
  Per-project block list changes will have no effect until lean mode ends.
  Proceeding anyway so the entry is ready when lean mode exits...
```

If `LEAN_DISABLED=false` and `GLOBAL_DISABLED=true`, warn:
```
⚠ Session pipeline is globally disabled (DISABLED is present).
  Per-project block list changes will have no effect until DISABLED is removed.
  Proceeding anyway so the entry is ready when global disable is lifted...
```

Then continue to normal execution regardless.

---

## Parse flags

Determine from args:
- `READONLY_MODE`: default `false`; set to `true` if args contain `--readonly`
- `PATH_ARG`: the path argument if provided, else empty string

## Run

```bash
# The project key is session-remember's: tr '/' '-' of the session's project directory (CLAUDE_PROJECT_DIR,
# else the session-cwd anchor), NEVER the git toplevel (from ~/.claude that is $HOME). bin/slug-list.sh owns the
# matching, so a slug starting with '-' is never read as grep flags (framework-health 2026-10-07, A1-A3).
SL="$HOME/.claude/bin/slug-list.sh"
PROJECT_SLUG=$(bash "$SL" slug ${PATH_ARG:+"$PATH_ARG"}) || exit 1
PROJECT_PATH="${PATH_ARG:-$PROJECT_SLUG}"

SR_DIR="$HOME/.claude/hooks/session-remember"

if [[ "$READONLY_MODE" == "true" ]]; then
  TARGET_FILE="$SR_DIR/readonly-list"
  MODE_LABEL="readonly (load context, skip capture)"
  OTHER_FILE="$SR_DIR/blacklist"
  OTHER_LABEL="blacklist (full disable)"
else
  TARGET_FILE="$SR_DIR/blacklist"
  MODE_LABEL="blocked (no load, no capture)"
  OTHER_FILE="$SR_DIR/readonly-list"
  OTHER_LABEL="readonly-list"
fi

if bash "$SL" has "$TARGET_FILE" "$PROJECT_SLUG"; then
  echo "Project $PROJECT_PATH is already in $(basename "$TARGET_FILE") ($MODE_LABEL)."
  exit 0
fi
if bash "$SL" has "$OTHER_FILE" "$PROJECT_SLUG"; then
  echo "⚠ Project $PROJECT_PATH is already in $OTHER_LABEL."
  echo "  Remove it first with /memory-unblock, then re-block with desired mode."
  exit 0
fi

bash "$SL" add "$TARGET_FILE" "$PROJECT_SLUG" >/dev/null || { echo "⛔ could not write $TARGET_FILE" >&2; exit 1; }

echo "✓ $PROJECT_PATH → $MODE_LABEL"
echo "  Slug: $PROJECT_SLUG"
echo "  File: $TARGET_FILE"
echo "  Takes effect at next session start."
```
