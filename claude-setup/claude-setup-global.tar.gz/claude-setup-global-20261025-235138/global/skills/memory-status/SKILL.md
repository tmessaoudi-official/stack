---
name: memory-status
description: Use when checking the current state of the session-remember memory system — which toggles are active (DISABLED, READONLY, lean) and what the effective mode is.
user-invocable: true
context: fork
model: haiku
---

**Front door:** `/gates-bypass memory status` routes here; this skill is the implementation (framework-health 4.5).

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /memory-status — report the current state of the session-remember memory system (DISABLED, READONLY, lean toggles, effective mode)
>
> No flags — invoked without arguments.
> ```

---

Report the current state of the session-remember memory system.

Run:
```bash
SR="$HOME/.claude/hooks/session-remember"; SL="$HOME/.claude/bin/slug-list.sh"
SLUG=$(bash "$SL" slug)    # this session's project key (CLAUDE_PROJECT_DIR, else the session-cwd anchor) — what common.sh matches
for f in DISABLED DISABLED.lean READONLY; do [ -e "$SR/$f" ] && echo "$f=present" || echo "$f=absent"; done
bash "$SL" has "$SR/blacklist" "$SLUG"     && echo "blacklist=THIS PROJECT LISTED" || echo "blacklist=not listed"
bash "$SL" has "$SR/readonly-list" "$SLUG" && echo "readonly-list=THIS PROJECT LISTED" || echo "readonly-list=not listed"
[ -e "$HOME/.claude/LEAN_MODE" ] && echo "LEAN_MODE=present" || echo "LEAN_MODE=absent"
echo "slug=$SLUG"
```

Interpret the result and report in this exact format:

```
Memory status (project <slug>):
- DISABLED toggle      : <present|absent>
- DISABLED.lean toggle : <present|absent>  [← lean mode session control]
- blacklist            : <this project listed|not listed>
- READONLY toggle      : <present|absent>
- readonly-list        : <this project listed|not listed>
- LEAN_MODE sentinel   : <present (since <activated_at>)|absent>
Effective mode         : <DISABLED | DISABLED-LEAN | BLACKLISTED | READONLY | READONLY-PROJECT | NORMAL>
```

Mode derivation — the order `hooks/session-remember/common.sh` applies (CLAUDE.md § Memory System Toggles,
refs/SESSION-REMEMBER.md § Kill switches): `DISABLED` ≡ `DISABLED.lean` > `blacklist` > `READONLY` ≡ `readonly-list` > normal.
- DISABLED present → `DISABLED` (memory-off owns this)
- else DISABLED.lean present → `DISABLED-LEAN` (lean mode owns this — use `/lean --session on` or `/lean off` to change)
- else THIS project in blacklist → `BLACKLISTED` (no load, no capture; `/memory-unblock`)
- else READONLY present → `READONLY`
- else THIS project in readonly-list → `READONLY-PROJECT`
- else → `NORMAL`

A list file merely existing changes nothing: only this project's own line does (the lists hold other projects too).

If LEAN_MODE is present, also run:
```bash
jq -r '"scope=\(.scope // "all") | v\(.version // 1) | project=\(.project_path // "n/a")"' \
  ~/.claude/LEAN_MODE 2>/dev/null || cat ~/.claude/LEAN_MODE
```
And append: `Lean mode active since <activated_at> (scope: <scope>) — run /lean status for full details.`

Keep the report under 18 lines. No commentary beyond the table and lean note.
