---
name: learning-on
description: Use when enabling the learning-output-style plugin to add insight blocks, trade-off commentary, and educational explanations to responses.
user-invocable: true
disable-model-invocation: true
---

**Front door:** `/gates-bypass on learning` routes here; this skill is the implementation (framework-health 4.5).

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /learning-on — Enable the learning-output-style plugin to add insight blocks, trade-off commentary, and educational explanations to responses.
>
> No flags — invoked without arguments.
> ```

---

# /learning-on — Enable Learning + Explanatory Output Style

Enables the `learning-output-style` plugin for this machine's Claude Code sessions.

## Steps

1. Run `bash ~/.claude/bin/learning-style.sh on` (it sets `"learning-output-style@claude-plugins-official": true` in `enabledPlugins`;
   a direct Write to `settings.json` is classifier-blocked for Claude, framework-health 4.8). Exit 0 = done (or already enabled);
   exit 5 = refused: its two protect rules are not installed on this machine (`/gates-bypass protect gates apply` installs
   them) - say so and stop; exit 1 = settings.json could not be round-tripped, nothing written.
   `bash ~/.claude/bin/learning-style.sh status` shows the current value without writing.
   `settings.json` often carries uncommitted changes already (`git -C ~ status -- .claude/settings.json`): the switch edits one key on top
   of them and keeps a backup `settings.json.bak.<epoch>` (the newest 2 are kept); it does not commit anything.
2. Confirm: "Learning mode enabled. Restart Claude Code for the change to take effect."

## What this enables

- `★ Insight` blocks after code — educational explanations of implementation choices specific to the codebase
- "Request contribution" prompts — Claude asks you to write meaningful business logic (5–10 lines) at key decision points rather than implementing everything itself
- Explanatory commentary on trade-offs and design choices

## When to use

- Exploring an unfamiliar codebase or technology area
- Deliberate learning sessions where you want explanations, not just execution
- Onboarding to a new project domain

Disable with `/learning-off` when switching back to execution mode.
