---
name: bootstrap
spotlight: true
description: Use when a project has no CLAUDE.md and no .claude/ config and needs a full Claude Code setup written from scratch. Use with --force to overwrite an existing config after creating a backup.
user-invocable: true
disable-model-invocation: true
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /bootstrap — Probe the current project deeply and write a tailored Claude Code config from scratch.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

Probe the current project deeply and write a tailored Claude Code config from scratch.
Use when the project has no Claude config yet.
Safe to re-run with `--force` to overwrite an existing config (backup created first).

Use `$ARGUMENTS` for any flags:

## Flags

| Flag | Behavior |
|------|---------|
| `--target PATH` | Source project path to bootstrap (default: current working directory) |
| `--force` | Overwrite an existing CLAUDE.md and `.claude/` config — backup is created first |

---

## Phase 0: Guard — check existing state

```bash
grep -rn '<!-- ADAPT:' CLAUDE.md .claude/ 2>/dev/null | head -5
test -f CLAUDE.md && echo "exists" || echo "absent"
```

**If ADAPT markers found**: stop and reply —
> "This project has unresolved ADAPT markers — it looks like you installed a bundle template.
> Run `/adapt-project` instead to fill those markers."

**If CLAUDE.md exists but no ADAPT markers and `--force` not passed**: stop and reply —
> "CLAUDE.md already exists and appears adapted. Pass `--force` to overwrite (backup will
> be created), or run `/repair` to fix drift without overwriting."

**If `--force`**: note that a backup will be created before writing. Also show the diff first:
```bash
[[ -f CLAUDE.md ]] && diff CLAUDE.md /dev/null || true
```
Let the user review what will be replaced before proceeding. Remind them: hand-edited content in the existing CLAUDE.md will be lost — the backup is the only safety net.

**If CLAUDE.md absent**: proceed.

---

## Phase 1: Deep exploration — 4 parallel Explore agents

Launch all four simultaneously. Each returns a concise structured report.

**Agent 1 — Tech stack**
Probe: `package.json`, `composer.json`, `Gemfile`, `Cargo.toml`, `go.mod`, `pyproject.toml`,
`requirements.txt`, `*.csproj`, `.nvmrc`, `.ruby-version`, `.python-version`, `.tool-versions`,
`Dockerfile*`, `compose*.y*ml`, `docker-compose*.y*ml`.
Report: primary language + version, framework + version, package manager, notable dependencies.

**Agent 2 — Project structure**
Probe: top-level directory tree (2–3 levels), `README.md`, `docs/`, `CONTRIBUTING.md`,
main entry points, config files, key source dirs.
Report: what the project does (1 sentence), key directories with their purpose, main entry points.

**Agent 3 — CI/CD + scripts + workflows**
Probe: `.github/workflows/`, `.gitlab-ci.yml`, `Jenkinsfile`, `Makefile`, `bin/`, `scripts/`,
`.pre-commit-config.yaml`, `taskfile.yml`, `justfile`.
Report: build command, dev-server command, test command, deploy command, common one-liners.

**Agent 4 — Testing + quality**
Probe: test directories, `jest.config.*`, `pytest.ini`, `phpunit.xml`, `.rspec`, `go test`,
`.eslintrc*`, `.pylintrc`, `rubocop.yml`, `shellcheck` usage, `prettier.config.*`,
`black` config, `shfmt` usage, `rustfmt.toml`.
Report: test command(s), linter(s) with file extensions, formatter(s) with file extensions.

---

## Phase 2: Phase gate — mandatory stop

Synthesize the four agent reports into a one-screen summary:

```
BOOTSTRAP SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Detected stack:   [language+version] / [framework] / [package manager]
Test command:     [command]
Linter(s):        [tool] → [ext]
Formatter(s):     [tool] → [ext]
Docker:           [compose services found / "none: rows will be TODO"] (omit only for the /path/to/your/project project itself, cwd = /path/to/your/project; projects under /path/to/your/project/projects/* keep it)

What will be created:
  CLAUDE.md                                  (full project config — all sections)
  .claude/settings.json                      (permissions scaffold)
  .claude/hooks/lint-on-write.sh             (if linter found)
  .claude/hooks/format-on-write.sh           (if formatter found)
  .claude/projects/.claude-template/memory/  (memory scaffold)
  docs/plans/                                (plan persistence — Rule 17 compliance)

```

Invoke the `ask-human` skill: question 'Proceed with bootstrap — create all files listed above?', options: 'Yes, create everything (Recommended)' / 'No, abort — exit without changes'.

**Hard stop** — do not write anything until the user confirms. If 'No': exit without changes.

---

## Phase 3: Write config from scratch

> **Note — the ask-human gate + bash-firewall are GLOBAL infrastructure, not per-project.** /bootstrap
> intentionally does NOT create or wire the `ask-human-gate-*` / `ask-bash-firewall` /
> `ask-human-question-guard` hooks into the
> project's `.claude/settings.json` — they live in `~/.claude` (user-global) and apply across every
> project. A bootstrapped project relies on the global gate; there is nothing to wire here. Mention this
> in the generated CLAUDE.md so a developer isn't surprised to find no gate hooks in their project config.

### Backup (if `--force` and existing files present)

Into the install store, never beside the project (a copied `.claude` holds settings and is not gitignored there):

```bash
d=$(umask 077; mkdir -p ~/.claude/backups/install && chmod 700 ~/.claude/backups/install && \
    mktemp -d ~/.claude/backups/install/$(date +%s)-"$(basename "$PWD")"-XXXX) && \
for e in .claude CLAUDE.md; do [ ! -e "$e" ] || cp -a -- "$e" "$d/"; done && \
printf '%s\t%s\t%s\n' "$(date +%s)" "$PWD" "$d" >> ~/.claude/backups/install/ledger.tsv && echo "backup: $d"
```

Report the backup path and its restore line (`cp -a <backup>/. ./`) before writing anything. The firewall may ask
once for the write outside the project; `claude-cleanup.sh` lists store folders older than 14 days. Then show a summary diff of what will be overwritten:
```bash
[[ -f CLAUDE.md ]] && diff CLAUDE.md /dev/null 2>/dev/null || echo "(no existing CLAUDE.md to diff)"
```

Pause and remind: any hand-edited content in the existing files exists only in the backup. Ask the user to confirm they've reviewed the backup before continuing.

### Directory structure

```bash
mkdir -p .claude/skills .claude/hooks .claude/agents
mkdir -p docs/plans
```

### CLAUDE.md — all sections filled from exploration

Write the full file. Use this section structure:

**`## What This Project Is`**
2–5 sentences: what it does, platform/runtime, key tech, single-dev vs team.
Source: README first paragraph + stack detection.

**`## Architecture`**
Key components and relationships — Markdown table or annotated list.
If microservices: map service → purpose. If monolith: top-level dirs → responsibility.
Source: structure probe.

**`## Common Workflows`**
5–10 most-used commands as bash one-liners with inline comments.
Source: CI/CD probe. Prefer Makefile targets > package.json scripts > bare CLI.

**`## Run everything in Docker`** (every project except `/path/to/your/project`; user ruling 2026-10-02)
A table `command | service | what it replaces` covering tests, lint, console, dependency install,
every gate and every hook-run tool, plus one line: the host needs Docker and nothing else.
Source: Dockerfile/compose probe. If the project has no compose service yet for a stage, write the
row as `TODO: not containerised` and say so in the completion report; run `/dockerize-project`
afterwards to build it. In `Common Workflows` and `Testing & Verification` give the containerised
command, not the bare host tool. Skip this section only for the `/path/to/your/project` project itself (cwd is `/path/to/your/project`); a project under `/path/to/your/project/projects/*` keeps it.

**`## Testing & Verification`**
How to run tests, what passing looks like, test types (unit/integration/E2E), coverage thresholds.
Source: test probe + CI YAML.

**`## File Layout Quick Reference`**
Annotated 2-level tree of non-obvious directories.
Omit `node_modules/`, `.git/`, build output dirs.
Source: structure probe.

**`## Gotchas & Pitfalls`**
3–8 project-specific traps. Look for README warnings, `.env.example` non-obvious keys,
CI retry/timeout hacks, known workarounds in commit history.

**`## Credentials & Stateful Data`**
Where credentials/keys/data live — `.env.example` key names, config file locations.
Source: `.env.example` + README setup sections.

**`## Debugging a Failed [X]`**
Fill `[X]` with the primary service or component name.
5–8 numbered steps from the project's actual debug surface (log locations, health-check commands).

**`## Claude Code Tooling`**
List slash commands, hook behaviors, and agents — exactly what is written in this session.

**`## Claude Code Configuration`**
Annotated file tree of `.claude/` contents.

### `.claude/settings.json`

Start from `~/.claude/templates/project-settings.json` (boundary model, 2026-08-29: bare `"Bash"`, `Read`,
`Edit`, `Write` in `allow` — inside the repo the global `hooks/ask-bash-firewall.sh` boundary gate is the
guard, not verb rules; `ask`/`deny` hold only THIS repo's footguns, e.g. deploy scripts, `migrate:fresh`,
`db:wipe`). Replace the example `ask`/`deny` entries with the project's real ones (detected deploy /
destructive scripts) or leave them empty. Also copy `~/.claude/templates/project-boundary.json` to
`.claude/boundary.json` and fill `protected[]` (paths inside the repo that must always ask, e.g.
`infra/prod`) and `trusted_outside[]` (directories outside the repo this project may write silently).
Also copy `~/.claude/templates/project-progress.json` to `.claude/progress.json` and fill it for
`/progress`, `/next` and `/goal-brief`: the cursor/master-plan files, the register files (known issues,
invariants, milestones), and a **targeted** `test_cmd` (it runs only on explicit `/progress --run-tests`,
after the exact string is shown; keep every path relative — absolute paths and `..` are rejected).

### Hooks

**If linter detected**: write `.claude/hooks/lint-on-write.sh` and add PostToolUse matcher.
**If formatter detected**: write `.claude/hooks/format-on-write.sh` and add PostToolUse matcher.

### Skills

New project-specific slash commands require a `SKILL.md` stub under `.claude/skills/<name>/SKILL.md`.
If the project's exploration reveals custom workflows worth capturing as skills, create the stub directory and a minimal `SKILL.md` with `name:`, `description:`, and `user-invocable:` frontmatter. Global skills live under `~/.claude/skills/<name>/SKILL.md`.

### Memory scaffold

Write:
- `.claude/projects/.claude-template/memory/MEMORY.md` — blank index
- `.claude/projects/.claude-template/memory/example_user.md` — user memory example
- `.claude/projects/.claude-template/memory/example_feedback.md` — feedback memory example

---

## Phase 4: Completion report

```
Bootstrap complete.

Created:
  CLAUDE.md                                  — all sections written from project exploration
  .claude/settings.json                      — permissions scaffold
  .claude/hooks/lint-on-write.sh             — [linter] on Edit/Write  (if applicable)
  .claude/hooks/format-on-write.sh           — [formatter] on Edit/Write  (if applicable)
  .claude/projects/.claude-template/memory/  — memory scaffold

Next steps:
  chmod +x .claude/hooks/*.sh    (activate hook scripts — required before they fire)
  /repair --check                (verify config coherence)
  /audit --quick                 (confirm coverage and hook wiring — ~2 min)
  /discover-expertise --write    (build this project's expertise index; CLAUDE.md Phase 0 reads it)
```

If `--force` was used, report the backup path, then ask via `AskUserQuestion` whether to delete it now
(recommended once the bootstrap is verified) or keep it for the 14-day `claude-cleanup.sh` sweep; on yes, `rm -rf -- <path>`.
If any "Run everything in Docker" row was written as `TODO: not containerised`, list those rows and
tell the user to run `/dockerize-project --dry-run` next.

Show final file tree and first 40 lines of CLAUDE.md:
```bash
find .claude -type f | sort
head -40 CLAUDE.md
```

## Subagent models

**Model ask (policy v2, every run):** resolve the mode first with `bash ~/.claude/bin/project-state.sh --tier 0 | jq -r .identity.mode` (autonomous = the ask-human gate is bypassed for this tree, else spec); with no shell, `Read` `~/.claude/state/gates-bypass-rules.json` and call it autonomous only when an unexpired rule whose `guards` include `ah` covers this directory (`global`, or `path` equal to / a recursive ancestor of it), else spec. **Spec mode:** before the first Agent call of a run, ask ONE `AskUserQuestion` that shows the whole table below in the question text, with each stored value as the recommended choice (for reviewers, the `reviewer-model` file value; in spec mode a stored value is only ever the recommended option). Shape: AskUserQuestion takes 2-4 options and cannot pre-select, so the options are keep-the-table (Recommended), one uniform alias for every agent, and a challenge escape. **Autonomous mode** (user ruling 2026-09-30, plan model-policy-bypass): do NOT ask. For each agent read its override from `~/.claude/state/model-overrides.json` (`Read` it; key = the table's Agent label as a slug: lowercase, spaces to hyphens, under `agents`, falling back to `agents."*"`; or `bash ~/.claude/bin/model-override.sh get agent <slug>`, which applies the same fallback) and use it when present (an `as-is` override means the session's model: `bash ~/.claude/bin/session-model.sh` prints its alias), else the table value below (reviewers: the `reviewer-model` file); an invalid or absent table means no overrides. Record one `ASSUMED (review): <agent> runs on <model> - source <override|table>` per agent in the active plan's Decisions Log (`bash ~/.claude/bin/project-state.sh --append-decision <active plan> ASSUMED "..."`, or edit the plan file directly when there is no shell). Both modes: pass `model:` on every Agent call, set to the answer. An orchestrator (`/mega-analysis`, `/loop --pipeline`) which already asked for this run and named the models replaces it.

Set by the model-assignment audit (decision D28, 2026-09-29; rubric D5: `opus` = judgment, `sonnet` = detection and mapping). **Pass `model:` on every Agent call** — an omitted model inherits the session, so quality and cost would follow the `/model` choice.

| Agent | model | why |
|---|---|---|
| Agents 1–4 (tech stack, structure, CI/CD, testing) — Phase 1 Explore agents | sonnet | each maps files and reports what it finds; no judgment call |
