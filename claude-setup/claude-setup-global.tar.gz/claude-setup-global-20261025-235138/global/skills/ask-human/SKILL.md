---
name: ask-human
description: >
  AskUserQuestion protocol — options, recommended first, max 4, yes/no — plus question
  quality: context, a minimal example, after-states, a visible challenge-the-premise escape.
user-invocable: true
allowed-tools: AskUserQuestion
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /ask-human — AskUserQuestion protocol — options, recommended first, max 4, yes/no;
>              question quality (five parts, rules, when mandatory).
>
> No flags — invoked automatically by Claude during the reasoning workflow.
> ```

---

# Human-Friendly Question Protocol

Every question asked to the user MUST follow this protocol. No free-text questions.
No numbered lists. No "Please reply with A, B, or C." Always use `AskUserQuestion`.

---

## Core Rules

| Rule | Requirement |
|------|------------|
| **Always use options** | Never ask a free-text question if options can cover ≥80% of cases |
| **First = Recommended** | The recommended option MUST be first. Label it `"Recommended"` at the end of the label text. |
| **Other is automatic** | `AskUserQuestion` always appends a free-text "Other" option — never add it manually |
| **Batch limit** | Max 4 questions per `AskUserQuestion` call — split larger sets into progressive rounds |
| **Header = chip** | `header` max 12 characters — it shows as a chip above the question |
| **No numbered lists** | Never output "1. Question\n2. Question" — call `AskUserQuestion` instead |

---

## Question quality — what goes INTO the question

The patterns below are the tool mechanics; this section is the content. It is the shared protocol
the per-repo `<prefix>-ask-human` skills used to carry five copies of (lifted here 2026-09-28,
review-remediation 7.6). A repo skill now holds only what is specific to that repo — its extra
"when mandatory" items and a worked example in its own domain — and defers to this section.
**A repo may be STRICTER, never looser:** when its own invariant tightens a rule here (where the
example goes, or what autonomous mode may do with a question), its `<prefix>-ask-human` says so
and wins for that repo — e.g. phorj's Invariant 15 never takes the recommended option on a language
question: autonomous mode records it as PENDING (and moves on), spec mode asks and stops.

**Asked or shown is the mode's call, not this section's** — unless a repo skill is stricter (above).
Whether a question STOPS the turn, or is shown and answered with the recommended option (logged
`ASSUMED (review)`; with confident picks (`cf`) on, a mid-task question is picked only under the tiered rule, never by default), is decided by CLAUDE.md § Mode. This section governs the question's shape
either way — a well-formed question is also what makes an `ASSUMED` pick reviewable in the morning.

**Confident picks (`cf`, row 26zg).** When the banner, the subagent brief or the per-prompt line says `CONFIDENT PICKS (cf): on`,
that tiered rule replaces the mode's mid-task question policy (the size gate still asks in spec mode): PICK when an objective test
decides — a recorded ruling dictates the option, or it is the only one passing a rule or test; a reversible, in-scope grey case is picked
only when `advisor()` agrees; otherwise ASK. Every pick is logged `ASSUMED (review)` citing its basis (the ruling, the test, or the
advisor verdict). Always asked: destructive steps, the 5-round certification cap, and grey cases when `advisor()` is unavailable. Under
a `no_ask` unattended window, a grey case `advisor()` did not settle is parked (the engine logs it), never auto-picked. The question
itself keeps the five parts below, so a later reviewer can judge the pick.

### The five required parts

| # | Part | Requirement |
|---|------|-------------|
| 1 | **Context** | What is being decided and *why it is being asked now*, in the `question` text — enough that the user needs no scrollback. |
| 2 | **Example** | A **minimal concrete example** of the problem — actual code, actual command output or error, an actual path — in the reply text just before the call. Not a description of the situation: the situation. |
| 3 | **Options** | Mutually exclusive, ordinarily 2–4, each `description` carrying its own consequence **and its after-state** (the same example under that option). |
| 4 | **Recommendation** | The recommended option FIRST, labelled `(Recommended)`, with the reason it wins in its description. |
| 5 | **Escape hatch** | A **visible** challenge path: a final *"None of these / challenge the premise"* option when there is room (≤ 3 real options), otherwise a sentence in the question text pointing at the auto-appended "Other". Never the per-option notes field — it is not rendered. |

### Non-negotiable rules

- **Never a free-text prose question.** Every question goes through `AskUserQuestion`; while the
  `qg` family is armed (CLAUDE.md § Mode) the question-guard Stop hook blocks a turn that ends on a
  bare `?` — and it is right to.
- **Never a bare `?` with no options.** If a real choice exists, enumerate it. An unstructured
  question makes the user do the work of designing the options.
- **Always a recommendation.** "What do you prefer?" with no lean is an abdication. State it and
  why — the user can then disagree cheaply.
- **The after-state goes in the option.** Prose outside the option list is easy to miss while
  comparing options.
- **One stop per question set.** Batch related questions (≤ 4 per call), then end the turn — never
  answer your own question and continue. (In autonomous mode the batch is shown, not asked; see above.)
- **Never re-open a ruled decision** without new evidence, and say what the new evidence is.
- **Challenge before accepting.** If the user's proposal has a failure mode, say so in one or two
  sentences — *and still deliver what was asked* under a stated assumption if they reaffirm it.

### When a question is mandatory

- Any **user-visible product, UX or language decision** — those are the user's, never ruled alone.
- Any **destructive, irreversible or outward-facing action** — force-push, history rewrite, deploy,
  publish, a delete with no backup. (Plain commit and push follow CLAUDE.md Rule 10 and the repo's
  own git-autonomy rule — do not ask about those where they are authorised.)
- Any **change to a documented invariant or declared ceiling** — weakening one is a product
  decision, not an implementation detail.
- A **certification loop that hits its cap** (5 rounds with findings still open) — this one asks in
  every mode.
- Any point where two readings of the request lead to **materially different work**.

The repo's `<prefix>-ask-human` adds that repo's concrete instances of these (its invariants, its
destructive commands, its own ruled decisions).

### When it is NOT needed

Routine judgement calls with an obvious default, and pure information questions. Asking about
everything is its own failure — it turns the user into a decision queue. Decide what you can
defend, state the assumption, and keep moving.

---

## Pattern 1 — Single-Select with Recommendation

Use when the user must pick exactly one option and you have a clear preference.

```
AskUserQuestion({
  questions: [{
    question: "Which implementation approach do you prefer?",
    header: "Approach",
    multiSelect: false,
    options: [
      {
        label: "Pragmatic (Recommended)",
        description: "Balanced approach — good architecture, reasonable scope. Best for most features."
      },
      {
        label: "Minimal",
        description: "Maximum reuse, fewest files changed. Best when deadline is tight."
      },
      {
        label: "Clean",
        description: "Best long-term architecture, most maintainable. Best for core features."
      }
    ]
  }]
})
```

**Rules**:
- Recommended option → first in the array, label ends with `(Recommended)`
- 2–4 options only (Other is auto-added)
- `multiSelect: false` (default — can be omitted)

---

## Pattern 2 — Yes / No Confirmation

Use before any destructive or irreversible action, and before starting implementation after plan approval.

```
AskUserQuestion({
  questions: [{
    question: "Proceed with the implementation plan above?",
    header: "Confirm",
    multiSelect: false,
    options: [
      {
        label: "Yes, proceed (Recommended)",
        description: "Start implementation with the approved plan."
      },
      {
        label: "Ask advisor for review",
        description: "Call advisor() for an independent second opinion before proceeding."
      },
      {
        label: "No, revise",
        description: "Go back and adjust the plan or approach."
      }
    ]
  }]
})
```

**Rules**:
- "Yes" is always first (positive action = recommended default)
- Include an "Ask advisor for review" option for any significant implementation gate, architectural decision, or risky action — position it between Yes and No
- When the user selects "Ask advisor for review", call `advisor()` immediately and present its findings before re-asking
- "No" option label describes what happens next (not just "No")
- Never use this pattern for destructive actions where "No" should be the safe default — invert the order in that case

---

## Pattern 3 — Multi-Select (non-exclusive choices)

Use when multiple answers can coexist (e.g. "which constraints apply?", "which areas to audit?").

```
AskUserQuestion({
  questions: [{
    question: "Which constraints apply to this change?",
    header: "Constraints",
    multiSelect: true,
    options: [
      {
        label: "No breaking changes (Recommended)",
        description: "Existing API contracts must stay intact."
      },
      {
        label: "No new dependencies",
        description: "Do not add any new npm/pip packages."
      },
      {
        label: "Minimal diff",
        description: "Change as few lines as possible."
      },
      {
        label: "Zero behavior change",
        description: "Pure refactor — no observable difference."
      }
    ]
  }]
})
```

**Rules**:
- `multiSelect: true` when choices are not mutually exclusive
- Still list the most common/recommended option first
- Still limited to 4 options (Other is auto-added for free text)

---

## Pattern 4 — Side-by-Side Preview (code or layout comparison)

Use when the user needs to visually compare code snippets, config examples, or UI layouts.

```
AskUserQuestion({
  questions: [{
    question: "Which API response format do you prefer?",
    header: "Format",
    multiSelect: false,
    options: [
      {
        label: "Flat (Recommended)",
        description: "Simpler to consume on the frontend.",
        preview: "{\n  \"id\": 1,\n  \"status\": \"pending\",\n  \"amount\": 100\n}"
      },
      {
        label: "Nested",
        description: "Groups related fields together.",
        preview: "{\n  \"claim\": {\n    \"id\": 1,\n    \"status\": \"pending\"\n  },\n  \"payment\": {\n    \"amount\": 100\n  }\n}"
      }
    ]
  }]
})
```

**Rules**:
- Only use `preview` when there is a concrete artifact to compare (code, layout, config)
- Do NOT use `preview` for simple preference questions
- `preview` is only supported for single-select (not multiSelect)
- Preview content renders as markdown in a monospace box

---

## Pattern 5 — Progressive Batching (max 4 per call)

When you have more than 4 questions, split into logical rounds. Do NOT dump all questions at once.

```
# Round 1 — Scope and context (most critical first)
AskUserQuestion({
  questions: [
    { question: "Which module is affected?", header: "Module", ... },
    { question: "What is the expected outcome?", header: "Output", ... },
    { question: "Any constraints?", header: "Constraints", ... }
  ]
})

# Wait for answers, then Round 2 — only if needed
AskUserQuestion({
  questions: [
    { question: "Should we create a feature branch?", header: "Branch", ... }
  ]
})
```

**Rules**:
- Group by logical theme (scope → output → constraints → details)
- Ask the most decision-critical questions first
- Only ask follow-up questions if answers from Round 1 reveal new ambiguities
- Never ask questions you could answer by reading the codebase — explore first

> **Scope — this governs *clarifying* questions only.** "Explore first" applies to questions
> whose answer is already on disk. It does **not** apply to the mandatory task-size gate in
> `CLAUDE.md` (*"State task size aloud"* → *"Invoke `ask-human` skill to confirm or
> redirect"*), which fires **before** any exploration by design — so the user can redirect the
> work before effort is spent on it. Two different question types, not a contradiction.

---

## Pattern 6 — Stating Ambiguity (for sub-agents without AskUserQuestion)

Sub-agents (e.g. architect) cannot use `AskUserQuestion`. When ambiguity exists, they state it inline with a default assumption. The supervisor then surfaces it to the user using Pattern 1 or 2.

**Sub-agent output format**:
```markdown
> ⚠️ **Assumption**: The request mentions "status field" but does not specify
> the source. I assumed it comes from the Mario API response.
> **Default**: Use `claim.status` from the existing Mario payload.
> **Alternative**: Fetch status from a dedicated `/status` endpoint.
> Supervisor should confirm with user before implementation begins.
```

**Supervisor then asks**:
```
AskUserQuestion({
  questions: [{
    question: "The architect assumed status comes from the Mario API payload. Is that correct?",
    header: "Assumption",
    multiSelect: false,
    options: [
      { label: "Yes, use Mario payload (Recommended)", description: "claim.status from existing payload." },
      { label: "No, use dedicated endpoint", description: "Fetch from a separate /status route." }
    ]
  }]
})
```

---

## Navigation (automatic — no configuration needed)

The Claude Code UI handles all navigation automatically:
- **Arrow keys** → move between options
- **Enter** → confirm selection
- **Space** → toggle selection (multiSelect mode)
- **First option** → pre-selected by default when the UI opens

You do not need to configure this — just ensure the recommended option is always first.

---

## Anti-patterns — Never Do These

| Forbidden | Why | Use instead |
|-----------|-----|-------------|
| `"Please reply with A, B, or C"` | Not interactive, error-prone | `AskUserQuestion` with options |
| Numbered question lists in prose | Non-interactive, user must type | `AskUserQuestion` with up to 4 questions |
| `"Other"` as a manual option | Auto-added by `AskUserQuestion` | Remove it — it's always there |
| Recommended option last | User defaults to first | Put recommended first |
| 5+ options per question | Overloads the user | Max 4 options + auto Other |
| Asking questions you can answer by reading files | Wastes user time | Read files first, then ask only what files can't answer — clarifying questions only; the size gate still fires first |
| Asking confirmation after a destructive action | Too late | Always ask BEFORE destructive actions |

---

## Quick Reference

```
Single choice + recommendation   → Pattern 1 (multiSelect: false, first = recommended)
Yes/No gate                       → Pattern 2 (Yes first, advisor option second, describe No action)
Multiple constraints/preferences  → Pattern 3 (multiSelect: true)
Code/layout comparison            → Pattern 4 (preview on options)
More than 4 questions             → Pattern 5 (progressive rounds)
Sub-agent ambiguity               → Pattern 6 (state assumption, supervisor asks)

Advisor option                    → Include "Ask advisor for review" between Yes and No on any
                                    significant gate; call advisor() when user selects it
```

$ARGUMENTS
