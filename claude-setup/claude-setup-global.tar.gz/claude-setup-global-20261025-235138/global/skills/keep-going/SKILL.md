---
name: keep-going
description: Use when the user wants a session, a project tree, or everything to keep working without stopping — switches the keep-going Stop hook on or off at any scope (session, project tree, exact directory, global) or shows its state.
user-invocable: true
args: "[on|off|status] [--session|--here|--path DIR|--global] [--for DUR|--forever] [--cap N|unlimited]"
side-effects: Session scope creates or removes ~/.claude/run/keep-going-<session_id> and its counter file (with --cap it writes cap=N into the former). --cap at another scope writes ~/.claude/projects/<slug>/state/keep-going-cap or ~/.claude/state/keep-going-cap. The other scopes edit ~/.claude/state/gates-bypass-rules.json through bin/gates-bypass.sh (family kg), which asks first.
disable-model-invocation: true
---

**Front door:** `/gates-bypass on|off keep-going WHERE [--cap N|unlimited]` runs the same executor (`bin/gates-bypass.sh`) this skill calls (framework-health 4.5).

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /keep-going — stop sessions from going idle between cycles. Same scopes as every gate.
>
>   /keep-going on                       this session only (default; no prompt, no expiry)
>   /keep-going on --here --for 2h       this directory and everything beneath it, for 2 hours
>   /keep-going on --path DIR --forever  a named project tree
>   /keep-going on --global --forever    EVERY session in EVERY project (asks; shows a warning)
>   /keep-going on --cap 50              ask me after 50 consecutive forced continuations (default 25)
>   /keep-going on --cap unlimited       no cap question; a stop message, a closing marker, the no-progress breaker, Esc or
>                                        KEEPGOING_OFF=1 end it, each but the last two after the KG-STOP question (--cap 0 is the same)
>   No-progress breaker: KEEPGOING_NOPROGRESS (default 3, 0 = off) forced continuations in a row with no tool call let the stop
>   through after the KG-STOP question, nothing disarmed (docs/SPEC.md §2.21)
>   (--cap works with any scope flag: session = cap=N in the sentinel; --here/--path = that project's keep-going-cap; --global = the global one)
>   /keep-going off [same scope flag]    disarm at that scope (default: this session)
>   /keep-going status                   the resolver view here + whether the Stop hook is registered
>
> Armed = when the session would stop and no shell, subagent, MCP task or cron runs in the background (a Monitor does not count:
> an expired one can stay "running" for hours, row 26zl), the Stop hook makes it do the next
> thing (autonomous mode: act on /next's pick; spec mode: ask "Do NEXT (Recommended) / Stop here"). It stands
> down on a stop message (always, under any cap), a closing KEEPGOING-DONE (the plan's verdict is done), a
> closing KEEPGOING-NEEDS-USER (the message's last word; the rest waits on you: a blocked/deferred step or an open Needs input / Blocked
> entry; see `project-state.sh | jq .plans.verdict`), or pending background work or a scheduled wake. A step
> that needs you must be marked `blocked` or listed under Needs input, or the verdict reads actionable. After the cap (default 25) consecutive forced continuations it ASKS you, in both modes:
> continue N more / continue unlimited for this prompt / stop. Destructive steps still ask.
> When it stands down you are TOLD first (row 26u): a phone push, then one KG-STOP question - stop here,
> or what to chase next. Any answer is a stop unless it is clearly a chase (the chase option, or typed text that asks to
> continue: keep going, continue, carry on, go ahead, proceed, chase, do it - but "option 1", or "let me run it, then
> continue", is a stop); under an unattended window with --no-ask nothing is asked: you get the push only, and the
> run stops there (the cap too, instead of its question). A stop ends the turn until a background
> task reports back, a chase is done next. Nothing is asked for pending
> background work (the job wakes the session), a Stop you just gave, or a headless run (claude -p, read from
> the transcript, else CLAUDE_CODE_ENTRYPOINT), which skips keep-going entirely; KEEPGOING_STOP_ASK=0 at launch
> skips the question (a desktop notification "stopped (<reason>)" still fires).
> An API error ends the turn WITHOUT a Stop (Claude Code fires StopFailure after its own retries), so keep-going never
> sees it: hooks/stop-failure-notify.sh tells you instead (log, desktop + terminal, opt-in ntfy push; register it with
> bash ~/.claude/bin/stop-failure-apply.sh on). For long unattended runs launch with CLAUDE_CODE_RETRY_WATCHDOG=1 (docs/SPEC.md §2.25).
> To stop a turn WITHOUT disarming: type a message with stop / pause / halt anywhere (or wait / enough first),
> even while Claude is working. Claude finishes the current step, says where it stopped, asks the KG-STOP question once and ends the turn; your
> next message resumes the loop. A message that also says "don't stop", "non-stop" or "keep going" is read as
> keep going. Esc is the hard brake (cuts mid-step).
> Statusline line 2: keep-going (sess|g|proj|rule) ↻n/cap.
> Tree and global scopes need --for DUR (max 30d) or --forever. An armed keep-going counts as "said non-stop".
> ```

# /keep-going

Keep-going is the resolver family `kg` (docs/SPEC.md §2.1 and §2.21): the same six scopes as every gate. The Stop hook must be registered once
(user-run: `! bash ~/.claude/bin/keep-going-apply.sh on`); without that, arming does nothing.

Arguments: a verb `on`, `off` or `status` (none = `status`) and one scope flag (none = `--session`). Run exactly one block, then report its output in one line.

**Session scope** (default; no prompt):

```bash
# on
touch ~/.claude/run/keep-going-$CLAUDE_CODE_SESSION_ID && rm -f ~/.claude/run/keep-going-count-$CLAUDE_CODE_SESSION_ID && echo "keep-going: ARMED for this session"
# on with --cap N|unlimited (N = 1-999999; unlimited or 0 = no cap): the sentinel's content carries it
printf 'cap=%s\n' "<N|unlimited>" > ~/.claude/run/keep-going-$CLAUDE_CODE_SESSION_ID && rm -f ~/.claude/run/keep-going-count-$CLAUDE_CODE_SESSION_ID && echo "keep-going: ARMED for this session, cap <N|unlimited>"
# off (a bare off removes only the session switch: say so when a wider scope still arms this directory)
rm -f ~/.claude/run/keep-going-$CLAUDE_CODE_SESSION_ID ~/.claude/run/keep-going-count-$CLAUDE_CODE_SESSION_ID && echo "keep-going: off for this session"; ( export BYPASS_SESSION_ID=$CLAUDE_CODE_SESSION_ID; source ~/.claude/hooks/bypass-resolve.sh && bypass_applies kg "$PWD" || exit 0; bypass_rule_applies kg "$PWD" && w="a tree/exact/global rule" || w="a project or global switch file"; echo "keep-going: STILL ARMED in $PWD by $w — /keep-going status shows it; disarm with /keep-going off --here | --path DIR | --global" )
```

**Any other scope** goes through the one executor, which edits the protected rules file and therefore asks (that prompt is the design). Show the
plan first (`--dry-run`), then apply only with `--yes`. `--for DUR` or `--forever` is required for `on` (never defaulted); `--global` additionally
warns that every session in every project is affected:

```bash
bash ~/.claude/bin/gates-bypass.sh on kg --here --for 2h --dry-run     # then the same line with --yes instead of --dry-run
bash ~/.claude/bin/gates-bypass.sh off kg --here --yes
```

**status**:

```bash
bash ~/.claude/bin/gates-bypass.sh status; bash ~/.claude/bin/keep-going-apply.sh status
```

**`--cap` at another scope** is a second command, after the `on` above: it writes the cap file for that scope (a protected `state/` path, so it asks; that prompt is the design).
The hook looks the cap up from the session's cwd upwards, nearest project first, so a cap set at a project root applies to every subdirectory:

```bash
D=~/.claude/projects/$(printf '%s' "<DIR>" | tr '/' '-')/state; mkdir -p "$D" && printf '%s\n' "<N|unlimited>" > "$D/keep-going-cap"   # --here / --path DIR
printf '%s\n' "<N|unlimited>" > ~/.claude/state/keep-going-cap                                                              # --global (every project without its own)
```

`off` does not remove a cap file (it is a setting, not a switch); delete it to go back to the default of 25. Lookup order: env `KEEPGOING_CAP`, the session sentinel's `cap=`, the nearest project file, the global file, 25.

At the cap the hook blocks once and tells Claude to ask `KEEPGOING-Q`: *Continue N more (Recommended)* / *Continue unlimited for this prompt* / *Stop here*; asked twice without an answer, the hook asks the KG-STOP question, then lets the stop through. When you see that block, ask exactly that, with the cap number in the question.

Never combine keep-going with another family in one command, and never pass `--except` or `--level` (the executor refuses both). `/gates-bypass`
`all` and `--run/--spec` never touch keep-going: it is an enable, not a bypass.

Under `on`, say that keep-going is armed, which counts as the user having said non-stop: finish each step, then take the next one without a closing
"what's next?" question (the Stop hook cannot reach a turn that ends on a question). Destructive or irreversible steps still ask. The user can say
"stop" at any time.

Known limit: while the hook forces continuations, `stop_hook_active` is true on every later stop, so the question guard and the completion guard
(which bail out on it) are skipped for those turns.
