---
name: learning-off
description: Use when disabling the learning-output-style plugin to switch from explanatory mode to direct execution mode.
user-invocable: true
disable-model-invocation: true
---

**Front door:** `/gates-bypass off learning` routes here; this skill is the implementation (framework-health 4.5).

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /learning-off — Disable the learning-output-style plugin to switch from explanatory mode to direct execution mode.
>
> No flags — invoked without arguments.
> ```

---

# /learning-off — Disable Learning + Explanatory Output Style

Disables the `learning-output-style` plugin for this machine's Claude Code sessions.

## Steps

1. Run `bash ~/.claude/bin/learning-style.sh off` (it sets `"learning-output-style@claude-plugins-official": false` in `enabledPlugins`;
   a direct Write to `settings.json` is classifier-blocked for Claude, framework-health 4.8). Exit 0 = done (or already disabled);
   exit 5 = refused: its two protect rules are not installed on this machine (`/gates-bypass protect gates apply` installs
   them) - say so and stop; exit 1 = settings.json could not be round-tripped, nothing written.
   `bash ~/.claude/bin/learning-style.sh status` shows the current value without writing.
   `settings.json` often carries uncommitted changes already (`git -C ~ status -- .claude/settings.json`): the switch edits one key on top
   of them and keeps a backup `settings.json.bak.<epoch>` (the newest 2 are kept); it does not commit anything.
2. Confirm: "Learning mode disabled. Restart Claude Code for the change to take effect."

## What this disables

- `★ Insight` blocks after code
- "Request contribution" prompts
- Explanatory commentary on trade-offs

## When to use

- Execution sessions: bug fixes, infra work, scripting, late-night sprints
- Any time you want fast, direct responses without educational overhead

Re-enable with `/learning-on` when you want explanatory mode back.
