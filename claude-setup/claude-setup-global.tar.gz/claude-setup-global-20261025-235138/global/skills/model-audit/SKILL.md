---
name: model-audit
description: Use when checking Claude model IDs across ~/.claude/ for outdated or date-suffixed IDs. Mode 1 normalizes IDs, Mode 2 challenges outdated versions.
user-invocable: true
---

# /model-audit — Claude Model ID Health Check

Two-mode health check for Claude model IDs across `~/.claude/`.
Mode 1 normalizes date-suffixed IDs. Mode 2 challenges outdated model versions.

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /model-audit — Scan ~/.claude/ for stale or date-suffixed Claude model IDs.
>
> Modes:
>   (default)     Normalize: fix date-suffixed IDs (e.g. claude-haiku-4-5-20251001 → claude-haiku-4-5)
>   --currency    Challenge outdated model versions against ~/.claude/refs/MODELS.md
>   --apply       Apply proposed fixes (default is dry-run)
>   --init        Create ~/.claude/refs/MODELS.md with current canonical lineup (skip if exists)
  --init --force  Overwrite MODELS.md even if it already exists (refresh stale data)
>   --scope=<path>  Restrict scan to a specific path (default: ~/.claude/)
> ```

---

## Mode 1: Normalize (default)

Detect and optionally fix date-suffixed Claude model IDs across `~/.claude/`.

Date-suffix pattern: `claude-(fable|mythos|opus|sonnet|haiku)-<M>-<m>-YYYYMMDD`
Canonical form: `claude-(family)-M-m` (no trailing date)

### Step 1: Scan

Use the **Grep tool**, not a recursive shell `grep`: the firewall refuses a recursive read of `~/.claude` (it holds
credential stores), and the tree holds gigabytes of session transcripts that are history, not configuration.

- pattern: `claude-(fable|mythos|opus|sonnet|haiku)-\d+-\d+-\d{8}`
- path: `--scope` if given, else `~/.claude`
- glob: `*.{sh,md,json,yaml,yml,py,toml}` · output_mode: `content` with line numbers
- Drop hits under `projects/*/` transcripts, `logs/`, `backups/` and `*.bak*`: they record what ran, and rewriting them
  changes nothing that runs.

### Step 2: Present plan

For each match, format as:

```
FILE: ~/.claude/hooks/session-remember/save.sh:224
  FOUND:      claude-haiku-4-5-20251001
  NORMALIZE → claude-haiku-4-5
```

If no matches: print "All model IDs are already in canonical form — no date suffixes found." and stop.

### Step 3: Apply (if `--apply`)

For each match, make the targeted replacement with the **Edit tool**, one occurrence at a time, preserving the
surrounding context. Never touch model IDs that are already canonical.

Before the first edit to each file, check its state (CLAUDE.md Rule 8): inside a git repo, `git status --porcelain -- <file>`
must be empty (otherwise stop and tell the user the file has uncommitted changes); outside one, the Rule 8 hook copies it
into `~/.claude/backups/rule8/` before the Edit and prints the copy and its restore line: name that backup. `settings.json` and guard hooks are classifier-blocked:
list those replacements for the user instead of editing them.

After applying: re-run the scan to confirm zero matches remain.

---

## Mode 2: Currency Check (`--currency`)

Challenge outdated Claude model versions using a user-maintained truth source.

**Prerequisite**: `~/.claude/refs/MODELS.md` must exist.
If not found: print "MODELS.md not found. Run `/model-audit --init` to create it." and stop.

### Step 1: Load canonical models

Read `~/.claude/refs/MODELS.md`. Extract rows with `Status = CURRENT`.
Build a map: `family → current_model_id` and `family → [superseded_ids]`.

### Step 2: Scan for all model ID references

Grep tool, same path, glob and exclusions as Mode 1 Step 1; pattern `claude-(fable|mythos|opus|sonnet|haiku)-\d`.

### Step 3: Classify each found model ID

For each match:
1. Strip any date suffix → `base_id`
2. Extract family (`fable` / `mythos` / `opus` / `sonnet` / `haiku`) and version numbers
3. Compare `base_id` to MODELS.md CURRENT for that family:

| Result | Action |
|--------|--------|
| `base_id == CURRENT` | ✅ Print as up-to-date (verbose mode only) |
| `base_id` is older within same family | ⚠️ OUTDATED — challenge |
| `base_id` is a different tier/family | **SKIP** — never propose cross-family upgrades |
| `base_id` unknown | ❓ Flag as UNRECOGNIZED |

**Hard rule — cross-family upgrades are never proposed.** Haiku is often chosen for cost/latency reasons. Sonnet is chosen for balance. Opus is chosen for capability. Cross-family changes require human judgment — the skill must not second-guess tier choices.

### Step 4: Present findings

Group by file. For each OUTDATED entry:
```
FILE: ~/.claude/CLAUDE.md:142
  FOUND:   claude-opus-4-7 (Opus family)
  CURRENT: claude-opus-4-8
  CHALLENGE: You are using Opus 4.7 in this location — Opus 4.8 is available.
             Intentional choice, or needs updating?
```

For each UNRECOGNIZED entry:
```
FILE: ~/.claude/agents/my-agent.md:5
  FOUND:   claude-opus-4-5 (not in MODELS.md)
  STATUS:  UNRECOGNIZED — may be deprecated or a typo
```

If all entries are current: "All model IDs match current versions in MODELS.md ✅"

### Step 5: Apply (if `--apply`)

For each OUTDATED entry: present the proposed replacement and ask for per-entry confirmation before writing. Never batch-replace all — each replacement is a deliberate choice.

---

## --init flag

Creates `~/.claude/refs/MODELS.md` with the current canonical Claude lineup.

**Safe to rerun** — never overwrites if file already exists. Prints the path if it already exists.
Use `--force` to overwrite an existing MODELS.md with a refreshed canonical lineup.

**Maintenance note**: this template is necessarily a bootstrap copy of `refs/MODELS.md`'s content —
there is nowhere else to read a canonical lineup from when the file doesn't exist yet. When Anthropic
ships a new model generation, update **both** this template and the live `refs/MODELS.md` in the same
change, or `--init --force` will regress an already-current registry (this happened: the template still
listed Opus 4.8/Sonnet 4.6 as CURRENT after Opus 5/Sonnet 5/Fable 5 shipped — fixed 2026-08-30).

```markdown
# Claude Models Reference
# Update this file when Anthropic releases new models.
# /model-audit --currency reads from here — keep it current.
# Format: | Model ID | Family | Version | Status | Context | Supersedes |
# Status values: CURRENT | SUPERSEDED (still valid, not retired) | PREVIEW
# Lineup last checked 2026-10-08 against platform.claude.com/docs/en/about-claude/models/overview (current: Fable 5.1, Opus 5.5,
# Sonnet 5.5, Haiku 5.5, all 1M; legacy list includes Opus 4.5 and Haiku 4.5). "unrecorded" = context window not checked. bin/tests/model-audit-registry.test.sh keeps
# this file and the /model-audit --init template identical.

## Current Canonical IDs

| Model ID | Family | Version | Status | Context | Supersedes |
|----------|--------|---------|--------|---------|------------|
| claude-fable-5-1 | fable | 5.1 | CURRENT | 1M | claude-fable-5 |
| claude-mythos-5 | mythos | 5 | CURRENT (Project Glasswing only) | 1M | mythos-preview |
| claude-opus-5-5 | opus | 5.5 | CURRENT | 1M | claude-opus-5 |
| claude-sonnet-5-5 | sonnet | 5.5 | CURRENT | 1M | claude-sonnet-5 |
| claude-haiku-5-5 | haiku | 5.5 | CURRENT | 1M | claude-haiku-4-5 |

## Superseded — still valid, live API models, not retired

| Model ID | Family | Context | Superseded by |
|----------|--------|---------|----------------|
| claude-fable-5 | fable | 1M | claude-fable-5-1 |
| claude-opus-5 | opus | 1M | claude-opus-5-5 |
| claude-sonnet-5 | sonnet | 1M | claude-sonnet-5-5 |
| claude-opus-4-8 | opus | 1M | claude-opus-5 |
| claude-opus-4-7 | opus | 1M | claude-opus-4-8 |
| claude-opus-4-6 | opus | 1M | claude-opus-4-8 |
| claude-sonnet-4-6 | sonnet | 1M | claude-sonnet-5 |
| claude-opus-4-5 | opus | 200K | claude-opus-4-6 |
| claude-haiku-4-5 | haiku | 200K | claude-haiku-5-5 |
```

---

## Combined run (both modes)

Running without `--currency` runs Mode 1 (normalize) only.
Running with `--currency` runs Mode 1 first (normalize), then Mode 2 (currency check).
Mode 1 results are applied before Mode 2 runs, so currency check always sees canonical base IDs.

---

## Usage examples

```bash
/model-audit                     # Normalize dry-run (show what would change)
/model-audit --apply             # Apply normalization fixes
/model-audit --init              # Create ~/.claude/refs/MODELS.md (skip if exists)
/model-audit --init --force     # Overwrite MODELS.md with refreshed data
/model-audit --currency          # Check currency against MODELS.md (dry-run)
/model-audit --currency --apply  # Normalize + propose currency upgrades
/model-audit --scope=~/.claude/hooks  # Restrict scan to hooks/ subdirectory
```
