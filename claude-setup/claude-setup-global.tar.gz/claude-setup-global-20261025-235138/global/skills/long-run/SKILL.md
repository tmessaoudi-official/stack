---
name: long-run
description: Use before running anything that may take over ~2 minutes or is heavy — a full test suite, cargo/npm build, git push with a pre-push gate, a sabotage series, docker build. Chooses foreground-with-timeout vs detached (bin/detach-run.sh), and reads the job's OWN exit line, never a wrapper's exit code.
user-invocable: true
args: "<command or script>"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /long-run — run a long or heavy job so it survives, and read its real exit code.
>
> Usage: /long-run <command or script>
> Helper: bin/detach-run.sh <script-file> [log]   (setsid-detached; appends EXIT=<rc> to the log)
> ```

---

Long jobs on this machine die in ways that look like success. Five projects learned a fragment each
(2026-07-18 → 2026-09-25) and the fragments contradict — "always foreground" vs "always detach". Both
are right for their own failure; this skill is the decision rule between them.

| Killer | What dies | Looks like |
|---|---|---|
| Bash tool timeout (max 600 s) | the call **and its process group** — including a background job started from the same session | a push that printed `[pre-push] OK` and exit 0, never transferred (Rule 15, 2026-08-23) |
| `run_in_background` ~10 min cap | the background task | a completed notification whose code is the last pipeline stage's (`tail` → 0) |
| memory killer | background tasks first; foreground calls were never killed | "exit 137" inside the log, "exit 0" on the notification |
| load (20–45 here) | full-tree, high-parallelism builds/suites | SIGKILL mid-link → a corrupted incremental cache |

## Decide

1. **Estimate** from the last run's log or the project memory, and look at the machine: `free -h`,
   per-core `mpstat -P ALL 1 1` (load average hides a single pinned core).
2. **Can it be smaller?** Run the targeted thing — one section of a suite (a section runner: setup +
   the one section), `cargo nextest -E`, one package — and keep the full run for once, at the end, on a
   frozen tree. Run ONE heavy job at a time.
3. **Under ~9 minutes, or memory-hungry → foreground** with the Bash tool's `timeout: 600000`.
   A `git push` NEVER goes through `run_in_background`: a later timeout in the same session kills its
   process group after its hooks passed, and the notification still says exit 0. A push whose
   pre-push gate fits in ~9 min runs foreground; a longer one (phorj: 7–12 min) goes through
   `detach-run.sh` below — `setsid` puts it outside the process group a timeout can reach.
4. **Longer, or must outlive the turn → detach** with the helper:
   ```bash
   cat > "$SCRATCH/job.sh" <<'EOF'
   cd /path/to/repo
   <the command>          # no `| tail` as the LAST stage — it replaces the exit code
   EOF
   bash ~/.claude/bin/detach-run.sh "$SCRATCH/job.sh" "$SCRATCH/job.log"
   ```
   `detach-run.sh` takes a script FILE, never a raw argv: the firewall strips `setsid`/`nohup` and
   classifies the real verb, but it cannot see through an unknown wrapper's arguments — an argv form
   would hide `git push --force` from the deny floor. It starts the job in its own session
   (`setsid nohup`), so a timeout elsewhere cannot reach it, and appends `EXIT=<rc>` — the script's own
   status — as the log's last line.

## Wait

5. **Wait on the job's own marker, nothing else.** A Bash `run_in_background` waiter gives one
   notification: `until grep -q '^EXIT=' "$LOG"; do sleep 20; done`. The waiter is itself subject to
   the ~10-min background cap — if it is killed, the JOB is not (it has its own session): re-arm the
   waiter. No `EXIT=` line long after the expected time → `kill -0 <pid>`: alive = still running,
   gone = the job's wrapper was killed (OOM) — read the log's tail and re-run. Never `pgrep -f
   <script>` (it matches the waiter itself), never a second Bash call polling a push, never a
   foreground `sleep` loop.
6. **Say how long it will take** before going quiet ("~12 min; the session will look idle").

## Read

7. **Read the job's own lines, not the notification.** `tail -n 30 "$LOG"`: the `EXIT=` value, the
   suite's tally line, the failing names. A notification's exit code is the waiter's or the last pipe
   stage's.
8. **Push**: a successful push prints a `To <host>:` line. Then `git rev-list --count
   origin/<branch>..<branch>` must be 0. No `To` line = it did not push, whatever the exit code said.
9. **Killed?** Treat the incremental cache as suspect (cargo: `rm -rf target/debug/incremental` on
   `undefined hidden symbol … .llvm.` link errors), re-run rather than trusting a half log, and see
   `/recover-session` if the kill took uncommitted work with it.

$ARGUMENTS
