---
name: pre-session-health
description: Use before starting any significant Claude session — fast (~30s) pre-flight scan of tooling health (hooks, session-remember, settings) rather than the project being worked on.
user-invocable: true
---

# /pre-session-health — Pre-Work Health Dashboard

Fast (~30s) pre-flight scan before starting a significant Claude session.
Checks the health of the tooling you're about to use, not the project you're working on.

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /pre-session-health — Quick health check of ~/.claude/ before starting a work session.
>
> Flags:
>   --fix     Auto-fix any green-level issues found (safe, non-destructive)
>   --quiet   Only print yellow/red items; suppress green lines
> ```

---

## Step 1: Git state

```bash
git -C "$HOME/.claude" status --short 2>/dev/null
```

- **Green** (0 lines): config is clean
- **Yellow** (≤5 lines): uncommitted changes — note them but proceed
- **Red** (>5 lines or staged deletions): significant drift — consider committing before working

---

## Step 2: Session-remember pipeline alive?

Check two signals:

**2a — Last save timestamp**:
```bash
# Find the most recent last-save.json across all projects
find "$HOME/.claude/projects" -name 'last-save.json' -exec stat -c '%Y %n' {} \; 2>/dev/null | sort -rn | head -1
```
- **Green**: timestamp within last 48h
- **Yellow**: timestamp 2–7 days ago
- **Red**: no `last-save.json` found, or older than 7 days (pipeline may not be running)

**2b — Recent hook errors**:
```bash
tail -20 "$HOME/.claude/logs/hooks-errors.log" 2>/dev/null | grep -i 'error\|FAILED\|fatal' | tail -5
```
- **Green**: no errors in last 20 log lines
- **Yellow/Red**: errors present — show them

**2c — Bash firewall gate alive** (v3 boundary gate needs python3; without it the hook fails CLOSED and *every* Bash call prompts):
```bash
FW="$HOME/.claude/hooks/ask-bash-firewall.sh"
[[ -x /usr/bin/python3 ]] && echo "python3: /usr/bin/python3" || { command -v python3 && echo "python3: shim (~300ms/call — install /usr/bin/python3)"; } || echo "python3: MISSING"
printf '{"cwd":"/tmp","tool_input":{"command":"ls"}}' | bash "$FW"                                   # expect: no output (defer)
printf '{"cwd":"/tmp","tool_input":{"command":"cat /etc/ssl/private/server.key"}}' | bash "$FW" | jq -r '.hookSpecificOutput.permissionDecision'   # expect: deny (private key read outside the project root)
# NOTE: do not probe with a credential-store path (~/.ssh/…, ~/.netrc, **/id_rsa): the settings.json
# `Bash(* …)` denies are TEXT-matched and block the probe command itself before the hook ever runs.
jq -r '[.hooks.PreToolUse[] | select(.matcher=="Bash") | .hooks[].command | select(test("ask-bash-firewall"))] | length' "$HOME/.claude/settings.json"  # expect: 1
```
- **Green**: `/usr/bin/python3` present, first probe silent, second probe `deny`, registered exactly once
- **Yellow**: python3 is a pyenv shim (works, ~300 ms per Bash call)
- **Red**: python3 missing, first probe emits `"ask"`, second probe not `deny`, or registration count ≠ 1 — fix before starting work (`bash ~/.claude/hooks/tests/test-bash-firewall.sh` for the full 167-case suite)

## Step 2d: Gates & permission engine

The `/gates-bypass` grid in its one-line form (framework-health 4.7): mode, engine, rules file, bypassed families, enables,
unattended window, the bypass-review counts (`review N (K risky)`, framework-health 5.5), plus one `WARN:` line per problem. Read-only; ~5 s on a loaded host (it skips the slow delegated facts).

```bash
GS=$(timeout 60 bash "$HOME/.claude/bin/gates-status.sh" --brief 2>&1); rc=$?
printf '%s\nexit=%s\n' "$GS" "$rc"
```

Show the summary line and every `WARN:` line verbatim, then grade by exit code and warning class:

| Exit / warning | Grade |
|---|---|
| exit 0 (no warnings) | **Green** |
| exit 1 with only: engine `SLOW`, engine status unknown (no status file, an unparsable status file, or `engine not installed` on a bundle target) or older than 24 h, a legacy permission-swap sentinel, a rule expiring within 24 h, a risky bypass-review event unreviewed, a rejected bypass-review group, an unreadable review summary | **Yellow** — note it; `SLOW` is host load, not a fault (never run the repair for it); review items go to `/gates-bypass review` (the user's verbs) |
| exit 1 with any of: `RULES-INVALID` (every rule ignored, every gate armed), engine `DOWN`, an engine status unknown that names a failure (`settings.json is missing or unreadable`, `the engine is registered but config/permission-rules.json is missing`, `the engine is not registered although the rules were moved out of settings.json at cutover`), `disableAllHooks` (every hook inert), a hook `NOT registered` for an ARMED gate or ON enable, `settings.json` unreadable | **Red** — fix before significant work: `/gates-bypass status` for the full grid and the command per row |
| exit 3 (the resolver could not run), exit 124 (timed out), exit 2 (usage) | **Red** — the gate state is unknown |

Never a warning: autonomous mode, bypassed rows, unratified ASSUMED entries — the summary shows them, the grade ignores them.

---

## Step 3: Model ID health

```bash
grep -rl 'claude-\(opus\|sonnet\|haiku\)-[0-9][0-9]*-[0-9][0-9]*-[0-9]\{8\}' \
  "$HOME/.claude" --include='*.sh' --include='*.md' --include='*.json' 2>/dev/null | head -5
```

- **Green**: no date-suffixed model IDs found
- **Yellow**: files with date-suffixed IDs found — list them, suggest `/model-audit --apply`

---

## Step 4: Memory index size

```bash
# Check MEMORY.md line counts across all projects
find "$HOME/.claude/projects" -name 'MEMORY.md' -exec wc -l {} \; 2>/dev/null | sort -rn | head -5
```

For each MEMORY.md found:
- **Green**: ≤150 lines
- **Yellow**: 151–180 lines — approaching 200-line truncation limit; suggest consolidation
- **Red**: >180 lines — truncation imminent; run `/retrospective` or manually consolidate

---

## Step 5: Stale handoff

```bash
# Check age of handoff.md
find "$HOME/.claude/projects" -name 'handoff.md' -exec stat -c '%Y %n' {} \; 2>/dev/null | sort -rn | head -3
```

- **Green**: handoff exists and is ≤3 days old
- **Yellow**: handoff is 3–7 days old — may be stale for ongoing work
- **Info**: no handoff found — not a problem unless work is in progress

---

## Step 6: Mega-analysis recency

```bash
ls -t "$HOME/.claude/projects/meta-reports"/*/full-analysis*.md 2>/dev/null | head -1
```

Extract the date from the path (format: `meta-reports/YYYY-MM-DD/`).
Compute days since last analysis:

```bash
LAST_RUN=$(ls -t "$HOME/.claude/projects/meta-reports"/*/full-analysis*.md 2>/dev/null | head -1 | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}' | head -1)
if [[ -n "$LAST_RUN" ]]; then
  DAYS=$(( ( $(date +%s) - $(date -d "$LAST_RUN" +%s) ) / 86400 ))
fi
```

- **Green**: ≤7 days ago
- **Yellow**: 8–14 days ago
- **Red**: >14 days ago — suggest `/mega-analysis --scope=global --quick`

---

## Output format

Print a dashboard at the end:

```
Pre-session health check — 2026-06-07 23:45
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Config git state      — clean (0 uncommitted changes)
✅ Session-remember      — last save 6h ago, no recent errors
✅ Gates & permissions   — mode autonomous | engine LIVE | rules ok (no WARN lines)
⚠️  Model IDs            — 2 files with date-suffixed IDs (run /model-audit --apply)
✅ Memory indexes        — all under 150 lines
✅ Handoff              — 1 day old (current)
⚠️  Mega-analysis        — last run 11 days ago (consider /mega-analysis --quick)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Status: READY (2 yellow items noted above)
```

Status line:
- **READY**: no red items
- **READY WITH WARNINGS**: yellow items only — start working, address yellows when convenient
- **BLOCKED**: any red item — address before starting significant work

---

## --fix flag

If `--fix` is passed, auto-apply safe fixes for yellow items:
- Model IDs: run `/model-audit --apply` (strips date suffixes only — no currency check)
- Memory: do NOT auto-consolidate (requires judgment)
- Mega-analysis: do NOT auto-run (too slow for a pre-flight check)

Never makes git commits. Only makes mechanical, obviously-safe changes.
