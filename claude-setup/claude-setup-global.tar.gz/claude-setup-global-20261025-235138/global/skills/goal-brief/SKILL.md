---
name: goal-brief
description: Use when a goal must be stated so it cannot be misread — before pasting a stop condition into the built-in /goal command, before handing work to another session or model, or when the user says "summarize the goal", "what exactly are we building", "define done". Produces a fixed-shape brief (goal, in scope, out of scope, done-when, constraints, ambiguities resolved) plus a single-line stop condition for /goal. Asks only about ambiguities that change the outcome; passes the brief through advisor() before showing it.
user-invocable: true
args: "[<topic> | --from-plan] [--save|--no-save]"
side-effects: Persists by default (pass --no-save to suppress). --save splices the brief into the plan's ## Goal section between goal markers (or writes progress/goal.md when no plan exists) after AskUserQuestion.
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /goal-brief — A goal statement that two engineers could not build differently: one-sentence
> goal, in scope, out of scope, done-when (testable), constraints, ambiguities resolved.
> Emits TWO outputs: the brief, and a marked "paste into /goal:" line holding ONE checkable
> stop condition (the built-in /goal takes a condition, not a goal).
>
> Arguments:
>   <topic>       brief a goal you describe (default when no plan is active)
>   --from-plan   brief the active plan's goal (default when a plan is active)
>   --save        DEFAULT. Write the brief into the plan's ## Goal section (goal markers)
>                 or progress/goal.md when no plan exists — confirmed first
>   --no-save     brief only, persist nothing
> ```

---

# /goal-brief — say the goal so it cannot be misread

"No misinterpretation" is a schema problem, not a prose problem. The brief has a fixed shape,
every ambiguity is resolved by a ruling rather than a guess, and the result is reviewed by
`advisor()` before you see it.

## Step 0 — one-tap chooser (mandatory; it is also the ask-human gate)

`ask-human-gate-block.sh` blocks every Bash/Read call of a new prompt until `AskUserQuestion`
has run in that turn, so the chooser comes BEFORE any probe. State *"Category: Small —
goal statement, no code"* and ask one `AskUserQuestion`: *From the active plan (Recommended
when one exists)* / *From a topic I will type* / *Cancel*. With `--from-plan` or a `<topic>`
already given: *Proceed* / *Cancel*. Then probe with `--tier 0`; only when several plans exist
and none is active, a second `AskUserQuestion` (newest four + *Other*), then
`bash ~/.claude/bin/project-state.sh --set-active-plan <path>`.

## Step 1 — collect

```bash
f=$(mktemp "<scratchpad directory from the system prompt>/goal-state.XXXXXX.json")
bash ~/.claude/bin/project-state.sh > "$f"
```

`Read` it. Sources for the draft, in order: `goal.text` with its source, the active plan's
title, Decisions Log and status block (`plans.active.*`), the registers, and — for a typed
topic — the user's words verbatim. Nothing else.

## Step 2 — draft the brief (fixed shape)

```
## Goal
<one sentence: verb + object + the observable outcome>
In scope: <bullets — what will exist or change>
Out of scope: <bullets — what will NOT, especially the tempting adjacent things>
Done when: <numbered, each one testable by a command, a file, or an observable state>
Constraints: <rules that bound the work: files not to touch, invariants, ceilings, deadlines>
Ambiguities resolved: <each one: the question, the ruling, who ruled (user / plan decision) — never "assumed">
```

Every line cites a collector field, a `file:line`, or the user's words, or carries an
*Inferred* grade.

## Step 3 — resolve ambiguities by ruling, not by guessing

List every reading of the goal that would make two engineers build different things. For each
that changes the outcome, ask via `AskUserQuestion` (at most four per round, recommended
option first, visible escape). Ambiguities already ruled in the plan's Decisions Log are cited,
not re-asked. Ambiguities that do not change the outcome are stated as constraints, not asked.

## Step 4 — self-test, then advisor

Ask yourself, in writing: *could two engineers build different things from this brief?* If
yes, return to Step 3. Then call `advisor()` with the brief in the transcript and fold its
findings; re-call once if it changed anything.

## Step 5 — output (two parts)

Part 1 is the brief from Step 2. Part 2 is one marked line:

```
paste into /goal: <ONE checkable stop condition — the "done when" items collapsed into a
single condition Claude can verify across turns, e.g. "bash bin/tests/project-state.test.sh
prints FAIL: 0 and refs/SKILLS.md lists /progress, /next and /goal-brief">
```

The built-in `/goal [condition|clear]` works toward a condition until it is met; it does not
take a paragraph. Never write the phrase "blast radius" (say *affected surfaces*).

## `--save` (the default)

Run this unless the user passed `--no-save`. A brief that is not written down dies with the
session: of the seven `/goal-brief` runs on 2026-09-03, **none** persisted — no plan gained a
goal block and no `progress/goal.md` was written, so five of the seven left no trace at all.


Show the exact text; Rule 8 check on the target; `AskUserQuestion` *Write (Recommended)* /
*Skip*. With an active plan: `bash ~/.claude/bin/project-state.sh --init-block <plan> --kind
goal` if it has no goal markers, then `--splice-block <plan> <tmp> --kind goal`. With no plan:
`bash ~/.claude/bin/project-state.sh --write-goal <tmp>` (lands in
`projects/<root-slug>/progress/goal.md`, under the same lock).

## Certification honesty

The collector is execution-certified; this skill's drafting is a prompt, run for real on
SEVEN projects on 2026-09-03. The `~/.claude` run resolved five ambiguities, took two advisor
rounds, and re-hit the `] AGREED:` parser defect on its own Decisions Log entry. None of the
seven persisted anything, and when `--save` was finally exercised later that day it proved to
be write-only — nothing read the goal back (fixed 28d9d6ce). `--no-save` has never run. Beyond
those runs its only safeguards are the fixed shape, the ruling-not-guess rule, and the advisor
pass it mandates.
