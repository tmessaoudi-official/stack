---
name: expertise-gate
description: Use when the user wants to turn the expertise Agent gate on, off, or check it (hooks/expertise-gate.sh in settings.json). User-only; registers or removes one PreToolUse hook entry.
user-invocable: true
args: "[on|off|status]"
side-effects: "`on`/`off` rewrite ~/.claude/settings.json (backup settings.json.bak.<ts>, only when something changes; the newest 2 are kept) via bin/expertise-gate-apply.sh; `status` is read-only"
disable-model-invocation: true
---

**Front door:** `/gates-bypass bypass|arm expertise-gate WHERE` turns the gate off / back on for a scope (family `eg`); this skill's `on|off|status` is hook registration, the same script as `/gates-bypass hook expertise-gate register|unregister|status` (framework-health 4.8).

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps.
>
> ```
> /expertise-gate [on|off|status] — register, remove or check the hard Agent gate (hooks/expertise-gate.sh).
>   on      add the hook to the PreToolUse `Agent` group (idempotent)
>   off     remove it again (settings.json comes back byte-for-byte when `on` was the only change)
>   status  print "registered" | "not registered" (default)
> Per-machine: it edits the settings.json of the machine this session runs on. A cloud session changes only its own copy.
> ```

---

# /expertise-gate

The gate denies an agent that targets a project with no expertise (docs/SPEC.md §2.20). This skill only registers it; the logic lives in
`bin/lib/expertise_gate.py`. It is **user-only**: the gate's design forbids the model switching it.

## Step 1 — Guard

```bash
for f in bin/expertise-gate-apply.sh hooks/expertise-gate.sh bin/lib/expertise_gate.py; do [ -f ~/.claude/$f ] && echo "present $f" || echo "MISSING $f"; done
```

If any line says MISSING, print one line — *"the expertise gate is not installed on this machine (missing: <files>); install the global config here first. Nothing changed."* — and STOP. Do not recreate the files.

## Step 2 — Run the ONE command matching the first word of ARGUMENTS (no word = status)

```bash
bash ~/.claude/bin/expertise-gate-apply.sh on
```
```bash
bash ~/.claude/bin/expertise-gate-apply.sh off
```
```bash
bash ~/.claude/bin/expertise-gate-apply.sh status
```

Show the output unchanged. `on`/`off` need no confirmation: both are idempotent and reversible, and the script refuses (touching nothing) when a permission swap is armed, settings.json does not round-trip, or `on` would register a hook file that is missing.
Any other word: print the usage line and stop.

If the call is denied, parked or asks and is refused (settings.json is a protected path), do NOT retry or reword it: show the user `! bash ~/.claude/bin/expertise-gate-apply.sh <on|off>` and stop.

## Step 3 — Tell the user

- After `on`/`off`: running sessions keep the old hooks; restart them.
- The gate's own off-switches stay the user's: `EXPERTISE_GATE_OFF=1` at launch, or the file `~/.claude/state/expertise-gate-off` (or the family `eg` via `/gates-bypass`). Off means the gate never DENIES; it still runs in advisory mode: it appends the pack pointer or the discover command to the agent's prompt and queues an `eg` review event (docs/SPEC.md §2.20).
- Never edit `settings.json` yourself; if the script errors, show the error and stop.
