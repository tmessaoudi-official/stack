---
name: permission-swap
description: Use when arming or disarming Claude Code's native settings.json permission engine — globally (empties permissions.ask/deny via bin/permission-swap.sh) or per-project (adds a broad allow set via bin/permission-swap-project.sh) — or checking current armed state.
user-invocable: true
args: "[on|off|status [--all]|preview|--recover|--help] [--scope=global|project] [--yes]"
side-effects: "on" (project scope only; global "on" retired 2026-10-07) adds a broad allow set to the current project's .claude/settings.local.json (project) — only after explicit AskUserQuestion confirmation. "off" restores. Both write/delete sentinel files under ~/.claude/state/ or ~/.claude/projects/<slug>/state/.
disable-model-invocation: true
---

**Front door:** `/gates-bypass status` shows the legacy swap row; turning a swap off stays here (retired, off-only; framework-health 4.5).

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /permission-swap — Arm or disarm Claude Code's native settings.json permission engine.
> ```
>
> Then output the complete flag table below. Then STOP.

| Subcommand / Flag | Description |
|--------------------|-------------|
| `on` | Project scope only: arm (adds the broad allow set — confirmed via AskUserQuestion before running). Global `on` is **retired** (2026-10-07): since the 2026-09-30 cutover it would only empty the backstop denies (SPEC §2.2 "Do not arm it") |
| `off` | Disarm / restore |
| `off --yes` | Force past detected drift (confirmed via AskUserQuestion before running) |
| `status` | Show current state for the target scope (default when no args) |
| `status --all` | Project scope only — discovery scan across every project on the machine |
| `preview` | Project scope only — read-only dry run: reports how many of the added allow rules are already covered by existing allow rules vs. actually effective, plus the ask/deny rule count (global + project-shared) that will still block regardless. Arms nothing. |
| `--recover` | Repair a stuck/corrupt state |
| `--scope=global` | Target `bin/permission-swap.sh` (default) |
| `--scope=project` | Target `bin/permission-swap-project.sh` |
| `--help` | Show this help |

---

# /permission-swap [on|off|status|--recover|--help] [--scope=global|project]

Thin wrapper around `bin/permission-swap.sh` (global) and `bin/permission-swap-project.sh`
(project) — sentinel-controlled on/off for Claude Code's native `settings.json` permission
engine. `on` is safety-critical: globally it empties `permissions.ask` **and**
`permissions.deny` (removing sudo/disk-wipe/credential-store protection and every ask prompt);
per-project it adds a broad `allow` set to that project's `.claude/settings.local.json`. Neither
script's own behavior is duplicated here beyond one read-only preview — every subcommand shells
out and reports the script's own output.

**Global `on` is retired (2026-10-07)**, and so is project level total, which raises the global swap: since the
2026-09-30 permission-engine cutover the global swap only empties the backstop denies (docs/SPEC.md §2.2 "Do not
arm it"). The global text below stays so that `off`, `status` and `--recover` still explain a swap armed earlier.

**Scope resolution**: `--scope=global` is the default (no flag needed). `--scope=project`
routes every subcommand to `permission-swap-project.sh` instead.

## Pre-check: current state

Before routing, always show current state for the target scope, so the user sees it before any
action — capturing `2>&1` on both, since a corrupt sentinel reports only to stderr on either
script and would otherwise render as an unexplained blank:

```bash
if [[ "$SCOPE" == "project" ]]; then
  # status --all: cross-directory discovery, not scoped to the current directory — that's the
  # whole point of --all. Has its own 3-value exit contract (0=clean, 1=entries skipped,
  # 2=scan itself couldn't run) that must be classified, not just displayed raw.
  OUT=$(bash ~/.claude/bin/permission-swap-project.sh status --all 2>&1); RC=$?
  [[ "$RC" -eq 2 ]] && echo "⚠ project-armed scan incomplete"
  printf '%s\n' "$OUT"
else
  bash ~/.claude/bin/permission-swap.sh status 2>&1
fi
```

Then continue to routing regardless — this is informational, not a gate.

---

## Routing

- No args, or first arg is `status` (without `--all`) → **STATUS**
- First arg is `status` with `--all` → **STATUS --ALL** (project scope only)
- First arg is `preview` → **PREVIEW** (project scope only)
- First arg is `on` with global scope (the default) → **RETIRED**: print "permission-swap on --scope=global is retired: since the 2026-09-30 permission-engine cutover it only empties the backstop denies in settings.json (docs/SPEC.md §2.2). For a bypass use /gates-bypass." and stop. Run nothing.
- First arg is `on` with `--scope=project` → **ON**
- First arg is `off` → **OFF**
- First arg is `--recover` → **RECOVER**
- `--help` anywhere in args → **HELP**

---

## HELP

Print the `--help` block above verbatim and stop. Neither underlying script has a `help`
subcommand to shell out to (`main()` in both dispatches only `on|off|status|--recover`,
anything else falls to a usage-and-exit-1 default) — this section owns its own text.

---

## STATUS

```bash
if [[ "$SCOPE" == "project" ]]; then
  bash ~/.claude/bin/permission-swap-project.sh status
else
  bash ~/.claude/bin/permission-swap.sh status
fi
```

Report the output verbatim.

---

## STATUS --ALL

Reject if `--scope` is `global` or unset — `--all` only exists on the project script, and the
global script would silently ignore it rather than error:

```bash
if [[ "$SCOPE" != "project" ]]; then
  echo "--all is project-scope only; use --scope=project"
else
  OUT=$(bash ~/.claude/bin/permission-swap-project.sh status --all 2>&1); RC=$?
  [[ "$RC" -eq 2 ]] && echo "⚠ project-armed scan incomplete"
  printf '%s\n' "$OUT"
fi
```

---

## PREVIEW

Reject if `--scope` is `global` or unset — the global script has no additive rules to preview
(its `on` is unconditionally subtractive, so its own banner text already tells the whole
story), and only the project script exposes this subcommand:

```bash
if [[ "$SCOPE" != "project" ]]; then
  echo "preview is project-scope only; use --scope=project"
else
  bash ~/.claude/bin/permission-swap-project.sh preview
fi
```

Report the output verbatim. Read-only — arms nothing, writes nothing. This is the same
computation Step 3 of **ON** below shells out to for the pre-arm confirmation; invoke it
directly here to check the effective delta without going through the arm/confirm flow.

---

## ON

*Project scope only — global `on` is retired (see Routing). `off`, `status` and `--recover` still serve both scopes, so a swap armed before the retirement can still be disarmed.*

### Step 1 — short-circuit: is this scope already armed, or is the target file corrupt?

This is a **separate** call from the Pre-check above — the project Pre-check runs
`status --all` (discovery across every project), which has no per-directory signal at all. `on`
needs its own plain `status` call for whichever scope it targets:

```bash
if [[ "$SCOPE" == "project" ]]; then
  ST=$(bash ~/.claude/bin/permission-swap-project.sh status 2>&1); RC=$?
else
  ST=$(bash ~/.claude/bin/permission-swap.sh status 2>&1); RC=$?
fi
```

Classify `$ST`/`$RC` into three cases — a corrupt sentinel is neither "armed" nor "not armed"
and must not collapse into either:

- **`$ST` contains `ARMED`** (case-sensitive — `NOT armed` also contains lowercase `armed`, so
  a case-insensitive match would misfire) → already armed. **Stop here.** Report the existing
  state (`$ST`) and do not show any preview or confirmation — the script itself would refuse
  with "Already armed ... refusing to re-arm," and a preview at this point would show a
  meaningless "arm — 0 ask / 0 deny" (live rules are already empty while armed).
- **`$ST` contains `NOT armed`** → proceed to Step 2, but this alone does not mean genuinely
  unarmed — `cmd_status` only checks sentinel *absence*, never `settings.json`/
  `settings.local.json` validity.
- **Neither substring present** (non-zero `$RC`, a "fails validation" message on stderr) → the
  sentinel exists but is corrupt. **Stop here.** Tell the user to run `/permission-swap
  --recover --scope=<scope>` and do not proceed to `on`.

### Step 2 — validate the target file before previewing

Only reached when Step 1 found "NOT armed." Validate the file `on` is about to read/write, so a
corrupt file is caught here with a clear message instead of surfacing as a confusing preview
failure or an avoidable round-trip into the script's own refusal:

```bash
if [[ "$SCOPE" == "project" ]]; then
  # settings.local.json may legitimately not exist yet — only validate if present.
  if [[ -f "$PWD/.claude/settings.local.json" ]] && ! jq -e . "$PWD/.claude/settings.local.json" >/dev/null 2>&1; then
    echo "settings.local.json is not valid JSON — run /permission-swap --recover --scope=project"
    exit 0
  fi
else
  if ! jq -e . ~/.claude/settings.json >/dev/null 2>&1; then
    echo "settings.json is not valid JSON — run /permission-swap --recover"
    exit 0
  fi
fi
```

### Step 3 — preview and confirm (safety-inverted, `/gates-bypass`-style)

The global script's warning banner is only available as its *last* step, after the mutation —
so that half of the preview stays skill-authored. The project script now exposes a read-only
`preview` subcommand that runs the real effective-delta math (covered vs. effective vs. the
ask/deny rules — global and project-shared — that will still block regardless of what gets
added) without arming anything, so the project branch shells out to it instead of re-deriving
or hardcoding the numbers:

```bash
if [[ "$SCOPE" == "project" ]]; then
  PREVIEW=$(bash ~/.claude/bin/permission-swap-project.sh preview 2>&1)
else
  ASK_N=$(jq '.permissions.ask | length' ~/.claude/settings.json)
  DENY_N=$(jq '.permissions.deny | length' ~/.claude/settings.json)
  PREVIEW="Removes $ASK_N ask rule(s) and $DENY_N deny rule(s) from settings.json —
  including sudo/disk-wipe/credential-store protection."
fi
```

Then `AskUserQuestion`:

- **Header**: `Arm?`
- **Question**: `Arm permission-swap (--scope=$SCOPE)? $PREVIEW`
- **Options**:
  1. `Keep controlled, don't arm (Recommended)` — take no action, report nothing changed.
  2. `Arm — $PREVIEW` — proceed to Step 4.

Level: **project Normal only** (2026-10-07). Project Total also raises the global swap to total — the retired path —
so it is not offered; say so in one line if the user asks for it. The original two-level question, kept for reference
(2026-09-24): **Normal (Recommended)** —
global: the perm except-lists still compile into ask rules; project: only the broad `allow` set is added.
**Total** — global: zero ask / zero deny rules, except-lists ignored; project: ALSO backs up and empties
ask/deny in this project's `.claude/settings.json` + `settings.local.json` (the shared file shows as
modified in the repo meanwhile) and raises the global swap to total.

### Step 4 — invoke

Only if the user picked option 2:

```bash
# project scope only (Routing stops global `on` before this step); level normal only
bash ~/.claude/bin/permission-swap-project.sh on
```

Report the output verbatim.

### Switching the level while armed (no off/on window)

```bash
bash ~/.claude/bin/permission-swap.sh recompile --level=normal           # global: lowering an EARLIER-armed swap only
bash ~/.claude/bin/permission-swap-project.sh level normal                # project (run from its dir)
```

Raising to `total` (global `recompile --level=total`, project `level total`) is retired with global `on`: it empties
the backstop denies.

`status` shows the armed level. A project leaving total lowers the global swap only if a project raised
it and no other project is still at total (last one out).

---

## OFF

### Step 1 — run plain, capture combined output

```bash
if [[ "$SCOPE" == "project" ]]; then
  OUT=$(bash ~/.claude/bin/permission-swap-project.sh off 2>&1); RC=$?
else
  OUT=$(bash ~/.claude/bin/permission-swap.sh off 2>&1); RC=$?
fi
```

`2>&1` is required — both scripts write their drift report to stderr, not stdout.

### Step 2 — classify the result

- **`$OUT` contains `Drift detected`** (ASCII substring match, case-sensitive — not the leading
  `⚠`/`⚠️` glyph, which appears in two different Unicode forms across the scripts and could
  silently miss if they're ever swapped) → genuine drift. Show `$OUT` (the delta) and ask via
  `AskUserQuestion`:
  - **Header**: `Force?`
  - **Question**: scope-specific — global: *"Drift detected — live ask/deny doesn't match what
    was armed or the original saved rules. Force restore and discard the live (drifted) rules?"*
    project: *"Drift detected — some of the recorded allow entries are no longer present.
    Force-strip whatever recorded entries remain?"*
  - **Options**: 1. `Don't force — leave settings unchanged (Recommended)` — stop here, report
    nothing changed. 2. `Force with --yes` — proceed to Step 3.
- **`$RC` is 0** → success. Report `$OUT` verbatim.
- **`$RC` is 2** → **not a failure.** The restore already succeeded and the sentinel was already
  deleted; only the `.recovery` audit-log write failed afterward. Report as a **completed
  disarm** with the script's own warning surfaced — never as an error, never offering a retry
  (retrying would hit "not armed," since the sentinel is already gone).
- **Any other non-zero `$RC`** (no drift substring, not 2) → genuine failure. Report `$OUT`
  as-is, no confirmation prompt.

**Do not conflate `off`'s exit 2 with `status --all`'s exit 2** (Pre-check / STATUS --ALL
above) — same code, same script family, unrelated meaning. `off`: disarm completed, only the
audit log failed. `status --all`: the scan itself couldn't run, nothing was touched.

### Step 3 — re-run with `--yes`

Only if the user picked "Force" in Step 2:

```bash
if [[ "$SCOPE" == "project" ]]; then
  OUT2=$(bash ~/.claude/bin/permission-swap-project.sh off --yes 2>&1); RC2=$?
else
  OUT2=$(bash ~/.claude/bin/permission-swap.sh off --yes 2>&1); RC2=$?
fi
```

**Apply the identical exit-code classification to this second call — drift text is suppressed
on the forced run (`force=true` gates it off in both scripts), so `$RC2` is the *only* signal
here:**

- `$RC2` is 0 → report success (`$OUT2`).
- `$RC2` is 2 → report as a **completed forced disarm** with the audit-log warning surfaced,
  never as a failure.
- Any other non-zero `$RC2` → genuine failure, report `$OUT2` as-is.

---

## RECOVER

```bash
if [[ "$SCOPE" == "project" ]]; then
  bash ~/.claude/bin/permission-swap-project.sh --recover
else
  bash ~/.claude/bin/permission-swap.sh --recover
fi
```

Report the output verbatim. No confirmation — this is a repair action, not an arm.
Project scope (R3/R4): a corrupt sentinel is first copied to
`~/.claude/backups/permission-swap/<slug>/sentinel.corrupt.<ts>`; one at level TOTAL, or one that is not
valid JSON, is NOT removed — the output names the failing fields; repair them by hand, then run
`permission-swap-project.sh level normal`.
