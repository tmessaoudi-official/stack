---
name: sabotage-check
description: Use after a test goes green and before claiming a guard works — writing a sabotage/mutation check, restoring from one, or reading its result. Proves the mutation applied, parsed and reddened the RIGHT assertion, breaks the condition not just the feature, and restores byte-exact.
user-invocable: true
args: "<file-under-test> [--suite <cmd>]"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /sabotage-check — prove a test would NOTICE the guarantee breaking: mutate, run, read, restore.
>
> Usage: /sabotage-check <file-under-test> [--suite <cmd>]
>   <file-under-test>  the source file holding the guarantee (not the test)
>   --suite <cmd>      the narrowest command that runs the relevant tests (default: ask the repo's CLAUDE.md)
> ```

---

A green suite proves the code passes the tests. Only a sabotage proves the tests would *notice* the
guarantee breaking (CLAUDE.md § Per-task gate vs milestone panel, "executable evidence" bullet 3). A
sabotage fails in eight ways that each read as success or as "the guard is weak"; every step below
closes one of them. Distilled from 20 memories across 6 projects (2026-08-22 → 2026-09-27).

## When

After the GREEN run of a TDD cycle, before the Rule 6 evidence table. Also when a reviewer asks
"would the tests catch X?" — answer with a sabotage, not an argument.

## Steps

1. **Baseline through the same path.** Run the unmutated code through the exact harness you will use
   for the mutants and record its tally line (`PASS: n FAIL: 0`, `test result: ok. n passed`). A
   harness that differs from the baseline (a section runner, a different cwd, a stale build) makes
   every later comparison meaningless. Cargo: a mutant written with an OLDER mtime than the last
   build is not rebuilt — see the stack notes.

2. **Snapshot by content.** `cp <file> "$SCRATCH/<name>.good"` — plain `cp`, never `cp -a` (keeps the
   old mtime) — and record `md5sum`/`cmp` material. The snapshot lives in the session scratchpad, not
   the repo.

3. **Write the mutation with a single-occurrence assert.** Python, not sed:
   ```python
   s = open(p).read(); a = "<exact old text>"; assert s.count(a) == 1, s.count(a)
   open(p, "w").write(s.replace(a, "<mutant>"))
   ```
   No multi-line `sed`, no `\Q…\E` around `\n`, no IFS-split strings — they fail silently and leave
   the file unchanged.

4. **Prove it landed and parses.** `cmp -s good file && echo NOT-APPLIED` must print nothing, and the
   mutant must pass the language's syntax check (`bash -n`, `php -l`, `cargo check`, `tsc --noEmit`,
   `python3 -m py_compile`). A mutant that does not parse tests nothing — the suite goes red for the
   wrong reason.

5. **Run, then read the tally AND the failing assertion's name.** A missing tally or an empty section
   means the run ABORTED — that is not "caught" and not "not caught". Red is only evidence when the
   assertion that went red is the one that guards this guarantee; read the failure message, not the
   exit code (a gpg-signing or missing-fixture error also exits non-zero).

6. **Pick the mutation set by the change's shape** — one mutant per row that applies:
   | Shape | Mutant | Proves |
   |---|---|---|
   | new feature / guard | delete it | the happy-path test depends on it |
   | a condition (`if`, a filter, a regex) | **force it always-true / always-false** | the test exercises BOTH sides — deleting a feature leaves a no-op-case test green either way |
   | a bug fix | **revert the fix** alone | the regression test reproduces the original bug |
   | several sites fixed for one bug | revert **each site alone** | every site is covered, not just the first |
   | an absence assertion ("X never appears") | also add a case where X must appear | the assertion can fail at all |

7. **Self-reference check.** The string an assertion greps for must not also appear in the comment,
   doc or fixture the change introduced — otherwise the "guard" matches itself and never fails. Slice
   the assertion to the smallest expression that carries the decision. Assert the MECHANISM when an
   improvement could give the OUTCOME a second way to be satisfied.

8. **Restore by content and prove it byte-exact.** `cat "$SCRATCH/<name>.good" > <file>` (a content
   write with a fresh mtime), then `cmp "$SCRATCH/<name>.good" <file> && echo RESTORE-OK`. Never
   `git checkout -- <file>` (discards any uncommitted work in the same file), never `mv`/`cp -a`
   (old mtime → a stale build). Re-run the baseline once after the last restore.

9. **Parallel mutation needs isolation.** Reviewer agents that mutate each get their own worktree
   (`isolation: "worktree"`), and nobody edits the tree while a mutant is swapped in — a swapped file
   is live for every other process that reads it (hooks, the statusline, other sessions).

10. **Report** one line per mutant in the completion evidence:
    `mutant <n> <what> — landed ✓ parses ✓ → red: <assertion name(s)> · restore cmp ✓`
    A mutant that stayed green is a finding (the guard is weak, or the mutant was vacuous — say which,
    with the evidence), never something to drop from the report.

## Long suites

When one run takes minutes, run the mutant series in ONE background script (swap → run → restore per
mutant, `cmp` at the end) and wait for its notification — see `/long-run`. Prefer a section runner
(setup + the one relevant section) over the full suite for mutants; run the full suite once on the
final restored code.

## Stack notes

| Stack | Syntax check | Trap |
|---|---|---|
| bash | `bash -n` | a runner that greps `✗` reads an aborted suite as "not caught" — read the tally line |
| Rust / cargo | `cargo check` | mtime: write the mutant with a fresh mtime (`cat >` + `touch`), else cargo skips the rebuild; `grep 'test result\|^error'` so a non-compiling mutant is not read as red |
| PHP | `php -l` | run the suite the way CI does (docker php vs host php differ in PCRE / ini) |
| TS / Vite | `tsc --noEmit` | a dev server answers any missing path with 200 + index.html — assert a body signature |
| git fixtures | — | global `commit.gpgsign=true` makes fixture commits fail → RED for the wrong reason; pass `-c commit.gpgsign=false` |

Per-project deltas (ledger files, sabotage runners) belong in that project's `*-lenses` skill or
`.claude/rules/`, not here.

$ARGUMENTS
