---
name: aggregate-findings
spotlight: true
description: Cross-stage synthesis of mega-analysis reports — deduplicates findings that appear across audit, skill-audit, inspect, sleuth, gaps, and vision stages. Produces a prioritized master list with cross-references and removes redundant noise. Use after a mega-analysis run to get one actionable summary instead of 10 separate reports.
user-invocable: true
args: "[--run=N] [--top=N]"
side-effects: Writes consolidated report to ~/.claude/projects/meta-reports/<date>/aggregate-<date>.md
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /aggregate-findings — Cross-stage synthesis of mega-analysis reports — deduplicates findings across audit, skill-audit, inspect, sleuth, gaps, and vision stages into one prioritized master list.
> ```
>
> Then output the complete flag table from the **"Flags"** section below. Then STOP.

---

# /aggregate-findings

## When to use
Run immediately after a `/mega-analysis` run to synthesize its 10 stage outputs into one deduplicated, prioritized master list. Also useful when manually reviewing reports across multiple runs.

## Flags
- `--run=N` — target run number (default: latest run in the most recent meta-reports date dir)
- `--top=N` — show only the top N unique findings (default: all)

## Step 0 — Locate reports

```bash
TODAY=$(date +%Y-%m-%d)
REPORT_DIR="$HOME/.claude/projects/meta-reports/$TODAY"
# If today has no run, find the most recent date dir
[[ -d "$REPORT_DIR" ]] || REPORT_DIR=$(ls -d "$HOME/.claude/projects/meta-reports"/*/  2>/dev/null | sort | tail -1)
# No project slug: the stage reports are found through the run report in meta-reports/, which is not per-project.
# (A SLUG derived here was never read, and it dropped the slug's leading "-"; removed 2026-10-07.)
```

Load the full-analysis run report to identify which stage reports exist.

## Step 1 — Read all stage reports (parallel, max 5 at a time)

Identify the stage report paths from the run status table. For each stage with a ✅, read the full report. Batch into two groups of ≤5 files:

**Batch A** (analysis stages):
- audit report
- skill-audit report
- inspect (project)
- inspect (global)
- sleuth (project)

**Batch B** (gap + vision stages):
- sleuth (global)
- gaps (project)
- gaps (global)
- inspect --vision (project)
- inspect --vision (global)

Read each file and pass to Step 2.

## Step 2 — Spawn 3 synthesis agents (parallel)

Spawn exactly 3 agents with the full report content:

### Agent 1: Deduplication detector
Prompt: "You are given 10 stage reports from a mega-analysis pipeline. Your job is to identify findings that appear in 2 or more stage reports — these are the highest-confidence issues. For each cross-stage finding, list: the finding name/ID, which stages mention it, what each stage says (noting any contradictions), and a deduplicated one-sentence summary. Output as a markdown table. Only report findings that appear in ≥2 stages."

### Agent 2: Priority ranker
Prompt: "You are given 10 stage reports from a mega-analysis pipeline. Your job is to produce a single master priority list of ALL unique findings (not cross-stage-only), ranked by: (1) severity (P0/High before P1/Med), (2) fix cost (Quick before Long), (3) breadth of impact. Remove exact duplicates. Format: numbered list with severity badge, one-line description, estimated fix time, and which stage it came from. Cap at 50 entries."

### Agent 3: Quick wins extractor
Prompt: "You are given 10 stage reports from a mega-analysis pipeline. Your job is to extract all 'quick win' findings: severity P1 or higher AND fix cost ≤30 min. These are the highest-value, lowest-effort items. Output as a table: finding, stage, exact file/line, exact fix, minutes. Include at most 20 rows; rank by impact."

## Step 3 — Synthesize into consolidated report

Combine all 3 agent outputs into:

```markdown
# Aggregate Findings — <date> (run N)
Generated: <timestamp> | Stages: 10 | Raw findings: ~<N> | Unique after dedup: ~<N>

## Top 10 Cross-Stage Findings (appear in ≥2 stages — highest confidence)
[Agent 1 table]

## Quick Wins (P1+ / ≤30 min fix)
[Agent 3 table]

## Master Priority List (all unique findings, ranked)
[Agent 2 list]
```

## Step 4 — Save and report

Save to `~/.claude/projects/meta-reports/<date>/aggregate-<date>.md`.

Report to user:
- Total unique findings
- Cross-stage duplicates found and collapsed
- Top 5 quick wins
- Suggest: "Run `/aggregate-findings --top=10` to see just the highest priority items"

## Self-reflection
After saving, note any findings where the stages disagreed (e.g., one stage calls it P0, another calls it P2). Flag these as "conflicting severity" in the report.

## Subagent models

**Model ask (policy v2, every run):** resolve the mode first with `bash ~/.claude/bin/project-state.sh --tier 0 | jq -r .identity.mode` (autonomous = the ask-human gate is bypassed for this tree, else spec); with no shell, `Read` `~/.claude/state/gates-bypass-rules.json` and call it autonomous only when an unexpired rule whose `guards` include `ah` covers this directory (`global`, or `path` equal to / a recursive ancestor of it), else spec. **Spec mode:** before the first Agent call of a run, ask ONE `AskUserQuestion` that shows the whole table below in the question text, with each stored value as the recommended choice (for reviewers, the `reviewer-model` file value; in spec mode a stored value is only ever the recommended option). Shape: AskUserQuestion takes 2-4 options and cannot pre-select, so the options are keep-the-table (Recommended), one uniform alias for every agent, and a challenge escape. **Autonomous mode** (user ruling 2026-09-30, plan model-policy-bypass): do NOT ask. For each agent read its override from `~/.claude/state/model-overrides.json` (`Read` it; key = the table's Agent label as a slug: lowercase, spaces to hyphens, under `agents`, falling back to `agents."*"`; or `bash ~/.claude/bin/model-override.sh get agent <slug>`, which applies the same fallback) and use it when present (an `as-is` override means the session's model: `bash ~/.claude/bin/session-model.sh` prints its alias), else the table value below (reviewers: the `reviewer-model` file); an invalid or absent table means no overrides. Record one `ASSUMED (review): <agent> runs on <model> - source <override|table>` per agent in the active plan's Decisions Log (`bash ~/.claude/bin/project-state.sh --append-decision <active plan> ASSUMED "..."`, or edit the plan file directly when there is no shell). Both modes: pass `model:` on every Agent call, set to the answer. An orchestrator (`/mega-analysis`, `/loop --pipeline`) which already asked for this run and named the models replaces it.

Set by the model-assignment audit (decision D5, 2026-09-29; source table `projects/-home-user-.claude/model-audit/classified-all.tsv`). **Pass `model:` on every Agent call** — an omitted model inherits the session, so quality and cost would follow the `/model` choice. `opus` = judgment work, `sonnet` = detection and mapping (rubric ruled 2026-09-29).

| Agent | model | why |
|---|---|---|
| Deduplication detector | opus | judges whether two findings are the same |
| Priority ranker | opus | ranking is judgment |
| Quick-wins extractor | sonnet | filters an already-ranked list |
