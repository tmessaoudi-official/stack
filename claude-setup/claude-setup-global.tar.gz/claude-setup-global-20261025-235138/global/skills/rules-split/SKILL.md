---
name: rules-split
description: Use when a CLAUDE.md (project or /path/to/your/project) has grown too long, or when adding path-scoped rules. Prunes stale gotchas against the code, splits the survivors into .claude/rules/<area>.md with paths: frontmatter, leaves a same-name one-line index, rewrites citations as quoted anchors, adds the intake rule.
user-invocable: true
args: "[<repo-path>] [--dry-run]"
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /rules-split — prune-then-split a large CLAUDE.md into path-scoped .claude/rules/ files.
>
> Usage: /rules-split [<repo-path>] [--dry-run]
>   <repo-path>  the repo whose CLAUDE.md to split (default: the git toplevel of cwd)
>   --dry-run    stop after step 4 and print the proposed split, write nothing
> ```

---

The procedure behind the 2026-09-26 review's P1-1 ruling (prune first, then split). It exists because
the same consolidation was scheduled four times (pdfturbo, scout, invoiceninja, /path/to/your/project) and each past
one-off relocation lost or corrupted something: line citations drifted (4 of 7 were already dead), a
relocated claim contradicted its own stamp, a "deliberate omission" note post-dated the deletion.

## How Claude Code loads rules (verified 2026-09-27 against code.claude.com/docs/en/memory.md; live 2026-09-28)

- `.claude/rules/*.md` (subdirectories too) load automatically. A rule **without** `paths:` loads at
  session start, like CLAUDE.md. A rule **with** `paths:` loads only when Claude **reads** a file that
  matches — not on every tool use.
- `paths:` takes a YAML list or a comma-separated string; globs support `**` and brace expansion
  (`src/**/*.{ts,tsx}`). An invalid pattern (an unescaped `[`) matches nothing, silently.
- `~/.claude/rules/` holds personal rules for every project; user rules load before project rules and
  neither overrides the other.
- **Live probe 2026-09-28** (`claude -p --setting-sources project`, random markers): an unscoped rule was in context
  with no file read; a `paths: ["src/**"]` rule appeared only after a Read of `src/a.txt`. Second probe, same night, on
  a scratch export of scout's split: a single-segment star (`src/php/*/Cli/**`) fired on `src/php/Car/Cli/CarScout.php`,
  a bare root filename (`Dockerfile`) fired on its Read, and a scoped file whose globs matched nothing read stayed out
  (the negative control). Other shapes are certified per repo by `/context`, or by the same probe: prompt on STDIN
  (`--allowedTools` is variadic and swallows a trailing prompt), `--allowedTools Read`, markers appended to the
  rules files of a COPY, and one control file that must not appear. Ask for the start set in a SEPARATE zero-read call:
  a single prompt's "list the markers before reading" line is composed after the reads and cannot be trusted (pdfturbo,
  same night: it listed every file the reads had loaded).
- **Count loads in the probe's transcript, never by marker string** (2026-10-09): a loaded scoped rule is an entry with
  `type == "attachment"`, `attachment.type == "nested_memory"` and `attachment.path` = the rules file. A marker grep
  over-counts: the session-remember "Today" digest at SessionStart re-quotes earlier probes' markers (a control that read
  nothing matching showed the marker 3 times, all from the digest). An UNSCOPED rule is listed at session start in the
  `attachment.type == "instructions"` entry's `files[].path` (with `type` User / Project / AutoMem): read that list, never
  grep the attachment for a filename — CLAUDE.md's own index lines name the rules files and match everywhere. Same day: a USER rule's `paths:` resolves against the
  session's cwd (absolute and `~/` globs never fire; `**/*.{a,b}` and `**/Name` fire at any depth, in any project), and
  `<dir>/.claude/rules/` of a folder inside another repo (~/.claude inside $HOME) still loads for sessions at or under it.
- Verify with `/context` → **Memory files**. Re-check this section against the docs if a split does not
  load as described — it is a dated fact, not a guarantee.

**Consequence for what may move**: anything that must be in context BEFORE Claude opens a file — a
gate, a pre-flight, a destructive-command rule, a "never do X" — stays in CLAUDE.md (the 2026-04-30
passive-presence ruling). Only knowledge you need *while working in* an area moves behind `paths:`.

## Steps

1. **Preconditions.** Clean tree for CLAUDE.md and `.claude/` (Rule 8), no other session active in the
   repo, and a snapshot: `cp CLAUDE.md "$SCRATCH/CLAUDE.md.pre-split"`. Record `wc -l` and the
   `/context` token count for CLAUDE.md (the before number for the evidence table).
2. **Inventory the consumers.** Everything that greps or parses this CLAUDE.md must keep working:
   `grep -rn 'CLAUDE.md' hooks/ bin/ tests/ .claude/ scripts/ 2>/dev/null`, the project's `*-lenses` /
   reviewer skills, doc-guard or ratchet tests, and the global untouchable strings (the `3C` marker, the
   `AGREED` date prefix, `.plan.md`, the progress-block markers, `Rule N` numbering). A heading a test
   greps for does not move, or the test moves with it in the same commit.
3. **Prune before moving.** For each gotcha, dated or not, check it against the code: `grep` the
   symbol, `[ -e ]` the path, run the command. Sample first — pdfturbo's sample was 1 stale in 5. A
   note claiming an omission is deliberate gets `git log -S '<sentence>'` to date it against the
   change it explains. Stale → delete (git history keeps it); unsure → keep and mark `[Unverified]`.
4. **Group the survivors by path area** (`src/pdf/**`, `api/Modules/**/tests/**`, `docker/**`, …). An
   area needs a real glob; knowledge with no path goes to a rule without `paths:` or stays in CLAUDE.md.
   `--dry-run` stops here and prints: area → rules file → globs → moved headings → line count.
5. **Write `.claude/rules/<area>.md`** with the frontmatter, then the moved text unchanged except for
   citations:
   ```markdown
   ---
   paths:
     - "src/pdf/**"
     - "tests/pdf/**"
   ---
   ```
6. **Leave a same-name index line** in CLAUDE.md for each moved section — `## <same heading>` + one
   line: what it covers and `→ .claude/rules/<area>.md (loads when you read <glob>)`. A reader of
   CLAUDE.md still learns the knowledge exists.
7. **Citations become quoted anchors.** Replace every `CLAUDE.md:123` / `line 123` with the section
   heading plus a short quoted phrase, in both directions (docs → CLAUDE.md and CLAUDE.md → rules).
   Add or extend an anchor-resolution check if the repo has doc guards.
8. **Add the intake rule** to CLAUDE.md: new lessons go to the matching rules file, not CLAUDE.md; a
   rules file is split again or pruned past ~300 lines when path-scoped (it loads only in its area) or ~150 when
   unscoped (it loads every session, like CLAUDE.md).
9. **Verify loading and consumers.** In a fresh session in the repo: `/context` shows the unscoped
   rules at start; after reading one file per glob, the scoped rule appears. Run the repo's doc guards,
   ratchets and every consumer from step 2. Record the after numbers.
10. **One commit per repo**, by pathspec, with the before/after line and token counts in the message.

## Evidence row

`CLAUDE.md <before> → <after> lines (<tok before> → <tok after> tokens in /context) · <n> rules files ·
<k> gotchas pruned as stale (<list>) · consumers re-run: <names> ✓ · scoped load verified: <file> → <rule> ✓`

$ARGUMENTS
