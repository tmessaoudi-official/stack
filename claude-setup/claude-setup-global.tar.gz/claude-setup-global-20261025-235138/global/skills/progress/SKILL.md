---
name: progress
spotlight: true
description: Use when asked where a project stands — "where are we", "what's done", "how far along", "what's left", "what's blocked", "give me a status/progress update", a percentage, or a time estimate. Renders an evidence-tiered report from bin/project-state.sh (plan status block, git, session files, registers, test records, ledger); every line cites its source; never guesses.
user-invocable: true
args: "[--deep] [--save] [--brief] [--run-tests] [--since=<ref>]"
side-effects: Read-only by default — a run persists ONE report snapshot under ~/.claude/projects/<root-slug>/progress/reports/ (gitignored, keep-10). --save rewrites the plan's status block between its markers and refreshes handoff.md, each write shown and confirmed via AskUserQuestion first. --run-tests executes the repo adapter's test_cmd only after the exact command was shown and confirmed.
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /progress — Evidence-tiered progress report for the current project: goal, counts and a
> size-weighted percentage with its denominator, a time range with its basis, done / todo /
> blocked / needs input / needs research, certified vs claimed, fragile, known issues,
> local-only work, staleness, scope drift, environment, delta since the last report,
> relevant lessons, and ONE recommendation. Every line cites a collector field or file:line.
>
> Flags:
>   --deep           add up to 5 general-purpose agents (scope drift, critical path, fragile
>                    code, undocumented work, TODO clusters); raw output under progress/raw/
>   --save           write back: plan status block (between markers) + handoff.md — shown
>                    and confirmed first
>   --brief          ten-line version (goal, numbers, next action, blockers, warnings)
>   --run-tests      run the adapter's test_cmd (shown first) in the background and record
>                    the result under progress/tests/ — never implied by any other flag
>   --since=<ref>    also count commits since <ref>
> ```

---

# /progress — where does this project stand, with evidence

The collector `~/.claude/bin/project-state.sh` gathers the facts; this skill renders them.
**Nothing in the report may come from anywhere else.** Facts you know from the conversation
but the collector did not see are allowed only with an explicit `[Inferred: from this session]`
grade.

## Step 0 — one-tap chooser (mandatory; it is also the ask-human gate)

`ask-human-gate-block.sh` blocks EVERY Bash/Read call of a new prompt until `AskUserQuestion`
has run in that turn — so nothing runs before the chooser, not even a probe. State
*"Category: Small — read-only report"* and ask ONE `AskUserQuestion` (with flags already on
the command line: *Proceed (Recommended)* / *Cancel* only): "Which report?" —
*Tier 1 report (Recommended)* — plan block + git + session + registers + tests, seconds ·
*Deep (--deep)* — adds the agent sweep, minutes · *Tier 1 and save (--save)* · *Cancel*.

Only after that answer, probe: `bash ~/.claude/bin/project-state.sh --tier 0` and check
`.identity.active_plan == null and (.plans.candidates | length) > 1`. If so, a SECOND
`AskUserQuestion`: "Which plan?" — the newest four candidates by mtime; the auto-appended
*Other* takes a path. Then `bash ~/.claude/bin/project-state.sh --set-active-plan <path>`.

## Step 1 — collect

```bash
bash ~/.claude/bin/project-state.sh --persist [--since <ref>]
```

stdout is `report: <path>` plus `warning:` lines. **`Read` the report file** — that is the
transport (compaction-safe); do not re-run to stdout.

If the report has no active plan and no candidates, or `plans.active.has_block` is false, say
so in the first line of the report: *"No structured status for this repo — `/progress --save`
will add the block to `<plan>` (`--init-block`), or run `--deep`."* Never render an empty
report as "nothing to do".

## Step 2 — render

**Author rule:** every line cites a collector field (`progress.pct`, `staleness[0]`,
`plans.active.steps[3]`) or a `file:line`, or carries an *Inferred* / *Speculative* grade.
**Vocabulary rule:** never write the phrase "blast radius" — say *affected surfaces*
(`advisor-completion-guard.sh` blocks a final message containing both that phrase and
"coverage", and this report can echo both from plan text). Shape: report first, one-line
pointer last, no tool calls after it.

Section order (omit an empty section; keep each to its bullets):

1. **Goal** — `goal.text` with `goal.source` and grade (`claude-md` is *Inferred*).
2. **Progress** — always the denominator: *"7 of 12 steps landed (3 certified, 2 blocked);
   11 of 24 points ≈ 46 % by size"* from `progress.*`. Then the estimate: `progress.eta` as a
   range with its basis — *velocity* (`velocity.points_per_week` over `velocity.window_days`,
   from evidence-sha commit dates + ledger) or *size table* when `velocity.fallback` is true
   (say why: fewer than 4 closed items). Add the one-line caveat: unknown unknowns are not
   in the denominator. Then **what moves the number**: the next unblocked `todo` steps by
   points.
3. **Done** — `state ∈ {done, certified, confirmed}` (`confirmed` = developer re-tested, done-tier) with the evidence tier per row:
   *Executed* (`check == verified`), *Claimed* (`unverifiable`, `record-rotated`,
   `sha-not-in-clone` — name which), and the sha. A row with `disputed: true` is **Disputed**
   and is never reported as Executed however good its sha looks — the collector found a
   contradiction in that row's own evidence, and it names it in `staleness[]`.
4. **Todo** — sized, critical path first (a step whose Files overlap many others, or that
   others name, goes first; say *Inferred* if it is judgment).
5. **Blocked / Needs input / Needs research** — from `plans.active.sections.*`; needs input
   also lists `plans.active.decisions` anomalies and any step whose Evidence is a pending
   ruling, plus every `plans.active.decisions.assumed[]` entry (`ts` + `text`, verbatim): picks
   Claude made alone in autonomous mode, not rulings, until the user rewrites the bullet to
   `AGREED (ratified ASSUMED): …` or `REJECTED: …` (CLAUDE.md § Mode). Entries are written with
   `bash ~/.claude/bin/project-state.sh --append-decision [<plan>] <AGREED|ASSUMED> "<text>"`,
   which stamps from the clock and appends at the end of the log — never hand-type a stamp.
6. **Certified vs claimed** — `progress.steps_certified` of the certified rows; the latest
   test record (`tests.latest`: sha, date, cmd, status) and `tests.commits_since` it; a green
   from a targeted command is never reported as a full-suite green — name the command.
7. **Fragile / Known issues** — `sections.fragile`, `sections.known_issues`, and the
   `registers[]` counts; each known issue with its deferral reason when the plan gives one
   (ruled / blocked / backlog / unknown).
8. **Local-only work** — `git.dirty` (with ages), `git.ahead`, `git.stashes`,
   `git.worktrees > 1`. Unpushed commits are a finding, not a footnote.
9. **Staleness and contradictions** — every `staleness[]` entry in plain words
   (`evidence-untouched-files`: "step N claims sha X, which touched none of its files";
   `handoff-behind-commits`; `decision-timestamp-after-mtime`: "a ruling is stamped later
   than the file was written — verify it was ratified"), plus `session.handoff.consumed`.
10. **Scope drift** (`--deep` only) — landed work no plan mentions; plan steps untouched for
    weeks (`evidence_ts` and `git.commits_by_day`).
11. **Environment** — `env.requires[]` missing tools; `env.lean.active` (skills and memory
    suspended; `/next` unavailable unless kept).
12. **Delta since last report** — `delta.*`: steps changed, steps renumbered, warnings
    new/cleared, progress before → after, commits since the baseline. A row whose number is
    reused appears under `steps_renumbered`, never under `steps_changed` — the collector
    cannot tell a reworded step from a replaced one, so it never claims identity. When such a
    row also carries `change` (`"todo→done"`), report BOTH and say it is ambiguous: *"row N:
    text changed and state todo→done — the step may have advanced after a reword, or different
    work may have replaced it; check the plan."* Never render it as progress, and never drop
    the transition. A rename with no state change carries no `change` key at all. Say "first
    report, no baseline" when null.
13. **Relevant lessons** — `memory.matches[]` verbatim, one line each.
14. **Recommendation** — exactly one next action, why it, the alternative, and the first
    three files to read. Effort in the size table's terms.
15. **Warnings** — `warnings[]` verbatim. Never drop one. A `liveness probe failed` warning (the
    adapter's `probe_cmd`, `env.probe`) means the running deployment is not what the plan's
    percentage implies — state it before the percentage, not after.

`--brief`: goal, the progress line, the estimate, the recommendation, blockers, warnings.

## Step 3 — `--deep`

Spawn ≤ 5 **general-purpose** agents (Explore cannot Write — CLAUDE.md Rule 4), unnamed, in
one message, each told to write its findings to
`<progress_dir>/raw/<lens>.md` and return at most ten lines. The five `<lens>` slugs are
fixed — `scope-drift`, `critical-path`, `fragile`, `undocumented`, `todo-clusters` — because
`/next --deep` reads them back by name; a sweep that invented `fragile-code.md` and
`undocumented-work.md` (scout, 2026-09-03) left two lenses unreadable. Lenses: scope drift, critical
path and dependencies, fragile code (do-not-simplify sites, Chesterton fences), undocumented
work, TODO clusters. Tell the user the sweep takes minutes before spawning. Merge their
returns into sections 4, 7 and 10 with `[Inferred: deep sweep, raw/<lens>.md]`.

## Step 4 — `--save`

1. Build the new status block from the report: states may only move **up with evidence**
   (`todo → done` needs a sha in the Evidence cell; `done → certified` needs a `test:<date>`
   ref whose record exists). Never invent a sha. Keep every row and column; add rows only for
   work the collector saw land (`--deep` findings) and say so in the Step cell.
   **The `Files` cell is space-separated globs**, and a trailing comma is stripped, so
   `a/**, b/**` works too. Never "fix" an `evidence-untouched-files` flag by narrowing the
   Files cell until it matches — check the sha first; the flag may be about the sha.
2. Write it to a temp file; read the current block with
   `bash ~/.claude/bin/project-state.sh --get-block <plan>` and diff against that — never
   hand-roll the extractor, a naive sed range picks up the schema example plans quote in a
   fenced block; Rule 8 check on the plan file (`git status --porcelain -- <plan>`); `AskUserQuestion` — *Write block + handoff
   (Recommended)* / *Block only* / *Skip*.
3. On approval: `--init-block <plan>` first if `has_block` is false, then
   `--splice-block <plan> <tmp>`; then write a fresh handoff (the `/handoff` format) to a
   temp file and `--refresh-handoff <tmp>` — it carries the progress-save line, not the manual
   marker, so the stop hook may still replace it later. **`--refresh-handoff` exits 3 and
   prints `skipped:` when the existing handoff is already stamped `<!-- manual -->`** — a
   human wrote it, and it is left untouched. That is a success, not a failure: report the
   skip, do not retry and do not force. Re-run `/progress --save` after the manual handoff is
   consumed at the next SessionStart if you still want the snapshot. `--save` is a snapshot, `/handoff` is
   the session-end statement. **Verify the handoff actually changed** (it carries the
   `<!-- written by /progress --save -->` line): across all seven projects swept on
   2026-09-03 not one handoff carried it, so the block was saved and the handoff left stale.

## `--run-tests`

Show the adapter's exact `test_cmd` (`identity.adapter`) in an `AskUserQuestion` — the adapter
travels in project bundles, so a cloned repo controls that string. On approval run
`bash ~/.claude/bin/project-state.sh --record-test --timeout <N>` **in the background**
(`run_in_background`), and make **no other Bash call until its completion notification** — a
timed-out Bash call SIGTERMs the whole process group and would kill the run (Rule 15). The
record names the command; render it as such.

## Certification honesty

The collector is execution-certified (`bin/tests/project-state.test.sh`, sabotage-checked;
the suite's summary line is the count). This rendering is a prompt, certified only by
invocation: `--brief` on `~/.claude` on 2026-09-02, then `--deep --save` across SEVEN projects
on 2026-09-03. The first `--deep` run found nine collector write-path defects and its `--save`
corrupted the plan twice before a fence-aware extractor was used; the seven-project sweep then
exposed nested-project plan contamination, a ruling parser hiding 107 rulings, and rows the
report contradicted itself about. `--run-tests` was first exercised on 2026-09-03 (`bash
bin/run-tests.sh`, 26 suites, 0 fail, 163 s, recorded at `0b41f223`); the run exposed nothing in
the flag itself but showed that a `test:<date>` ref resolves to the newest record of that date,
so a same-day re-run silently re-points every row that cites it. `--since=<ref>` has still never
been exercised. When the report is challenged, the collector's JSON is
the arbiter — point at the field.

## Subagent models

**Model ask (policy v2, every run):** resolve the mode first with `bash ~/.claude/bin/project-state.sh --tier 0 | jq -r .identity.mode` (autonomous = the ask-human gate is bypassed for this tree, else spec); with no shell, `Read` `~/.claude/state/gates-bypass-rules.json` and call it autonomous only when an unexpired rule whose `guards` include `ah` covers this directory (`global`, or `path` equal to / a recursive ancestor of it), else spec. **Spec mode:** before the first Agent call of a run, ask ONE `AskUserQuestion` that shows the whole table below in the question text, with each stored value as the recommended choice (for reviewers, the `reviewer-model` file value; in spec mode a stored value is only ever the recommended option). Shape: AskUserQuestion takes 2-4 options and cannot pre-select, so the options are keep-the-table (Recommended), one uniform alias for every agent, and a challenge escape. **Autonomous mode** (user ruling 2026-09-30, plan model-policy-bypass): do NOT ask. For each agent read its override from `~/.claude/state/model-overrides.json` (`Read` it; key = the table's Agent label as a slug: lowercase, spaces to hyphens, under `agents`, falling back to `agents."*"`; or `bash ~/.claude/bin/model-override.sh get agent <slug>`, which applies the same fallback) and use it when present (an `as-is` override means the session's model: `bash ~/.claude/bin/session-model.sh` prints its alias), else the table value below (reviewers: the `reviewer-model` file); an invalid or absent table means no overrides. Record one `ASSUMED (review): <agent> runs on <model> - source <override|table>` per agent in the active plan's Decisions Log (`bash ~/.claude/bin/project-state.sh --append-decision <active plan> ASSUMED "..."`, or edit the plan file directly when there is no shell). Both modes: pass `model:` on every Agent call, set to the answer. An orchestrator (`/mega-analysis`, `/loop --pipeline`) which already asked for this run and named the models replaces it.

Set by the model-assignment audit (decision D5, 2026-09-29; source table `projects/-home-user-.claude/model-audit/classified-all.tsv`). **Pass `model:` on every Agent call** — an omitted model inherits the session, so quality and cost would follow the `/model` choice. `opus` = judgment work, `sonnet` = detection and mapping (rubric ruled 2026-09-29).

| Agent | model | why |
|---|---|---|
| `--deep` lens agents (up to 5: scope-drift, critical-path, fragile, undocumented, todo-clusters) | sonnet | evidence gathering; every line still cites its source |
