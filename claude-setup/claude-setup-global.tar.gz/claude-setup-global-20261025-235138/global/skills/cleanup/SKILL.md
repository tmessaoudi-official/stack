---
name: cleanup
spotlight: true
description: Use when cleaning up ephemeral Claude Code temp files: session-remember artifacts, stale backups, old logs, orphaned project entries, old JSONLs, session UUID dirs, paste-cache files, plans, specs, bundles, raw analysis outputs, session-env dirs, file-history, tasks, IDE locks, run files, team session dirs, telemetry spool files, and daemon PID sessions.
user-invocable: true
disable-model-invocation: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /cleanup — Safe ephemeral-file cleanup for Claude Code config directories (session-remember artifacts, stale backups, old logs, orphaned project entries, old JSONLs, session UUID dirs, paste-cache files).
> ```
>
> Then output the complete flag table from the **"Safe defaults"** section below. Then STOP.

---

Safe ephemeral-file cleanup for Claude Code config directories.

Identifies and optionally removes:
- **sr-tmp**: `/tmp/sr-*` session-remember mktemp artifacts older than 60 minutes; `/tmp/sr-test-*` dirs (a test HOME a session-remember suite leaves when it aborts before its teardown); `/tmp/claude-export-*` staging dirs left by interrupted bundle runs
- **plugin-tmp**: `~/.claude/plugins/*.json.tmp.<id>` files (top level only) older than 24 h — Claude Code writes `plugins/<name>.json` through a tmp file and a rename, and an interrupted write leaves the tmp file behind for good
- **snapshots**: `~/.claude/shell-snapshots/` files older than 7 days
- **backups**: `*.bak.<timestamp>` and `*.backup.<timestamp>` files, keeping the 10 newest per
  base file (`_CC_BACKUP_KEEP`), and tagged installer pre-images `*.bak.<tag>-<timestamp>` (gbask, egprot,
  sppr, pshadow, perm), keeping the 2 newest per file + tag; "newest" is by the timestamp in the NAME, and the copy
  the installer's `--rollback` would pick is always kept, with its `.post` (`bin/lib/bak_prune.py`); scans
  `~/.claude` at unbounded depth (never `/path/to/your/project` — 2026-08-30 policy, reverted from an earlier `/path/to/your/project`-inclusive
  design), skipping `state/`, `backups/rule8/` and `backups/install/`. A plain `<file>.bak.<epoch>` may be the user's
  own copy: only the keep-10 rule here ever lists it, and the daily `--auto` sweep never touches it
- **claude-bak**: Claude-made copies `<path>.claude-bak.<epoch>` (file or dir, beside the original or, for a skills/rules/agents/commands entry, under `backups/claude-bak/`; `bin/claude-bak.sh` names them — the
  marker is the only proof of who made a copy) older than 30 days by the epoch in the NAME, under `~/.claude` only;
  `state/`, `backups/rule8/` and `backups/install/` are never entered; a future epoch is kept (row 26zc)
- **rule8**: the Rule 8 store `~/.claude/backups/rule8/<session>/` (copies `hooks/backup-before-write.sh` makes of
  non-git files): copy dirs older than 14 days by the time in their name; a session whose copies are all old goes
  whole. `--rule8` runs only this scan; `--session=<id>` lists every copy of one session — the Phase 8 offer (dry
  run first; `--apply` only after the user says yes)
- **install**: the install store `~/.claude/backups/install/<epoch>-<name>-XXXX/` (what `/install`, `/bootstrap
  --force`, claude-adapt and claude-import overwrote) and parked import bundles `~/.claude-bundle-<epoch>`: listed
  once older than 14 days by the epoch in their name; `ledger.tsv` and unrecognised names are kept
- **logs** (opt-in with `--logs`): `~/.claude/logs/*.log` files larger than 500 KB are size-rotated (keeps 3 rotations: `hooks-errors.log`, `hooks-errors.log.1`, `hooks-errors.log.2`, oldest deleted); `~/.claude/logs/edits/YYYYMMDD.txt` daily files older than 30 days are deleted
- **reports** (opt-in with `--reports`): analysis report `.md` files in `inspections/`, `sleuth/`, `gaps/`, `visions/`, `audits/`, `repairs/`, and `meta-reports/`, scanned at **exactly 3 levels deep** under a project slug (deeper-nested report dirs are invisible to this flag); the **3 newest live reports per directory are always kept** (`_CC_REPORTS_KEEP`) — old ones are **moved to `<project>/archive/<type>/`** (not deleted) — preserves mega-analysis delta history; archive dirs themselves are pruned to 10 newest (`_CC_ARCHIVE_KEEP`) to prevent unbounded growth; add `--purge` to permanently delete instead
- **orphaned** (opt-in with `--orphaned`): `~/.claude/projects/` entries whose source dir is gone or was a temp path:
  - `test-artifact` (slug matches `-tmp-tmp.*`): entire dir deleted
  - `system-temp` (source-path in `/tmp/` or `/var/tmp/`, or slug starts with `-tmp-`): entire dir deleted
  - `orphaned` (source-path recorded but dir no longer exists): JSONLs deleted, `memory/` preserved
- **jsonl** (opt-in with `--jsonl`): old session transcript `.jsonl` files in live projects older than N days (default 30); active session is always protected
- **sessions** (opt-in with `--sessions`): per-conversation UUID artifact dirs (`~/.claude/projects/<slug>/<UUID>/`) older than N days (default 60); each dir contains `subagents/` and `tool-results/` from one conversation and can reach 75+ MB; active session protected via `last-save.json`
- **paste** (opt-in with `--paste`): files in `~/.claude/paste-cache/` older than N days (same threshold as `--sessions`, default 60); no native retention policy exists
- **plans** (opt-in with `--plans`): Rule 17 plan files in two locations — `~/docs/plans/*.plan.md` (repo-local) and `~/.claude/projects/*/plans/*.plan.md` (global, hybrid plan-location sentinel); always `--dry-run` first and confirm each task is complete before `--apply`
- **native-plans** (opt-in with `--native-plans`): Claude Code's OWN plan-mode artifacts in `~/.claude/plans/*.md` (codename files + agent variants) — distinct from Rule 17 `*.plan.md`; deletes files older than N days (default 30, tune with `--native-plans-days=N`)
- **specs** (opt-in with `--specs`): `~/.claude/docs/specs/*.md` design spec documents; review before deleting — specs often inform future decisions
- **bundles** (opt-in with `--bundles`): `claude-setup-*.tar.gz` archives (and `.sha256` sidecars) left by `/bundle` runs, scanned in `~/` and `~/.claude/` only (never `/path/to/your/project` — 2026-08-30 policy; a deployment destination holding one canonical artifact isn't a delete-all-unconditionally target); safe to delete (re-run `/bundle` to regenerate)
- **raw** (opt-in with `--raw`): pipeline-intermediate dirs named `raw`, `raw-*`, or `*-raw` anywhere 2–4 levels under a project slug — covers the canonical `*/sleuth/raw*/` `*/gaps/raw*/` `*/inspections/raw*/` `*/audits/raw*/` shapes as well as non-canonical producers (`forge/raw`, `visions/raw`, `parity-review/raw`, `feasibility-*/raw`, `meta-reports/*/raw`, `review-aggregate-raw`, `reviews/<date>-raw`) — the dir-name pattern itself is the guard, not a fixed path/producer whitelist
- **session-env** (opt-in with `--session-env`): `~/.claude/session-env/<UUID>/` **directories** (F-3.1, 2026-08-30 — was a dead `-type f` check against a directory-only tree, matched 0/3177 entries ever) — one per session (pid, cwd, status); accumulate unboundedly; prunes by `--session-days` threshold
- **file-history** (opt-in with `--file-history`): `~/.claude/file-history/<UUID>/` dirs — versioned file content per conversation; can reach 10-12MB per dir; prunes by `--session-days` threshold
- **tasks** (opt-in with `--tasks`): `~/.claude/tasks/session-<hex>/` dirs (F-3.2, 2026-08-30 — was a UUID regex against a `session-<hex>`-only tree, matched 0/93 entries ever) — TaskCreate/Update state per conversation; `pins.json` and non-`session-*` app dirs never touched; prunes by `--session-days` threshold
- **ide-locks** (opt-in with `--ide-locks`): `~/.claude/ide/*.lock` files — one per IDE connection; stale when IDE disconnects; removes only locks whose PID is no longer running
- **run-files** (opt-in with `--run-files`): twelve per-session families in `~/.claude/run/` — `session-cwd-<sid>.txt`, `status-context-<sid>.txt`, `status-banner-<sid>.txt`, `actual-window-<sid>.txt`, `ctx-notified-<sid>.txt` (banner/stop hooks), `touched-files-<sid>.txt` (backup-before-write's per-session Edit/Write list) the suffix-less `permission-mode-<sid>` (written every Stop/PostToolUse for the `⚠⚠⚠ BYPASS` statusline segment), `session-model-<sid>` (bin/session-model.sh's cache, dot-prefixed temp included), `advisor-last-<sid>` (the statusline's advisor segment) and the keep-going guard's `keep-going-count-<sid>`, `keep-going-stopask-<sid>`, `keep-going-noask-<sid>` (never the `keep-going-<sid>` enable) — **plus** (F-3.4, 2026-08-30) four dot-prefixed mktemp leftovers from the statusline scripts that used a different naming convention entirely: `.actual-window.*`, `.status-banner.*`, `.status-agents.*`, `.status-ctx.*` (66 found on the machine that surfaced this, oldest 2+ months); accumulate unboundedly; threshold 1440min (24h) matches the banner's own self-clean, which reaps five of the twelve named families (not session-model, advisor-last, actual-window, ctx-notified, the keep-going three) (a live session refreshes its files on every tool call); sessions idle >1440min will lose their CWD anchor (stop hook degrades gracefully). Stale `<family>-bypass-<sid>` gate-bypass markers (all 6 families — see `/gates-bypass`) are **reported `[protected]`, never deleted** (ask-gated self-mod path — `rm` them by hand); `active-plan-<sid>` pointers are left to the banner (reaped only when the target plan is gone)
- **history** (opt-in with `--history`): reports `~/.claude/history.jsonl` size and warns if it exceeds ~2MB; **informational only — never auto-deleted** (truncating breaks `--resume`); manual rotation command is printed when oversized
- **jobs** (opt-in with `--jobs`): reports `~/.claude/jobs/` directory size and warns if it exceeds ~100MB, and lists `jobs/<id>/tmp/` (a background session's temp dir) once the job is `done` for 1 day or idle for 7 days; `state.json` and `timeline.jsonl` (the job record) are never listed
- **teams** (opt-in with `--teams`, new 2026-08-30): `~/.claude/teams/session-<hex>/` dirs — per-session team-mode config; no reaper existed before this; prunes by `--session-days` threshold
- **telemetry** (opt-in with `--telemetry`, new 2026-08-30): `~/.claude/telemetry/1p_failed_events.*.json` — failed analytics-event spool files; prunes by `--jsonl-days` threshold
- **pid-sessions** (opt-in with `--pid-sessions`, new 2026-08-30): `~/.claude/sessions/<pid>.json` and `<pid>.<sha>.key` — per-process daemon session state; PID-liveness check like `--ide-locks`, removes only entries whose PID is no longer running

**Default mode is `--dry-run`** — shows what would be changed without touching files.
Run with `--apply` to act (ask-tier permission, prompts in Claude Code).

**The daily safe sweep `--auto`** (row 26zc, AGREED 2026-10-16): `session-start-banner.sh` launches
`claude-cleanup.sh --auto` detached on every main-session start; it runs at most once per 24 h
(`~/.claude/run/cleanup-auto.stamp`, written after a completed sweep, and a `flock` on `cleanup-auto.lock`) and
DELETES only: `/tmp/sr-test-*` + `/tmp/claude-export-*` dirs older than 60 min, `plugins/*.json.tmp.*` older than
24 h, shell snapshots older than 7 days, the `jobs/<id>/tmp/` dirs `--jobs` lists, and **claude-bak** copies older
than 30 days, and the `run/` caches older than 24 h (`keep-going-{count,stopask,noask}-*`, `advisor-last-*`,
`session-model-*` and its `.session-model-*` temp — C-P2-1, AGREED 2026-10-16 19:03). Nothing else — never a plain
`.bak` copy, `/tmp/sr-*` files, `state/`, the Rule 8 or install store, any other `run/` file (no other `--run-files`
family, no enable, no bypass marker), transcripts. `--auto --dry-run` previews it (no gate, no stamp); `--auto` takes no other flag (exit 2).
`CLAUDE_CLEANUP_AUTO_OFF=1` in Claude Code's environment turns it off. Deletions are logged at INFO in
`~/.claude/logs/hooks-errors.log` (`claude-cleanup | auto: …`). A delete that fails (in any mode) is shown as
`[failed]`, logged at ERROR (`could not delete: …`) and skipped: the run goes on, `--auto` still writes its stamp,
the next run retries it, and the exit code is 1 (row 26zn).

```
~/.claude/bin/claude-cleanup.sh [--dry-run] [--apply] [--logs] [--reports] [--purge]
                                 [--orphaned] [--jsonl] [--jsonl-days=N]
                                 [--sessions] [--session-days=N] [--paste] [--verbose]
                                 [--plans] [--native-plans] [--native-plans-days=N]
                                 [--specs] [--bundles] [--raw] [--run-files]
                                 [--session-env] [--file-history] [--tasks] [--ide-locks]
                                 [--history] [--jobs] [--teams] [--telemetry] [--pid-sessions]
                                 [--scope=global|project|all] [--project=<slug>|all]
~/.claude/bin/claude-cleanup.sh --auto [--dry-run]
```

## What is NOT touched

- `/path/to/your/project` (or any other project/repo outside `~/.claude`) — never scanned by any category, including `--reports`/`--orphaned`/`--jsonl`/`--sessions`/`--raw`; 2026-08-30 policy, after a prior `--bundles`/`--backups` design briefly reached into `/path/to/your/project`
- `~/.claude/projects/*/memory/` — session-remember summaries and handoff notes (unless `--orphaned` targets a temp/test-artifact entry)
- `~/.claude/settings.json`, `CLAUDE.md`, hooks, commands — config files
- Any `/tmp/sr-*` file written in the last 60 minutes, and any `/tmp/sr-test-*` dir with anything inside it written in the last 60 minutes (active session / running suite protection)
- `~/.claude/plugins/*.json.tmp.*` younger than 24 h (a write may be in flight), anything below the top level of `plugins/`, and every real `plugins/*.json`
- `*.bak.php`, `*.bak.sh` etc. — non-timestamped `.bak.*` files (not cleanup backups)
- Active session JSONL (detected from `last-save.json` — always protected even with `--jsonl`)
- Active session UUID dir (detected from `last-save.json` — always protected even with `--sessions`)
- `~/.claude/run/{session-cwd-*.txt,status-context-*.txt,status-banner-*.txt,permission-mode-*}` written in the last 1440 minutes (24h); `--run-files` only targets files older than 1440min — matches banner self-clean threshold
- `~/.claude/run/*-bypass-*` per-session gate-bypass markers (all 6 families) and `active-plan-*` pointers — never deleted by `--run-files` (reported `[protected]` / left to the banner)
- `~/.claude/llm-sandbox/` — session-remember LLM call sandbox; its JSONLs are prunable with `--jsonl`
- Any path containing `/state/` — bypass/autonomous sentinels are a structural guard in `_cc_act`/`_cc_act_dir` (reported `[protected]`), independent of which flag would otherwise match it

## Usage in Claude Code

Ask Claude to run it:

```
Run ~/.claude/bin/claude-cleanup.sh --dry-run
Run ~/.claude/bin/claude-cleanup.sh --apply
Run ~/.claude/bin/claude-cleanup.sh --apply --logs
Run ~/.claude/bin/claude-cleanup.sh --apply --reports
Run ~/.claude/bin/claude-cleanup.sh --dry-run --orphaned --jsonl
Run ~/.claude/bin/claude-cleanup.sh --apply --orphaned --jsonl --jsonl-days=60
Run ~/.claude/bin/claude-cleanup.sh --dry-run --sessions --paste
Run ~/.claude/bin/claude-cleanup.sh --apply --sessions --session-days=90 --paste
Run ~/.claude/bin/claude-cleanup.sh --dry-run --plans --specs --bundles --raw
Run ~/.claude/bin/claude-cleanup.sh --apply --bundles --raw
```

Or ask directly: *"Clean up old Claude temp files"* — Claude will invoke `--dry-run` first
and show you the plan before asking to apply.

## Safe defaults

| Flag | Behavior |
|------|---------|
| (no flags) | Same as `--dry-run` — show what would change without touching files |
| `--dry-run` | Explicit dry-run (same as no flags; useful for scripting clarity) |
| `--apply` | Act on identified files |
| `--auto` | The daily safe sweep (the SessionStart banner launches it; at most once per 24 h): deletes only the ruled classes — see "The daily safe sweep" above; `--auto --dry-run` previews it; no other flag combines with it |
| `--rule8` | Only the Rule 8 store `~/.claude/backups/rule8/` (copy dirs older than 14 days, by the time in their name) |
| `--session=<id>` | Only that session's Rule 8 copies — the Phase 8 offer: list (dry run), then `--apply` after the user says yes; implies `--rule8` |
| `--logs` | Size-rotate `~/.claude/logs/*.log` files >500KB (keep 3); prune `logs/edits/` files >30 days |
| `--reports` | Include analysis reports scan — archives old ones (off by default); also prunes archive dirs to 10 newest |
| `--purge` | With `--reports`: permanently delete instead of archiving |
| `--orphaned` | Delete temp/test-artifact project entries; delete JSONLs from orphaned entries |
| `--jsonl` | Prune old session transcripts from live projects (default: >30 days) |
| `--jsonl-days=N` | Age threshold for `--jsonl` (default: 30 days) |
| `--sessions` | Prune per-conversation UUID artifact dirs (default: >60 days); active session always protected |
| `--session-days=N` | Age threshold for `--sessions` (default: 60 days) |
| `--paste` | Prune `~/.claude/paste-cache/` files older than `--session-days` threshold |
| `--verbose` | Show every kept file alongside actions |
| `--plans` | List Rule 17 plan files from both `~/docs/plans/*.plan.md` (repo-local) and `~/.claude/projects/*/plans/*.plan.md` (global); always review before `--apply` |
| `--native-plans` | Prune Claude Code native plan-mode files `~/.claude/plans/*.md` older than N days (default 30) |
| `--native-plans-days=N` | Age threshold for `--native-plans` (default: 30 days) |
| `--specs` | List `~/.claude/docs/specs/*.md` — design spec documents |
| `--bundles` | List `~/claude-setup-*.tar.gz` bundle archives |
| `--raw` | List `raw`/`raw-*`/`*-raw` pipeline intermediate dirs, 2–4 levels under a project slug (canonical + non-canonical producers) |
| `--run-files` | Prune `~/.claude/run/` per-session files >1440 min (24h) old — `session-cwd-*.txt`, `status-context-*.txt`, `status-banner-*.txt`, `permission-mode-*`, `touched-files-*.txt`, `actual-window-*.txt`, `ctx-notified-*.txt`, `session-model-*`, `advisor-last-*`, `keep-going-{count,stopask,noask}-*`; stale `*-bypass-*` gate-bypass markers (all 6 families) reported `[protected]`, never deleted |
| `--history` | Report `~/.claude/history.jsonl` size (warn if >~2MB); informational only — never auto-deleted (truncating breaks `--resume`) |
| `--jobs` | Report `~/.claude/jobs/` size (warn if >~100MB); list `jobs/<id>/tmp/` of jobs done 1+ d or idle 7+ d (job record kept) |
| `--session-env` | Prune `~/.claude/session-env/<UUID>` session metadata files older than `--session-days` |
| `--file-history` | Prune `~/.claude/file-history/<UUID>/` dirs older than `--session-days` |
| `--tasks` | Prune `~/.claude/tasks/<UUID>/` dirs older than `--session-days`; UUID dirs only |
| `--ide-locks` | Remove `~/.claude/ide/*.lock` files whose PID is no longer running |
| `--teams` | Prune `~/.claude/teams/session-<hex>/` dirs older than `--session-days` |
| `--telemetry` | Prune `~/.claude/telemetry/1p_failed_events.*.json` older than `--jsonl-days` |
| `--pid-sessions` | Remove `~/.claude/sessions/<pid>.{json,key}` whose PID is no longer running |
| `--scope=global\|project\|all` | Filter artifact layer: `global` = infra only (tmp/plugin-tmp/snapshots/backups/logs/paste/specs/bundles/plans/native-plans/history/jobs); `project` = per-slug data only (reports/orphaned/jsonl/sessions/raw); `all` (default) = both layers. Accept `both` as synonym for `all`. |
| `--project=<slug>\|all` | Restrict project-layer scans to a specific slug (e.g. `-stack-projects-foo`); only affects project-layer categories (reports/orphaned/jsonl/sessions/raw); `all` (default) = all slugs. Combines with `--scope=project` for targeted cleanup of one project's data. |

## Scope × project mapping

| Category | Layer | `--project` filterable |
|----------|-------|----------------------|
| tmp, plugin-tmp, snapshots, backups, rule8, install, logs, paste, specs, bundles, plans, native-plans, run-files, session-env, file-history, tasks, ide-locks, history, jobs, teams, telemetry, pid-sessions | `global` | no |
| reports, orphaned, jsonl, sessions, raw | `project` | yes |

## Tests

```bash
bash ~/.claude/bin/run-tests.sh
```
