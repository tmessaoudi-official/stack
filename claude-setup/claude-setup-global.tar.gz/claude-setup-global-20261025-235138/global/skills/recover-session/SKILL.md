---
name: recover-session
description: Use when resuming after a PC freeze, reboot, killed terminal, or a subagent cut off by rate limits/timeouts — BEFORE editing anything. Snapshots uncommitted work three ways, then salvages lost scratchpad content (drafted files, commit messages, agent reports) from the dead session's .jsonl transcript.
user-invocable: true
args: "[<repo-path>] [--session <id>]"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /recover-session — make a crashed session's work unlosable, then salvage what /tmp lost.
>
> Usage: /recover-session [<repo-path>] [--session <id>]
>   <repo-path>     the repo the dead session worked in (default: the git toplevel of cwd)
>   --session <id>  the dead session's id when known (default: found by mtime + cwd)
> ```

---

On 2026-09-26 a PC freeze hit three concurrent sessions and each re-derived the same recovery by hand.
A reboot wipes `/tmp` — every scratchpad, drafted commit message and gate log — while the dead
session's transcript under `~/.claude/projects/` survives and still holds every Write input and every
command it composed. Order matters: **snapshot first, salvage second, edit last.**

## Signals that you are resuming a crash

`/next` checks the first one (its Step 2 "Crash check"): the machine rebooted AFTER the previous
session's last transcript write (`uptime -s` newer than that `.jsonl`'s mtime) while the tree is
dirty; a scratchpad path the plan or handoff names no longer exists; a subagent's notification never
arrived. Not a signal on its own: an empty handoff (`session.handoff.consumed`) — the SessionStart hook
consumes it on every normal start.

## 1. Touch nothing — look

```bash
git -C "$REPO" status --porcelain
ls "$REPO/.git/MERGE_HEAD" "$REPO/.git/REBASE_HEAD" "$REPO/.git/CHERRY_PICK_HEAD" 2>/dev/null
```
An in-progress merge/rebase/cherry-pick doubles the blast radius of every later git command
(BLAST-RADIUS.md § Git state gate) — report it, do not resolve it here.

## 2. Snapshot three ways (none of them changes the tree)

```bash
ts=$(date +%Y%m%dT%H%M%S)
D="$REPO/var/claude/recovery"
git -C "$REPO" check-ignore -q "$D/probe" || D="$SCRATCH/recovery"   # never leave untracked noise a later `git add -A` sweeps in
mkdir -p "$D"
git -C "$REPO" --no-pager -c core.pager=cat diff --no-ext-diff HEAD > "$D/wip-$ts.patch"   # --no-ext-diff: difftastic output is not a patch
git -C "$REPO" ls-files --others --exclude-standard -z | (cd "$REPO" && tar czf "$D/wip-untracked-$ts.tgz" --null -T -)
sha=$(git -C "$REPO" stash create)
[[ -n "$sha" ]] && git -C "$REPO" update-ref "refs/recovery/wip-$ts" "$sha"   # stash create prints NOTHING on a clean tree
```
`git diff` and `git stash create` both skip untracked files — the tarball is not optional. The ref keeps
gc from dropping the dangling stash commit. When `$SCRATCH` is under `/tmp`, it does not survive the
NEXT reboot: copy anything precious somewhere durable.

## 3. Find the dead session's transcript

Never rebuild a transcript path from a slug — Claude Code's slug and the hooks' slug differ (`.`
becomes `-` in one of them). Search:

```bash
# newest transcripts (last 3 days) whose entries ran in this repo, excluding your own session.
# Filter BEFORE truncating: most recent transcripts here are side-call ones from other slugs, so a
# "newest 40" cut can drop the dead session entirely. find, not ls (rtk may rewrite ls output).
find ~/.claude/projects -maxdepth 2 -name '*.jsonl' -mtime -3 -printf '%T@ %p\n' | sort -rn | cut -d' ' -f2- |
  while read -r f; do
    [[ "$f" == *"$CLAUDE_CODE_SESSION_ID"* ]] && continue
    grep -q -m1 "\"cwd\":\"$REPO" "$f" && echo "$f"
  done | head -3
```
Measured 2026-09-27 on this machine: 3 s over the 1,099 transcripts of the last 3 days (48 s without
the `-mtime` window, 9,046 files); it found the 2026-09-26 freeze's twes-in session first. Widen
`-mtime` if the crash is older.
Subagents: `~/.claude/projects/<slug>/<session-id>/subagents/agent-*.jsonl`, with `agent-*.meta.json`
naming each agent's type.

**Never `cat` or Read a transcript** — they run to megabytes and flood the context. Extract with
`jq`/`grep` into files under `$D`, and read those. Pass the transcript to jq as a FILE argument, never
through `--argjson`/`--arg` (one argv string over 128 KiB fails the whole exec).

## 4. Salvage

- **What it was doing** — the last actions:
  ```bash
  jq -r 'select(.type=="assistant") | .timestamp as $t | .message.content[]? | select(.type=="tool_use")
         | "\($t) \(.name) \(.input.file_path // .input.command // "" | tostring | .[0:160])"' "$T" | tail -30
  ```
  Timestamps are UTC.
- **A drafted file** (plan edit, commit message, report) — the last Write of that path:
  ```bash
  jq -rn --arg p "<name>" '[inputs | select(.type=="assistant") | .message.content[]?
         | select(.type=="tool_use" and .name=="Write") | select(.input.file_path | endswith($p))
         | .input.content] | last // empty' "$T" > "$D/<name>"
  ```
  `[inputs …] | last` keeps only the final Write of that path (verified against a live transcript,
  2026-09-27); a later `Edit` of the same file is not applied — check for one
  (`.name=="Edit"` with the same `file_path`) and replay it by hand.
- **A cut-off agent's report** usually sits in an UNEXECUTED `tool_use`: an agent that writes its
  report with `cat > report.md <<'EOF' … EOF` composes the whole body inside `.input.command`.
  Extract the commands, cut the heredoc body, and **verify the tail** — a truncating regex fails
  silently. `thinking` blocks are encrypted (empty text + signature): useless.
- **Probe/test artifacts on disk** (`var/claude/**`, untracked probe files) survive independently.
  Prefer a run whose CONTROL passed; a run whose control failed is vacuous.

## 5. Toolchain residue

- Cargo: `undefined hidden symbol … .llvm.` link errors after a kill → `rm -rf target/debug/incremental`,
  then rebuild (a killed link corrupts the incremental cache).
- Half-written logs and background runs are not evidence: re-run them (see `/long-run`).
- A reviewer or sabotage run may have left a mutated file: compare `md5sum` against the snapshot
  before trusting any source file.

## 6. Resume

Run `/next` to re-establish plan + progress. Treat every figure the dead session wrote into docs or the
plan (test counts, sabotage outcomes, `AGREED` entries) as a PREDICTION: re-measure it, and check each
Decisions-Log stamp against the file's mtime (a stalled session can write its own answer to its own
question). Delete `refs/recovery/*` only after the recovered work is committed and pushed:
`git update-ref -d refs/recovery/wip-<ts>`.

$ARGUMENTS
