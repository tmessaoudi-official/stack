---
name: discover-expertise
description: Use when starting work in a project and you need to know where ITS expertise lives (conventions, routing, commands, gates, domain reviewers), or to build or refresh its expertise index and practices file in the global per-project store (a container of repos gets one entry per unit). Reads the project's own CLAUDE.md, agents, skills, rules, docs, memory and gate configs, lists tool-found anti-patterns by file:line, never opens secret files, never invents expertise.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /discover-expertise — Show where THIS project's own expertise lives (CLAUDE.md headings with line numbers, agents, skills, rules, docs,
> memory, routing, commands, overrides of global rules, freshness). The global config is domain-generic; each project carries its own.
>
> Flags:
>   --write        write the GLOBAL per-project store ~/.claude/projects/<slug>/expertise/ (index.md + practices.md); a container of repos
>                  gets one entry per unit. Nothing is written into the project (user ruling 2026-10-03) EXCEPT an opted-in container: when
>                  <container>/.claude/expertise/index.md exists, --write for the container and for each unit writes under that folder instead
>                  (<container>/.claude/expertise/<unit>/) and the global store is not used for that tree (user ruling 2026-10-03, spa-rac).
>   --write-repo   write <project>/.claude/expertise.md (the index) instead; commit it yourself — this skill never commits
>   --dir PATH     a project other than the current directory
> ```

---

# /discover-expertise

The global `~/.claude` holds no project's domain knowledge (docs/SPEC.md §2.20). This skill finds the project's own and
points at it. The index is **pointers, never copies**: it cannot drift from its sources, and a differing HEAD sha marks it
stale rather than wrong.

## Step 1 — Build the index (deterministic)

```bash
bash ~/.claude/bin/discover-expertise.sh --dir "${DIR:-$PWD}"
```

Show the output. It names, with `file:line` pointers: identity and stack (the `adapt-project` probe), CLAUDE.md headings,
`.claude/agents`, `.claude/skills`, `.claude/rules`, docs, the project's memory, its routing section, its make/npm/composer
commands, the headings that override a global rule, and the git sha it was built from.

- **Container** — a directory whose child directories are repositories of their own. It is a container when it is
  not a repo itself, or when it IS a repo holding **>= 2** nested repos; a repo with ONE nested clone (`$HOME` holding `~/.claude`)
  stays a repo (`bin/lib/discover_expertise.py` `units()`; the expertise gate and `expertise-verify` use the same rule). A container
  gets its own index plus a `## Units` section, one entry per unit.
- **Expertise pack** — the section listing the installed L4: `.claude/rules/expertise-core.md` (loaded every session), the
  path-scoped rule packs `.claude/rules/expertise-<unit>.md` (`paths: <unit>/**`; a container's L4 is rules only, because units do
  not load the container's skills), `EXPERTISE-REFERENCE.md` and `domain-*` skills. No pack → it says so; nothing is invented.
  Detail: `docs/SPEC.md` §2.20 "rules-only L4 for a container".

## Step 2 — Judge the gaps (this is the part that needs you)

Read the pointed-at sections before relying on them — the index says WHERE, not WHAT.

- **`no CLAUDE.md`** → say so plainly and offer `/bootstrap` through `ask-human`. Do not write expertise the project has not stated.
- **`the project states no routing section`** → list the agents and skills it does carry and ask (`ask-human`) whether the
  project wants a Routing section; do not invent a routing table.
- **Overrides** → the project's statement wins over the global rule for that repo (`skills/ask-human/SKILL.md`). Quote the
  `file:line`, then follow it.
- **Stale** (an existing index — in the global store, an in-tree `.claude/expertise/`, or `.claude/expertise.md` — whose `built from:` sha differs from `git rev-parse --short HEAD`) → rebuild.

## Step 2b — Judge the practices (after reading the pointed-at sources)

The index also carries `## Findings (tool-found)`: deterministic, names and file:line only (secret files are listed from `git ls-files` and never
opened; credentials are named by key, never by value). Treat them as facts (`exact`) or leads to confirm (`pattern`). Then add what a tool cannot decide
to `practices.md` (global store), under **Judged practices**, one row each: class **G** good (the FLOOR — never do worse), **A** anti-pattern (never copy),
**U** unknown; evidence as file:line; the better way; cost **S** do it / **M** do it and tell the user / **L** large, costly or impractical — **ASK FIRST,
never automatic** (production credentials or data, outside access, history rewrite, a major runtime/framework upgrade, or beyond an agreed budget).
Grade every judged row Inferred unless a tool confirmed it. A security finding is reported to the user at once. Never open `.env*`, key or dump contents.
The user's rule (2026-10-03): the project's good practices are the floor; everything WE write follows best practice, whatever the project does.

## Step 3 — `--write`

```bash
bash ~/.claude/bin/discover-expertise.sh --dir "${DIR:-$PWD}" --write
```

Writes `~/.claude/projects/<slug>/expertise/index.md` and `practices.md` atomically (a container of repos: its own index plus one entry per unit). A re-write
regenerates ONLY the block between `tool-found:begin/end`; judged rows are never overwritten. Nothing is written into the project, except into an opted-in container's own `.claude/expertise/` (its `index.md` is the opt-in marker; see --write above). `--write-repo` puts the
index in `<project>/.claude/expertise.md` instead (uncommitted; committing follows CLAUDE.md Rule 10). Never edit the project's `CLAUDE.md` from here.

## Certification honesty

The script behind this skill is execution-certified (`bin/tests/discover-expertise.test.sh`, 64 assertions; every guarantee has a sabotage that turns
the named test red, restored byte-exact; read-only smoke on the real twes-in project). This prose — the judging
step — is a prompt and has not been exercised end to end.
