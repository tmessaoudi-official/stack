---
name: bash-test-harness
description: Use when writing or fixing a bash test suite for a script or hook. Sandboxes HOME, the log_obs log, git config, gpg and desktop notifiers via bin/tests/lib/isolate.sh, fakes $SCRIPT_DIR collaborators, points destructive probes at disposable siblings, fault-injects partial writes, and checks the suite leaked nothing.
user-invocable: true
args: "<script-under-test>"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /bash-test-harness — isolate a bash script under test so its tests touch nothing real.
>
> Usage: /bash-test-harness <script-under-test>
> Library: bin/tests/lib/isolate.sh (iso_setup, iso_obs_log, iso_home, iso_shims, iso_shim,
>          iso_stage, iso_link, iso_trap_add, iso_log_count, iso_leak_begin, iso_leak_check)
> ```

---

Every bash suite here used to roll its own isolation, and each learned one leak at a time: a suite
writing fixture lines into the live `hooks-errors.log` on every run (claude-cleanup, fixed 2026-09-27),
fixture commits failing on the global `commit.gpgsign=true` (RED for the wrong reason), real desktop
notifications, a `SCRIPT_DIR` that still pointed at the real collaborators, and a strict suite
aborting on `unbound variable` after its assertions had run. The library closes the mechanical half;
this checklist is the rest.

## Steps

1. **Inventory the side-effect surfaces** of the script under test — read it for: writes under
   `$HOME` (state, run, projects), `log_obs` / `hooks-errors.log`, `notify-send`, `git` (commits,
   config), `gpg`, network (`curl`, `gh`, `git push`), the `claude` CLI (costs money), `sudo`,
   collaborators called as `"$SCRIPT_DIR/x.sh"`, and deletions (`rm`, `find -delete`).
2. **Source the library and sandbox each surface.**
   ```bash
   . "$(dirname "${BASH_SOURCE[0]}")/lib/isolate.sh"
   iso_setup            # fake HOME (+ ~/.claude skeleton, git identity, no signing, no XDG/system
                        # git config, private GNUPGHOME), private OBS_LOG, shims for notify-send /
                        # claude / sudo (sudo FAILS), EXIT cleanup chained onto any existing trap
   iso_shim gh 0        # any other command the script calls — records "name args" to $ISO_ROOT/shim.log
   ```
   Pieces are composable: a large existing suite with one leak may need only `iso_obs_log` +
   `iso_trap_add iso_cleanup` (that is how `claude-cleanup.test.sh` adopted it).
3. **Traps compose, never replace.** `trap X EXIT` silently REPLACES the previous EXIT trap and the
   loser's temp dirs leak. Register your own cleanups with `iso_trap_add '<cmd>'`, or call
   `iso_trap_add iso_cleanup` AFTER any plain `trap … EXIT` the suite already has.
4. **`SCRIPT_DIR` collaborators** (CLAUDE.md Rule 7): `SCRIPT_DIR` resolves from `BASH_SOURCE[0]`,
   so running from another cwd changes nothing. `s=$(iso_stage path/to/script.sh)`, write fakes into
   `$ISO_STAGE/`, `iso_link` the real sourced deps, run `bash "$s"`.
5. **Overridable directories.** If the script hard-codes a directory it scans or deletes in, give it
   an `_X_DIR="${_X_DIR:-$HOME/...}"` override in its "overridable for tests" section instead of
   pointing the test at the real one.
6. **Destructive guards probe a DISPOSABLE sibling** of the protected target, and the test asserts
   the real target is untouched afterwards (`[ -e ]`, `cmp`), never only the exit code.
7. **Faults.** Truncate ONE write mid-way with `( ulimit -f <blocks>; ulimit -c 0; <step> )` —
   SIGXFSZ kills the shell, so code after the write never runs; fake binaries via `iso_shim <name>
   <rc>`; make sure the fault does not also break the NEXT step you mean to observe.
8. **Assertions** are anchored: match a log line on its producer field (`| INFO | script | …`), not
   a bare substring the fixture itself contains. Print a tally line (`PASS: n FAIL: m (of t)`) and
   exit non-zero on any failure — a suite without a tally cannot be told apart from an aborted one.
9. **Leak check, in the suite itself.** `iso_leak_begin <producer>` at the start, then
   `iso_leak_check <producer>` as an assertion at the end: it counts the producer's lines in the REAL
   `~/.claude/logs/hooks-errors.log` (shared by every session's hooks — never compare size or mtime).
   A suite that creates temp dirs asserts none survive (count against a STAMP file's mtime, not a
   directory's — a directory's mtime moves every time the suite writes into it).
10. **Register the suite** in `bin/run-tests.sh` (a hardcoded list for `bin/tests/`; hook tests are
    globbed) — a suite missing there never runs in the full pass.
11. **Then prove it guards anything**: `/sabotage-check` — including one mutant that removes the
    isolation itself and shows the leak assertion go red (run that mutant with `HOME` pointed at a
    scratch dir, so the "real" log it pollutes is a stand-in).

$ARGUMENTS
