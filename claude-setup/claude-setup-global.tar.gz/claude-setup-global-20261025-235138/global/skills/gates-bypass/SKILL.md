---
name: gates-bypass
description: Use when reviewing or changing any safety-gate bypass or machine switch — the front door for every gate family (ask-human gate, bash firewall, question guard, completion guard, prework guard, autonomous-3c, permission rules, expertise gate, keep-going, confident picks), the autonomous/spec mode, the unattended window and the model overrides. Shows one read-only grid of everything, then changes one thing through the executor after a confirm.
user-invocable: true
args: "[status [--json|--brief]] [bypass|arm|on|off WHAT (--here|--path DIR|--global|--session) [--for DUR|--forever] [--level normal|total] [--except P] [--cap N|unlimited] [--dry-run]] [bypass|arm mode] [lint] [orphans] [on|off memory|lean|learning] [memory readonly|status|block|unblock] [lean status|block|unblock] [engine status|repair|rollback [--to-shadow]] [protect gates|expertise|scope-parity print|apply|rollback] [hook keep-going|expertise-gate|perm-logger|push-batch|stop-failure status|register|unregister] [stack-md status|apply|remove] [--status] [--run [--for DUR]] [--spec] [unattended on|off|status --mode park|allow --for DUR [--path P] [--no-ask]] [unattended off --all|--path P|--global] [models status|skills|agent|agent-type|hook|reset ...] [--lint] [--orphans] [--migrate] [apply-parked list|check|apply [--dir DIR] [--test-timeout S] [--unprotected]] [review] [--scope=global|project|session|rule] [--family=CODE] [--all-guards-off] [--all-guards-on]"
side-effects: Gates through bin/gates-bypass.sh — edits ~/.claude/state/gates-bypass-rules.json (linted before an atomic replace) and creates or removes legacy bypass sentinels under ~/.claude/state/, ~/.claude/projects/<slug>/state/ and ~/.claude/run/; the unattended and models paths run bin/unattended.sh and bin/model-override.sh, which write ~/.claude/state/unattended.json and ~/.claude/state/model-overrides.json (the Write tool only in a session with no shell). Every change is shown as a plan and confirmed via AskUserQuestion first. The 4.8 subcommands run bin/perm-engine-apply.sh, bin/gates-bypass-ask-apply.sh, bin/keep-going-apply.sh, bin/expertise-gate-apply.sh, bin/perm-shadow-apply.sh (settings.json / the engine rules; each mutating call prompts), and `on|off learning` runs bin/learning-style.sh (settings.json). Status, lint, orphans and every status/print form write nothing.
disable-model-invocation: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /gates-bypass — the front door for every gate, enable and machine switch: one read-only grid (gates-status.sh), one executor (gates-bypass.sh), a confirm before every change.
> ```
>
> Then output the flag table and the routing table below. Then STOP.

| Flag | Value | Default | Description |
|------|-------|---------|-------------|
| `--status` | — | off | Same as `status`: print the grid (`bin/gates-status.sh`) and stop. No question, no mutation. |
| `--json` | — | off | With `status`: the grid as JSON (for /next and scripts). |
| `--brief` | — | off | With `status`: one summary line plus `WARN:` lines (what pre-session-health reads). |
| `--here` | — | — | WHERE for `on`/`off`: this directory and everything beneath (a recursive rule). |
| `--path` | DIR | — | WHERE: that absolute directory and beneath (never `/` or `$HOME` or above). Also the unattended window's root. |
| `--global` | — | — | WHERE: every directory (a `{"global": true}` rule, or the global sentinel on `off`). |
| `--session` | — | — | WHERE: this session only (a `run/<file>-<sid>` sentinel; takes no duration; `perm` has no session scope). |
| `--for` | DUR | asked | How long: `30m`, `2h`, `7d`, at most 30 days (unattended: 1 m to 7 d). Never defaulted: asked each time. |
| `--forever` | — | off | The explicit escape from `--for`. |
| `--level` | `normal`\|`total` | normal | `fw` / `perm` only. At `--session` scope it is the fw sentinel's content (`total` or empty); `perm` has no session scope. |
| `--except` | PATH | none | A hole in THIS rule or window (repeatable): absolute, normal form, strictly inside `--path`/`--here`; any family incl. `kg`/`cf`, and `unattended on`. Inside it only a deeper rule/window decides (row 26zu). Never seeded automatically. |
| `--cap` | N\|`unlimited` | unchanged | `on keep-going` only: forced continuations before the cap question (1-999999; `0` = unlimited). Session → the sentinel; `--here`/`--path` → the project's cap; `--global` → the global cap. `off` never removes a cap. |
| `--dry-run` | — | off | Print the executor's plan and exit 0; nothing written. |
| `--run` | — | off | Mode → **autonomous** for this project tree (merges `ah qg ac pw auto3c` into the root's rule). `fw`/`perm` untouched. |
| `--spec` | — | off | Mode → **spec** here (strips the five from every rule covering `$PWD`; exit 6 names a legacy sentinel still granting `ah`). |
| `--mode` | `park`\|`allow` | asked | Unattended window mode (see `unattended`). |
| `--no-ask` | — | off | Unattended: also deny `AskUserQuestion` (opt-in). A prompt that says "ask me" or "let me decide" lifts it for that turn (row 26zj). |
| `--all` | — | on (bare `off`) | Unattended `off`: end every window; `--path P` / `--global` end only that one (row 26z). |
| `--lint` | — | off | Same as `lint`: validate `gates-bypass-rules.json`; print every problem (exit 5 when invalid). No mutation. Run it the moment `⚠⚠ RULES-INVALID` shows. |
| `--orphans` | — | off | Same as `orphans`: list session files of every family older than 24 h with the exact `rm` line for each. No mutation. |
| `--migrate` | — | off | Offer, project by project, to replace legacy per-project sentinels with a recursive rule. |
| `--dir` | DIR | the only one | `apply-parked`: which `parked/` directory (required when there are several). |
| `--test-timeout` | S | 1800 | `apply-parked apply`: seconds per test suite; a timeout is red (rolled back). |
| `--to-shadow` | — | off | `engine rollback`: undo the cutover only (engine back to shadow, permissions restored) instead of the full rollback. |
| `--unprotected` | — | off | `apply-parked apply`: land WITHOUT the step-4.6 protect rule — only for the one landing that installs it. |
| `--scope` | `global`\|`project`\|`session`\|`rule` | — | Old spelling of WHERE: `global` = `--global`, `session` = `--session`, `rule` = `--here`/`--path`. `project` (an EXACT-cwd sentinel) can no longer be created: it becomes a recursive rule (`--here`), the designed fix for the cwd-drift stalls. `off … --here` / `--path P` still removes a project sentinel. |
| `--family` | code(s) | — | Old spelling of WHAT: `--family=ah` = `ah`. |
| `--all-guards-off` | WHERE | — | Old spelling = `on ah,fw,qg,ac,pw,auto3c WHERE` (the six original codes; NOT `all`, which also adds `perm` and `eg`). |
| `--all-guards-on` | WHERE | — | Old spelling = `off ah,fw,qg,ac,pw,auto3c WHERE`. |

## Routing — every control, where it lives

One row per control. "skill" = this skill (or the named one) runs it after a confirm; "`!`" = a one-time installer or repair the
classifier will not let Claude run (settings.json / guard-hook edits): give the user the exact line, never run it. The `bypass|arm`
gate verbs are live (step 4.3, landed c57ff699; `on|off` stay valid for every family). The `engine` / `protect` / `hook` / `stack-md`
subcommands (framework-health 4.8) run the installers themselves; since H48 landed (2026-10-08) every one of them has a protected ask rule.

| Control | Command | Runs as |
|---|---|---|
| Status of everything (families, mode, engine, rules, swap, window, overrides, memory, lean, learning, cert schedule) | `bash ~/.claude/bin/gates-status.sh` (`--json`, `--brief`) | skill, read-only |
| Gate bypass: `ah` `qg` `ac` `pw` `auto3c` `fw` `perm` `eg` | `/gates-bypass bypass WHAT WHERE --for DUR` and `/gates-bypass arm WHAT WHERE` (`on` / `off` = the same) | skill → `bin/gates-bypass.sh` |
| Keep-going `kg` (an enable: grant = ON) | `/gates-bypass on keep-going WHERE [--cap N\|unlimited]` and `off keep-going WHERE` (`bypass`/`arm` refuse it: an enable) | skill (or /keep-going) |
| Confident picks `cf` (an enable: grant = ON, row 26zg) | `/gates-bypass on confident WHERE [--for DUR]` and `off confident WHERE` (`bypass`/`arm` refuse it; refused, exit 5, until `protect scope-parity apply` has installed its 4 protect rules) | skill |
| Expertise gate `eg` (grant = gate off) | `/gates-bypass bypass expertise-gate WHERE --for DUR` (= `eg`); `/expertise-gate status` | skill (or /expertise-gate) |
| Mode (spec / autonomous) | `/gates-bypass bypass mode` (`--for DUR`) and `/gates-bypass arm mode` (= `--run` / `--spec`) | skill |
| Rules file check | `/gates-bypass lint` (`--lint`) | skill, read-only |
| Orphaned session files, every family | `/gates-bypass orphans` (`--orphans`) | skill, read-only |
| Legacy project sentinels to rules | `/gates-bypass --migrate` | skill |
| Unattended window | `/gates-bypass unattended on --mode park --for 10h`, `off`, `status` | skill → `bin/unattended.sh on|off` (its dialog is the consent); `status` = Read |
| Parked patches (protected-file changes waiting to land) | `/gates-bypass apply-parked list`, `check`, `apply` | skill → `bin/apply-parked.sh` (apply: plan, confirm, `--yes`) |
| Bypass review (ratify what a bypass let through; user-only) | `/gates-bypass review` | skill → `bin/bypass-review.sh` (rounds of ≤4 groups; `ack`/`reject` prompt) |
| Model-policy overrides | `/gates-bypass models status` and `models …` | skill → `bin/model-override.sh` (set/unset prompt) |
| Permission engine health | `/gates-bypass engine status` (= `bash ~/.claude/bin/perm-engine-doctor.sh`) | skill, read-only |
| Permission engine repair or rollback | `/gates-bypass engine repair` (refused on SLOW), `/gates-bypass engine rollback [--to-shadow]`, `/gates-bypass engine backstop-sync [--dry-run]` | skill → `perm-engine-apply.sh` (prompts) |
| Ask rules that protect this executor | `/gates-bypass protect gates print\|apply\|rollback` | skill → `gates-bypass-ask-apply.sh` (prompts) |
| Ask rules that protect the expertise gate | `/gates-bypass protect expertise print\|apply\|rollback` | skill → `expertise-gate-protect-apply.sh` (prompts) |
| Ask rules for the eg/kg/cf sentinels (scope parity) | `/gates-bypass protect scope-parity print\|apply\|rollback` | skill → `scope-parity-protect-apply.sh` (prompts) |
| Keep-going hook registration | `/gates-bypass hook keep-going status\|register\|unregister` | skill → `keep-going-apply.sh` (prompts) |
| Expertise-gate hook registration | `/gates-bypass hook expertise-gate status\|register\|unregister` (or `/expertise-gate`) | skill → `expertise-gate-apply.sh` (prompts) |
| PermissionRequest logger (shadow) | `/gates-bypass hook perm-logger status\|register\|unregister` | skill → `perm-shadow-apply.sh` (prompts) |
| StopFailure notifier registration (row 26zp) | `/gates-bypass hook stop-failure status\|register\|unregister` | skill → `stop-failure-apply.sh` (prompts: protect rules, engine test 7e) |
| Push-batch guard registration (Rule 10, batch 30) | `/gates-bypass hook push-batch status\|register\|unregister` | skill → `push-batch-apply.sh` (prompts: PB-c's protect rules, landed 55f50e06) |
| /path/to/your/project CLAUDE.md exclusion | `/gates-bypass stack-md status\|apply\|remove` (apply/remove: the user asks for it, never Claude unasked) | skill → `stack-claude-md-scope.sh` (apply/remove prompt) |
| Legacy permission swap (retired; off only) | `/permission-swap off --scope=global` or `--scope=project` | skill (/permission-swap) |
| Certification schedule | `/certify --set <schedule text>` | skill (/certify) |
| Memory capture | `/gates-bypass on\|off memory`, `memory readonly\|status\|block\|unblock` (= `/memory-*`) | skill → the /memory-* SKILL.md (see Enables) |
| Lean mode | `/gates-bypass on\|off lean`, `lean status\|block\|unblock` (= `/lean*`) | skill → the /lean* SKILL.md (see Enables) |
| Learning output style | `/gates-bypass on\|off learning` (= `/learning-on\|off`) | skill → the /learning-* SKILL.md (see Enables) |
| Launch-time off-switches | `CLAUDE_BASH_FIREWALL_OFF=1`, `QGUARD_OFF=1`, `ACGUARD_OFF=1`, `PREWORK_OFF=1`, `KEEPGOING_OFF=1`, `KEEPGOING_STOP_ASK=0` (only the keep-going stop question, row 26u), `PUSH_BATCH_OFF=1`, `STOPFAILURE_NOTIFY_OFF=1`, `EXPERTISE_GATE_OFF=1`, `REMOTE_BANG_OFF=1`, `CLAUDE_CLEANUP_AUTO_OFF=1` (the daily safe sweep, row 26zc) before starting Claude Code | status only |

## `status` — the grid (always first)

Run it in one Bash call; it is read-only and never prompts:

```bash
bash ~/.claude/bin/gates-status.sh
```

Table A has one row per family — the family list is the resolver's own registry, and every state, level and expiry comes from
the resolver (`hooks/bypass-resolve.sh`), never a re-implementation: kind (gate / badge / enable), state (`ARMED`/`BYPASSED`, or
`ON`/`OFF`), level, every granting source (`g` global sentinel, `proj` project sentinel, `sess` session sentinel, `rule:<path|global>`),
until (the latest covering expiry, since sources OR), except count (the covering rules' union, every family since row 26zu), hook registration, and the
command that changes the row. Block B is the machine: mode, engine status, rules file, legacy swap, unattended window (counts only,
never command text), parked patches, bypass review (counts only: unreviewed, risky, rejected groups — never a group's text; framework-health 5.5),
unratified ASSUMED entries, model overrides, cert schedule, stack-md scope, memory, lean, learning.
Exit 1 = warnings (listed at the bottom); 0 = none.

Report the grid verbatim. Then, when the rules file exists, add the **rules detail** — the grid lists only the rules covering
`$PWD`, so a rule elsewhere, or an expired one, is visible only here:

```bash
# The rules file is named only in READERS ([ -f ] and jq FILE): any other command naming it is a protected ask (row 26r).
cd "$HOME/.claude/state" 2>/dev/null && [ -f gates-bypass-rules.json ] && HAVE=1
if [ -z "${HAVE:-}" ]; then
  echo "rules: none (no gates-bypass-rules.json)"
else
  LINT=$( ( source "$HOME/.claude/hooks/bypass-resolve.sh" 2>/dev/null && bypass_rules_lint ) 2>/dev/null )
  if [[ -n "$LINT" ]]; then
    echo "⚠⚠ RULES-INVALID — every rule is disabled until this is fixed:"
    printf '   %s\n' "$LINT"
  else
    # Same liveness as the resolver's alive() (hooks/bypass-resolve.sh): a date lives through that local day, a timestamp
    # until that UTC instant. A plain string compare called a timestamp that passed earlier today alive.
    TODAY=$(date +%Y-%m-%d); NOW=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    jq -r --arg today "$TODAY" --arg now "$NOW" '.rules[] |
      (if .global == true then "  GLOBAL" else "  \(.path)  \(if .recursive then "recursive" else "root-only" end)" end) +
      "  guards=\(.guards | join(","))" +
      (if ((.except // []) | length) > 0 then "  except=\((.except | length))" else "" end) +
      (if .level then "  level=\(.level)" else "" end) +
      (if .expires then (if (.expires | if length == 10 then . >= $today else . > $now end) then "  expires \(.expires)" else "  EXPIRED \(.expires)" end) else "" end) +
      (if .note then "  # \(.note)" else "" end)' gates-bypass-rules.json
    jq -r '.rules[] | select((.except // []) | length > 0) | "    except under \(.path // "GLOBAL"):", ("      " + ((.except // [])[]))' gates-bypass-rules.json
  fi
fi
```

An `EXPIRED` row is not an error — the gate is armed again, which is the feature working. Offer to remove it
(`/gates-bypass off <codes> --path <its path>`) so the file stays readable.

If `status` or `--status` was the request, **stop here** — no questions, no mutation.

## `bypass` / `arm` (and `on` / `off`) — the one command (plan permission-unification, step 6; grammar framework-health 4.3)

```
/gates-bypass bypass WHAT WHERE (--for 30m|2h|7d | --forever) [--level total] [--except PATH]…     (= on)
/gates-bypass arm    WHAT WHERE                                                                  (= off)
/gates-bypass on|off keep-going WHERE [--for DUR | --forever] [--cap N|unlimited]
WHAT   gates (ah qg ac pw auto3c) | firewall (fw) | perms (perm) | all | codes such as ah,qg | expertise-gate (eg) | keep-going (kg) | confident (cf)
       `all` = the five gates + fw + perm + eg (the expertise gate's off-switch). It NEVER includes kg (keep-going ON), which is an enable, not a bypass:
       `bypass` / `arm` refuse kg (exit 2) — use `on|off keep-going` or /keep-going. eg and kg use the same scopes as every family (docs/SPEC.md §2.1).
       cf (confident picks, row 26zg) is an enable like kg: never in `all`, `--run`/`--spec` never move it, `bypass`/`arm` refuse it.
WHERE  --here (this directory and everything beneath, never above) | --path X | --global | --session
```

`--level` at `--session` scope is the fw sentinel's content (`total` or empty); without `--level` an existing sentinel keeps its content.
`--cap` and every `on|off keep-going` reset that scope's continuation counter; `off` never removes a cap (it is a setting).

**Executor:** `bash ~/.claude/bin/gates-bypass.sh …` (tests `bin/tests/gates-bypass.test.sh`). It is a plain script — **no `!` run is
needed per bypass**. It writes every rule and sentinel itself; this skill never hand-writes `touch` / `rm` / `jq` into a state file.

**Protocol:**
1. Resolve WHAT / WHERE / HOW LONG from the words (old flags: see the alias rows of the flag table). Ask (`AskUserQuestion`) for any
   missing part. **`on` with no duration ASKS every time** — never default one (`--session` takes none: a sentinel cannot expire).
   When the current state is "armed", the first, recommended option is *Keep the guard armed*; when a bypass exists, it is
   *Remove it, restore the guard* — never lead with removing protection.
2. Run the script **without `--yes`**: it prints `PLAN: …` with the absolute path and exits 4 (nothing written). `--dry-run` prints the same and exits 0.
3. Show that plan via `AskUserQuestion`; on approval re-run the identical command with `--yes`. The script prints the resolver's view
   (per family `ARMED`/`BYPASSED`/`ON`/`OFF` and the source).
4. `off` exit 6 = a targeted family is *still* granted by another source (a broader rule, another sentinel); the output names it — offer to remove that too.
5. Re-run `bash ~/.claude/bin/gates-status.sh` and show the changed rows.

**Building a rule** — gather the whole rule in ONE `AskUserQuestion` round, then one confirmed run. In order:
1. **Path** — default `$PWD` (`--here`) or `--path DIR`; `/` and `$HOME` and above are refused by the script (a rule there covers every project).
2. **Guards** — which codes. Recommend the set legacy sentinels already grant here, if any, so migrating changes reach and nothing else.
3. **Blacklist** — `--except P` (repeatable), always offered, default **none**. Resolve relative entries against the rule's path and
   echo every absolute path back: a typo'd entry matches nothing and silently leaves that subtree bypassed. An entry may contain `*`
   (one path segment); quote it so the shell never expands it. Every entry must lie strictly inside the rule path (the executor refuses
   others, exit 2, and the lint voids a hand-written one). For `qg`/`ac`/`kg`/`cf`/`eg` it is matched on the session cwd (row 26zu).
   **A `perm` rule's except** compiles into ask rules only when `permission-swap.sh recompile` runs while a legacy swap is armed;
   with the engine LIVE the engine reads the rules file itself.
4. **Expiry** — `--for DUR` (suggest one when the reason is temporary) or `--forever`. An expired rule re-arms its gates by itself.
5. **Level** — asked only when the guards include `fw` or `perm`: **Normal (Recommended)**, or **Total** (the firewall never asks
   inside this path; only its deny floor refuses; a `perm` rule at total compiles none of its except asks).

Root-only rules (`"recursive": false`) are not created any more: the executor always writes recursive rules, because the
exact-match reach caused the documented stalls. An existing root-only rule is still honoured and shown (`root-only` in the detail).

**Rules the script enforces** (exit codes: 2 usage · 3 duration missing · 4 needs `--yes` · 5 refused · 6 still granted):
`--for` is at most 30 days (`--forever` is the explicit escape) · `--here`/`--path` at `$HOME` or above is refused · `perm` is applied only
while the permission engine is `LIVE` · an existing rules file that fails lint is never edited · every write is linted by the resolver
before an atomic replace · re-`on` for the same target *replaces* those guards (no duplicate) and keeps an existing except / level unless
overridden · the `on` plan prints `NOTE: the deeper rule at P … decides inside its tree` for every live rule of the same family strictly inside the
new rule's tree (every path rule, for a global one) whose level or except list differs: the longest covering path decides there (row 26z-b, user
ruling 2026-10-15; resolution unchanged) - show those lines in the confirm · `settings.json` is never touched.

**eg and kg (2026-10-03, plan scope-parity).** A `kg` rule takes no `--level` and is always written as its own rule (a `cf` rule too); `--except` is
fine (row 26zu): it is matched on the session cwd, like every cwd-keyed family. `eg` is keyed
on the SESSION's cwd, not on the project an agent is pointed at: an agent launched from `~/.claude` that names `/path/to/your/project/projects/x` is judged
by `~/.claude`'s scope (known limit, SPEC §2.1).

**Confident picks `cf` (row 26zg, user rulings 2026-10-15 12:10 / 12:42).** An independent enable, like `kg`: `on confident WHERE [--for DUR]`
grants it, `off confident WHERE` removes it; it is never part of `all`, and `--run` / `--spec` never move it, so every gate stays independently
armable. It replaces the MID-TASK question policy of either mode: in spec mode the size gate still asks and clear picks are taken; in autonomous mode
the recommended option is no longer taken by default. The tiered rule: PICK when an objective test decides (a recorded ruling dictates it, or it is
the only option passing a rule or test); a reversible, in-scope grey case is picked only if `advisor()` agrees; otherwise ASK. Every pick is logged
`ASSUMED (review)` with its basis. Always asked: destructive steps, the 5-round certification cap, grey cases without `advisor()`. Under a `no_ask`
unattended window an unsettled grey case is PARKED (logged, branch skipped). The model learns it from the SessionStart banner, every subagent brief
and every prompt (`hooks/ask-human-gate-arm.sh` injects the rule while on, and one `OFF now` line when it ends); the statusline's mode item shows `spec+cf` / `autonomous+cf`.
`on confident` is refused (exit 5) until `/gates-bypass protect scope-parity apply` has installed its four protect rules (all three scopes,
the session file included). The plan prints a NOTE when the question guard (`qg`) is bypassed where cf is on (`arm qg` restores it).

**Guard against an unprompted off-switch:** the `!` row "Ask rules that protect this executor" adds ask rules for `bypass` / `arm` / `on` /
`off` / `--run` / `--spec` / the python entry point, so a bare Bash call of the script prompts; `--yes` alone is not consent, and `status`,
`lint` and `orphans` never ask. Installed 2026-10-08; until it has run on a machine, Claude can flip any gate there in one Bash call.
These rules are `protected`: they prompt even under a `perm` bypass at level total. **An unattended window in `allow` mode lets them
through** (guard invocations are not its core set, user ruling 2026-10-01); `park` mode parks them.

## `bypass mode` / `arm mode` (= `--run` / `--spec`) — the mode (CLAUDE.md § Mode)

The `ah` family decides the working mode: **armed = spec** (every gate fires), **bypassed = autonomous** (announce and run; ambiguity →
the recommended option, logged `ASSUMED (review)`, or the tiered rule while confident picks (`cf`) are on; destructive steps still ask). The mode moves the five conversational families
together: `ah qg ac pw auto3c`. **`fw` and `perm` are independent and never touched here**, nor is any rule's `level`.

- `bypass mode` / `--run [--for DUR]` merges the five into the rule at the **project root** (the git toplevel; `~/.claude` when the toplevel is `$HOME`;
  the same root `hooks/cert-schedule.sh` and /next use), or adds a recursive rule there. Already autonomous → it says so and stops.
  If the existing root rule is root-only, the plan says subdirectories stay in spec mode.
- `arm mode` / `--spec` strips the five from **every rule covering `$PWD`**, ancestors included (an ancestor rule re-arms its whole tree — the plan
  names it), drops a rule left with no guards, and exits 6 while a legacy sentinel still grants `ah`: offer `off <codes> --global` /
  `--here` / `--session` for each source the output names. The toggle is done only when the grid's mode row reads `spec`.
- The mode takes **no WHERE** (the tree is always the project root): `bypass mode --here`, `--run --global` and the like exit 2.

Same protocol as `on`/`off`: run without `--yes` (plan, exit 4), confirm with ONE `AskUserQuestion` (*Apply …* / *Apply with an expiry* /
*Cancel*; *Apply — spec mode (Recommended)* first for `--spec`, because it restores guards), then re-run with `--yes`. The reference
semantics are pinned by the executor's tests T20a–e (`bin/tests/gates-bypass.test.sh`), not by recipes here.

## `lint`, `orphans`, `--migrate`

**`lint`** (read-only; `--lint` is the same):

```bash
bash ~/.claude/bin/gates-bypass.sh lint
```

Exit 0 = valid (or no rules file); exit 5 = `RULES-INVALID` with every problem listed: the whole file is ignored and every gate is armed
(strict and loud, below). It takes no arguments.

**`orphans`** (read-only; `--orphans` is the same) — session files of EVERY family older than 24 h (`*-bypass-<sid>`,
`expertise-gate-off-<sid>`, `keep-going-<sid>`, `keep-going-count-<sid>`, `confident-pick-<sid>`), never this session's, each with the exact `rm -f` line for the
user to run by hand:

```bash
bash ~/.claude/bin/gates-bypass.sh orphans
```

It always exits 0 and deletes nothing. Removal stays ask-gated by design, as `claude-cleanup.sh --run-files` treats them.

**`--migrate`** — never mechanical, never batched:
1. List every `~/.claude/projects/*/state/` directory holding a legacy sentinel of any family.
2. Reverse each slug to a real path. **The slug is lossy** (`-stack-projects-twes-in` could be `/path/to/your/project/projects/twes-in` or
   `/path/to/your/project/projects/twes/in`): generate the dash-split candidates, keep those that pass `[ -d ]`, and ask when more than one survives.
3. Per project, show the families bypassed and the replacing command (`on <codes> --path <dir> --for DUR|--forever`); one confirm each.
   Warn explicitly that a rule at `/path/to/your/project` covers every project beneath it, and one at `~/.claude` covers `hooks/` and `settings.json`.
4. After the rule is in place, offer `off <codes> --path <dir>` to remove the now-redundant sentinels (the executor unlinks the
   project sentinel for that exact path). **The ordering trap:** sources OR, so a leftover sentinel keeps working after its rule is gone.

## Enables — memory, lean, learning (routed to their skills; framework-health 4.5)

These are switches that turn something ON, so they use `on` / `off` (user ruling 2026-10-07), and they are not resolver families: the
executor refuses them as a WHAT (exit 2). **Routing order:** when the first words match a row below, this skill **Reads that SKILL.md and
follows its steps** with the remaining words as its arguments; anything else is a WHAT for the executor. The named skill is the
implementation (one code path, two entry points; ASSUMED 2026-10-08 09:31); it never routes back here, so there is no loop.

| Front-door form | Implementation (Read and follow) |
|---|---|
| `/gates-bypass on memory` | `~/.claude/skills/memory-on/SKILL.md` |
| `/gates-bypass off memory` | `~/.claude/skills/memory-off/SKILL.md` |
| `/gates-bypass memory readonly` | `~/.claude/skills/memory-readonly/SKILL.md` |
| `/gates-bypass memory status` | `~/.claude/skills/memory-status/SKILL.md` |
| `/gates-bypass memory block [PATH] [--readonly]` | `~/.claude/skills/memory-block/SKILL.md` |
| `/gates-bypass memory unblock [PATH]` | `~/.claude/skills/memory-unblock/SKILL.md` |
| `/gates-bypass on lean [FLAGS]`, `off lean [FLAGS]`, `lean status` | `~/.claude/skills/lean/SKILL.md` (as `on …` / `off …` / `status`) |
| `/gates-bypass lean block [PATH]` | `~/.claude/skills/lean-block/SKILL.md` |
| `/gates-bypass lean unblock [PATH]` | `~/.claude/skills/lean-unblock/SKILL.md` |
| `/gates-bypass on learning` | `~/.claude/skills/learning-on/SKILL.md` |
| `/gates-bypass off learning` | `~/.claude/skills/learning-off/SKILL.md` |

The short skills (`/memory-off`, `/lean on`, …) stay valid and behave identically. Not routed: `/keep-going` (its front-door form is
`on|off keep-going`, the executor itself), `/expertise-gate` (the gate's bypass is `bypass|arm expertise-gate WHERE`; its on/off is hook
registration: `/gates-bypass hook expertise-gate …`), `/permission-swap` (retired, off-only), `/memory-promote` (not a switch).
`/learning-on|off` run `bin/learning-style.sh` (a direct Write to `settings.json` is classifier-blocked); it refuses (exit 5) on a machine
where its two protect rules are not installed (`/gates-bypass protect gates apply` installs them).

## `engine` / `protect` / `hook` / `stack-md` — the installers as subcommands (framework-health 4.8)

These were `!` lines the user typed. This skill now runs the script itself. Read-only forms run directly. Every mutating form is
covered by a `protected` ask rule, so running it **prompts**, and approving that prompt is the consent (this skill is user-only, never
model-invoked). Before each mutating run, show the exact command and what it changes in ONE `AskUserQuestion`. If the call is denied,
parked (an unattended window in `park` mode) or refused, do NOT retry or reword it: give the user the Runs command below prefixed with `!` and stop.

| Subcommand | Runs | Writes |
|---|---|---|
| `/gates-bypass engine status` | `bash ~/.claude/bin/perm-engine-doctor.sh` | nothing |
| `/gates-bypass engine repair` | the doctor first (see below), then `bash ~/.claude/bin/perm-engine-apply.sh repair` | settings.json registration, firewall SELFMOD |
| `/gates-bypass engine rollback [--to-shadow]` | `bash ~/.claude/bin/perm-engine-apply.sh rollback [--to-shadow]` | settings.json, engine back to shadow |
| `/gates-bypass engine backstop-sync [--dry-run]` | `bash ~/.claude/bin/perm-engine-apply.sh backstop-sync [--dry-run]` | settings.json backstop denies (respelled in place) |
| `/gates-bypass protect gates print\|apply\|rollback` | `bash ~/.claude/bin/gates-bypass-ask-apply.sh` with `--print` / no argument / `--rollback` | the engine's ask + protected lists |
| `/gates-bypass protect expertise print\|apply\|rollback` | `bash ~/.claude/bin/expertise-gate-protect-apply.sh` with `--print` / no argument / `--rollback` | firewall SELFMOD + engine rules |
| `/gates-bypass protect scope-parity print\|apply\|rollback` | `bash ~/.claude/bin/scope-parity-protect-apply.sh` with `--print` / no argument / `--rollback` | firewall SELFMOD + engine rules |
| `/gates-bypass hook keep-going status\|register\|unregister` | `bash ~/.claude/bin/keep-going-apply.sh status\|on\|off` | settings.json Stop group |
| `/gates-bypass hook expertise-gate status\|register\|unregister` | `bash ~/.claude/bin/expertise-gate-apply.sh status\|on\|off` | settings.json PreToolUse `Agent` group |
| `/gates-bypass hook perm-logger status\|register\|unregister` | `bash ~/.claude/bin/perm-shadow-apply.sh` with `status` / no argument / `--rollback` | settings.json PermissionRequest |
| `/gates-bypass hook stop-failure status\|register\|unregister` | `bash ~/.claude/bin/stop-failure-apply.sh status\|on\|off` | settings.json `StopFailure` group (row 26zp: log, desktop + terminal notification, opt-in ntfy push when a turn dies on an API error) |
| `/gates-bypass hook push-batch status\|register\|unregister` | `bash ~/.claude/bin/push-batch-apply.sh status\|on\|off` | settings.json PreToolUse `Bash` group (the PB-a hook, landed 55f50e06) |
| `/gates-bypass stack-md status\|apply\|remove` | `bash ~/.claude/bin/stack-claude-md-scope.sh status\|apply\|remove` | every `/path/to/your/project/projects` root's `.claude/settings.local.json`, or `settings.json` for a root that is not its own git repo (apply/remove) |

`/gates-bypass hook expertise-gate register` is the same script as `/expertise-gate on` (and `unregister` = `off`).

**`engine repair` runs `engine status` first** and acts on the doctor's exit code: 0 (`LIVE` / `SHADOW` / `OFF`) — nothing to repair,
stop; **2 (`SLOW`) — refuse: the self-test ran out of time, which is host load, not a fault; never run the repair for it** (check
`/proc/pressure/cpu`, re-run `engine status` later); 1 (`DOWN`) — offer the repair.

**`engine backstop-sync` runs `--dry-run` first** and shows its `respelled:` / `skipped` / `kept, no floor twin` lines in the one
`AskUserQuestion`; only on a yes does it run without the flag. It respells a settings.json backstop deny `Bash(X)` to the engine floor's
`Bash(*X)` in place (LIVE only; nothing added or removed). `bash ~/.claude/bin/perm-engine-apply.sh status` prints the count to sync (`engine status` is the doctor and does not).

**Every mutating form prompts** since parked patch H48 landed (2026-10-08): it added wildcard Bash rules for the two protect installers
and `stack-claude-md-scope.sh apply|remove` (a trailing `2>&1` cannot walk past them). On a machine where `/gates-bypass protect gates apply`
has not run yet, those three would run with no prompt: run it first. `perm-shadow-apply.sh`'s apply rule matches the bare command only (`Bash(*perm-shadow-apply.sh)`): run it exactly,
with no redirection. `stack-md apply|remove` writes into every `/path/to/your/project/projects` root, including trees other sessions own: only the user
runs it; Claude never runs it unasked, not even to test (`status` is the only form to run on its own).

## `apply-parked` — land the parked patches (framework-health 4.4)

A change to a protected file made while edits were parked ships as a patch in `~/.claude/projects/<slug>/<run>/parked/`, headed by
`Parked-Patch:` / `Requires:` / `Tests:` / `Post-apply:` lines. Executor: `bash ~/.claude/bin/apply-parked.sh list|check|apply …`
(tests `bin/tests/apply-parked.test.sh`).

1. `list` (read-only): every patch in `LC_ALL=C` order with its state — `pending` (`(after X)` when its own hunks apply but its Requires has not landed yet), `waits on X` (its hunks
   build on X, so it applies once X has; an ordering, not a fault — `check` simulates the whole sequence), `applied`
   (moved to `parked/applied/`), `CONFLICT` or `INVALID`.
2. `check` (read-only): simulates the whole sequence on a temp copy; reports OK / FAIL per patch. Nothing is written.
3. `apply` without `--yes`: validates (headers, paths under `~/.claude/` only, Requires order, Tests files, no symlinked target),
   simulates, prints the plan, exits 4. Show it via `AskUserQuestion`; on approval re-run with `--yes`.
   It backs up every target (`~/.claude/backups/apply-parked-<ts>/`), applies in order, runs each listed suite once, and on a red or
   timed-out suite restores every file byte-for-byte (exit 1, patches stay parked). Green moves the patches to `parked/applied/` and
   prints each `POST-APPLY` line — run those next (they are usually `!` lines) — and a suggested pathspec commit. It never commits.
4. It refuses (exit 5) while the step-4.6 protect rules `Bash(*apply-parked.sh apply*)` and `Bash(*apply_parked*)` (exactly these strings; the module name catches
   `python3 -m apply_parked`) are not both in
   `config/permission-rules.json` `protected`, because until then this command rewrites protected files without a prompt. `--unprotected`
   is for the ONE landing that installs them; say so in the confirm. A target with uncommitted changes is refused too (commit or stash first).

## `review` — ratify what a bypass let through (framework-health 5.6)

The bypass-review queue (`logs/bypass-review.ndjson`, docs/SPEC.md §2.19) holds what a bypassed gate or an unattended window let
through without asking, grouped by gate + signature. Only the user ratifies it: `ack|reject` refuse (exit 5) unless their three rules
are `protected`, and while an unattended window is live. This section is self-contained because `/next`'s *Review now* reads it as a
file (this skill is `disable-model-invocation`). A *Review now* answer is consent to START a review, never to acknowledge anything:
each write needs the user's answer in its round AND the protected prompt on the call that runs it.

1. **Snapshot** (writes nothing but the queue import and a temp file). Note the printed snapshot path; every later step uses it, so
   events that arrive mid-review stay unreviewed:

```bash
# REVIEW_SHOW — import, snapshot the groups, number the ones with unreviewed events or a standing REJECT (risky first, as `list` sorts them)
SNAP=$(mktemp "${TMPDIR:-/tmp}/bypass-review.XXXXXX") && bash ~/.claude/bin/bypass-review.sh import >/dev/null \
  && bash ~/.claude/bin/bypass-review.sh list --json > "$SNAP" && python3 - "$SNAP" <<'EOF'
import json, sys
g = [x for x in json.load(open(sys.argv[1])) if x['unreviewed'] > 0 or x['verdict'] == 'reject']
print('snapshot %s: %d group(s) to review' % (sys.argv[1], len(g)))
for i, x in enumerate(g):
    print('[%d] %s %s  %d unreviewed, %d risky  (events %s .. %s)%s' % (i, x['gate'], x['signature'], x['unreviewed'], x['risky'], x['first'], x['last'],
                                                                      '  REJECTED earlier' if x['verdict'] == 'reject' else ''))
    for s in x['samples']:
        print('      ' + s)
EOF
```

2. **One round = at most 4 groups**, in snapshot order, one `AskUserQuestion` call with one question per group: header = the gate code,
   question = `[n] <signature> — <u> unreviewed, <k> risky, <first> .. <last>` plus the samples, labelled *the OLDEST 3 unreviewed* (an OK
   covers every event up to `<last>`, newer than any sample shown). Options: **OK** (acknowledge: expected, keep the bypass as it is),
   **Reject** (should not have gone through), **Later** (no write). The auto-added *Other* ends the review after this round. A group marked
   *REJECTED earlier* has nothing new: OK here clears the standing reject once its source was narrowed (its ✗ and grid warning go away). Never
   recommend OK for a risky group.
3. **Build the lines** from the answers (Later = left out). It prints them and runs nothing; a bad index or verdict prints nothing:

```bash
SNAP=/path/printed/in/step/1 ANSWERS='ack 0;reject 2'   # REVIEW_BUILD — one "<ack|reject> <n>" per answered group, ';'-separated
python3 - "$SNAP" "$ANSWERS" <<'EOF'
import json, shlex, sys
g = [x for x in json.load(open(sys.argv[1])) if x['unreviewed'] > 0 or x['verdict'] == 'reject']
out = []
for a in filter(None, (s.strip() for s in sys.argv[2].split(';'))):
    v, n = (a.split() + [''])[:2]
    if v not in ('ack', 'reject') or not n.isdigit() or int(n) >= len(g):
        sys.exit('bad answer %r (want "ack N" or "reject N", N < %d): nothing printed' % (a, len(g)))
    x = g[int(n)]
    out.append('bash ~/.claude/bin/bypass-review.sh %s %s --upto %s' % (v, shlex.quote(x['group']), shlex.quote(x['last'])))
print('\n'.join(out))
EOF
```

4. **Run the printed lines verbatim** in ONE Bash call, followed by `bash ~/.claude/bin/bypass-review.sh summary`. Never put them in a file and
   run the file: the protect rule `Bash(*bypass-review.sh ack*)` matches the command text, so a `bash file` call would write without the
   prompt that is the consent. Exit 5 = refused (protect rules missing, or an unattended window is live): stop and show the message.
5. Next round from the same snapshot, until the groups run out or the user picks *Other*. Then `summary` once more.

**What "risky" means** (`risk()` in `bin/lib/bypass_review.py`, pinned by `bin/tests/bypass-review.test.sh`): an event counts as risky
when it was ALLOWED and scored HIGH. HIGH = a protected ask rule let through; a Bash command with `rm -r`, `git reset --hard|push|clean -f|
checkout --`, `chmod|chown -R`, `dd`, `mkfs`, `shred`, `truncate` or a truncating redirect; a settings / `~/.claude/{hooks,state,config}` /
gates-bypass / permission-rules / unattended / apply-parked path or a credential-shaped one (`.ssh/`, `id_*`, `.env`, `.pem`, `.netrc`,
`.aws/`, `credentials`, `.gnupg`); an Edit/Write outside the session cwd. MEDIUM = any other write or allowed ask; LOW = reads, Stop skips.

**Reject records; it tightens nothing.** The statusline keeps `✗N` (a rejected group waiting for a tightened rule) until the user
narrows the source. Name the path for the group's gate, and do NOT run it as part of the review:
`fw` → `arm fw` for that tree, or an `--except` on the rule that grants it; `unattended` → end the window or switch it to `--mode park`;
`perm` → the engine rule (`config/permission-rules.json`, via `/gates-bypass engine` or a parked patch); `pb` (push-batch guard) → push with a `push.reason` only when it is one, or
`/gates-bypass hook push-batch unregister`; any other gate family → `arm <code>`. Reject has no standing relief: a group that keeps
recurring stays risky in the grid until its source is narrowed (no standing approvals, Decision 76).
A later `ack` of the same group supersedes a `reject` (the last verdict written wins; `upto` is the latest of the group's reviews).
`compact` (drops events already reviewed, never an unreviewed one) is housekeeping: offer it separately, with its own confirm.

## `unattended` — the time-boxed park/allow window (plan unattended-window, user ruling 2026-10-01)

```
/gates-bypass unattended on --mode park|allow --for 90m|10h|2d [--path /abs/root [--except /abs/root/sub]...] [--no-ask]
/gates-bypass unattended off [--all | --path /abs/root | --global]
/gates-bypass unattended status
```

**Several windows (row 26z, user ruling 2026-10-15).** The marker holds up to 32 windows, one per path (no `--path` = the global one). `on` adds a
window or replaces the one at that path; the most specific live window covering the session's cwd applies (a deeper `allow` inside a `park` tree is
allowed there; the global window ranks last; at the same path park beats allow). `off` and `off --all` end every window, `off --path P` / `off --global`
end one. `on` and `status` name each deeper live window that overrides another. A path at `$HOME` or above is refused (a window there covers every
project: use the global window), and so is one not in normal form (a `.` or `..` component, a doubled `/`). ONE bad field voids the whole marker: no window applies anywhere, the statusline shows `UNATTENDED(INVALID)`, and
gates-status warns.

A window makes an overnight run stop waiting on permission dialogs. **park** = every would-be ask becomes a logged DENY ("parked - needs a human"); **allow** = asks proceed,
EXCEPT the core self-protection set (protected Edit rules, anything NAMING `unattended`, any command that writes a bypass sentinel or the rules file, whatever the verb (row 26r)), which stays parked (it matches the command text only: a script file or interpreter that does not name the window gets past it, so the window is for a trusted run, not a sandbox); `AskUserQuestion` is NEVER touched unless you pass `--no-ask` (opt-in; then it is denied: "take the recommended option, log it as ASSUMED"). Deny / floor / settings denies are untouched; the window is path-scoped when `--path` is given and ends at expiry.
Detail: `docs/SPEC.md` "Unattended window". Start with **park** for a first run; `/gates-bypass --run` (autonomous mode) belongs with a window, because the ask-human gate
(`ah`) needs an `AskUserQuestion`, which a window leaves alone unless `--no-ask`.

**Route (user ruling 2026-10-13, framework-health row 16b): always the executor** for `on`/`off`, `bash ~/.claude/bin/unattended.sh on|off`, in every mode (`status` stays a Read). Its
command hits a protected Bash ask, and that dialog IS the consent: Bash asks still show a real dialog under bypassPermissions, while an Edit/Write ask
there is applied silently, so the engine now DENIES it. The Write/Read steps below are only the fallback for a session with NO Bash tool; under
bypassPermissions that Write is denied (correct: no consent is possible there). This skill is user-only (`disable-model-invocation`): never run this
section from a model-initiated call.

1. Resolve MODE, DURATION and optional PATH from the words; ask (`AskUserQuestion`) for anything missing. **Never default a duration.** Duration is 1 minute to 7 days:
   convert to whole SECONDS (`90m` = 5400). `--path` must be an absolute directory that is not `/`, `$HOME` or a parent of `$HOME`.
2. `on`: show the exact command and ask for confirmation (`AskUserQuestion`), then run `bash ~/.claude/bin/unattended.sh on --for <DUR> --mode park|allow
   [--path P] [--no-ask]` (the dialog that follows is the consent). No shell: first **Read** the marker; when it holds a `windows` list, or a
   window with a future `until` at another path, **refuse**: a Write replaces the whole file and would end every other window (the skill has no clock,
   and `for` is only valid in the single form) - give the user the executor line instead. Otherwise **Write** `~/.claude/state/unattended.json` (absolute path) with exactly
   `{"for": <seconds>, "mode": "park"|"allow"}` plus `, "path": "/abs/root"` when scoped, plus `, "no_ask": true` only when `--no-ask` was given (never by default). Do NOT write `until`: you have no clock, and the permission engine stamps
   `until = <marker file mtime> + for` on the first call it sees (a marker written long before is already expired, never a fresh window). **While a window is live the executor (and the Write) is DENIED** (core self-protection: anything naming `unattended`), so a live window cannot be replaced or ended from here: tell the user to run `! bash ~/.claude/bin/unattended.sh off` or wait for expiry.
3. `off`: only possible when NO window is live (see the note above); otherwise answer with the `!` command. Run `bash ~/.claude/bin/unattended.sh off`
   (or `off --path P` / `off --global` for one window). No shell: **Write** `{"until": 0, "mode": "park"}` to the same file (an expired marker is no
   window); it ends EVERY window, so say so when the marker held a list.
4. `status`: **Read** `~/.claude/state/unattended.json` (never a Bash call: one naming `unattended` is denied while a window is live, exactly when
   status matters, and asks otherwise) and report each window: ACTIVE when `until` is an integer in the future (shows time left; if only `for` is
   present it is pending: it starts on the next tool call), else INACTIVE; for a `windows` list, also which one applies at the cwd (the most specific
   covering it). A marker breaking any rule below is INVALID: say so - no window applies anywhere. Then **Read** the tail of `~/.claude/logs/unattended-parked.ndjson` (absent = nothing parked) and list the
   last parked calls (`ts tool cmd`) so the user can see what a run could not do.
5. Report the result in two lines: window state, and what it will and will not do (park vs allow). Never claim a window is active before the engine has stamped `until`
   (re-Read the marker after the next tool call if the user wants proof).

Strictness the engine enforces (`bin/lib/unattended.py` read_marker; a bad marker is NO window anywhere): regular non-symlink file; one window, or
`{"windows": [...]}` with nothing else at the top and at most 32 entries holding only `until`, `mode`, `path`, `no_ask`, `except` (a non-empty list of
absolute normal-form paths strictly inside `path`, `*` = one segment; a global window takes none; row 26zu); an integer `until` at most
7 days ahead (or, in the single form only, an integer `for` 60..604800); `mode` park|allow; `no_ask` true|false; `path` absolute and not `/`, `$HOME`
or a parent of it. A window applies when it is live, its path covers the session's cwd and its except does not; inside an except only a strictly
deeper live window applies (a global or shallower one never fills the hole - the rules' model, user ruling 2026-10-17 01:02).

## `models` — the model-policy overrides, every level (plan model-policy-bypass, user ruling 2026-10-01)

```
/gates-bypass models status
/gates-bypass models skills as-is [NAME|*]      /gates-bypass models skills off [NAME|*]
/gates-bypass models agent <label|*> <model>    /gates-bypass models agent <label|*> off
/gates-bypass models agent-type <type|*> <model>    /gates-bypass models agent-type <type|*> off
/gates-bypass models hook  <class|*> <model>    /gates-bypass models hook  <class|*> off
/gates-bypass models reset                      (remove every override)
```

The override table `~/.claude/state/model-overrides.json` is YOUR standing answer to the model policy, at four levels:
- **skills** — `{"<skill>": "as-is"}` or `{"*": "as-is"}`: that skill (or all) runs on the session model and is never stopped for a weaker one.
- **agents** — `{"<slug>": "<model>"}` or `{"*": "<model>"}` (every agent without its own entry): the model a spawner skill uses for that agent when it does not ask (autonomous mode), or shows as the recommended choice (spec mode).
  The key is the agent label from the skill's table, SLUGGED: lowercase, spaces to hyphens (`Priority ranker` -> `priority-ranker`); labels with spaces are invalid keys. `agents."*"` is also the hook's default when `agent-types` has no `*`.
- **agent-types** — `{"<subagent_type>": "<model>"}` or `{"*": "<model>"}`: enforced on EVERY Agent call by `hooks/agent-model-override.sh`. A specific entry FORCES that model on every call of that type (over a spec-mode answer too); `*` (else `agents."*"`) applies only to calls that carry no explicit model, and beats a frontmatter `model:` pin. Aliases `sonnet`/`opus`/`haiku` (or `as-is`) only. The key is the harness agent type (`general-purpose`, `Explore`, a project agent's name), never a label.
- **hooks** — `{"<class>": "<model>"}` or `{"*": "<model>"}` (every class without its own entry) for headless calls that cannot ask: `session-remember.bulk`, `session-remember.consolidate`, `precompact-handoff`.

**Route (user ruling 2026-10-13, framework-health row 16b): always the executor**, `bash ~/.claude/bin/model-override.sh list|set|unset`: `set` and
`unset` hit a protected Bash ask whose dialog is the consent (under bypassPermissions an Edit/Write ask is applied silently, so the engine denies the
Write). The Read/Write steps below are only the fallback for a session with NO Bash tool. This skill is user-only; never run it from a model-initiated call.

1. Resolve LEVEL, NAME and VALUE from the words. For anything missing ask (`AskUserQuestion`): level (skills / agents / agent-types / hooks / reset), then the name, then the value (skills: only `as-is`
   or off; agents and agent-types: `as-is` (= inherit the session model), an alias `opus`/`sonnet`/`haiku`, or off; hooks: `as-is` (= keep the built-in default), a model id such as `claude-haiku-4-5`, or off). Never guess a model.
2. Run `bash ~/.claude/bin/model-override.sh list` (no shell: **Read** `~/.claude/state/model-overrides.json`). Absent = `{"version": 1}`. If the file exists but is not valid by the rules below, say so and offer `reset` instead of editing it.
3. Apply the change in your head: set or remove one key (`reset` = `{"version": 1}`). Validate the WHOLE result, because one bad field invalidates the file and then NOTHING applies:
   top level has only `version` (= 1), `skills`, `agents`, `agent-types`, `hooks`; every key matches `^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$` (`*` is allowed in every section; a specific key beats `*`); every skill value is exactly `as-is`;
   every agents/agent-types/hooks value matches `^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$` (`as-is` matches). Drop an empty section instead of writing `{}` only if you like; an empty object is valid.
4. Show the resulting table and ask one confirm (`AskUserQuestion`: Apply (Recommended) / Cancel). `as-is` for `*` removes the weaker-model safety net in interactive sessions too: say so.
5. Run `bash ~/.claude/bin/model-override.sh set <skill|agent|agent-type|hook> <name> <value>` or `unset <kind> <name>` (one call per changed key; `reset` =
   `unset` for every key `list` printed, one dialog each). It validates and writes atomically. No shell: **Write** the whole file (valid JSON, no comments,
   newline at the end; never through a symlink); that Write is a protected edit, denied under bypassPermissions. While an unattended window is live both
   routes are allowed in `allow` mode (the override table is deliberately not core).
6. `status`: run `model-override.sh list` (no shell: **Read** the file) and print it grouped by level, plus the resolved mode (autonomous when an `ah` rule covers this directory; see the spawner skills' Model ask line).
   `bash ~/.claude/bin/model-override.sh lint` checks the table; the file format is identical on both routes.

---

# Reference

**Ten families**, the resolver's registry (`_bypass_file_for` in `hooks/bypass-resolve.sh`; the grid reads the list from there):

| Family | Code | Kind | Sentinel filename | What it controls |
|---|---|---|---|---|
| ask-human gate | `ah` | gate | `ask-human-gate-bypass` | Task categorization + AskUserQuestion gate; decides the mode |
| question guard | `qg` | gate | `ask-human-question-guard-bypass` | Stop-hook block on a free-text `?` without AskUserQuestion |
| completion guard | `ac` | gate | `advisor-completion-guard-bypass` | Stop-hook Phase 6C `advisor()` requirement |
| prework guard | `pw` | gate | `advisor-prework-guard-bypass` | PreToolUse Phase 3C `advisor()` requirement |
| autonomous-3c | `auto3c` | badge | `autonomous-3c-bypass` | Statusline badge only; does not make a session autonomous (`ah` does) |
| bash firewall | `fw` | gate | `ask-bash-firewall-bypass` | The v3 boundary gate on every Bash command (friction only, see below) |
| permission rules | `perm` | gate | *(none — rules only)* | The permission engine's ask rules; no sentinel, no session scope |
| expertise gate | `eg` | gate | `expertise-gate-off` | The Agent-call expertise gate (grant = the gate is off) |
| keep-going | `kg` | enable | `keep-going` | The Stop hook that keeps a session working (grant = ON) |
| confident picks | `cf` | enable | `confident-pick` | Mid-task questions follow the tiered rule, in either mode (grant = ON; row 26zg, below) |

Every family except `perm` can be granted from **four** independent sources; `perm` from rules only:

```
global   ~/.claude/state/<filename>                        (legacy sentinel, presence = granted)
project  ~/.claude/projects/<cwd-slug>/state/<filename>    (legacy sentinel, EXACT cwd match only)
session  ~/.claude/run/<filename>-<session_id>             (legacy sentinel, presence = granted)
rule     ~/.claude/state/gates-bypass-rules.json           (path rules: recursive + except + expiry + level)
```

**These are an independent OR, not a precedence chain.** Any one of them granting is enough; nothing outranks anything. (An env
var is a separate, blunter switch that exits the hook first.) If you see a `>` chain in any doc describing these scopes, it is stale.

**The `fw` family lifts FRICTION, not the firewall** (2026-09-23). Any source granting `fw` lifts only boundary asks (writes outside
the project root but inside the rule) and NET writes with literal data. Credential/host denies, Claude self-mod paths, `.env` writes,
`protected[]`, unresolvable targets, nested shells, `xargs` and non-literal command names still prompt or deny inside a bypassed tree.
The only full off-switch is `CLAUDE_BASH_FIREWALL_OFF=1`.

All four are resolved by **one shared function**, `bypass_applies` in `hooks/bypass-resolve.sh`, which every guard hook, the
statusline and the grid use — a status view that disagreed with the gate would be worse than none.

### Why rules exist — the legacy project sentinel is an EXACT cwd match

`projects/<cwd-slug>/state/<file>` is keyed on the payload `cwd` with `/`→`-`. A sentinel for `/path/to/your/project/projects/twes-in` therefore does
**not** apply when the shell sits in `/path/to/your/project/projects/twes-in/api`. That caused three documented stalls (twes-in 2026-09-15 and
2026-09-17, invoiceninja 2026-09-09) and the failure is **self-sealing**: the armed gate blocks the `cd` that would repair it.
A rule names an **absolute path** (never a slug — `/path/to/your/project/projects/twes-in`, `/path/to/your/project/projects/twes/in` and `/path/to/your/project/projects-twes/in`
all slugify identically) and applies recursively to everything beneath it.

### The rules file

`~/.claude/state/gates-bypass-rules.json` (written by the executor only):

```json
{ "version": 1,
  "rules": [
    { "path": "/path/to/your/project/projects/twes-in",
      "recursive": true,
      "guards": ["ah","fw","qg","ac","pw"],
      "except": ["/path/to/your/project/projects/twes-in/api/vendor",
                 "/path/to/your/project/projects/twes-in/web/node_modules"],
      "expires": "2026-10-15T06:00:00Z",
      "note": "overnight autonomous runs" },
    { "global": true, "guards": ["fw","perm"], "level": "total", "expires": "2026-10-20" } ] }
```

| Field | Required | Meaning |
|---|---|---|
| `path` | yes (or `global`) | Absolute path; `/` refused. Matching is **component-wise**, so `/a/twes-in` never matches `/a/twes-in-api` |
| `global` | yes (or `path`) | `true` = every cwd and target; takes no `path` / `recursive` / `except` |
| `recursive` | no | `true` = the path and everything under it (the executor always writes `true`); `false` = that directory only |
| `guards` | yes | Which families this rule grants, by code. A `kg` rule holds only `kg` (no except, no level) |
| `except` | no | Subtrees where every family stays **armed**. An entry may contain `*`, matching **exactly one path segment** |
| `expires` | no | `YYYY-MM-DD` (alive through that local day) or `YYYY-MM-DDTHH:MM:SSZ` (until that UTC instant); then the gate re-arms |
| `level` | no | `normal` (absent) or `total`; meaningful for `fw` / `perm` only |
| `note` | no | Free text |

**`except` is never populated automatically** — a directory is excepted only because someone typed it. **`*` is one path segment,
never more**: `/c/projects/*/state` matches `/c/projects/-abc/state/x` but NOT `/c/projects/a/b/state` (anchored regex with `[^/]*`,
not a shell glob, which crosses `/`). Entries without `*` stay literal. Globs are allowed **only** in `except`; one in `path` is a lint error.

### What `except` can and cannot do

An except is a **hole in its own rule** (row 26zu, user rulings 2026-10-17 01:02): the rule grants none of its families inside it. The point
it is matched on is the operation's **target** when the guard has one, else the session **cwd**:

| Family | Matched on | Notes |
|---|---|---|
| `pw` prework guard | target | PreToolUse `Edit\|Write` carries `file_path` |
| `fw` bash firewall | each target | its tokeniser resolves every target; one excepted target taints the command; at `total` too |
| `ah` ask-human gate | target for file-shaped tools, else cwd | Edit/Write/Read/NotebookEdit pass `file_path`; Bash/Agent/Glob/Grep pass none |
| `perm` permission rules | target (level: cwd) | the engine asks inside it at normal and total; Bash reaches it via the union below |
| `qg` / `ac` Stop guards, `auto3c`, `eg`, `kg`, `cf` | cwd | a session whose cwd is inside the hole is armed / off there |

**Only a deeper rule fills a hole.** Inside an except, a live rule whose path is STRICTLY deeper than the excepting rule, covers the cwd and
reaches the point (its own except does not match) decides there with its own families, level and except: `/path/to/your/project --except /path/to/your/project/projects`
leaves pdfturbo's own rule in charge of pdfturbo. A same-path or shallower rule (a global one) never fills the hole; with no deeper rule the
point is armed for every family. The `on` plan names every deeper rule inside each except (`NOTE: inside the except P, the deeper rule at Q decides`).

**A grant is family-scoped; an `except` is not.** A rule only ever grants the families in its own `guards[]`, but its `except` list
**protects that subtree against every family**: a `perm` blacklist on `api/vendor` re-arms the firewall there too. With family-scoped
excepts, a blacklist made the Edit tool prompt while `sed -i .../api/vendor/foo.php` stayed silent. On the Bash path an except FORCES
an `ask` on any command naming a path inside it — every verb, reads included. Only statically resolved literal paths count, so
`grep -r x .` stays silent. The union lives in the resolver (`bypass_any_except`, `bypass_except_hit`, batched as `bypass_batch`); **both
are required**, and the direction of error is safe by construction: the union can only add friction. The one thing it no longer does (row 26zu)
is override a strictly deeper rule that reaches the target.

Two more rules the resolver enforces, both found as live fail-opens during review: **a rule bounds its target as well as its cwd**
(standing in a bypassed project does not bypass an edit to `/etc/passwd`), and **for the firewall one excepted target taints the whole
command** (`touch src/a vendor/b` asks; an unresolvable `$VAR` target keeps the gate armed).

### Strict and loud

One malformed rule invalidates the **entire file** and nothing is granted — a typo must never silently narrow protection. The alarm:
`⚠⚠ RULES-INVALID` on statusline line 2, an `ERROR` line in `~/.claude/logs/hooks-errors.log` (once per change to the file), a warning
in `gates-status.sh`, and `/gates-bypass --lint` names the rule and the field. Two rules declaring the same `path` for the same guard
are also an error (which one wins is undefined).

### Known limits

- `gates-status.sh` takes tens of seconds on a saturated host (one resolver call per family); `bypass_batch` exists in `hooks/bypass-resolve.sh` but the grid does not use it yet (not scheduled: step 8 closed without it).
- The expertise Agent gate's own on/off/status lives in `/expertise-gate status|on|off`; its scopes are this skill's `eg` family.
