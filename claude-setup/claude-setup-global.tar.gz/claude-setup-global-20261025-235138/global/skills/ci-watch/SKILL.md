---
name: ci-watch
description: Use right after a git push, or before claiming a lane is "covered by CI". Pins the full SHA once, finds the run(s) for it, waits on that fixed SHA with a bounded wait, reads the failing step, separates infra failures (quota, runner runtime) from code, and reports last-green per workflow.
user-invocable: true
args: "[<sha>] [--coverage]"
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /ci-watch — after a push: watch the right CI run and read the result honestly.
>
> Usage: /ci-watch [<sha>] [--coverage]
>   <sha>       the pushed commit (default: HEAD, resolved ONCE to the full sha)
>   --coverage  report last-green per workflow instead of watching one push
> Needs: gh (GitHub CLI), authenticated. Without it the skill says so and stops.
> ```

---

In autonomous mode Claude commits every verified step and pushes in batches: every 30 unpushed commits, at a
milestone end, and before any stop or hand-off (CLAUDE.md Rule 10, rulings 2026-10-04 and 2026-10-08: count 30). Run this skill after each
of those pushes; with batches, one red push hides up to 30 commits, so an unwatched CI is the gap: 12 consecutive red pushes once went unnoticed (scout, found 2026-09-05), and a monitor armed
on a padded, invented SHA ended "exit 0, no output" having watched nothing (twes-in). Distilled from 7
memories across 5 projects.

## 0. Preconditions

`command -v gh && gh auth status` — absent or unauthenticated: say "CI not watched: gh unavailable"
in the report and stop. Never report a push as CI-green without having read a run.

## 1. Pin the SHA once

```bash
SHA=$(git rev-parse HEAD)    # or the <sha> argument — FULL 40-char sha, resolved once, BEFORE any loop
```
Never type, shorten or pad a sha — `gh run list --commit 15b332b` returns an empty list, and a padded
one matches nothing forever. Never call `git rev-parse HEAD` inside a poll loop (HEAD moves when you
commit the next step).

## 2. Confirm the push landed

The push output has a `To <host>:` line, and `git rev-list --count origin/<branch>..<branch>` is `0`.
Otherwise there is nothing to watch — see `/long-run` step 8.

## 3. Find the run(s)

```bash
gh run list --commit "$SHA" --json databaseId,workflowName,status,conclusion,createdAt
```
Empty for more than ~3 minutes is a FINDING, not "slow CI": the sha is wrong, the workflow is
path-filtered and skipped this change, Actions is disabled, or the push did not land. Say which.

## 4. Wait — bounded, on the fixed SHA

One notification: a Bash `run_in_background` waiter that exits on every terminal state, with a cap:
```bash
for i in $(seq 1 90); do                       # ~30 min at 20 s
  s=$(gh run list --commit "$SHA" --json status,conclusion,workflowName)
  jq -e 'length > 0 and all(.status == "completed")' <<<"$s" >/dev/null && { echo "$s"; exit 0; }
  sleep 20
done; echo "TIMEOUT waiting for CI on $SHA"; exit 1
```
Or `gh run watch <id> --exit-status` for a single known run. A timeout is reported loudly, never as
success.

## 5. Read a failure

- Completed as `failure` in 2–4 s with no steps and no log → **quota/billing** (exhausted Actions
  minutes), not the code. Report it as infra.
- Otherwise `gh run view <id> --log-failed` and read the failing step.
- Passes locally, fails in CI → diff the runtimes before touching code: language version, PCRE, ini,
  Node, env vars (reproduce with the workflow's exact flags, e.g. its `RUSTFLAGS`).

## 6. Coverage claims (`--coverage`)

"Covered by CI" is a claim about the workflow file, not about CLAUDE.md's summary of it:
- Read `.github/workflows/*.yml` for what actually runs.
- Per workflow: `gh run list --workflow <file> --status success --limit 1 --json headSha,createdAt`.
  A lane (job/step) added AFTER that date has never gone green — it is not coverage yet.

## Report

`CI <sha7>: <workflow> <conclusion> (<duration>) …` per workflow, the failing step if any, infra vs
code, and for `--coverage` the last-green date per workflow. The Rule 6 evidence table cites this line.

$ARGUMENTS
