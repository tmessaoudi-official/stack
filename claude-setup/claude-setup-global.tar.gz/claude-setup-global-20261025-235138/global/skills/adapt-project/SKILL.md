---
name: adapt-project
spotlight: true
description: Use when a project has unresolved ADAPT markers after installing a bundle template. Use after /install to probe the project and fill all <!-- ADAPT: --> blocks automatically.
user-invocable: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /adapt-project — Post-import command: explore this project deeply and fill all ADAPT markers left by /install. Safe to re-run — if no markers remain, exits without doing anything.
>
> No flags — invoked without arguments.
> ```

---

# /adapt-project — Project Adaptation

Post-import command: explore this project deeply and fill all ADAPT markers left by `/install`.
Safe to re-run — if no markers remain, exits without doing anything.

---

## Phase 0: Guard — scan before doing anything

Run these two checks:

```bash
grep -rn '<!-- ADAPT:' CLAUDE.md .claude/ 2>/dev/null
find .claude/hooks/ -name '*.sh.template' 2>/dev/null
```

Also verify global infrastructure is present before proceeding:
```bash
ls ~/.claude/BLAST-RADIUS.md 2>/dev/null || echo "MISSING: run /install first"
```
`~/.claude/BLAST-RADIUS.md` is required for risky-operation pre-flight checks. If missing, stop and tell the user to run `/install` before adapting.

Also check for active plan files from prior sessions (Rule 17):
```bash
ls docs/plans/*.plan.md 2>/dev/null
```
If any exist, read them and announce — prior sessions may have recorded decisions that affect how adaptation should proceed.

**Before checking the counts**, also scan for CONFIGURE markers (global template markers, filled manually — NOT by this command):

```bash
grep -rn '<!-- CONFIGURE:' CLAUDE.md .claude/ 2>/dev/null
```

**If CONFIGURE markers are found**: stop immediately and explain:
> "Found `<!-- CONFIGURE: ... -->` markers. These are **global template markers** — they must be filled manually by the team admin. This command only fills `<!-- ADAPT: ... -->` markers (per-project templates). Do not run `/adapt-project` on global template files."

**If both ADAPT check and `.sh.template` check return empty** (zero ADAPT markers, zero template files):
→ Reply: "No ADAPT markers found — this project config is already adapted. Nothing to do."
→ Stop.

**Otherwise**: report a summary before proceeding:
```
Found:
  • N ADAPT markers across M files:
      CLAUDE.md           — X markers
      .claude/settings.json — Y markers  (if any)
      .claude/skills/     — Z markers    (if any)
      .claude/agents/     — W markers    (if any)
  • K hook template(s) pending activation (.sh.template files)
```

---

## Phase 1: Deep exploration — 4 parallel Explore agents

Launch all four agents simultaneously. Brief each agent to return a concise structured report.

> **ask-human gate:** these subagents share the session_id, but the `SubagentStart`/`SubagentStop`
> hooks now auto-bypass the gate for active subagents, so they will not be blocked. Fallback if you
> ever see them stall on the gate: ask the user to run `/gates-bypass` (a path rule for the project
> root, optionally with an expiry) — never hand-`touch` a sentinel: the legacy per-project file
> matches the exact cwd only, and every bypass change goes through `/gates-bypass` (global CLAUDE.md).

**Agent 1 — Tech stack**
Probe: `package.json`, `composer.json`, `Gemfile`, `Cargo.toml`, `go.mod`, `pyproject.toml`,
`requirements.txt`, `*.csproj`, `.nvmrc`, `.ruby-version`, `.python-version`, `.tool-versions`,
`Dockerfile*`, `compose*.y*ml`, `docker-compose*.y*ml`.
Report: primary language + version, framework + version, package manager, notable dependencies.

**Agent 2 — Project structure**
Probe: top-level directory tree (2-3 levels), `README.md`, `docs/`, `CONTRIBUTING.md`,
main entry points, config files, key source dirs.
Report: what the project does (1 sentence), key directories with their purpose, main entry point(s).

**Agent 3 — CI/CD + scripts + workflows**
Probe: `.github/workflows/`, `.gitlab-ci.yml`, `Jenkinsfile`, `Makefile`, `bin/`, `scripts/`,
`.pre-commit-config.yaml`, `taskfile.yml`, `justfile`.
Report: build command, dev-server command, deploy command, common one-liners.

**Agent 4 — Testing + quality**
Probe: test directories, `jest.config.*`, `pytest.ini`, `phpunit.xml`, `.rspec`, `go test`,
`.eslintrc*`, `.pylintrc`, `rubocop.yml`, `shellcheck` usage, `prettier.config.*`,
`black` config, `shfmt` usage, `rustfmt.toml`.
Report: test command(s), linter(s) with file extensions, formatter(s) with file extensions.

---

## Phase 2: Phase gate — mandatory stop

Synthesize the four agent reports into a one-screen summary:

```
ADAPT SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Detected stack:   [language+version] / [framework] / [package manager]
Test command:     [command]
Linter(s):        [tool] → [ext]
Formatter(s):     [tool] → [ext]
Docker:           [compose services found / "none: rows will be TODO"] (omit only for the /path/to/your/project project itself, cwd = /path/to/your/project; projects under /path/to/your/project/projects/* keep it)

What will be filled:
  CLAUDE.md › What This Project Is          (from README + stack detection)
  CLAUDE.md › Architecture                  (from dir structure probe)
  CLAUDE.md › Common Workflows              (from Makefile/scripts/CI)
  CLAUDE.md › Run everything in Docker      (from Dockerfile/compose probe)
  CLAUDE.md › Testing & Verification        (from test probe)
  CLAUDE.md › File Layout Quick Reference   (from structure probe)
  CLAUDE.md › Gotchas & Pitfalls            (from README warnings / .env.example)
  CLAUDE.md › Credentials & Stateful Data   (from .env.example / config files)
  CLAUDE.md › Debugging section             (inferred from primary component)
  CLAUDE.md › Claude Code Tooling lists     (from .claude/ inventory)
  CLAUDE.md › Claude Code Configuration     (from .claude/ inventory)
  .claude/hooks/lint-on-write.sh.template   → activate as lint-on-write.sh  (if linter found)
  .claude/hooks/format-on-write.sh.template → activate as format-on-write.sh (if formatter found)
  .claude/settings.json                     (add detected tools to allow list)
  [any other ADAPT markers found in Phase 0]

```

Invoke the `ask-human` skill: question 'Proceed with adaptation — fill all ADAPT markers listed above?', options: 'Yes, fill everything (Recommended)' / 'No, abort — exit without changes'.

**Hard stop** — do not write anything until the user confirms. If 'No': exit without changes.

---

## Phase 3: Fill all ADAPT markers

Work through each file systematically. For every `<!-- ADAPT: ... -->` block, replace it with
project-specific content derived from the exploration above. Never leave a partial fill.

### CLAUDE.md — section by section

**`## What This Project Is`**
Write 2–5 sentences: what the project does, platform/runtime, key tech choices,
single-dev vs team, release cadence. Source: README first paragraph + stack detection.

**`## Architecture`**
Describe key components and their relationships. A Markdown table or annotated list works well.
Source: structure probe + CI/CD probe (services, modules, layers). If microservices found,
map service → purpose. If monolith, map top-level dirs → responsibility.

**`## Common Workflows`**
List the 5–10 most-used commands as bash one-liners with inline comments:
```bash
make test          # Run test suite
make dev           # Start dev server
# ...
```
Source: CI/CD probe. Prefer Makefile targets > package.json scripts > bare CLI commands.

**`## Run everything in Docker`** (every project except `/path/to/your/project`; user ruling 2026-10-02)
A table `command | service | what it replaces` covering tests, lint, console, dependency install,
every gate and every hook-run tool, plus one line: the host needs Docker and nothing else.
Source: Dockerfile/compose probe. A stage with no compose service gets the row
`TODO: not containerised`; list those rows in the completion report and point to
`/dockerize-project --dry-run`. In `Common Workflows` and `Testing & Verification` give the
containerised command, not the bare host tool. Skip this section only for the `/path/to/your/project` project itself (cwd is `/path/to/your/project`); a project under `/path/to/your/project/projects/*` keeps it.

**`## Testing & Verification`**
Include: how to run tests, what "passing" looks like, test types (unit/integration/E2E),
any coverage thresholds. Source: test probe + CI YAML.

**`## File Layout Quick Reference`**
Annotated 2-level tree. Focus on non-obvious directories.
Source: structure probe. Omit `node_modules/`, `.git/`, build output dirs.

**`## Gotchas & Pitfalls`**
3–8 project-specific traps. Look for:
- README "Note:" / "Warning:" / "Important:" sections
- `.env.example` keys with non-obvious values
- CI retry/timeout hacks that hint at flaky areas
- Known workarounds in commit history (if accessible)

**`## Credentials & Stateful Data`**
Where credentials/keys/data live. Source: `.env.example` key names, config file locations,
README setup sections.

**`## Debugging a Failed [X]`**
Fill `[X]` with the primary service/component name (e.g. "Container", "Test Suite", "API").
Write 5–8 numbered steps derived from the project's actual debug surface
(log locations, health-check commands, dependency checks).

**Top-of-file routing block**
- If an agent `.md` exists in `.claude/agents/`: fill with the agent's name and delegation rule.
- If no agent exists: delete the entire routing block (it's optional).

**Claude Code Tooling lists** and **Claude Code Configuration** tree:
Replace all ADAPT placeholders with the actual `.claude/` file inventory
(slash commands present, hooks present, agents present, settings.json summary).

### Hooks — activate templates

For each `*.sh.template` in `.claude/hooks/`:

1. Read the template. Fill `LINTER`/`FORMATTER`, `DIFF_FLAG`, and `EXT` from the probe data.
   - Linter template: use the detected linter binary name + primary source extension
   - Formatter template: use the detected formatter binary name + its diff flag + source extension
2. Write the filled content to the same path without the `.template` suffix (e.g. `lint-on-write.sh`).
3. Make it executable: note in the summary — the user must run `chmod +x .claude/hooks/<name>.sh`.
4. Add a `PostToolUse` entry to `.claude/settings.json`:
   ```json
   {
     "matcher": "Edit|Write",
     "hooks": [{ "type": "command", "command": ".claude/hooks/<name>.sh" }]
   }
   ```
5. Do NOT delete the `.sh.template` file — leave it as documentation of the template that was used.

### settings.json — allow list

Add the detected linter/formatter/test-runner binaries to the `allow` list if not already present.
Preserve all existing entries; only append.

### Commands — any residual ADAPT markers

For each `SKILL.md` in `.claude/skills/*/` that still contains `<!-- ADAPT: -->` blocks:
fill from probe data where possible; leave unfilled only if probe data is truly insufficient,
and annotate why.

---

## Phase 4: Completion report

After all fills are complete:

0. If any "Run everything in Docker" row is `TODO: not containerised`, list those rows in the
   report and tell the user to run `/dockerize-project --dry-run` next.

1. Count residual `<!-- ADAPT:` markers across all files:
   ```bash
   grep -rn '<!-- ADAPT:' CLAUDE.md .claude/ 2>/dev/null | grep -v '.sh.template'
   ```

2. **If zero remaining**: clean up companion one-time files, then report success.

   **Strip the skeleton banner** from `CLAUDE.md` (the blockquote that starts with
   `> **This is a project-scope skeleton`):
   ```bash
   python3 - CLAUDE.md <<'PYEOF'
   import sys, pathlib, re
   path = pathlib.Path(sys.argv[1])
   text = path.read_text(encoding="utf-8")
   cleaned = re.sub(
       r'^> \*\*This is a project-scope skeleton.*?^---\n',
       '', text, count=1, flags=re.DOTALL | re.MULTILINE
   )
   if cleaned != text:
       path.write_text(cleaned.lstrip('\n'), encoding="utf-8")
   PYEOF
   ```

   **Delete companion one-time files:**
   ```bash
   rm -f .claude/settings.notes.md
   ```

   **Self-destruct if this is a project-bundle copy** — the global `~/.claude/skills/adapt-project/SKILL.md`
   is permanent, but a copy installed under `.claude/skills/adapt-project/SKILL.md` is a one-time
   post-import tool that should not persist. Check and remove:
   ```bash
   [[ -f ".claude/skills/adapt-project/SKILL.md" ]] && rm -f ".claude/skills/adapt-project/SKILL.md"
   rmdir ".claude/skills/adapt-project" 2>/dev/null || true
   ```

   Then report:
   ```
   Adaptation complete — all ADAPT markers resolved.

   Cleaned up:
     CLAUDE.md                   — skeleton banner removed
     settings.notes.md           — deleted (configuration guide no longer needed)
     .claude/skills/adapt-project/SKILL.md — self-destructed (one-time post-import tool)

   Memory scaffold:
     Review .claude/projects/.claude-template/memory/
     Delete example_user.md and example_feedback.md once you've written your own memories.

   Next steps:
     chmod +x .claude/hooks/*.sh          (activate hook scripts — required before they fire)
     /repair --check                      (verify config is coherent)
     /audit --quick                       (confirm command coverage and hook wiring — ~2 min)
     /discover-expertise --write          (build this project's expertise index; CLAUDE.md Phase 0 reads it)

   Per-machine env vars to verify (set in shell profile before starting Claude Code):
     SR_TZ=<zone>    — session-remember consolidation timezone (default: {{TZ}}).
                       Must be set on machines in a different timezone or timestamps will be wrong.
     SR_MODEL=<id>   — global override of the LLM used by session-remember; per-class defaults apply when unset
                       (claude-haiku-5-5 for SR_MODEL_BULK, SR_MODEL_CONSOLIDATE and SR_MODEL_HANDOFF).
   ```

3. **If any remain**: list every residual marker with file + line number, explain why
   the probe couldn't fill it (e.g. "no README found", "ambiguous architecture"),
   and what the user should write there manually. Do NOT report success.
   Re-run `/adapt-project` after manually filling those sections — the Phase 0 guard
   will skip already-resolved markers and only process what remains.

## Subagent models

**Model ask (policy v2, every run):** resolve the mode first with `bash ~/.claude/bin/project-state.sh --tier 0 | jq -r .identity.mode` (autonomous = the ask-human gate is bypassed for this tree, else spec); with no shell, `Read` `~/.claude/state/gates-bypass-rules.json` and call it autonomous only when an unexpired rule whose `guards` include `ah` covers this directory (`global`, or `path` equal to / a recursive ancestor of it), else spec. **Spec mode:** before the first Agent call of a run, ask ONE `AskUserQuestion` that shows the whole table below in the question text, with each stored value as the recommended choice (for reviewers, the `reviewer-model` file value; in spec mode a stored value is only ever the recommended option). Shape: AskUserQuestion takes 2-4 options and cannot pre-select, so the options are keep-the-table (Recommended), one uniform alias for every agent, and a challenge escape. **Autonomous mode** (user ruling 2026-09-30, plan model-policy-bypass): do NOT ask. For each agent read its override from `~/.claude/state/model-overrides.json` (`Read` it; key = the table's Agent label as a slug: lowercase, spaces to hyphens, under `agents`, falling back to `agents."*"`; or `bash ~/.claude/bin/model-override.sh get agent <slug>`, which applies the same fallback) and use it when present (an `as-is` override means the session's model: `bash ~/.claude/bin/session-model.sh` prints its alias), else the table value below (reviewers: the `reviewer-model` file); an invalid or absent table means no overrides. Record one `ASSUMED (review): <agent> runs on <model> - source <override|table>` per agent in the active plan's Decisions Log (`bash ~/.claude/bin/project-state.sh --append-decision <active plan> ASSUMED "..."`, or edit the plan file directly when there is no shell). Both modes: pass `model:` on every Agent call, set to the answer. An orchestrator (`/mega-analysis`, `/loop --pipeline`) which already asked for this run and named the models replaces it.

Set by the model-assignment audit (decision D5, 2026-09-29; source table `projects/-home-user-.claude/model-audit/classified-all.tsv`). **Pass `model:` on every Agent call** — an omitted model inherits the session, so quality and cost would follow the `/model` choice. `opus` = judgment work, `sonnet` = detection and mapping (rubric ruled 2026-09-29).

| Agent | model | why |
|---|---|---|
| the 4 Explore probes (tech stack, structure, CI/CD, other) | sonnet | mapping of the repository |
