---
name: memory-unblock
description: Use when removing a project from the session-remember blacklist or readonly-list to re-enable memory capture.
user-invocable: true
disable-model-invocation: true
---

**Front door:** `/gates-bypass memory unblock [path]` routes here; this skill is the implementation (framework-health 4.5).

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /memory-unblock — remove a project from the session-remember blacklist or readonly-list to re-enable memory capture
>
> Usage: /memory-unblock [path]
>   [path]  Optional project path. Defaults to the current project (discovered via git root or CLAUDE.md walk).
> ```

---

# /memory-unblock [path]

Remove a project from the session-remember blacklist and/or readonly-list.
Removes from BOTH lists if the slug appears in either.

If no path is given, the project is this session's project directory (`CLAUDE_PROJECT_DIR`, else the session-cwd anchor the SessionStart banner writes; `bin/slug-list.sh slug`), the same key session-remember matches. It is never the git toplevel, which from `~/.claude` would be `$HOME`.

---

## Pre-check: global pipeline state

Before modifying any block lists, run:
```bash
[ -f "$HOME/.claude/hooks/session-remember/DISABLED.lean" ] && echo "LEAN_DISABLED=true" || echo "LEAN_DISABLED=false"
[ -f "$HOME/.claude/hooks/session-remember/DISABLED" ] && echo "GLOBAL_DISABLED=true" || echo "GLOBAL_DISABLED=false"
```

If `LEAN_DISABLED=true`, warn:
```
⚠ Session pipeline is controlled by lean mode (DISABLED.lean present).
  Per-project block list changes will have no effect until lean mode ends.
  Proceeding anyway so the entry is removed for when lean mode exits...
```

If `LEAN_DISABLED=false` and `GLOBAL_DISABLED=true`, warn:
```
⚠ Session pipeline is globally disabled (DISABLED is present).
  Per-project block list changes will have no effect until DISABLED is removed.
  Proceeding anyway so the entry is removed for when global disable is lifted...
```

Then continue to normal execution regardless.

---

## Run

```bash
# The project key is session-remember's (CLAUDE_PROJECT_DIR, else the session-cwd anchor; never the git toplevel),
# and bin/slug-list.sh owns the matching: the old `grep -qxF "$slug"` read the leading '-' as flags and never matched,
# and `grep -vxF … > tmp && mv` could not remove the only line (framework-health 2026-10-07, A1-A3).
SL="$HOME/.claude/bin/slug-list.sh"
PROJECT_SLUG=$(bash "$SL" slug ${PATH_ARG:+"$PATH_ARG"}) || exit 1
PROJECT_PATH="${PATH_ARG:-$PROJECT_SLUG}"

SR_DIR="$HOME/.claude/hooks/session-remember"
REMOVED_FROM=()
bash "$SL" remove "$SR_DIR/blacklist"     "$PROJECT_SLUG" >/dev/null && REMOVED_FROM+=("blacklist")
bash "$SL" remove "$SR_DIR/readonly-list" "$PROJECT_SLUG" >/dev/null && REMOVED_FROM+=("readonly-list")

if [[ ${#REMOVED_FROM[@]} -eq 0 ]]; then
  echo "Project $PROJECT_PATH is not in any block list."
  echo "  Slug: $PROJECT_SLUG"
  exit 0
fi

echo "✓ $PROJECT_PATH unblocked"
echo "  Removed from: ${REMOVED_FROM[*]}"
echo "  Takes effect at next session start."
```
