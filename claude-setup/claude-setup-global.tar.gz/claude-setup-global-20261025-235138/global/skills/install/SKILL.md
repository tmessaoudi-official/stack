---
name: install
description: Use when installing a claude-export bundle onto this machine or into a project and adapting it to the target environment. Use after receiving a .tar.gz bundle produced by /bundle.
user-invocable: true
spotlight: true
disable-model-invocation: true
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /install — Install a claude-export bundle onto this machine or into a project and adapt it to the target environment. Use after receiving a .tar.gz bundle produced by /bundle.
> ```
>
> Then output the complete flag table from the **"Step 1: Parse Arguments"** section below. Then STOP.

| Flag | Value | Default | Description |
|------|-------|---------|-------------|
| `--from <path>` | .tar.gz path | required | Path to the bundle archive to install |
| `--target <path>` | directory | current working directory | Target project directory (for project-scope bundles) |

---

Install a claude-export bundle onto this machine or into a project, then adapt it to the target.

Parse `$ARGUMENTS` for flags. The bundle must include `claude-import.sh` at its root
(produced by `/bundle` with `--scope global`, `--scope project`, or `--scope all`).

**Lean-mode interlock**: Before doing anything, run:
```bash
if [[ -f "$HOME/.claude/LEAN_MODE" ]]; then
  echo "⛔ Lean mode is active — installing over stub files would corrupt your config."
  echo "   Run /lean off first, then retry /install."
  exit 1
fi
```
If LEAN_MODE exists, abort immediately with the above message. Do not proceed.

**Trust model**: `claude-import.sh` is self-destructive — it cleans up its extraction directory
after running. No authoring tools are installed on the target. This machine remains the origin.

---

## Step 1: Parse Arguments

Extract from `$ARGUMENTS`:
- `--from <path>` — path to the `.tar.gz` bundle (required; invoke `ask-human` if not provided)
- `--target <path>` — target project directory for project scope (default: current working directory)

If `--from` is not present: search the current directory:
```bash
ls -lh claude-setup-*.tar.gz 2>/dev/null || echo "No bundles found in current directory"
```
If multiple bundles are found: invoke the `ask-human` skill: question 'Which bundle do you want to install?', options listing each found file (most recent first = Recommended). If exactly one is found, use it automatically.

> ⚠️ **The `.sha256` sidecar must accompany the `.tar.gz`**: the importer verifies the checksum before extracting. If you move the bundle to a different directory or machine, copy BOTH `<bundle>.tar.gz` AND `<bundle>.tar.gz.sha256` together. Moving only the `.tar.gz` causes a hard failure.

Determine `TARGET`:
- If `--target` appears in `$ARGUMENTS`: use that value
- Otherwise: current working directory

---

## Step 2: Phase 0 — Pre-flight

**2a. Inspect bundle contents:**
```bash
tar -tzf <bundle> | head -50
```

**2b. Detect which scopes are in the bundle:**
- Has `project/` or `project/CLAUDE.md` entry → contains **project scope**
- Has `global/` or `global/CLAUDE.md` entry → contains **global scope**

**2b-extra. Global-presence guard for project-scope installs:**

If the bundle contains **project scope** (and NOT global scope), check whether the global
framework is already in place on this machine before installing:

```bash
ls ~/.claude/CLAUDE.md 2>/dev/null && echo "global: present" || echo "global: MISSING"
ls ~/.claude/hooks/session-remember/ 2>/dev/null && echo "session-remember: present" || echo "session-remember: MISSING"
```

If `~/.claude/CLAUDE.md` is **missing**: warn the user explicitly:

```
⚠  No global Claude Code setup detected at ~/.claude/CLAUDE.md.

The project bundle you're about to install relies on the global reasoning framework
(8-Phase Workflow, Mental Models, Core Rules) being present in ~/.claude/CLAUDE.md.

Without it, Claude will behave as a generic assistant — no structured workflow, no
memory pipeline, no destructive-command protocol.

```

Invoke the `ask-human` skill: question 'No global Claude Code setup detected at `~/.claude/CLAUDE.md`. How do you want to proceed?', options: 'Stop — I will install the global bundle first, then re-run (Recommended)' / 'Proceed anyway — install project scope without global framework'.

- If user selects option 1: stop here. Let the user install the global bundle, then re-run.
- If user selects option 2: note the gap in the report and proceed to 2c.

If `session-remember` pipeline is missing but `~/.claude/CLAUDE.md` is present: emit a
non-blocking warning (the project bundle works without it, but `/memory-status` will show
degraded mode). Then proceed.

**2c. Check for conflicts:**

**Project scope conflict**: if the bundle contains project scope AND `$TARGET/.claude/` OR `$TARGET/CLAUDE.md` exists
(the installer's own condition, `install_project.sh`: a hand-written CLAUDE.md with no `.claude/` also gets its prompt, and with
stdin at `/dev/null` and no `--project-mode` the installer stops with `no answer on stdin`):

Show the user exactly what the bundle would install:
```bash
tar -tzf <bundle> | grep '^[^/]*/project/'
```

Invoke the `ask-human` skill: question 'Claude config (`.claude/` and/or `CLAUDE.md`) already exists at `$TARGET`. How do you want to install?', options: 'Replace — overwrite with bundle contents (backup created first) (Recommended)' / 'Merge — keep CLAUDE.md and existing .claude/ files, add only the missing ones' / 'Manual-Merge — show me each file to choose selectively'.

Wait for the user's answer before proceeding.

- If **REPLACE**: back up the existing config into the install store first (never beside the project: a copied
  `.claude` holds settings and is not gitignored there), then proceed to Step 3:
  ```bash
  d=$(umask 077; mkdir -p ~/.claude/backups/install && chmod 700 ~/.claude/backups/install && \
      mktemp -d ~/.claude/backups/install/$(date +%s)-"$(basename "$TARGET")"-XXXX) && \
  for e in .claude CLAUDE.md .mcp.json; do [ ! -e "$TARGET/$e" ] || cp -a -- "$TARGET/$e" "$d/"; done && \
  printf '%s\t%s\t%s\n' "$(date +%s)" "$TARGET" "$d" >> ~/.claude/backups/install/ledger.tsv && echo "backup: $d"
  ```
  Announce the printed path — restore with `cp -a <backup>/. "$TARGET"/` if anything goes wrong. Step 3 then passes
  `--project-mode overwrite`: the installer's overwrite/merge prompt has no terminal here (stdin is `/dev/null`), so
  without the flag it stops with `no answer on stdin` (an installer older than the flag exits 1 silently, or with
  `unknown option '--project-mode'`). A current installer makes its own store backup too; this one is kept because
  an older bundle's installer may make none, and Step 5's adaptation edits are made by this skill. The firewall may ask once for
  the write outside the project. `claude-cleanup.sh` lists store folders older than 14 days.

- If **MERGE**: no backup is needed (nothing existing is overwritten: the installer copies only files that do not exist yet and
  keeps `CLAUDE.md`); proceed to Step 3 with `--project-mode merge` (panel 2026-10-13 C2-P3-6). A bundle installer older than
  the flag takes `printf '1\n' | bash …` (1 = merge) instead.

- If **MANUAL-MERGE**: follow the [Manual-Merge Guide](#manual-merge-guide) below, then stop
  (do not call the bash installer or run adaptation).

**Global scope conflict** is handled by the bash installer (exit code 2), and it needs no whole-tree backup here: a
configured `~/.claude` (with `CLAUDE.md`, `skills/` or `settings.json`) is never written — the bundle is parked in
`~/.claude-bundle-<epoch>` with a merge guide — and an unconfigured one is written only after the installer copies
each entry it will overwrite into `~/.claude/backups/install/<epoch>-.claude-XXXX/` (credentials and history are
never copied). Announce any `backup:` line it prints, with its restore line.

---

## Step 3: Run the Bash Installer

**If `~/.claude/bin/claude-import.sh` exists** (present after any previous install):
```bash
bash ~/.claude/bin/claude-import.sh --from <bundle> [--target $TARGET] [--project-mode overwrite]
```

**If this is a first install** (no `~/.claude/` yet — `claude-import.sh` isn't at that path):
```bash
tar -xzf <bundle>
cd <extracted-dir>/
bash ./claude-import.sh [--target $TARGET] [--project-mode overwrite]
```

Pass `--target` only if the bundle contains project scope, `--project-mode overwrite` only when Step 2 chose
Replace, and `--project-mode merge` only when it chose Merge. If the installer rejects it as an unknown option, the bundle predates the flag: answer its prompt on stdin
instead — `printf '2\n' | bash … [--target $TARGET]` (2 = overwrite).

**Check exit code:**
- **Exit 0**: all scopes installed successfully → proceed to Step 4
- **Exit 2**: global scope skipped — `~/.claude/` already exists. The bash installer
  printed a manual-merge guide above. Present it to the user. Invoke the `ask-human` skill: question 'Do you need help cherry-picking specific files from the bundle?', options: 'Yes — walk me through the files (Recommended if unsure)' / 'No — I will handle it manually'. Do not run adaptation for the global scope.
- **Exit 1**: hard error — show the full error output and stop.

---

## Step 4: Verify Installation

If global scope was installed:
```bash
ls ~/.claude/
```

Key reference files installed: `~/.claude/CLAUDE.md` (global reasoning framework), `~/.claude/BLAST-RADIUS.md` (blast-radius pre-flight checks used by the destructive-command protocol), `~/.claude/refs/SKILLS.md` (skill index), `~/.claude/refs/SESSION-REMEMBER.md` (memory pipeline tuning knobs).

**Activate settings** — `settings.json` arrives as a template to avoid overwriting an existing config:
```bash
cp ~/.claude/settings.json.template ~/.claude/settings.json
# Edit ~/.claude/settings.json — add your test runner, build tools, linters to "allow"
```
> **Scope note:** the bash installer (`claude-import.sh`) only **copies** the template — it does **not**
> auto-merge or adapt `settings.json`. The allow/deny/ask tuning below is a manual edit (or performed by
> Claude during /install Step 5). Don't expect the script to wire test runners/linters for you.

**Make hooks executable** — `claude-import.sh` already restores +x on every shipped `*.sh` under
`hooks/`, `mcp/`, `bin/` (the importer's `_ci_restore_exec_bits`), so for a normal bundle install
this is a **no-op**. Only run it if you copied the global config in by hand (bypassing the importer) —
hooks silently do nothing without the execute bit:
```bash
chmod +x ~/.claude/hooks/*.sh
```

**Verify the gate hooks work** — run the hook self-tests after install (catches a broken copy or a missing exec bit before the next session relies on them):
```bash
bash ~/.claude/hooks/tests/test-ask-human-gate.sh && bash ~/.claude/hooks/tests/test-bash-firewall.sh && bash ~/.claude/hooks/tests/test-question-guard.sh
```

**Install MCP npm dependencies** — `node_modules/` is excluded from bundles (platform-specific); rebuild in ~30 s:
```bash
for pkg_dir in ~/.claude/mcp/*/; do
  if [[ -f "${pkg_dir}package.json" ]]; then
    echo "npm ci: $(basename "$pkg_dir")"
    (cd "$pkg_dir" && npm ci)
  fi
done
```
If `~/.claude/mcp/` has no subdirectories with `package.json`, this loop is a no-op.

**Register local plugin marketplace** — if the bundle included a local marketplace, register it so skills are discoverable:
```bash
if [[ -d "$HOME/.claude/plugins/marketplaces/local" ]]; then
  claude plugin marketplace add "$HOME/.claude/plugins/marketplaces/local"
  echo "Local marketplace registered."
else
  echo "No local marketplace in bundle — skipping."
fi
```

**Register MCP servers** — stdio MCP servers do **not** load until registered with Claude Code.
The bash installer prints a `claude mcp add <name> --scope user -- bash <wrapper>` line per wrapper
it finds; run those. For the desktop MCP, register the wrapper matching the host display server
(`desktop-wayland-wrapper.sh` / `desktop-x11-wrapper.sh` on Linux, `desktop-windows-wrapper.sh` on
WSL→Windows). HTTP-backed servers start with `docker compose up -d` in their `mcp/<name>/` dir
instead. Verify with `claude mcp list`.

**Wire hooks** — for a fresh install, `cp settings.json.template settings.json` already wires everything except the permission engine, which the export strips because its rules file does not ship. The target runs without the engine: `bin/perm-engine-apply.sh` refuses there (it needs `config/permission-rules.json`), and the gates grid reports `engine not installed`. Without the engine there is no protected tier either. Under bypassPermissions nothing in the template asks before a gate is switched off or a guard file is changed: an Edit-tool edit meets no permission hook (the template's Edit/Write hooks are the backup, ask-human and prework guards, none keyed on the path), a Bash write meets only the firewall's self-mod tier and only for the verbs it models, and `gates-bypass-ask-apply.sh` cannot add the protecting asks there: with the engine not LIVE it writes `settings.json` AND `config/permission-rules.json`, and it aborts before writing anything when either does not load, and a target has no rules file. In default mode the target still prompts natively (the template has no allows); in `acceptEdits` mode it does not for Edit/Write inside the working directory, so from a `~/.claude` cwd a guard-hook or sentinel edit lands with no dialog (Inferred, unprobed). Details: docs/SPEC.md §2.19. For an UPDATE where `~/.claude/` already existed, manually add any missing entries; an entry naming a `bin/*-apply.sh` registers through that script instead (it backs up `settings.json` first). The complete hook set required (pinned to the exported template by `bin/tests/claude-export-bin-refs.test.sh` B3):

| Event | Hook | Purpose |
|-------|------|---------|
| `SessionStart` | `session-remember/start.sh` (timeout 30), `patch-playwright-mcp.sh` (10), `ensure-mcp-health.sh` (6), `session-start-banner.sh` (5) | Pipeline start, MCP health, session banner |
| `PostToolUse` | `session-remember/trigger.sh` (10), `edit-log.sh` on `Edit\|Write` (3), `ask-human-gate-track.sh` on `AskUserQuestion` (5), `plan-write-check.sh` on `Edit\|Write` (5, warn-only) | Memory capture, edit audit, gate tracking, plan-file shape warning |
| `PreToolUse` | `rtk hook claude` on `Bash` (5 — machine-local binary, drop if rtk is not installed), `backup-before-write.sh` on `Edit\|Write` (10), `ask-human-gate-block.sh` on `Bash\|Read\|Edit\|Write\|NotebookEdit\|Agent\|Glob\|Grep\|mcp__.*__(jira\|confluence)_(create\|update\|delete\|add\|edit…)` (10), `ask-bash-firewall.sh` on `Bash` (5 — v3 boundary gate, needs python3), `advisor-prework-guard.sh` on `Edit\|Write` (10), `skill-invocation-log.sh` (3) and `skill-model-notice.sh` (5) on `Skill`, `agent-model-override.sh` (5) and `expertise-gate.sh` (10; `bin/expertise-gate-apply.sh on`) on `Agent`, `push-batch-guard.sh` on `Bash` (10; `bin/push-batch-apply.sh on`) | rtk rewrite, backup gate, ask-human enforcement, bash boundary gate, Phase 3C evidence guard, skill usage log, model-policy notice and agent model override, expertise gate, Rule 10 push batch |
| `Stop` | `session-remember/stop.sh` (30), `stop-context-bar.sh` (15), `stop-git-status.sh` (5), `ask-human-question-guard.sh` (5), `advisor-completion-guard.sh` (5), `keep-going-guard.sh` (5; `bin/keep-going-apply.sh on`) | Memory save, context bar (+ `permission-mode-<sid>` for the BYPASS statusline segment), git status, end-of-turn question guard, Completion-Gate evidence guard, keep-going loop |
| `StopFailure` | `stop-failure-notify.sh` (10; `bin/stop-failure-apply.sh on`) | A turn that died on an API error: log, desktop + terminal notification, opt-in ntfy push (`CLAUDE_STOPFAILURE_NTFY_URL`) |
| `PreCompact` | `precompact-handoff.sh` (90) | Auto-handoff before compaction |
| `SubagentStop` | `subagent-stop-status.sh` (5) | Subagent status display |
| `SubagentStart` | `subagent-start-context.sh` (5) | Subagent context injection |
| `UserPromptSubmit` | `ask-human-gate-arm.sh` (5), `skill-invocation-log.sh` (3), `skill-model-notice.sh` (5), `remote-bang.sh` (3) | Arms the ask-human gate on each new user message, skill usage log, model-policy notice, the remote `!` hand-off |
| `PermissionRequest` | `perm-request-log.sh` (5; `bin/perm-shadow-apply.sh`) | Logs real permission prompts for the engine's shadow comparison (prints and decides nothing) |

**Library scripts** (NOT registered as event hooks): `session-status.sh` and `log-helpers.sh` are sourced by other hook scripts at runtime. They have no event handler registration in `settings.json` — registering them would be wrong. `/repair --check` correctly reports them as unregistered (not drift).

**Re-install plugins** — plugins from external marketplaces are not bundled. A reinstall script is generated automatically at bundle time. If present:
```bash
bash ~/.claude/plugins-reinstall.sh
```
The script registers marketplaces (idempotent) then re-installs all plugins from origin. If `plugins-reinstall.sh` is absent (older bundle), install manually:
```bash
# Re-install on this machine (repeat for each plugin):
claude plugin install <name>@<marketplace>
# Example: claude plugin install superpowers@claude-plugins-official
```

**Refill scrubbed placeholders** — if the bundle was scrubbed, the installer prints a
**"Scrubbed placeholders — replace with real values"** guide (`{{TZ}}` is auto-resolved to
the host timezone; `CHANGE_ME_*`, `/path/to/your/project`, `YOUR_SERVICE_INSTANCE` must be filled
in by hand; `<your-lead-agent>` is legacy — nothing produces it since 2026-08-19, but pre-existing
bundles can still carry it). Run the
`grep` it suggests and replace every remaining placeholder before relying on the config.
`MANIFEST.json` › `scrubbed_placeholders` lists exactly what was scrubbed.

Open a Claude Code session and run:
```
/memory-status    — confirm session-remember pipeline is active
/audit --quick    — verify command coverage and hook wiring (3 agents, ~2 min)
```

If project scope was installed, check files landed:
```bash
ls $TARGET/.claude/
```

---

## Step 5: Adapt Project Scope

**Run this step only if project scope was freshly installed** (not skipped, not manual-merged,
not already-existing).

### 5a. Check for ADAPT markers

```bash
grep -c "ADAPT:" "$TARGET/.claude/CLAUDE.md" 2>/dev/null || echo "0"
```

If the count is 0 (no ADAPT markers), the CLAUDE.md is already a real config — skip adaptation
and report that the file appears to be pre-adapted. Proceed to Step 6.

### 5b. Probe the target project silently

Read the following without asking the user:
- `$TARGET/package.json` (Node.js/JS project — name, scripts, devDependencies)
- `$TARGET/requirements.txt` or `$TARGET/pyproject.toml` (Python)
- `$TARGET/Cargo.toml` (Rust)
- `$TARGET/go.mod` (Go)
- `$TARGET/composer.json` (PHP)
- `$TARGET/Gemfile` (Ruby)
- `$TARGET/pom.xml` or `$TARGET/build.gradle` (Java)
- `$TARGET/*.csproj` (C#/.NET)
- `$TARGET/.github/workflows/` (CI: GitHub Actions)
- `$TARGET/.gitlab-ci.yml` (CI: GitLab)
- `$TARGET/Jenkinsfile` (CI: Jenkins)
- `$TARGET/README.md` (first 20 lines — project name and description)
- `git -C $TARGET log --oneline -5` (recent activity context)

From this, determine:
- Primary language(s) and tech stack
- CI/CD system (if any)
- Detected linters/formatters (from devDependencies, requirements, or `which` checks)
- Project name

### 5c. Ask targeted questions (only what wasn't auto-detected)

Invoke the `ask-human` skill using Pattern 5 (progressive batching — max 4 questions per call):

**Round 1 — always ask (2 questions):**
- Q1 header 'Description': 'What is this project in one sentence?' (even if README has one — confirm or improve it). Free-text via Other.
- Q2 header 'Lead agent': 'Does this project need a specialist lead agent?', options: 'No lead agent needed (Recommended)' / 'Yes — infrastructure / ops domain' / 'Yes — data / ML domain' / 'Yes — other domain (describe in notes)'.

**Round 2 — only if not auto-detected (up to 3 questions):**
- Q3 header 'Stack' (if language unclear): 'Primary language(s) / tech stack?', options based on detected candidates + 'Other'.
- Q4 header 'Linting' (if linters unclear): 'Which tools should run on file writes?', options listing detected candidates + 'None' + 'Other'.
- Q5 header 'Deny list' (always): 'Any commands Claude must never run without explicit confirmation?', options: 'None — use defaults (Recommended)' / 'Yes — describe in notes'.

If everything was detected, only ask Round 1.

### 5d. Fill ADAPT markers in CLAUDE.md

Using probed data + answers: write real prose, tables, and code blocks into each ADAPT section.
Remove all `<!-- ADAPT: ... -->` comment wrappers once the content is written.

Key sections to fill:
- **What This Project Is**: project name, description, platform, key tech, solo/team, version cadence
- **Architecture**: structure based on detected layout (check `src/`, `lib/`, `app/`, `internal/`, etc.)
- **Common Workflows**: build/test/lint commands from detected tooling
- **Testing & Verification**: test commands, types, expected output
- **File Layout Quick Reference**: annotated tree of non-obvious directories
- **Gotchas & Pitfalls**: at minimum one entry per detected footgun; can grow over time
- **Claude Code Tooling** section: list the commands that were installed from the bundle

For the "Specific to this computer setup" section: fill in routing rule (if user chose yes to agent)
and timezone note.

### 5e. Adapt hook templates

For each `.sh.template` file in `$TARGET/.claude/hooks/`:

1. Determine the right linter/formatter from the answer to question 5c-4 and the detected stack.
2. Fill in `LINTER` and `EXT` placeholders.
3. Rename from `.sh.template` to `.sh`:
   ```bash
   mv "$TARGET/.claude/hooks/<name>.sh.template" "$TARGET/.claude/hooks/<name>.sh"
   chmod +x "$TARGET/.claude/hooks/<name>.sh"
   ```
4. Add the hook to `$TARGET/.claude/settings.json` under `hooks` → `PostToolUse`:
   ```json
   {
     "hooks": {
       "PostToolUse": [
         {
           "matcher": "Edit|Write",
           "hooks": [{ "type": "command", "command": ".claude/hooks/<name>.sh" }]
         }
       ]
     }
   }
   ```
   Merge with any existing hooks/permissions in settings.json rather than overwriting.

If no suitable linter was identified for a template, leave it as `.sh.template` and note it
in the report.

### 5f. Adapt or delete agent template

If user answered **yes** to a specialist agent:
1. Invoke the `ask-human` skill: question 'What are the key files, directories, and commands this agent should know about?', options: 'Describe them in notes (free-text)' / 'Skip — I will fill the agent definition manually'.
2. Fill in the `lead-agent.md.template` skeleton:
   - Replace `[ADAPT: Agent Name]` with the chosen domain name (e.g. "Infrastructure Lead Agent")
   - Fill Domain Knowledge section with: key files, common workflows, debugging protocol,
     gotchas, and coding conventions from probed + answered context
   - Fill Mental Models section with 3–5 models most relevant to the domain
3. Rename: `mv lead-agent.md.template <domain>-lead-dev.md`
4. Add the routing rule to the top of CLAUDE.md (above the project description):
   ```markdown
   > **[Domain] tasks MUST be delegated to the `<domain>-lead-dev` agent**
   > (subagent_type: `<domain>-lead-dev`).
   ```

If user answered **no**:
1. Delete the template: `rm "$TARGET/.claude/agents/lead-agent.md.template"`

### 5g. Adapt commands and settings.json

For each `.md` command file that contains ADAPT markers:
- Fill the markers with project-specific content (linter name, actual file patterns, etc.)
- Remove the ADAPT comment wrappers

For `$TARGET/.claude/settings.json`:
- Add linter/formatter binary to `allow` (from hook setup)
- Add detected test runner to `allow`: e.g. `Bash(pytest:*)`, `Bash(npm test:*)`, `Bash(rspec:*)`
- Add detected build tool to `allow`: e.g. `Bash(make:*)`, `Bash(cargo:*)`, `Bash(gradle:*)`
- Add any commands the user named in question 5c-5 to `deny` or `ask`

### 5h. Clean up and report

Delete the adaptation guide (it was a temporary reference):
```bash
rm -f "$TARGET/.claude/settings.notes.md"
```

Report to the user:
```
Adaptation complete.

Adapted:
  CLAUDE.md              — filled all ADAPT sections with project-specific content
  hooks/<name>.sh        — wired <linter> for <ext> files on write
  agents/<name>.md       — filled domain knowledge for <domain> agent  (or: deleted template)
  .claude/skills/lint/SKILL.md  — updated with actual linter commands
  settings.json          — added allow rules for <tools>

Review recommended:
  .claude/CLAUDE.md § Gotchas  — only a starter; add more as you discover them
  .claude/settings.json        — review deny/ask rules against your workflow

Next:
  chmod +x .claude/hooks/*.sh                 — activate hook scripts (required before they fire)
  /repair --check                             — verify config is coherent
  /adapt-project                              — re-run adaptation if ADAPT markers remain or need updating
  /audit --quick                              — confirm command coverage and hook wiring (~2 min)
  /memory-status                              — confirm session-remember pipeline is active
```

**Closing the install** (the last step, once the install is verified): when this run printed any `backup:` path or a
`~/.claude-bundle-<epoch>` merge source, ask via `AskUserQuestion` whether to delete them now (recommended once the
install is verified) or keep them for the 14-day `claude-cleanup.sh` sweep; on yes, `rm -rf --` each printed path.

---

## Manual-Merge Guide

Used when user chose M (manual-merge) for a project scope conflict.

1. Extract the bundle to a temp directory:
   ```bash
   TMPDIR=$(mktemp -d /tmp/claude-merge-XXXX)
   tar -xzf <bundle> --directory="$TMPDIR"
   ```

2. Find the project content directory:
   ```bash
   PROJECT_DIR=$(find "$TMPDIR" -maxdepth 2 -type d -name "project" | head -1)
   ```

3. For each file in the project content, show:
   - The incoming file path and first 10 lines
   - Whether it already exists at the target
   - A recommendation: `copy` (new file), `diff + decide` (both exist), `skip` (existing is richer)

4. Show the exact copy commands the user can run selectively:
   ```bash
   # To copy a specific file:
   cp "$PROJECT_DIR/.claude/skills/lint/SKILL.md" "$TARGET/.claude/skills/lint/SKILL.md"

   # To diff before deciding:
   diff "$TARGET/.claude/skills/lint/SKILL.md" "$PROJECT_DIR/.claude/skills/lint/SKILL.md"
   ```

5. Clean up temp dir: `rm -rf "$TMPDIR"`

6. Stop — do not run the bash installer or adaptation for project scope.

---

## Usage Examples

- `/install --from claude-setup-global-<ts>.tar.gz` — install global scope
- `/install --from claude-setup-project-<ts>.tar.gz --target /path/to/project` — install + adapt project scope
- `/install --from claude-setup-global-<ts>.tar.gz --target ~/myproject` — install both scopes if bundle has both
