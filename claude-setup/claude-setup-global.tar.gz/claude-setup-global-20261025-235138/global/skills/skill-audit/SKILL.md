---
name: skill-audit
spotlight: true
description: Use when performing an exhaustive 15-dimension quality audit of every skill file across global and project scopes. Use when skill quality, coverage, trigger design, or convergence-gate compliance needs a deep systematic review.
user-invocable: true
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /skill-audit — Exhaustive 15-dimension quality audit of every skill file across global and project scopes.
>
> Flags:
>   --quick                   Run global batch A+B only (skip deep-dives)
>   --scope=global|project    Run one scope only (default: both)
>   --skill=<name>            Run audit for a single named skill
> ```

---

# /skill-audit — Per-Skill 15-Dimension Deep Report

Exhaustive quality audit of every skill file — global (`~/.claude/skills/`) AND project scope (`.claude/skills/`). Each skill gets a structured report across 15 dimensions. **Read-only — never auto-applies anything.**

Use `$ARGUMENTS` for flags: `--quick` (global batch A+B only, skip deep-dives), `--scope=global|project` (one scope only), `--skill=<name>` (single skill).

---

## Step 0: Setup

```bash
PROJECT_SLUG=$(echo "${CLAUDE_PROJECT_DIR:-$PWD}" | sed 's|^/|-|; s|/|-|g')
REPORT_DIR="$HOME/.claude/projects/$PROJECT_SLUG/audits"
mkdir -p "$REPORT_DIR"
TODAY=$(date +%Y-%m-%d)
# One naming scheme: skill-audit-<date>.md, then skill-audit-<date>-runN.md (before 2026-10-07 the first run was
# <date>-skill-audit.md; /mega-analysis still finds those, newest by mtime)
RUN=1
REPORT_PATH="$REPORT_DIR/skill-audit-${TODAY}.md"
while [[ -f "$REPORT_PATH" ]]; do
  RUN=$(( RUN + 1 ))
  REPORT_PATH="$REPORT_DIR/skill-audit-${TODAY}-run${RUN}.md"
done

# The global skills come from disk, never from a hand-kept list: every ~/.claude/skills/<name>/SKILL.md,
# split into two halves for Agents 1 and 2. Step 2 checks that each one got a report row.
GLOBAL_SKILLS=()
for d in "$HOME/.claude/skills"/*/; do
  [[ -f "$d/SKILL.md" ]] && GLOBAL_SKILLS+=("$(basename "$d")")
done
HALF=$(( (${#GLOBAL_SKILLS[@]} + 1) / 2 ))
BATCH_A=("${GLOBAL_SKILLS[@]:0:$HALF}")
BATCH_B=("${GLOBAL_SKILLS[@]:$HALF}")
echo "Global skills: ${#GLOBAL_SKILLS[@]} (batch A ${#BATCH_A[@]}, batch B ${#BATCH_B[@]})"
printf 'A: %s\n' "${BATCH_A[*]}"; printf 'B: %s\n' "${BATCH_B[*]}"
```

Announce: "Skill audit: `$CLAUDE_PROJECT_DIR` → saving to `$REPORT_PATH`"

---

## The 15 Dimensions

For **every skill file**, assess:

1. **Frontmatter completeness** — Does the SKILL.md have `name:`, `description:`, and `user-invocable:` in frontmatter? Is `user-invocable` set correctly (true = user types `/skill-name`; false = Claude invokes proactively)?

2. **Trigger specificity** — For `user-invocable: false` skills: is the proactive trigger pattern described and specific enough to avoid false positives? Would a cold-start Claude know when to invoke this? For `user-invocable: true`: is the invocation pattern and expected arguments documented?

3. **Purpose drift** — Compare the `description:` field to the skill's entry in `~/.claude/refs/SKILLS.md` (the global skills list; CLAUDE.md no longer carries a slash-commands table) to the actual skill content. Any divergence where they contradict each other?

4. **Coverage scope** — Enumerate explicitly what the skill actually checks, reads, or does — not what the description claims. What is the concrete execution path?

5. **Missing angles** — What a senior engineer would expect this skill to cover that it doesn't. Be specific: name the scenario, not the category.

6. **Output format consistency** — Does it produce a structured report? Where is output saved? Is the save location and filename consistent with the `$HOME/.claude/projects/$SLUG/<type>/YYYY-MM-DD[-runN].md` convention?

7. **Side effects** — Does it write files, call agents, modify state, create branches, or trigger external calls? Are all side effects documented in the skill header?

8. **Idempotency** — Safe to invoke twice in a row? Does re-running accumulate state, create duplicate files, or change behavior?

9. **Error handling** — What happens when preconditions aren't met: no git repo, no docker, dirty working tree, empty project, missing tools (jq, docker, shellcheck)? Are failures loud or silent?

10. **ask-human gate compliance** — For every question the skill asks the user: does it use `AskUserQuestion` via the `ask-human` skill? Is the recommended option first? No free-text questions? No numbered prose lists? Note: skills that complete work without any user questions are OK here.

11. **Convergence gate compliance** — For skills that do analysis or implementation work: does the skill route its Phase 3C (pre-implementation) and Phase 6C (pre-completion) certification through `/certify` (which applies the mode and the project's certification schedule), as `~/.claude/CLAUDE.md` mandates, rather than restating its own loop? N/A for read-only lookup/utility skills that produce no persistent artifacts.

12. **Composition safety** — Is this skill invoked by other skills (e.g., `mega-analysis`, `audit`)? Check for circular invocation paths. Are all parent callers documented? Would removing or renaming this skill break a pipeline?

13. **Cold-start readiness** — Can Claude execute this skill correctly with zero prior conversation context? Identify any instruction that assumes prior session knowledge, a prior tool call result, or a variable set earlier in the conversation.

14. **Token efficiency** — Is the skill lean and precise, or bloated with redundant instructions, repeated preambles, or content already in `~/.claude/CLAUDE.md`? Content duplicated from CLAUDE.md creates drift: future CLAUDE.md edits won't propagate.

15. **Generalizability verdict** — Classify:
    - **KEEP-GLOBAL**: generic, useful on any machine, no machine-specific content
    - **KEEP-PROJECT-ONLY**: has a hard project-specific dependency (docker compose, make, bin/env-*, .env)
    - **PROMOTE-CANDIDATE**: currently project-scoped but generic enough for global
    - **DUPLICATE-OF-OTHER**: functionally identical to another skill — merge or delete candidate

**Severity per dimension:**
- `OK` — no issue
- `P2` — minor gap, worth noting
- `P1` — meaningful gap that degrades usefulness
- `P0` — blocks correctness, causes wrong output, or creates security risk

---

## Step 1: Spawn parallel agents

Respect flags before spawning:
- `--quick`: spawn only agents 1 and 2 (skip 3 and 4)
- `--scope=global`: spawn only agents 1, 2 (skip 3 and 4)
- `--scope=project`: spawn only agent 3
- `--skill=<name>`: find the skill directory, spawn the right agent with that single skill
- Default: spawn all 4 in a single message (parallel)

Replace `<PROJECT>` with the actual `$CLAUDE_PROJECT_DIR` path.
Replace `<PROJECT_SLUG>` with the derived slug.

---

**Agent 1 — Global skills batch A**

> Read `~/.claude/skills/<name>/SKILL.md` for each name in this list: `<BATCH_A>` (substitute the `BATCH_A` names printed in Step 0 — every one of them). Also read `~/.claude/refs/SKILLS.md` for the stated purpose of each skill, and `~/.claude/CLAUDE.md` for the skill-invocation rules.
>
> For EACH skill, produce a structured report across all 15 dimensions. For dimension 11 (convergence gate): check whether the skill routes 3C/6C certification through `/certify` (and calls `expanding-context` where its input is narrow). For dimension 12 (composition safety): check whether this skill is referenced inside `mega-analysis/SKILL.md` or `audit/SKILL.md` as a pipeline step.
>
> Research only, no writes. Do not summarize — produce the full per-skill table for every skill in the list.

---

**Agent 2 — Global skills batch B**

> Read `~/.claude/skills/<name>/SKILL.md` for each name in this list: `<BATCH_B>` (substitute the `BATCH_B` names printed in Step 0 — every one of them). Also read `~/.claude/refs/SKILLS.md` for stated descriptions.
>
> For EACH skill, produce the same structured 15-dimension table. Small toggle skills (a few lines that flip one switch) may share a condensed table, one row per skill, all 15 dims.
>
> Research only, no writes. Do not summarize — every skill in the list gets its row.

---

**Agent 3 — Project skills** *(skipped with `--scope=global`)*

> Read each skill file in `<PROJECT>/.claude/skills/` (directories matching `*/SKILL.md`). If the directory doesn't exist or is empty, report "No project skills found" and exit.
>
> Read `<PROJECT>/CLAUDE.md` — the "Slash commands" or "Skills" section — for the stated description of each skill.
>
> For EACH skill, produce the 15-dimension table. For dimension 15 (Generalizability), use the full verdict:
> - **KEEP-PROJECT-ONLY**: hard project-specific dependency (docker compose, make, bin/env-*, .env)
> - **PROMOTE-CANDIDATE**: generic enough to work in any project with minor adaptation
> - **DUPLICATE-OF-GLOBAL**: functionally identical to a global skill — merge or delete
>
> Research only, no writes.

---

**Agent 4 — Deep-dives** *(skipped with `--quick`)*

> These skills are invoked as part of larger pipelines or have complex multi-agent orchestration that warrants extra scrutiny. (A curated list by design, unlike Agents 1 and 2 — it names the pipeline orchestrators.) Read each file fully: `mega-analysis/SKILL.md`, `audit/SKILL.md`, `inspect/SKILL.md`, `sleuth/SKILL.md`, `gaps/SKILL.md`, `repair/SKILL.md`.
>
> For each, produce the standard 15-dim table PLUS answers to these deep-dive questions:
>
> **Pipeline correctness**: Does the skill's agent-spawn sequence match what its own header and `~/.claude/refs/SKILLS.md` say the pipeline does? Are there documented steps the skill doesn't implement?
>
> **Flag completeness**: For every `--flag` documented in the skill header or `~/.claude/refs/SKILLS.md`: is it actually implemented in the skill's logic? Are flags checked via `$ARGUMENTS`?
>
> **Cold-start agent quality**: For every `Agent()` call inside the skill: is the subagent prompt fully self-contained for a cold-start agent (no assumed prior context)? Is `subagent_type` specified? Is `isolation: "worktree"` used where the agent modifies files?
>
> **Ask-human audit**: List every place the skill surfaces a question to the user. Confirm each uses the `ask-human` skill and `AskUserQuestion`, not free-text.
>
> Research only, no writes.

---

## Step 2: Synthesize

**Coverage check first** (skip with `--skill=<name>` or `--scope=project`): every name in `GLOBAL_SKILLS` from Step 0 must have a row in Agent 1's or Agent 2's output. List any missing name, then re-spawn that batch's agent for the missing names only, before writing the report. The report's header states `Coverage: <rows>/<${#GLOBAL_SKILLS[@]}> global skills`; a report with fewer rows than skills is not complete.

After all agents complete, produce a consolidated report:

```markdown
# /skill-audit Report — <DATE>
Generated: <DATE> | Project: <PROJECT_DIR> | Skills audited: N global + M project

## Health Summary
| Severity | Count | Skills affected |
|----------|-------|----------------|
| P0 | | |
| P1 | | |
| P2 | | |
| OK across all dims | | |

## Critical findings (P0)
[full detail for each]

## High-priority findings (P1)
[full detail for each]

## Generalizability verdicts
| Skill | Scope | Verdict |
|-------|-------|---------|
...

## Top 5 actions
1–5 ordered by impact

*Nothing in this report is auto-applied.*
```

Write the full per-skill tables + synthesis to `$REPORT_PATH`. Announce the path.

Also write a JSON sidecar `$REPORT_PATH.json` with this structure for pipeline consumption:
```json
{
  "generated": "<ISO date>",
  "skills_audited": { "global": N, "project": M },
  "findings": {
    "p0": [{ "skill": "...", "dim": N, "summary": "..." }],
    "p1": [{ "skill": "...", "dim": N, "summary": "..." }]
  },
  "generalizability": { "skill-name": "KEEP-GLOBAL|KEEP-PROJECT-ONLY|PROMOTE-CANDIDATE|DUPLICATE-OF-OTHER" }
}
```

## Step 3: Present

Show in conversation: health summary table + all P0 findings + P1 findings + top 5 actions. For P2: show count only. Then invoke the `ask-human` skill: question 'Would you like to see P2 findings?', options: 'Yes, show all P2 findings' / 'No, close the report (Recommended)'.

## Subagent models

**Model ask (policy v2, every run):** resolve the mode first with `bash ~/.claude/bin/project-state.sh --tier 0 | jq -r .identity.mode` (autonomous = the ask-human gate is bypassed for this tree, else spec); with no shell, `Read` `~/.claude/state/gates-bypass-rules.json` and call it autonomous only when an unexpired rule whose `guards` include `ah` covers this directory (`global`, or `path` equal to / a recursive ancestor of it), else spec. **Spec mode:** before the first Agent call of a run, ask ONE `AskUserQuestion` that shows the whole table below in the question text, with each stored value as the recommended choice (for reviewers, the `reviewer-model` file value; in spec mode a stored value is only ever the recommended option). Shape: AskUserQuestion takes 2-4 options and cannot pre-select, so the options are keep-the-table (Recommended), one uniform alias for every agent, and a challenge escape. **Autonomous mode** (user ruling 2026-09-30, plan model-policy-bypass): do NOT ask. For each agent read its override from `~/.claude/state/model-overrides.json` (`Read` it; key = the table's Agent label as a slug: lowercase, spaces to hyphens, under `agents`, falling back to `agents."*"`; or `bash ~/.claude/bin/model-override.sh get agent <slug>`, which applies the same fallback) and use it when present (an `as-is` override means the session's model: `bash ~/.claude/bin/session-model.sh` prints its alias), else the table value below (reviewers: the `reviewer-model` file); an invalid or absent table means no overrides. Record one `ASSUMED (review): <agent> runs on <model> - source <override|table>` per agent in the active plan's Decisions Log (`bash ~/.claude/bin/project-state.sh --append-decision <active plan> ASSUMED "..."`, or edit the plan file directly when there is no shell). Both modes: pass `model:` on every Agent call, set to the answer. An orchestrator (`/mega-analysis`, `/loop --pipeline`) which already asked for this run and named the models replaces it.

Set by the model-assignment audit (decision D5, 2026-09-29; source table `projects/-home-user-.claude/model-audit/classified-all.tsv`). **Pass `model:` on every Agent call** — an omitted model inherits the session, so quality and cost would follow the `/model` choice. `opus` = judgment work, `sonnet` = detection and mapping (rubric ruled 2026-09-29).

| Agent | model | why |
|---|---|---|
| the audit agents (global batch A, batch B, project, deep-dive) | opus | they review skills a strong model wrote |
