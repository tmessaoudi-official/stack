---
name: next
spotlight: true
description: Use when resuming work — "let's continue", "what's next", "where were we", "pick up where we left off", "what should we do now". Reconciles the handoff and plan against git, then recommends ONE next action with why, the alternative, what it needs, the first three files to read, and its effort. Twenty lines, evidence-cited. Never persists a report (a resume must not move the /progress delta baseline).
user-invocable: true
args: "[--deep]"
side-effects: None on disk except, when several plans exist and none is active, writing the chosen plan to ~/.claude/run/active-plan-<session> after AskUserQuestion. Never runs --persist, --save or --record-test.
wants-session-model: strong
---

## --help

> If ARGUMENTS contains `--help`: output the text below verbatim, then immediately STOP — do not execute any other steps. (`--help` takes precedence over all other flags.)
>
> ```
> /next — Resume: reconciles handoff + plan + git, then recommends ONE next action with why,
> the alternative, what it needs, the first three files to read, and its effort. ≤ 20 lines.
> Performs CLAUDE.md Rule 17's Phase 0 row (find the plan, read it, announce, attach).
>
> Flags:
>   --deep   consult the deep-sweep raw files if a /progress --deep ran before
>            (scope-drift, critical-path, fragile, undocumented, todo-clusters .md)
> ```

---

# /next — what should we do now

## Step 0 — one-tap chooser (mandatory; it is also the ask-human gate)

`ask-human-gate-block.sh` blocks every Bash/Read call of a new prompt until `AskUserQuestion`
has run in that turn, so the chooser comes BEFORE any probe. State *"Category: Small —
read-only resume"* and ask one `AskUserQuestion`: *Resume from the plan and handoff
(Recommended)* / *Deep — also read a prior deep sweep's raw files* / *Cancel*. Then probe with
`bash ~/.claude/bin/project-state.sh --tier 0`; only if it finds several plans and no active
pointer, a second `AskUserQuestion` with the newest four candidates plus the auto-appended
*Other*, then `bash ~/.claude/bin/project-state.sh --set-active-plan <path>`.

## Step 1 — collect, without persisting

```bash
bash ~/.claude/bin/bypass-review.sh import >/dev/null
f=$(mktemp "<scratchpad directory from the system prompt>/next-state.XXXXXX.json")
bash ~/.claude/bin/project-state.sh > "$f"
```

The `import` line is the one write `/next` makes: it moves new unattended-window events and the firewall's `TOTAL(allowed)` lines into the bypass-review
queue and rewrites `run/bypass-review-summary.json` (idempotent — a cursor, no baseline), so the collector's `review`
counts are current. A non-zero exit is a `Watch:` item, never a reason to stop.

then `Read` that file (never `/tmp` directly — the scratchpad path is the one named in the
system prompt). **Never `--persist` here**: every `/progress` moves the delta baseline by
design; a resume must not, or two `/next` calls make the next `/progress` delta empty.

**Handoff source, in order** (the collector cannot see this conversation; you can):
1. `session.handoff.text` when the file has content;
2. when `session.handoff.consumed` is true and a `SESSION CONTINUITY` block is present in
   this conversation's context, its `Handoff` section — say *"handoff consumed at session
   start; read from the injected context"*;
3. otherwise `session.today_tail` and `session.buffer_tail`.

## Step 2 — reconcile before recommending

- A handoff "Next" item that already landed is **dropped with its sha**: match its key words
  against `git log --oneline -20` subjects and against `plans.active.steps[].state`. Say
  what was dropped and why — "handoff said X; commit 836bf89a did it".
- A plan step marked `doing` is the default candidate; a `blocked` step is never recommended
  unless its blocker is listed as resolved in `sections.blocked` or the handoff.
- `staleness[]` entries and `warnings[]` are surfaced before the recommendation when they
  would change it (a forged ruling, a foreign pointer, no status block).
- `env.lean.active` true: say that skills and memory are suspended and what that means for the
  action.
- **Crash check.** When `git.dirty` is non-empty, compare the boot time with the previous session's
  last activity: `uptime -s` against the mtime of the newest `~/.claude/projects/*/*.jsonl` whose
  entries carry this cwd, excluding this session's. A reboot AFTER that activity means the last
  session died mid-work (its `/tmp` scratchpad is gone): the NEXT action is `/recover-session`,
  before any edit. `session.handoff.consumed` alone is NOT a crash signal — the SessionStart hook
  consumes the handoff on every normal start.

## Step 3 — output (≤ 20 lines, then stop)

```
Goal: <goal.text> [<goal.source>]
Mode: <identity.mode><"+cf" when identity.confident> · certification: <identity.certification_schedule.value, or "not set — ask once, write to <write_to>" when mode is autonomous>
Where we are: <progress line with denominator> · last commit <git.head> <age> · <dirty n> dirty
Verdict: <plans.verdict.state> — <plans.verdict.reason>
Dropped from handoff: <item> — landed in <sha>            (omit if none)
NEXT: <one action>                                        (S/M/L from the step's Size)
Why: <one sentence citing the step, the decision, or the blocker it clears>
Alternative: <one other candidate and why it lost>
Needs: <input / research / tools — from sections.needs_input, needs_research, env.requires>
Read first: <file 1>, <file 2>, <file 3>
Watch: <staleness or warning that matters — a "liveness probe failed" warning always matters>   (omit if none)
To review: <n> ASSUMED — the 5 newest as <ts> <text>, then "+N more in <plan>"   (plans.active.decisions.assumed; omit if none)
Review: <n> unreviewed (<k> risky), <r> rejected — /gates-bypass review   (review.*; omit when review.present is false or all three are 0)
Parked: <n> denied / <m> auto-allowed by the unattended window today — the 3 newest denied as <ts> <tool> <cmd>   (omit if the log is absent)
```

**Parked line.** Read `~/.claude/logs/unattended-parked.ndjson` with the `Read` tool and a large `limit` (it is append-only: the newest lines are LAST; never a shell command naming it: an active
window parks any Bash call that names `unattended`). `/next` persists nothing, so count today's lines by `converted` (`deny` = parked, `allow` = auto-allowed). A `deny` line is
something an unattended run could not do and that needs the user; surface it as a candidate NEXT when it blocks the plan.

**Review line.** `review` is the bypass-review queue (framework-health step 5): what a bypassed gate or an unattended
window let through without asking. Risky events (`k`) or a rejected group (`r`) make it a candidate NEXT —
*Review now* runs `/gates-bypass review`, which reads its section of that skill and follows it. Acknowledging and rejecting are
the user's own verbs (they prompt, and refuse while an unattended window is live): never run them from `/next`.

An `ASSUMED` or `AGREED` entry is written with `bash ~/.claude/bin/project-state.sh --append-decision
[<plan>] <AGREED|ASSUMED> "<text>"` — it stamps from the clock, so a hand-guessed stamp cannot trip
`decision-timestamp-after-mtime`.

`Mode` is re-resolved on every run (bypass state can change mid-session); it and the schedule
come from the same resolver and helper the SessionStart banner uses, so they cannot disagree.
`+cf` marks the confident-pick enable (family `cf`, row 26zg): mid-task questions follow its tiered rule
(pick on an objective test; advisor() must agree on a reversible in-scope grey case; otherwise ask), whatever the mode.

**Verdict line.** `plans.verdict` (row 26s) is what keep-going stops on: `actionable` = a doing/todo step
exists, and NEXT defaults to `plans.verdict.next` unless Step 2 overrides it (a crash → `/recover-session`,
a risky Review or a blocking Parked line, a handoff item that outranks the step); `needs-user` = nothing
actionable, but blocked/deferred steps (`waiting`), an unknown State cell, a skipped status row, or open
Needs input / Blocked entries wait on the user, so NEXT names what the user must do; `done` = every step
done/certified/confirmed and nothing waiting. No active plan, or one with zero steps, is `needs-user`. It
reads the plan only, never git dirt, so a step that needs the user must be marked `blocked` or listed under
Needs input, or it reads as actionable. Which entries count as closed (a leading `RESOLVED`/`RULED`/`DONE`/`CLOSED`,
a short `label — RESOLVED` prefix, striking or checking it, a sole bare `Nothing`) is docs/SPEC.md §2.13 item 14.

Every line cites a collector field or a `file:line`, or carries an *Inferred* grade. Never
write the phrase "blast radius" (say *affected surfaces*) — the completion guard matches it.

Close with one `AskUserQuestion`: *Start NEXT now (Recommended)* / *Take the alternative* /
*Show the full /progress report* / *Not now*. On "Start", proceed under the normal CLAUDE.md
gate: state the task size and go through the phases; `/next` does not skip them.

## Certification honesty

The collector behind this skill is execution-certified (`bin/tests/project-state.test.sh`);
this rendering is a prompt, invoked once on `~/.claude` on 2026-09-02 (the "Deep" branch
with no raw files present) and never otherwise exercised.
