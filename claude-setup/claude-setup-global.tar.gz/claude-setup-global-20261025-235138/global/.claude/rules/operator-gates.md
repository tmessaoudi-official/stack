<!-- Moved verbatim from ~/.claude/CLAUDE.md (operator-gates.md) by domain-agnostic step 9, 2026-10-09.
     Loads in every ~/.claude session (project rules of ~/.claude); other projects read docs/SPEC.md §2 on demand. -->

## From CLAUDE.md (Phase 3C)

**A bypass can be scoped to a directory tree** (2026-09-22). Besides the three legacy sentinel
scopes, `state/gates-bypass-rules.json` holds path rules: an absolute path, `recursive` true/false,
the guard families it covers, an optional `except` list of subtrees where the guard stays armed, and
an optional `expires` date. All four sources are an independent **OR** — none outranks another — and
all resolve through one shared function, `bypass_applies` in `hooks/bypass-resolve.sh`. The rules
exist because the legacy per-project sentinel is an *exact* cwd match, which stranded three
overnight runs when the shell drifted into a subdirectory. Two things to know when reasoning about
them: **an except is a hole in its own rule** (row 26zu, user rulings 2026-10-17 01:02), matched on the
target when the guard has one (prework, firewall, perm, the ask-human file tools) and on the session cwd
otherwise (the Stop guards, kg, cf, eg, auto3c, ah prompts, the level); inside it only a strictly deeper
covering rule that reaches the point decides, and every entry lies strictly inside its rule path; and the model is **strict and loud** — one malformed rule invalidates the entire
file, every gate stays armed, and `⚠⚠ RULES-INVALID` appears on statusline line 2. Ask the user to diagnose with
`/gates-bypass --lint` (a user-only skill).

## From CLAUDE.md (Phase 3C)

**A grant is family-scoped; an `except` unions across families** (2026-09-22). A rule bypasses only
the families in its own `guards[]`, but its `except` subtrees stay armed for *every* family — so a
blacklist written for one guard cannot be walked around via another. Row 26zu narrows the union to
same-depth and shallower rules: a strictly deeper covering rule that reaches the target decides there
(`holed` in `_BYPASS_VRULE`), so an ancestor's except never vetoes a deeper project's own grant. Never "simplify" the two
resolver functions (`bypass_any_except`, `bypass_except_hit`) by passing a family through: that
reintroduces a hole where the Edit tool prompts but `sed -i` into the same path is silent.
"Stays armed" means **prompts**: a blacklisted path asks on every Bash command that names it,
reads included, so both layers say the same thing. It did NOT start out that way — as first shipped
an `except` only withdrew the rule's grant, which protects nothing where the firewall has no
baseline ask, and `sed -i` into a blacklisted `api/vendor` was silent while `Edit` on the same path
prompted. Three things keep it honest and are easy to break: the ask sits **below `deny`**, which is the
only ordering that decides an outcome (`deny` exits; `defer` merely logs, so the blacklist ask
fires either way and ordering there only decides whether the prompt NAMES the blacklist); the
`bypass_any_except` check lives **outside** the `bypass_applies fw` branch, or a perm-only rule
never reaches Bash; and the post-loop `exit 0` is gated on `FW_BYPASS_PENDING`, because that exit is
a bypass and an except alone must not authorise one. Noise is bounded: only statically resolved
literal paths count, so `grep -r x .` stays silent.

## From CLAUDE.md (Phase 3C)

**A seventh family, `perm`, covers Claude Code's own `settings.json` prompts** (2026-09-22). It is
**rules-only** — no env var, no sentinel files. Since the 2026-09-30 engine cutover the LIVE engine reads
`state/gates-bypass-rules.json` itself; the legacy arming by `bin/permission-swap.sh` (it emptied `ask`/`deny` wholesale) is retired to
`off` only (f82e7653; ~/.claude/CLAUDE.md still says "armed by", flagged for the user), so the rest of this paragraph applies only while a
legacy swap is still armed. A `perm` rule's `except` subtrees are *compiled* into synthesized
`ask` rules installed into the armed `settings.json`, so the blanket bypass stays and only the
blacklisted subtrees prompt. Two operational consequences bind Claude: **after editing any `perm`
rule, run `bash ~/.claude/bin/permission-swap.sh recompile`** or the change has no effect while the
statusline still shows `PERM(rule)` — expect that command to PROMPT, because it reads
`state/gates-bypass-rules.json` and `state/` is itself blacklisted; that is the design working, not
a fault, and the same applies when the user runs `/gates-bypass --lint` (a user-only skill); and `off` restores the pristine rules from the sentinel, never
from the compiled set. A hook's `allow` cannot cancel an `ask` rule, so removing rules is the only
mechanism — do not propose a hook as a way to silence a permission prompt.

## From CLAUDE.md (Phase 3C)

**Level `total`** (2026-09-24): an fw grant at level total (rule `"level":"total"`, sentinel content
`total`) never asks — only the deny floor refuses (credential reads/uploads, host-critical writes — for the
spellings §2.4 lists; since plan `credential-ancestor-tiering` a recursive read of a tree holding a credential
store (also `find … -exec <reader> {}` and `mv`, plan `find-exec-tree-read`) and a credential path given to an unmodelled verb ASK at normal and DENY at total — so `grep -rn X .` from
`~` or `~/.claude` is refused at total: use the Grep tool; `$( )`-built read paths remain open, §2.4), and
an unclassifiable command is allowed (unless an except is in play, row 26zu); the global swap at `--level=total` installs zero ask/deny rules
(a `perm` RULE at total only drops its own except asks). Statusline:
`fw!` / `perm!` in the `⚠ bypassed …` gates group, `PERM-OPEN!` / `PERM-PROJ!`. At total the self-mod tier is ignored (ruling 2026-09-24),
but every `except` is HONOURED (row 26zu, superseding that ruling for excepted subtrees): a target inside a hole asks
and a cwd inside one has no total grant; the floor
still denies a credential path (or a host write) found in the RAW text of a command the classifier could
not classify (`docs/SPEC.md` §2.4).
