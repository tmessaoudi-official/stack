<!-- Moved verbatim from ~/.claude/BLAST-RADIUS.md (operator-registries.md) by domain-agnostic step 9, 2026-10-09.
     Loads in every ~/.claude session (project rules of ~/.claude); other projects read docs/SPEC.md §2 on demand. -->

## From BLAST-RADIUS.md (Protected paths)

`~/.claude/state/gates-bypass-rules.json` belongs to the same protected class. It is not a
presence-only sentinel but a **payload-carrying** config: it holds every recursive bypass scope,
except-list and expiry for this machine, so leaking it in a bundle would export the complete map of
which safety gates are off and where. It matches both arms of the export leak assertion (the
`*/state/*` path clause and the `*-bypass-*` name clause) and has explicit regression tests —
cases (e) and (f) in `bin/tests/claude-export-leak-check.test.sh`. Do not rely on the name clause
alone if that assertion is ever refactored; the note below about thin name-clause protection applies
to this file too.

## From BLAST-RADIUS.md (Protected paths)

asserts against leakage at build time). The permission-swap sentinels' protection is thinner than the
bypass toggles': the export assertion's path clause (`-path '*/state/*'`) still catches them, but its
name clauses (`-name '*-bypass'`, `-name '*-bypass-*'`) do not — don't assume a refactor of that
assertion preserves coverage for these two filenames.

## From BLAST-RADIUS.md (Protected paths)

**One carve-out inside `state/`: `~/.claude/state/model-notice/`** (model policy v2, D22, 2026-09-29) is NOT a sentinel set. It holds
one per-session marker file written by `hooks/skill-model-notice.sh`, which prunes files older than 7 days itself — except the
running session's own file — because `claude-cleanup.sh` never touches `state/`. Do not "fix" that prune to match the rule above,
and do not delete the directory's files by hand while a session is running (the user's override for that session lives in them).
It sits under `state/` only so that modelled shell writers (redirects, `sed -i`, `touch`) ask before writing to it; an
interpreter writing from inside its own code (`python3 - <<EOF`) does not ask (probed 2026-09-29).

## From BLAST-RADIUS.md (§ Config Artifact Updates)

### Config Artifact Updates — Manual Registries

These registries are **not auto-synced** — adding a file or plugin does not update them. Missing entries cause silent omissions at bundle/install time. Check after every new command or plugin.

| Trigger | Registry to update | File |
|---------|--------------------|------|
| New `~/.claude/skills/*/SKILL.md` created | `_CE_GENERIC_SKILLS` — add the entry | `~/.claude/bin/lib/claude-export/config/defaults.sh` |
| New local plugin or skill created under `plugins/marketplaces/local/` | Review `_CE_EXCLUDES` scope — `"plugins/"` blocks the whole tree | Same file |
| New `~/.claude/bin/` script created that should travel with a bundle | `_CE_GENERIC_SKILLS` or `_CE_ORIGIN_ONLY_FILES` depending on portability | Same file |
| New hook/script that joins the permission engine or shadow logging (`perm_shadow.py`, `perm-request-log.sh`, `gates_bypass.py` ...) | firewall `SELFMOD` list; engine `protected` + `ask` in `config/permission-rules.json` (`Edit(~/.claude/...)` form; `settings.json` keeps only the backstop denies since the 2026-09-30 cutover, so do NOT add a settings ask) via the user-run `bin/gates-bypass-ask-apply.sh` (it writes the engine file only while the engine is LIVE); keep `logs/` (command text) out of exports | `hooks/ask-bash-firewall.sh`, `config/permission-rules.json`, `settings.json` |
| New unattended-window files (`bin/unattended.sh`, `bin/lib/unattended.py`, `state/unattended.json`) | engine `protected` (Edit + `Bash(*unattended*)` rules), firewall `SELFMOD`, export list; `logs/unattended-parked.ndjson` holds command text: keep out of exports | `config/permission-rules.json`, `hooks/ask-bash-firewall.sh`, `bin/lib/claude-export/config/defaults.sh` |

**Automated backstop**: `/audit` Agent I surfaces drift between `defaults.sh` and `~/.claude/skills/`. Run after any sprint that creates skills or plugins — it is the canary that catches what manual review misses.
