<!-- Moved verbatim from ~/.claude/CLAUDE.md (operator-memory.md) by domain-agnostic step 9, 2026-10-09.
     Loads in every ~/.claude session (project rules of ~/.claude); other projects read docs/SPEC.md §2 on demand. -->

## From CLAUDE.md (Memory System Toggles)

**Model override**: Set `SR_MODEL=<model-id>` in the environment before starting Claude Code to override the model of every session-remember call class that has no knob of its own. Per-class knobs win over it: `SR_MODEL_BULK`, `SR_MODEL_CONSOLIDATE` and `SR_MODEL_HANDOFF` (all default `claude-haiku-5-5` since 2026-10-08/09 — bulk/consolidate 2026-10-08, handoff 7c8cac22; CLAUDE.md names no model id, only "haiku by default"; these calls are headless and cannot ask, so the default is the decision) — see `refs/SESSION-REMEMBER.md` (date-suffix-free, forward-compatible).

**Timezone override**: Set `SR_TZ=<zone>` (e.g. `SR_TZ=UTC`, `SR_TZ=America/New_York`) to override the session-remember consolidation timezone. Default: `{{TZ}}`. Required on any machine where `$TZ` is not set to Paris — without this, daily consolidation fires at the wrong time and all session timestamps are offset.

**Tunable knobs** (set as env vars before launching Claude Code): see `~/.claude/refs/SESSION-REMEMBER.md` for the full table.
