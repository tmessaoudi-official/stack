#!/usr/bin/env python3
"""Permission engine core (plan: permission-unification). Called ONLY by hooks/permission-engine.sh. PERM_ENGINE_MODE=shadow logs SHADOW-<decision> and prints nothing.

stdin  : the PreToolUse hook payload (JSON)
stdout : one hook-decision JSON line, or nothing (= no decision, the harness default applies)
exit   : 0 on success; any exception => nonzero, which the wrapper turns into the CONSTANT ASK (a DENY for an Edit-family call under
         bypassPermissions or with no permission_mode key - row 26a).

Rules live in config/permission-rules.json (settings shape: {"permissions":{"deny","ask","allow"},"floor":[...],"protected":[...]}).
Matching semantics were MEASURED against the real harness: docs/research/perm-hook-probe-20260930/SEMANTICS.md.
Intended, stricter divergences: D1 bash -c / sh -c / eval payloads are analysed; D2 ~ and $HOME are equivalent;
D4 a rule that contains | && or ; is also matched against the WHOLE command (per-sub-command matching can never fire it);
D5 a Grep/Glob of a directory at or under a protected Read rule's directory is a hit (the harness lets it through);
D3 `--lint` flags a single-slash file rule (root-relative in the harness).
"""
import functools
import json
import os
import re
import shlex
import stat
import subprocess
import sys
import time

HOME = os.path.expanduser('~')
HOOKDIR = os.path.dirname(os.path.abspath(__file__))
_T0 = time.time()
EDIT_TOOLS = {'Edit', 'Write', 'NotebookEdit', 'MultiEdit'}
READ_TOOLS = {'Read', 'Grep', 'Glob', 'NotebookRead'}
SHELLS = {'bash', 'sh', 'zsh', 'dash', 'ksh'}
SIMPLE_WRAPPERS = {'nohup', 'time', 'command', 'exec', 'builtin'}
MAX_DEPTH = 4
ASSIGN = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*=')
# Protected-tier read-only exemption (plan protected-tier-readonly-exempt, 2026-10-01). Deliberately NOT SAFE_BUILTINS: no sed (w command), find (-exec),
# sort (-o), node, awk, tee, git, pagers (LESSOPEN / +!cmd run a shell); rg only without --pre (runs a command per file).
READ_VERBS = {'cat', 'head', 'tail', 'wc', 'ls', 'stat', 'file', 'diff', 'echo', 'printf', 'grep', 'egrep', 'fgrep', 'rg', 'jq', 'nl', '[', 'test'}     # `[[` is NOT: it evaluates arithmetic (runs code)
# A protected Bash rule that names a bypass SENTINEL (the confident-pick enable too, row 26zg) or the bypass rules file, and nothing else (row 26r, 26k any-verb, user ruling 2026-10-14): any
# command that WRITES the path asks, whatever the verb. Such a rule is CORE (parked in an allow window), exempts only a reader with no FILE redirect
# (>/dev/null, 2>/dev/null and N>&M are stripped first; a /tmp/ redirect target may be a symlink into state/), and also matches a heredoc body when an interpreter is in the command.
SENTINEL_RULE = re.compile(r'^\*(?:[a-z0-9-]+-bypass|permission-profile-[a-z-]+\.json|expertise-gate-off|confident-pick|gates-bypass-rules\.json|\.claude/run/\*-bypass-)\*$')
INTERPRETERS = SHELLS | {'python', 'python3', 'perl', 'ruby', 'node', 'php', 'awk', 'xargs', 'eval', 'source', '.', 'fish', 'lua', 'tclsh', 'deno', 'bun', 'pwsh', 'busybox'}
# Commands the harness runs WITHOUT any allow rule (measured, default mode, headless: docs/research/perm-hook-probe-20260930).
# They never block an allow of the other sub-commands. NOT safe (measured to prompt): git status/log/diff, grep, uniq, awk,
# env, printenv, touch, cp, rm, python3, curl, timeout, export, mkdir, tee.
SAFE_BUILTINS = {'cd', 'echo', 'pwd', 'true', 'ls', 'cat', 'test', '[', 'sleep', 'date', 'head', 'tail', 'wc', 'sort', 'tr',
                 'cut', 'basename', 'dirname', 'printf', 'which', 'uname', 'whoami', 'id', 'find', 'sed', 'readlink',
                 'realpath', 'hostname', 'df', 'du', 'ps', 'type', 'nproc', 'seq', 'stat', 'file', 'diff', 'node'}


# ---------------------------------------------------------------- Bash parsing
def _strip_heredocs(cmd, keep_quoted=False):
    """Remove heredoc BODIES (data). -> (text_without_bodies, [unquoted-tag bodies; every body with keep_quoted], ok).
    Only an operator OUTSIDE quotes counts (a false detection would hide real commands); a heredoc with no
    terminator is left unstripped and reported ok=False (fail toward more analysis, never less)."""
    out, bodies, ok = [], [], True
    i, n, q = 0, len(cmd), None
    pending = []                                   # (tag, quoted, strip_tabs) awaiting the next newline
    while i < n:
        c = cmd[i]
        if q:
            out.append(c)
            if c == '\\' and q == '"' and i + 1 < n:
                out.append(cmd[i + 1]); i += 2; continue
            if c == q:
                q = None
            i += 1; continue
        if c == '\\' and i + 1 < n:
            out.append(c); out.append(cmd[i + 1]); i += 2; continue
        if c in '\'"':
            q = c; out.append(c); i += 1; continue
        if cmd.startswith('<<', i) and not cmd.startswith('<<<', i):
            m = re.match(r'<<(-?)[ \t]*(?:\'([^\']+)\'|"([^"]+)"|([A-Za-z_][A-Za-z0-9_]*))', cmd[i:])
            if m:
                tag = m.group(2) or m.group(3) or m.group(4)
                pending.append((tag, bool(m.group(2) or m.group(3)), m.group(1) == '-'))
                out.append(m.group(0)); i += len(m.group(0)); continue
        if c == '\n' and pending:
            out.append(c); i += 1
            for tag, quoted, strip in pending:
                body, found = [], False
                while i <= n:
                    j = cmd.find('\n', i)
                    line = cmd[i:] if j < 0 else cmd[i:j]
                    i = n + 1 if j < 0 else j + 1
                    if (line.lstrip('\t') if strip else line) == tag:
                        found = True; break
                    body.append(line)
                if not found:
                    ok = False                      # unterminated: analyse the text as-is
                    out.append('\n'.join(body)); i = n
                elif not quoted or keep_quoted:
                    bodies.append('\n'.join(body))
            pending = []
            continue
        out.append(c); i += 1
    return ''.join(out), bodies, ok


def _split_top(cmd):
    """Split on unquoted && || ; | & and newline. Returns (segments, ok). ok=False on unbalanced input."""
    segs, cur, i, n = [], [], 0, len(cmd)
    q = None          # current quote char
    depth = 0         # ( ) and $( ) nesting
    bt = False        # inside backticks
    while i < n:
        c = cmd[i]
        if q:
            cur.append(c)
            if c == '\\' and q == '"' and i + 1 < n:
                cur.append(cmd[i + 1]); i += 2; continue
            if c == q:
                q = None
            i += 1; continue
        if c == '\\' and i + 1 < n:
            cur.append(c); cur.append(cmd[i + 1]); i += 2; continue
        if c in '\'"':
            q = c; cur.append(c); i += 1; continue
        if c == '`':
            bt = not bt; cur.append(c); i += 1; continue
        if c == '#' and (not cur or cur[-1] in ' \t\n;&|('):      # comment: rest of the line is not a command
            while i < n and cmd[i] != '\n':
                i += 1
            continue
        if c == '&' and cmd[i:i + 2] != '&&':
            prev = cmd[i - 1] if i else ''
            if prev in '<>' or cmd[i + 1:i + 2] == '>':            # >&2  2>&1  &>  &>>
                cur.append(c); i += 1; continue
            if prev == '|':                                        # |& (pipe stderr too)
                i += 1; continue
        if c == '(':
            depth += 1
        elif c == ')':
            depth = max(0, depth - 1)
        if depth == 0 and not bt:
            two = cmd[i:i + 2]
            if two in ('&&', '||'):
                segs.append(''.join(cur)); cur = []; i += 2; continue
            if c in ';|&\n':
                segs.append(''.join(cur)); cur = []; i += 1; continue
        cur.append(c); i += 1
    segs.append(''.join(cur))
    return [s.strip() for s in segs if s.strip()], (q is None and depth == 0 and not bt)


def _inner_groups(seg, quotes=True):
    """Bodies of $( ), backticks and a leading ( ) subshell / { } group in one segment.
    quotes=False for an unquoted heredoc body, where ' and " are literal text and only $( ) / backticks run."""
    out = []
    i, n = 0, len(seg)
    q = None                                         # None | "'" | '"': inside '...' $( ) and backticks are inert; inside "..." they RUN and a ' is literal
    while i < n:
        c = seg[i]
        if c == '\\' and q != "'" and i + 1 < n:
            i += 2; continue
        if quotes and q is None and c in ('\'', '"'):
            q = c; i += 1; continue
        if quotes and q is not None and c == q:
            q = None; i += 1; continue
        if q == "'":
            i += 1; continue
        if seg.startswith('$(', i):
            d, j = 1, i + 2
            while j < n and d:
                d += (seg[j] == '(') - (seg[j] == ')'); j += 1
            out.append(seg[i + 2:j - 1] if d == 0 else seg[i + 2:]); i = j; continue
        if c == '`':
            j = seg.find('`', i + 1)
            out.append(seg[i + 1:j] if j > 0 else seg[i + 1:]); i = (j + 1) if j > 0 else n; continue
        i += 1
    s = seg.strip()
    if s.startswith('(') and s.endswith(')'):
        out.append(s[1:-1])
    if s.startswith('{') and s.rstrip().endswith('}'):
        out.append(s.strip('{} ;'))
    return out


def _strip_wrappers(words):
    """Drop leading VAR=x assignments and env/nohup/time/... wrappers; returns the effective words."""
    w = list(words)
    changed = True
    while w and changed:
        changed = False
        while w and ASSIGN.match(w[0]):
            w.pop(0); changed = True
        if w and w[0] == 'env':
            w.pop(0)
            while w and (w[0].startswith('-') or ASSIGN.match(w[0])):
                w.pop(0)
            changed = True
        elif w and w[0] in SIMPLE_WRAPPERS:
            w.pop(0); changed = True
        elif w and w[0] == 'timeout':
            w.pop(0)
            while w and (w[0].startswith('-') or re.match(r'^[0-9.]+[smhd]?$', w[0])):
                w.pop(0)
            changed = True
        elif w and w[0] == 'nice':
            w.pop(0)
            while w and (w[0].startswith('-') or re.match(r'^[0-9]+$', w[0])):
                w.pop(0)
            changed = True
    return w


def _payload(words):
    """The command string a shell -c / eval would run, or None."""
    if not words:
        return None
    if words[0] == 'eval':
        return ' '.join(words[1:]) or None
    if os.path.basename(words[0]) in SHELLS:
        for k, w in enumerate(words[1:], 1):
            if w.startswith('-') and not w.startswith('--') and 'c' in w[1:] and k + 1 < len(words):
                return words[k + 1]
    return None


_ASSIGN_LIT = re.compile(r'(?:^|[;&|\n])\s*([A-Za-z_][A-Za-z0-9_]*)=([^\s;&|$`"\'()<>]+)')
_SED_ADDR = re.compile(r'^[0-9]*(,[0-9]*|,\$)?p$|^\$p$')
_REDIR = re.compile(r'(?<![0-9])(&>>?|[0-9]*>>?|>&)\s*(\S+)')


def _literal_assigns(cmd):
    """VAR=literal assignments in the command (no $, backtick, quote or substitution in the value). Chained values are NOT resolved: a value containing $ is not literal."""
    return dict(_ASSIGN_LIT.findall(cmd))


def _tmp_target(t, assigns):
    """True when a redirect target STATICALLY lands under /tmp/: a literal /tmp/... path or $VAR/${VAR} whose literal value is under /tmp/; no `..`, no $ or backtick left."""
    t = t.strip('\'"')
    m = re.match(r'^\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?(/.*)?$', t)
    if m:
        if m.group(1) not in assigns:
            return False
        t = assigns[m.group(1)] + (m.group(2) or '')
    t = t.strip('\'"')
    return t.startswith('/tmp/') and '..' not in t and '$' not in t and '`' not in t and '(' not in t


# A NAME operand runs code: `a[$(cmd)]` given to printf -v NAME or test -v NAME evaluates the subscript (panel 26s B-P1-1; re-probed 2026-10-15,
# bash 5.3.9, with a marker file and a quoted heredoc so no outer shell expanded the $()). The numeric operands do NOT: printf's numeric
# conversions, a `*` width or precision, %(fmt)T, and test's -t / -eq -ne -lt -le -gt -ge reject 'a[$(cmd)]' and '1+1' unevaluated
# ("invalid number", "integer expected"); only [[ -eq ]], declare -i and let do arithmetic. The first probe (2026-10-14) was a false
# positive. The stricter rule below stays (row 26v, B2-P3-1): it costs an ask, never a silent pass. So printf is a reader only with a
# LITERAL format (no $ or `) of %s %b %q %c %% alone, and test only without the operators below.
_TEST_ARITH = {'-v', '-t', '-eq', '-ne', '-lt', '-le', '-gt', '-ge'}
_PRINTF_SPEC = re.compile(r'%(?:%|[-+ #0-9.]*[sbqc])')


def _printf_reads(args):
    a = list(args)
    if a and a[0] == '--':
        a = a[1:]
    if not a:
        return True
    if a[0].startswith('-'):
        return False                                      # -v NAME (or an option we do not model)
    fmt = a[0]
    if '$' in fmt or '`' in fmt:
        return False                                      # a run-time format can hold any spec
    return '%' not in _PRINTF_SPEC.sub('', fmt)


def _read_only_entry(seg, words, eff_words, assigns=None, strict=False):
    """True when this sub-command only READS: raw words start (after harmless timeout/nice/command/rtk) with a READ_VERBS verb - no VAR=x, no env in front
    (an assignment can turn a reader into a runner) - and the segment has no output redirect / process substitution, and rg has no --pre."""
    prefix = words[:len(words) - len(eff_words)] if len(eff_words) <= len(words) else words
    if any(w == 'env' or ASSIGN.match(w) for w in prefix):
        return False
    ew = list(eff_words)
    if ew and ew[0] == 'rtk':
        ew = ew[1:]
    if ew and ew[0] == 'sed':
        args = [x for x in ew[1:] if x != '-n']
        if '-n' not in ew[1:] or not args or not _SED_ADDR.match(args[0]):
            return False                                  # only `sed -n <address>p FILE`: any other script can write (w) or execute (e)
        if any(x.startswith('-') for x in args) or any(x in ('-i', '--in-place') or x.startswith('-i') for x in ew[1:]):
            return False
    elif not ew or ew[0] not in READ_VERBS:
        return False
    if ew[0] == 'printf' and not _printf_reads(ew[1:]):
        return False                                      # printf evaluates ARITHMETIC (a subscript runs `$(cmd)`) for -v NAME and every numeric spec
    if ew[0] in ('[', 'test') and any(x in _TEST_ARITH for x in ew[1:]):
        return False                                      # the same for [ / test with -v, -t or an arithmetic comparison (also after ! / -o)
    rest = re.sub(r'(?<![0-9])[0-9]*>&[0-9-]+(?=\s|$|[;&|)])|(?<![0-9])&?[0-9]*>>?\s*/dev/null(?=\s|$|[;&|)])', '', seg)     # (?<![0-9]): a 40k-digit run was O(n^2) (20 s, panel F4)     # only the harmless forms are stripped; ANY other '>' (2>f, &>f, >&f, >>f, >(cmd)) is a writer
    if '<(' in rest or '>(' in rest:
        return False
    if '>' in rest:                                       # a redirect is a WRITE; harmless only when every target statically lands under /tmp/ (commit-message files)
        masked = re.sub(r"'[^']*'|\"(?:[^\"\\\\]|\\\\.)*\"", lambda m: 'Q' * len(m.group(0)), rest)      # a '>' inside quotes is data: mask quoted strings (same length) before parsing operators
        if strict and '>' in masked:
            return False                                  # strict (sentinel rules): any file redirect is a write, /tmp/ included (a symlink there can point into state/)
        ops = list(_REDIR.finditer(masked))
        if sum(m.group(1).count('>') for m in ops) != masked.count('>') or not all(_tmp_target(rest[m.start(2):m.end(2)], assigns or {}) for m in ops):
            return False                                  # an operator we could not parse (`>&file`, `2>&1x`) or a target not statically under /tmp/
    if ew[0] == 'rg' and any(x == '--pre' or x.startswith('--pre=') or x.startswith('--pre-glob') for x in ew[1:]):
        return False
    return True


COMPOUND_STARTERS = {'while', 'until', 'for', 'if', '{', '(', 'case', 'read', 'select'}      # a pipe into one of these feeds everything after it
LAUNCHERS = {'do', 'then', 'else', 'elif', 'while', 'until', '!', '{', '(', 'time', 'exec', 'command', 'builtin', 'nohup', 'setsid', 'nice', 'ionice',
             'stdbuf', 'env', 'sudo', 'timeout', 'rtk', 'proxy'}


def _may_run_code(e):
    """A non-reader segment whose VERB (first word after shell keywords, launchers, options, numbers and assignments) is an interpreter or a variable /
    substitution (`do $c`, `setsid $SHELL`, `nice -n 10 ionice -c 3 bash`, `rtk proxy bash`). A `$word` that is merely an ARGUMENT (`printf '%s' "$s"`,
    `git log -- "$X"`) is not an interpreter: the 2026-10-01 13:01 loop prompt came from treating it as one. Used only to withdraw the protected-tier
    read-only exemption when a pipe could feed it. Residual: an option VALUE that is not a number (`stdbuf -o L bash`) hides the verb."""
    if e.get('whole') or e.get('ro'):
        return False
    for x in e.get('words') or []:
        if x in LAUNCHERS or x.startswith('-') or ASSIGN.match(x) or re.fullmatch(r'[0-9.]+[smhd]?', x):
            continue
        return x[:1] in ('$', '`') or os.path.basename(x) in INTERPRETERS
    return False


def parse_bash(cmd, depth=0):
    """-> (entries, ok). entry = {'eff': effective command, 'aux': [other spellings for deny/ask]}."""
    entries = []
    cmd, bodies, ok = _strip_heredocs(cmd)                           # bodies are DATA, except $( )/`` in unquoted ones
    assigns = _literal_assigns(cmd) if depth == 0 else {}
    entries.append({'eff': None, 'aux': [cmd], 'whole': True})     # D4: compound-shaped rules match the whole line
    for b in bodies:
        for inner in _inner_groups(b, quotes=False):
            if depth < MAX_DEPTH:
                e2, ok2 = parse_bash(inner, depth + 1); entries += e2; ok = ok and ok2
    segs, balanced = _split_top(cmd)
    ok = ok and balanced
    if not balanced:                      # unparseable: also cut naively so deny/ask can still match
        segs = segs + [s.strip() for s in re.split(r'&&|\|\||;|\||\n', cmd) if s.strip()]
    pos = 0
    fed = False
    for seg in segs:
        at = cmd.find(seg, pos)
        prev = cmd[:at].rstrip()[-2:] if at >= 0 else ''
        after_pipe = prev.endswith('|') and not prev.endswith('||') or prev.endswith('|&')
        fed = fed or after_pipe and (seg.split(None, 1) or [''])[0] in COMPOUND_STARTERS
        after_pipe = after_pipe or fed
        if at >= 0:
            pos = at + len(seg)
        for inner in _inner_groups(seg):
            if depth < MAX_DEPTH:
                e2, ok2 = parse_bash(inner, depth + 1); entries += e2; ok = ok and ok2
        try:
            words = shlex.split(seg, posix=True)
        except ValueError:
            words = seg.split(); ok = False
        eff_words = _strip_wrappers(words)
        eff = ' '.join(eff_words)
        ro = depth == 0 and _read_only_entry(seg, words, eff_words, assigns)
        entries.append({'eff': eff if eff else seg, 'aux': list({seg, ' '.join(words)}), 'ro': ro, 'ros': ro and _read_only_entry(seg, words, eff_words, assigns, strict=True), 'words': words, 'afterpipe': after_pipe})     # only a TOP-LEVEL reader is exempt: a substitution / heredoc-body / -c payload reader is consumed by the command around it
        pay = _payload(eff_words)
        if pay and depth < MAX_DEPTH:
            e2, ok2 = parse_bash(pay, depth + 1); entries += e2; ok = ok and ok2
    return entries, ok


# ---------------------------------------------------------------- matching
@functools.lru_cache(maxsize=1024)                      # the SAME (long) command string was re-scanned for every rule: 826 calls x 1.3 ms on a 40 KB command = 1.1 s CPU (panel 2026-10-01)
def _expand_home(s):
    s = s.replace('${HOME}', HOME).replace('$HOME', HOME)
    return re.sub(r'(^|[\s=:])~(?=/|\s|$)', lambda m: m.group(1) + HOME, s)


def _glob_bash(pat):
    return re.sub(r'(\.\*){2,}', '.*', re.escape(pat).replace(r'\*', '.*'))      # `* **/x` made `.*\ .*.*/x` (cubic backtracking: 1.6 KB = 1.2 s CPU, panel 2026-10-01); adjacent stars mean the same as one


@functools.lru_cache(maxsize=None)     # re's own cache holds 512; 244 rules x variants overflowed it (3 KB command took 1.5 s)
def _bash_regex(pat):
    if pat.endswith(':*'):
        pat = pat[:-2] + ' *'
    if pat.endswith(' *'):
        return re.compile('^' + _glob_bash(pat[:-2]) + '( .*)?$', re.S)
    return re.compile('^' + _glob_bash(pat) + '$', re.S)


def bash_match(pat, sub):
    for p, s in ((pat, sub), (_expand_home(pat), _expand_home(sub))):
        if _bash_regex(p).match(s):
            return True
    return False


def _sent_match(pat, s):
    """bash_match for a SENTINEL_RULE pattern (`*lit*` / `*lit*lit*`, no `~`), in linear time: the DOTALL regex `^.*a.*b.*$` holds iff `a` occurs and
    `b` occurs after it, so find each literal after the previous one. The regex rescanned to the end at every `a`: 3000 `.claude/run/` lines in one
    `python3 -c` took 1.3-1.9 s (row 26r), and an engine timeout at total is SILENT. No home-expanded second try: no sentinel literal holds `~`, `$HOME`
    or a home path, so expansion can never create a match."""
    pos = 0
    for x in (x for x in pat.split('*') if x):
        i = s.find(x, pos)
        if i < 0:
            return False
        pos = i + len(x)
    return True


# ---- glob check (panel 26t A2-P1-1 + B2-P2-1, row 26v; cd-aware ruling 2026-10-14 22:35) ------------------------------------------------------
# A glob can only expand to a file that EXISTS, so the exact target list is the sentinel files already in state/, run/ and projects/*/state/ (one
# listing each, never a walk: glob.iglob('/*/*/*/*/*/*/*/zz') ran > 20 s and the wrapper's stall then failed OPEN at total). Each unquoted word is
# matched against them with BASH semantics ([!x] [^x] [[:alpha:]], braces, extglob after `extglob`, a redirect glued to a word, ~ ~+ ~user). A relative
# glob resolves against the payload cwd; a command that can change directory (cd/pushd/popd anywhere, a run-time verb, source) makes it cwd-independent.
# Every step counts against a per-call budget; past it the check fails CLOSED (asks). Accepted limits (SPEC 2.19): a $VAR / run-time word, a script
# file, an alias defined outside the command, extglob switched on outside it, a symlink deeper than the first glob component or made in the same command.
_GLOB_CH = re.compile('[*?\\[]')                   # : an overflowing numeric brace sequence (a run of digits and -)
_CD = re.compile(r'(?<![A-Za-z0-9_-])(?:cd|pushd|popd)(?![A-Za-z0-9_-])')
_ODD_VERB = re.compile(r'[$`{*?\[]')
_GLOB_STEPS, _BRACE_CAP, _SCAN_CAP = 200000, 256, 4096
_glob_left = [_GLOB_STEPS]
_SENT = [()]                                            # the loaded sentinel patterns (set per call by _glob_reset)


class _GlobBudget(Exception):
    """The glob check ran out of budget: the caller treats the word as reaching a sentinel (fail CLOSED). Raised, so lru_cache never stores it."""


def _glob_reset(prot=()):
    """Per evaluate() call: a fresh budget, fresh listings (perm_shadow_diff evaluates many calls in one process), the protected sentinel patterns."""
    _glob_left[0] = _GLOB_STEPS
    _SENT[0] = tuple(sorted({a for rt, a in map(_split_rule, prot) if rt == 'Bash' and SENTINEL_RULE.match(a)}))
    for f in (_sentinel_files, _cands, _glob_matches, _realpath, _scan_links):
        f.cache_clear()


def _spend(n):
    _glob_left[0] -= n
    if _glob_left[0] < 0:
        raise _GlobBudget()


@functools.lru_cache(maxsize=1)
def _sentinel_files():
    c = os.path.join(HOME, '.claude')
    dirs = [os.path.join(c, 'state'), os.path.join(c, 'run')]
    try:
        with os.scandir(os.path.join(c, 'projects')) as it:
            dirs += [os.path.join(e.path, 'state') for e in it]
    except OSError:
        pass
    out = []
    for d in dirs:
        try:
            with os.scandir(d) as it:
                out += [e.path for e in it]
        except OSError:
            pass                                          # no state/ there: nothing to reach
    return tuple(out)


@functools.lru_cache(maxsize=16)
def _cands(sargs):
    """The existing files a loaded sentinel pattern names: the only files a glob word can reach that matter."""
    return tuple(f for f in _sentinel_files() if any(_sent_match(a, f) for a in sargs))


@functools.lru_cache(maxsize=4096)
def _realpath(p):
    return os.path.realpath(p)


_POSIX = {'alpha': str.isalpha, 'digit': str.isdigit, 'alnum': str.isalnum, 'upper': str.isupper, 'lower': str.islower, 'space': str.isspace,
          'blank': lambda c: c in ' \t', 'punct': lambda c: c.isprintable() and not c.isalnum() and not c.isspace(), 'print': str.isprintable,
          'graph': lambda c: c.isprintable() and not c.isspace(), 'cntrl': lambda c: ord(c) < 32 or ord(c) == 127,
          'xdigit': lambda c: c in '0123456789abcdefABCDEF', 'word': lambda c: c.isalnum() or c == '_'}


@functools.lru_cache(maxsize=4096)
def _gcomp(p):
    """One path component of a bash glob -> (tokens, minimum length). Tokens: 0 = *, 1 = ?, 2 = a run of digits and -, a 1-char str (literal), or
    (negated, tests) for a bracket ([!x] and [^x] negate, a-z ranges, [:class:], an unknown class matches anything). An unclosed [ is a literal."""
    out, i, n = [], 0, len(p)
    while i < n:
        ch = p[i]
        if ch in '*':
            t = 0 if ch == '*' else 2
            if not out or out[-1] != t:
                out.append(t)
            i += 1
            continue
        if ch == '?':
            out.append(1); i += 1
            continue
        if ch == '[':
            j = i + 1
            neg = j < n and p[j] in '!^'
            j += neg
            k, tests, ce = j, [], -2
            while k < n and (p[k] != ']' or k == j):
                _spend(1)                                   # an unclosed [ scans to the end once per [: budgeted, else quadratic (row 26za)
                if p.startswith('[:', k) and ce != -1 and ce < k + 2:
                    ce = p.find(':]', k + 2)                # no later :] means none will appear: never rescan (B3-P3-1)
                if p.startswith('[:', k) and ce > k:
                    e = ce
                    tests.append(_POSIX.get(p[k + 2:e], lambda c: True)); k = e + 2
                elif k + 2 < n and p[k + 1] == '-' and p[k + 2] != ']':
                    tests.append(lambda c, lo=p[k], hi=p[k + 2]: lo <= c <= hi); k += 3
                else:
                    tests.append(lambda c, x=p[k]: c == x); k += 1
            if k < n:
                out.append((neg, tuple(tests))); i = k + 1
                continue
        out.append(ch); i += 1
    return tuple(out), sum(1 for t in out if t not in (0, 2))


def _closure(toks, st):
    todo = list(st)
    while todo:
        k = todo.pop()
        if k < len(toks) and toks[k] in (0, 2) and k + 1 not in st:
            st.add(k + 1); todo.append(k + 1)
    return st


def _gmatch(comp, s):
    """A compiled component against one name, as a set-of-positions automaton (no backtracking: O(tokens x len(s)), every step budgeted).
    dotglob is off: a leading . matches only a literal leading ."""
    toks, need = comp
    if need > len(s) or (s[:1] == '.' and toks[:1] != ('.',)):
        return False
    st = _closure(toks, {0})
    for c in s:
        _spend(len(st) + 1)
        nx = set()
        for k in st:
            if k == len(toks):
                continue
            t = toks[k]
            if t == 0 or t == 2 and (c.isdigit() or c == '-'):
                nx.add(k)
            elif t == 1 or (t == c if isinstance(t, str) else isinstance(t, tuple) and any(f(c) for f in t[1]) != t[0]):
                nx.add(k + 1)
        st = _closure(toks, nx)
        if not st:
            return False
    return len(toks) in st


_SEQ = re.compile(r'^(-?[0-9]+)\.\.(-?[0-9]+)(?:\.\.(-?[0-9]+))?$|^([A-Za-z])\.\.([A-Za-z])(?:\.\.(-?[0-9]+))?$')


def _brace_split(w):
    """(prefix, alternatives, suffix) of the first brace group bash expands (a top-level comma list or a {x..y[..z]} sequence), else None."""
    i = 0
    while True:
        i = w.find('{', i)
        if i < 0:
            return None
        depth, j, commas = 0, i, []
        _spend(1)
        while j < len(w):
            _spend(1)                                     # an unclosed { rescans to the end: budgeted (panel 26t B3-P3-1)
            if w[j] == '{':
                depth += 1
            elif w[j] == '}':
                depth -= 1
                if depth == 0:
                    break
            elif w[j] == ',' and depth == 1:
                commas.append(j)
            j += 1
        if j < len(w):
            if commas:
                bounds = [i] + commas + [j]
                return w[:i], [w[a + 1:b] for a, b in zip(bounds, bounds[1:])], w[j + 1:]
            m = _SEQ.match(w[i + 1:j])
            if m:
                num = m.group(1) is not None
                a, b = (int(m.group(1)), int(m.group(2))) if num else (ord(m.group(4)), ord(m.group(5)))
                inc = m.group(3) if num else m.group(6)
                st = abs(int(inc or 1)) or 1
                cnt = abs(b - a) // st + 1
                if cnt > _BRACE_CAP:
                    return w[:i], ['' if num else '?'], w[j + 1:]
                step = st if b >= a else -st
                return w[:i], [str(a + k * step) if num else chr(a + k * step) for k in range(cnt)], w[j + 1:]
        i += 1


def _braces(w):
    """Bash brace expansion of one word, at most _BRACE_CAP results in all; a larger product raises _GlobBudget (fail closed)."""
    todo, done = [w], []
    while todo:
        x = todo.pop()
        sp = _brace_split(x)
        if sp is None:
            done.append(x)
        else:
            todo += [sp[0] + a + sp[2] for a in sp[1]]
        _spend(1)
        if len(todo) + len(done) > _BRACE_CAP:
            raise _GlobBudget()
    return done


_EXTG = re.compile(r'[?*+@!]\(')


def _extglob(p):
    """With extglob on, ?( *( +( @( !( groups -> * (conservatively); a group that holds a / or never closes fails closed."""
    while True:
        m = _EXTG.search(p)
        if not m:
            return p
        depth, j = 0, m.end() - 1
        while j < len(p):
            depth += (p[j] == '(') - (p[j] == ')')
            if depth == 0:
                break
            j += 1
        if j >= len(p) or '/' in p[m.start():j]:
            raise _GlobBudget()
        p = p[:m.start()] + '*' + p[j + 1:]


def _tilde(p, cwd, cd):
    """-> (path, known). ~ and ~user expand; ~+ is the payload cwd outside cd mode; ~-, ~+ in cd mode and an unknown user are an UNKNOWN directory."""
    if not p.startswith('~'):
        return p, True
    head, sep, rest = p.partition('/')
    if head == '~':
        return HOME + sep + rest, True
    if head in ('~+', '~-'):
        return (cwd + sep + rest, True) if head == '~+' and cwd and not cd else (p, False)
    e = os.path.expanduser(head)
    return (e + sep + rest, True) if e != head else (p, False)


@functools.lru_cache(maxsize=256)
def _scan_links(d):
    """(name, real target) of the symlinks directly in d: one listing, capped (over the cap fails closed)."""
    out, n = [], 0
    try:
        with os.scandir(d) as it:
            for e in it:
                _spend(1)                                 # every entry costs budget (past it: fail closed); the cap counts symlinks (panel 26t A3-P3-2)
                if e.is_symlink():
                    n += 1
                    if n > _SCAN_CAP:
                        raise _GlobBudget()
                    out.append((e.name, _realpath(e.path)))
    except OSError:
        pass                                              # no such directory: no link to reach through
    return tuple(out)


def _comps_match(toks, comps):
    return len(toks) == len(comps) and all(_gmatch(t, c) for t, c in zip(toks, comps))


def _glob_one(p, known, cwd, cd, cands):
    """The candidates one expanded glob pattern reaches. The base name is matched first, so a word that names no sentinel lists nothing."""
    d, slash, b = p.rpartition('/')
    hits = [f for f in cands if b and _gmatch(_gcomp(b), os.path.basename(f))]
    if not hits or not known:
        return hits                                       # an unknown directory (~-, ~nouser): the base name decides (fail closed)
    if not slash:
        if cd:
            return hits                                   # bare word, cwd-independent
        rc = _realpath(cwd)
        return [f for f in hits if _realpath(os.path.dirname(f)) == rc]
    absolute = p.startswith('/')
    comps = d.split('/')
    if not absolute and cd:
        if any(_GLOB_CH.search(c) for c in comps):
            return hits
        if '..' in comps:
            comps = comps[len(comps) - comps[::-1].index('..'):]
        tail = [c for c in comps if c not in ('', '.')]
        if not tail:
            return hits
        suf = '/' + '/'.join(tail)
        return [f for f in hits if os.path.dirname(f).endswith(suf) or _realpath(os.path.dirname(f)).endswith(suf)]
    parts = (d if absolute else cwd.rstrip('/') + '/' + d).split('/')
    gi = next((k for k, c in enumerate(parts) if _GLOB_CH.search(c)), None)
    if gi is None:
        rd = _realpath('/'.join(parts) or '/')
        return [f for f in hits if _realpath(os.path.dirname(f)) == rd]
    rest = [c for c in parts[gi:] if c not in ('', '.')]        # a . or empty component never changes the directory (panel 26t A3-P2-3)
    if '..' in rest:
        return hits                                       # a .. after a glob component: the base name decides
    pre = _realpath('/'.join(parts[:gi]) or '/').rstrip('/')
    toks = [_gcomp(c) for c in rest]
    out = []
    for f in hits:
        for x in {os.path.dirname(f), _realpath(os.path.dirname(f))}:
            if x.startswith(pre + '/') and _comps_match(toks, x[len(pre) + 1:].split('/')):
                out.append(f)
                break
        else:
            rd = _realpath(os.path.dirname(f))
            for name, t in _scan_links(pre or '/'):       # a symlink in the first glob component (stln?/ -> state/)
                if _gmatch(toks[0], name) and (rd == t and len(toks) == 1 or rd.startswith(t + '/') and _comps_match(toks[1:], rd[len(t) + 1:].split('/'))):
                    out.append(f)
                    break
    return out


@functools.lru_cache(maxsize=1024)
def _glob_matches(word, cwd, cd, xg, sargs):
    """The sentinel files an unquoted WORD reaches when bash expands it, plus the literal names its braces build (bash creates those whether or not
    they exist). Raises _GlobBudget past the budget. A word still holding $ or ` after $HOME is the run-time class (accepted limit)."""
    out = []
    for piece in re.split(r'(?<![0-9])[0-9]*[<>&|]+', word):    # a redirect glued to a word: x>~/.claude/state/... (the lookbehind keeps a digit run linear, B3-P3-1)
        piece = re.sub(r'\$\{HOME\}|\$HOME(?![A-Za-z0-9_])', lambda m: HOME, piece)
        if not piece or '$' in piece or '`' in piece or not (_GLOB_CH.search(piece) or '{' in piece or xg and _EXTG.search(piece)):
            continue
        for alt in _braces(piece):
            if xg:
                alt = _extglob(alt)
            q, known = _tilde(alt, cwd, cd)
            if not _GLOB_CH.search(q):
                out.append(q)                             # a literal the braces built: _sent_match decides
            else:
                out += _glob_one(q, known, cwd, cd, _cands(sargs))
    return tuple(out)


def _verb(e):
    for x in e.get('words') or []:
        if not (x in LAUNCHERS or x.startswith('-') or ASSIGN.match(x) or re.fullmatch(r'[0-9.]+[smhd]?', x)):
            return x
    return ''


_CMD_START = LAUNCHERS | {'if', 'case', 'function', 'select', ';;'}   # not xargs: it runs programs, never the source / . builtins (an `xargs cd` is a cd WORD)


def _cd_mode(entries, bodies):
    """Can the command change directory before a glob expands? A cd/pushd/popd WORD anywhere in a segment (the parsed words have lost their quotes
    and escapes; a case arm's `x)` or a `(` / `{` glued in front is cut off), source / . as the verb or right after a command-start word (if, then,
    do, a case arm, a function head ...), an alias or eval whose text holds one, a run-time verb, or a cd in an interpreter body. A whole
    word only: a commit message that says cd is one word with spaces and stays out (panel 26t A3-P3-4). Not only the verb: `if cd`, `f() { cd`,
    `case x in x)cd` and `xargs cd` were silent (panel round 3 A-P1-1). A cd word that is only an argument (`echo cd`) also counts: that errs
    toward asking."""
    for e in entries:
        v = _verb(e)
        if v in ('cd', 'pushd', 'popd', 'source', '.') or _ODD_VERB.search(v):
            return True
        ws = e.get('words') or []
        if v in ('alias', 'eval') and any(_CD.search(x) for x in ws[1:]):
            return True
        for i, w in enumerate(ws):
            b = re.sub(r'^.*[)({]', '', w)
            if b in ('cd', 'pushd', 'popd'):
                return True
            if b in ('source', '.') and (b != w or i == 0 or ws[i - 1] in _CMD_START or ws[i - 1].endswith((')', '{', '('))):
                return True
    return any(_CD.search(b) for b in bodies)


def _glob_hit(arg, sargs, tin, cwd, entries, bodies, ro_exempt):
    """After every literal check missed: does an unquoted glob or brace word (in a sub-command, or a line of an interpreter's heredoc body) reach an
    existing file this sentinel rule names? Past the budget: yes (fail closed)."""
    flat = re.sub(r'[\'"\\]', '', str(tin.get('command', '')))
    cd = not cwd or _cd_mode(entries, bodies)
    xg = 'extglob' in flat
    words = [w for e in entries if not (ro_exempt and e.get('ros')) for w in e.get('words') or ()]
    for b in bodies:
        for ln in b.split('\n'):
            try:
                words += shlex.split(ln, posix=True)
            except ValueError:
                words += ln.split()
    try:
        return any(_sent_match(arg, m) for w in words if _GLOB_CH.search(w) or '{' in w or xg and _EXTG.search(w)
                   for m in _glob_matches(w, cwd or '', cd, xg, sargs))
    except _GlobBudget:
        return True


def _body_hit(pat, body):
    """A sentinel rule against a heredoc BODY, line by line: a path never spans a newline (a name split across lines is the run-time-built class)."""
    return any(_sent_match(pat, ln) for ln in body.split('\n'))


def _glob_path(p):
    out, i = [], 0
    while i < len(p):
        if p.startswith('**/', i):
            out.append('(?:.*/)?'); i += 3
        elif p.startswith('**', i):
            out.append('.*'); i += 2
        elif p[i] == '*':
            out.append('[^/]*'); i += 1
        elif p[i] == '?':
            out.append('[^/]'); i += 1
        else:
            out.append(re.escape(p[i])); i += 1
    return ''.join(out)


@functools.lru_cache(maxsize=None)
def path_regex(rule_path, cwd):
    if rule_path.startswith('//'):
        return re.compile('^' + _glob_path(rule_path[1:]) + '$')
    if rule_path.startswith('~/'):
        return re.compile('^' + _glob_path(HOME + rule_path[1:]) + '$')
    if rule_path.startswith('/'):                       # harness: project-root relative
        return re.compile('^' + _glob_path(cwd.rstrip('/') + rule_path) + '$')
    if rule_path.startswith('**/'):
        return re.compile('^' + _glob_path(rule_path) + '$')
    return re.compile('^' + _glob_path(cwd.rstrip('/') + '/' + rule_path) + '$')


def _norm_path(p, cwd):
    p = os.path.expanduser(p)
    if not os.path.isabs(p):
        p = os.path.join(cwd, p)
    return os.path.normpath(p)


# ---------------------------------------------------------------- rules
_RULE = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)\((.*)\)$', re.S)


def _split_rule(rule):
    m = _RULE.match(rule)
    return (m.group(1), m.group(2)) if m else (None, rule)


def _tool_family(tool):
    if tool == 'Bash':
        return 'Bash'
    if tool in EDIT_TOOLS:
        return 'Edit'
    if tool in READ_TOOLS:
        return 'Read'
    return None


def _rule_family(rt):
    return 'Read' if rt in READ_TOOLS else ('Edit' if rt in EDIT_TOOLS else rt)


def _name_match(pattern, tool):
    return re.fullmatch(re.escape(pattern).replace(r'\*', '.*'), tool) is not None


def _file_paths(tin, cwd):
    out = []
    for k in ('file_path', 'notebook_path', 'path'):
        v = tin.get(k)
        if isinstance(v, str) and v:
            p = _norm_path(v, cwd)
            out.append(p)
            rp = os.path.realpath(p)
            if rp != p:
                out.append(rp)
    return out


def _rule_dir_prefix(arg, cwd):
    """Directory part (with trailing /) of a file rule's absolute pattern before its first glob char, or None."""
    if arg.startswith('//'):
        a = arg[1:]
    elif arg.startswith('~/'):
        a = HOME + arg[1:]
    elif arg.startswith('**/') or not arg.startswith('/'):
        return None
    else:
        a = cwd.rstrip('/') + arg
    m = re.search(r'[*?]', a)
    if not m:
        return None                                   # an exact file: a directory search cannot be "under" it
    return a[:m.start()].rsplit('/', 1)[0] + '/'


def _dir_under_rule(arg, tin, cwd):
    """D5: a Grep/Glob whose search directory is AT or UNDER the rule's directory area reads protected files
    (measured GR1/GR2: the harness lets it through). Only that direction: an ancestor search is not blocked."""
    pre = _rule_dir_prefix(arg, cwd)
    if pre is None:
        return False
    d = tin.get('path')
    d = _norm_path(d, cwd) if isinstance(d, str) and d else cwd
    return (d.rstrip('/') + '/').startswith(pre)


def _hit(rules, tool, tin, cwd, entries=None, ro_exempt=False, bodies=()):
    """First rule in `rules` that matches this call, else None. `bodies`: heredoc bodies a SENTINEL rule also matches (protected tier only)."""
    fam = _tool_family(tool)
    for r in rules:
        rt, arg = _split_rule(r)
        if rt is None:                                   # bare tool-name rule
            if _name_match(r, tool):
                return r
            continue
        if _rule_family(rt) != fam:
            continue
        if fam == 'Bash':
            compound = re.search(r'\||&&|;', arg) is not None
            sent = SENTINEL_RULE.match(arg) is not None
            for e in entries:
                if e.get('whole') and not compound:
                    continue
                if ro_exempt and e.get('ros' if sent else 'ro'):
                    continue
                for s in ([] if e['eff'] is None else [e['eff']]) + e['aux']:
                    if (_sent_match(arg, s) if sent else bash_match(arg, s)):
                        return r
            if sent and any(_body_hit(arg, b) for b in bodies):
                return r
            if sent and _glob_hit(arg, _SENT[0] or (arg,), tin, cwd, entries, bodies, ro_exempt):     # literal checks first: the glob check is the costly one
                return r
        else:
            rx = path_regex(arg, cwd)
            for p in _file_paths(tin, cwd):
                if rx.match(p):
                    return r
            if tool in ('Grep', 'Glob') and _dir_under_rule(arg, tin, cwd):        # D5
                return r
    return None


def _safe_builtin(eff, aux):
    """True for a SAFE_BUILTINS command used read-only (no file redirect, no destructive option)."""
    try:
        w = shlex.split(eff)
    except ValueError:
        return False
    if not w or w[0] not in SAFE_BUILTINS:
        return False
    for a in aux + [eff]:                                    # any output redirect to a file: not read-only
        if re.search(r'(?<![0-9&])>>?(?!&)(?!\s*/dev/null)', re.sub(r'[0-9]?>\s*/dev/null|[0-9]?>&[0-9-]', '', a)):
            return False
    c0, rest = w[0], w[1:]
    if c0 == 'find' and any(x in ('-delete', '-exec', '-execdir', '-ok', '-okdir', '-fprint', '-fprintf', '-fls') for x in rest):
        return False
    if c0 == 'sed' and ('-n' not in rest or any(x.startswith('-i') or x == '--in-place' for x in rest)):
        return False
    if c0 == 'sort' and any(x == '-o' or x.startswith('--output') or (x.startswith('-o') and len(x) > 2) for x in rest):
        return False
    if c0 == 'node' and rest not in (['-v'], ['--version']):
        return False
    return True


def _all_allowed(allow, entries):
    matched = False
    for e in entries:
        if e.get('whole'):
            continue
        if any(rt == 'Bash' and bash_match(arg, e['eff']) for rt, arg in (_split_rule(r) for r in allow)):
            matched = True
        elif not _safe_builtin(e['eff'], e['aux']):
            return False
    return matched                                           # safe builtins alone are not an allow


def _interp_bodies(tin, entries):
    """Every heredoc body (quoted or not) of a command in which some sub-command runs an interpreter (`python3 - <<'EOF'`, `bash <<EOF`, a heredoc
    written to a file the same command then runs): what such a script does is in its body (row 26r). [] otherwise."""
    cmd = str((tin or {}).get('command', ''))
    if '<<' not in cmd or not any(_may_run_code(e) for e in entries or []):
        return []
    return _strip_heredocs(cmd, keep_quoted=True)[1]


def evaluate(perms, floor, tool, tin, cwd, level='none', mode='default', protected=()):
    """-> (decision, reason). decision in deny|ask|allow|none. Order: deny > ask > allow > none."""
    deny = list(floor) + ([] if level == 'total' else list(perms.get('deny', [])))
    ask = [] if level in ('normal', 'total') else list(perms.get('ask', []))
    prot = list(protected)                                      # self-mod tier: survives `normal` AND `total` (user ruling 2026-09-30, F2: stricter than the firewall, which ignores its self-mod tier at total)
    allow = list(perms.get('allow', []))
    fam = _tool_family(tool)
    entries, ok = (None, True)
    _glob_reset(protected)
    if fam == 'Bash':
        entries, ok = parse_bash(str((tin or {}).get('command', '')))
    tin = tin or {}
    r = _hit(deny, tool, tin, cwd, entries)
    if r:
        return 'deny', 'permission engine: deny rule %s' % r
    r = _hit(ask, tool, tin, cwd, entries)
    if r:
        return 'ask', 'permission engine: ask rule %s' % r
    ro_ok = False                                                # exemption withdrawn when a pipe / process substitution can feed an interpreter (reading INTO execution)
    if fam == 'Bash':
        cmd_text = entries[0]['aux'][0] if entries and entries[0].get('whole') else str(tin.get('command', ''))     # the heredoc-STRIPPED text: a `|` inside a heredoc body is data, not a pipe
        procsub = re.search(r'<\(|>\(', cmd_text) is not None
        ro_ok = not any(_may_run_code(e) and (e.get('afterpipe') or procsub) for e in entries)     # only an interpreter FED by a pipe (or any interpreter when a process substitution is present) withdraws the exemption
    r = _hit(prot, tool, tin, cwd, entries, ro_exempt=ro_ok, bodies=_interp_bodies(tin, entries) if fam == 'Bash' else ())
    if r:
        return 'ask', 'permission engine: protected ask rule %s' % r
    if not (mode == 'plan' and fam in ('Bash', 'Edit')):        # plan mode: never `allow` a shell or write call (a hook allow cannot be trusted to stay inside plan mode; write block verified Z3)
        if fam == 'Bash':
            if ok and _all_allowed(allow, entries):
                return 'allow', 'permission engine: every sub-command matches an allow rule'
        else:
            r = _hit(allow, tool, tin, cwd, entries)
            if r:
                return 'allow', 'permission engine: allow rule %s' % r
    return 'none', ''


# ---------------------------------------------------------------- IO
def _load(path):
    cfg = json.load(open(path))
    perms = cfg['permissions']
    for k in ('deny', 'ask', 'allow'):
        v = perms.get(k, [])
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            raise ValueError('permissions.%s must be a list of strings' % k)
    floor = cfg.get('floor', [])
    prot = cfg.get('protected', [])
    for name, v in (('floor', floor), ('protected', prot)):
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            raise ValueError('%s must be a list of strings' % name)
    return perms, floor, prot


def lint(path):
    perms, floor, prot = _load(path)
    probs = []
    for k in ('deny', 'ask', 'allow'):
        for r in perms.get(k, []) + (floor if k == 'deny' else []):
            rt, arg = _split_rule(r)
            if rt in ('Read', 'Edit', 'Write') and arg.startswith('/') and not arg.startswith('//'):
                probs.append('%s: %s starts with a single "/" — root-relative in the harness; use // for an absolute path or ~/' % (k, r))
            if rt not in (None, 'Bash', 'Read', 'Edit', 'Write', 'NotebookEdit', 'MultiEdit', 'Grep', 'Glob'):
                probs.append('%s: %s — rule form not supported by the engine (ignored)' % (k, r))
    return probs


def resolve_level(cwd):
    """Level of the `perm` bypass at the payload's TOP-LEVEL cwd, from the shared resolver (the same one the
    statusline and every guard use). Any trouble => none (strict); a resolver TIMEOUT exits 124 (stall).
    Fast path first (plan perm-engine-inprocess-level): hooks/perm_level.py answers well-formed rules files in-process, no bash/jq spawn;
    it returns None on anything unusual and the authoritative bash resolver below decides (differential test: test-perm-level.sh)."""
    try:
        sys.dont_write_bytecode = True
        import perm_level
        fast = perm_level.level(cwd, home=HOME)
        if fast in ('none', 'normal', 'total'):
            return fast
    except Exception:
        pass                                                      # a broken fast path must never decide: fall through to bash
    try:
        r = subprocess.run(['bash', '-c', '. "$1/bypass-resolve.sh" 2>/dev/null && bypass_level perm "$2"', '_', HOOKDIR, cwd],
                           capture_output=True, text=True, timeout=3)
        v = r.stdout.strip()
        return v if v in ('none', 'normal', 'total') else 'none'
    except subprocess.TimeoutExpired:
        sys.exit(124)           # a STALL, not a verdict: degrading to 'none' here turned a slow box into real ASKs (advisor 6C); 124 lets the wrapper fail open at total
    except (OSError, subprocess.SubprocessError):
        return 'none'


def except_hit(cwd, targets):
    """True when some target lies inside the `except` list of a bypass rule covering cwd and no strictly deeper covering rule reaches it (the
    resolver's own cross-family union, bypass_except_hit, row 26zu - so the statusline, the firewall and the engine cannot disagree). A stall or exec failure => True: this answer REMOVES a bypass,
    so failing closed keeps the asks (sonnet-audit 2026-10-06 A-F3; before the cutover the same subtrees were static ask rules)."""
    for t in targets:
        try:
            if os.environ.get('PERM_ENGINE_FAULT') == 'except-stall':
                raise subprocess.TimeoutExpired('bypass_except_hit', 3)      # test hook: a resolver that stalls (load, missing jq)
            r = subprocess.run(['bash', '-c', '. "$1/bypass-resolve.sh" 2>/dev/null && bypass_except_hit "$2" "$3"', '_', HOOKDIR, cwd, t],
                               capture_output=True, text=True, timeout=3)
            if r.returncode == 0:
                return True
        except (OSError, subprocess.SubprocessError):
            return True
    return False


def _log(line):
    path = os.environ.get('PERM_ENGINE_LOG') or os.path.join(HOME, '.claude', 'logs', 'permission-engine.log')
    try:
        with open(path, 'a') as f:
            f.write(line + '\n')
    except OSError:
        pass


# ---------------------------------------------------------------- unattended window (plan unattended-window, user 2026-10-01)
_CORE_EDIT = ('Edit', 'Write', 'NotebookEdit', 'MultiEdit')


_WLIB = []


def _window_lib():
    """bin/lib/unattended.py, loaded once by its explicit file path (never via sys.path, no bytecode written): its read_marker/select decide allow vs ask,
    so the engine trusts exactly that protected file. A load failure raises; _window turns it into NO window (asks stay asks)."""
    if not _WLIB:
        import importlib.util
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'bin', 'lib', 'unattended.py')
        spec = importlib.util.spec_from_file_location('_perm_engine_unattended', path)
        mod = importlib.util.module_from_spec(spec)
        sys.dont_write_bytecode = True
        spec.loader.exec_module(mod)
        _WLIB.append(mod)
    return _WLIB[0]


def _window(cwd):
    """-> (mode 'park'|'allow', no_ask bool) | None. The marker state/unattended.json is STRICT (bin/lib/unattended.py read_marker): a regular non-symlink file
    holding one window {until|for, mode, path?, no_ask?} or {"windows": [...]} (row 26z: at most 32, no `for`); ONE bad field, a path at $HOME or above, or an
    until more than 7 days ahead voids the whole marker = NO window (an ask stays an ask). The most specific live window covering cwd applies (select).
    No-shell activation: the /gates-bypass skill has no clock, so the FIRST valid read stamps until = marker mtime + for (a stale pending marker is already
    expired, never a fresh window); a pending marker that cannot be stamped would slide forever (panel 2026-10-01c F1): no window."""
    try:
        mp = os.path.join(HOME, '.claude', 'state', 'unattended.json')
        if not os.path.lexists(mp):
            return None                                   # the common case: no marker, no library load (~5 ms CPU)
        lib = _window_lib()
        st, ws, _why = lib.read_marker(mp, stamp=True)
        w = lib.select(ws, cwd) if st == 'ok' else None
        return (w['mode'], w['no_ask']) if w else None
    except Exception:
        return None


def _core_rule(rule):
    """The self-protection core that stays parked even in allow mode: a protected EDIT rule, anything naming `unattended` (a run must never extend or end its own
    window), and a sentinel touch/rm or any-verb sentinel rule (row 26r). Guard INVOCATIONS (gates-bypass.sh, model-override, apply scripts) are not core (user ruling 2026-10-01)."""
    rt, arg = _split_rule(rule)
    if 'model-overrides.json' in rule:
        return False                                       # user ruling 2026-10-01: the override table only picks models; a no-shell /gates-bypass models call must work while a window is live
    if 'unattended' in rule or rt in _CORE_EDIT or rt == 'Edit':
        return True
    return rt == 'Bash' and (re.match(r'(touch|rm)\b', arg or '') is not None or SENTINEL_RULE.match(arg or '') is not None)


def _core_hit(prot, tool, tin, cwd):
    """Panel 2026-10-01c F2/F3: judge core over EVERY core protected rule that hits the call, not over the reason of the first verdict (an ordinary ask rule, or an
    earlier non-core protected rule, used to shadow a sentinel touch/rm and the window converted it to allow)."""
    try:
        entries, _ok = (None, True)
        _glob_reset(prot)
        if _tool_family(tool) == 'Bash':
            entries, _ok = parse_bash(str((tin or {}).get('command', '')))
            cmd_text = entries[0]['aux'][0] if entries and entries[0].get('whole') else str((tin or {}).get('command', ''))
            procsub = re.search(r'<\(|>\(', cmd_text) is not None
            ro_ok = not any(_may_run_code(e) and (e.get('afterpipe') or procsub) for e in entries)
        else:
            ro_ok = False
        bodies = _interp_bodies(tin, entries) if _tool_family(tool) == 'Bash' else ()
        return any(_core_rule(r) and _hit([r], tool, tin or {}, cwd, entries, ro_exempt=ro_ok, bodies=bodies) for r in prot)
    except Exception:
        return True                                        # undecidable: stay parked (fail closed)


def _names_window(tin):
    """An ORDINARY ask rule can fire first and hide the protected rule behind it (correctness panel P0: `qv x; rm .../unattended.json` was converted to allow), so in allow
    mode ANY ask whose input names `unattended` stays parked, whichever rule produced it."""
    try:
        return 'unattended' in json.dumps(tin or {}, ensure_ascii=False).lower()
    except (TypeError, ValueError):
        return True


def _would_fire(perms, floor, tool, tin, cwd, mode, prot, payload):
    """framework-health 8.4: a call the perm grant (level normal/total) let through gets the verdict level `none` WOULD have given;
    an ask or deny there is queued for the user's review (logs/bypass-review.ndjson). Runs after the verdict is fixed and can never
    change it: every failure, the queue lib missing included, is swallowed. The queue write never waits for the summary lock
    (record wait=False): a blocking flock inside a verdict is a fail-open path at total. Replayed over 1 630 real calls (2026-10-08):
    27 would fire (11 rules); the second evaluate costs ~4.6 ms CPU."""
    try:
        # A second parse must never push a verdict toward the CPU budget (ITIMER_VIRTUAL -> the failure verdict) or a wall timeout (silent
        # at total): skip once this process has used PERM_ENGINE_WOULD_CPU_S of CPU (default 1 s; a normal call uses ~0.1 s, the worst
        # crafted 8c command 0.12 s per pass on 2026-10-08). Losing a rare would-fire event is the cheap side.
        # Keep it well below PERM_ENGINE_CPU_S (the budget, default 4 s): at or above it the guard can never fire before exit 154.
        if time.process_time() >= float(os.environ.get('PERM_ENGINE_WOULD_CPU_S', '1')):
            return
        d, r = evaluate(perms, floor, tool, tin, cwd, 'none', mode, prot)
        if d not in ('ask', 'deny'):
            return
    except Exception:
        return
    _queue(tool, tin, d, 'allowed', r, cwd, payload)


def _queue(tool, tin, would, action, rule, cwd, payload):
    """Queue one perm event for /gates-bypass review (logs/bypass-review.ndjson). Never changes a verdict: every failure, the queue lib
    missing included, is swallowed; the write never waits for the summary lock (record wait=False)."""
    try:
        sys.dont_write_bytecode = True
        lib = os.environ.get('PERM_ENGINE_REVIEW_LIB') or os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'bin', 'lib')
        if lib not in sys.path:
            sys.path.insert(0, lib)
        import bypass_review
        t = tin or {}
        detail = t.get('command') or t.get('file_path') or t.get('notebook_path') or t.get('path') or json.dumps(t)[:200]
        bypass_review.record('perm', tool, would, action, rule=rule, detail=str(detail), cwd=cwd, sid=str(payload.get('session_id') or ''), wait=False)
    except Exception:
        pass


def _window_log(mode, tool, tin, reason, converted):
    try:
        path = os.path.join(HOME, '.claude', 'logs', 'unattended-parked.ndjson')
        os.makedirs(os.path.dirname(path), exist_ok=True)
        cmd = str((tin or {}).get('command') or (tin or {}).get('file_path') or '')[:120]
        with open(path, 'a') as f:
            f.write(json.dumps({'ts': time.strftime('%Y-%m-%dT%H:%M:%S%z'), 'mode': mode, 'tool': tool, 'rule': reason[:200], 'cmd': cmd, 'converted': converted}) + '\n')
    except OSError:
        pass


def _cf_on(cwd, sid):
    """Confident picks (family cf, row 26zg) at cwd for this session, from the shared bash resolver. Asked only for an AskUserQuestion under a no_ask window
    (rare), so the spawn is affordable. Any trouble => True: the cf wording only PARKS a grey case (less autonomy), the other wording would auto-pick one.
    Only an exit 1 from bypass_applies itself reads as off: a resolver that cannot be sourced exits 3, a stall raises (tests NAC4/NAC5). Known limit: an
    internal resolver failure that bypass_applies reports as 1 (jq missing, an unreadable rules file) is indistinguishable from "not granted"."""
    fault = os.environ.get('PERM_ENGINE_FAULT', '')
    try:
        if fault == 'cf-stall':
            raise subprocess.TimeoutExpired('bypass_applies cf', 3)              # test hook: a resolver that stalls
        hd = os.path.join(HOOKDIR, 'no-such-dir') if fault == 'cf-nosource' else HOOKDIR   # test hook: a resolver that cannot be sourced
        r = subprocess.run(['bash', '-c', '. "$1/bypass-resolve.sh" 2>/dev/null || exit 3; BYPASS_SESSION_ID="$3" bypass_applies cf "$2"', '_', hd, cwd, sid],
                           capture_output=True, text=True, timeout=3)
        return r.returncode != 1
    except (OSError, subprocess.SubprocessError):
        return True


def _ask_lifted(sid):
    """Row 26zj: this session's latest real prompt explicitly asked for a question (bin/lib/unattended.py ask_lifted - the check keep-going's no_ask_at
    uses too, so the two never disagree). Any failure => False: no_ask keeps denying, as before the lift existed."""
    try:
        return bool(_window_lib().ask_lifted(sid))
    except Exception:
        return False


def apply_window(mode, tool, tin, decision, reason, perm_mode='default', no_ask=False, prot=(), cwd='', sid=''):
    """-> (decision, reason). park: ask -> deny; allow: ask -> allow except the core; AskUserQuestion -> deny in both. deny / allow / none are untouched."""
    if tool == 'AskUserQuestion':
        if not no_ask or _ask_lifted(sid):
            return decision, reason                      # opt-in only (user ruling 2026-10-01): a window never touches a question unless the marker says no_ask;
                                                         # and never in a turn whose prompt explicitly asked for one (row 26zj, user ruling 2026-10-16 00:25)
        if _cf_on(cwd, sid):                             # user ruling 2026-10-15: under cf a grey case advisor() did not settle is parked, never auto-picked
            new = ('deny', 'unattended window (%s, confident picks on): do not ask - take a pick only when the tiered rule settles it (an objective test, or '
                           'advisor() agreed) and log it as ASSUMED (review); a grey case it does not settle is PARKED: log it, skip that branch and continue - never auto-pick it' % mode)
        else:
            new = ('deny', 'unattended window (%s): do not ask - take the recommended option and log it as ASSUMED (review)' % mode)
    elif decision == 'ask' and (mode == 'park' or _core_hit(prot, tool, tin, cwd) or _names_window(tin) or (perm_mode == 'plan' and _tool_family(tool) in ('Bash', 'Edit'))):   # plan mode: never allow a shell/write call (evaluate's invariant)
        new = ('deny', 'unattended window (%s): parked - needs a human; do not retry or work around it; log it and continue with other work [%s]' % (mode, reason))
    elif decision == 'ask':
        new = ('allow', 'unattended window (allow): %s' % reason)
    else:
        return decision, reason
    _window_log(mode, tool, tin, reason or 'AskUserQuestion', new[0])
    return new


def main(argv):
    if len(argv) >= 3 and argv[1] == '--lint':
        probs = lint(argv[2])
        for p in probs:
            print(p)
        return 1 if probs else 0
    fault = os.environ.get('PERM_ENGINE_FAULT', '')
    try:                                                          # panel 2026-10-01 F4: a CPU-time budget. ITIMER_VIRTUAL counts only THIS process's user CPU (load starvation does not
        import signal                                             # consume it); the default SIGVTALRM (26) disposition kills the process, so timeout reports 154 - never 124 - so CPU-bound slowness (a crafted
        signal.setitimer(signal.ITIMER_VIRTUAL, float(os.environ.get('PERM_ENGINE_CPU_S', '4')))   # command) becomes the wrapper's failure verdict (ask, or the bypass-edit deny), and only WALL-clock starvation (124) may fail open
    except (ValueError, OSError, AttributeError):
        pass
    if fault == 'spin':
        while True:
            pass
    if fault == 'crash':
        return 3
    if fault == 'hang':
        time.sleep(60)
    if fault == 'garbage':
        print('garbage {{ not a decision')
        return 0
    payload = json.load(sys.stdin)
    tool = payload['tool_name']
    tin = payload.get('tool_input') or {}
    cwd = payload.get('cwd') or os.getcwd()
    mode = payload.get('permission_mode') or 'default'
    path = os.environ.get('PERM_ENGINE_RULES') or os.path.join(HOME, '.claude', 'config', 'permission-rules.json')
    t_load = time.time()
    perms, floor, prot = _load(path)
    t_rules = time.time()
    level = resolve_level(cwd)
    t_level = time.time()
    if level in ('normal', 'total') and _tool_family(tool) != 'Bash' and except_hit(cwd, _file_paths(tin, cwd)):
        level = 'none'                                            # a blacklisted subtree keeps every ask at EVERY level (DESIGN 9; row 26zu: an except is a hole at total too); Bash reaches it through the firewall
    decision, reason = evaluate(perms, floor, tool, tin, cwd, level, mode, prot)
    pre_window = decision                                         # 8.4: the window converts only ask/deny verdicts (_window_log queues those via import)
    win = _window(cwd)
    if win:
        decision, reason = apply_window(win[0], tool, tin, decision, reason, mode, win[1], prot, cwd, str(payload.get('session_id') or ''))
    bp_ask = ''
    if decision == 'ask' and mode == 'bypassPermissions' and _tool_family(tool) == 'Edit':
        # framework-health row 16b: Claude Code applies an Edit/Write hook ASK silently in this mode (row 16a, 3 of 3), so the ask
        # becomes a deny and a review event. Bash asks still show a real dialog there (2 observations) and are left alone.
        bp_ask = reason
        decision, reason = 'deny', ('bypassPermissions applies edit prompts silently, so this one is denied: needs a human; do not retry'
                                    ' or work around it; log it and continue with other work [%s]' % reason)
    t_eval = time.time()
    try:                                                          # Rule 14 aid (2026-10-01): a stall must name its slow phase next time
        if t_eval - _T0 > float(os.environ.get('PERM_ENGINE_SLOW_S', '1')):
            _log('%s | SLOW | %s | total=%.2fs load=%.2fs rules=%.2fs level=%.2fs eval=%.2fs' % (time.strftime('%Y-%m-%dT%H:%M:%S%z'), tool, t_eval - _T0, t_load - _T0, t_rules - t_load, t_level - t_rules, t_eval - t_level))
    except ValueError:
        pass
    shadow = os.environ.get('PERM_ENGINE_MODE') == 'shadow'      # log only: never print a decision, never prompt
    if shadow:                                                    # step 7: EVERY call incl. "none" - the diff tool needs the calls the engine stayed silent on
        try:
            sys.dont_write_bytecode = True                        # BEFORE the import: a module's .pyc is written as it loads, so setting it inside the module is too late
            import perm_shadow
            perm_shadow.record_decision(payload, decision, level, reason)
        except Exception:
            pass                                                  # a broken recorder must never change a decision
    if bp_ask and not shadow:
        _queue(tool, tin, 'ask', 'parked', bp_ask, cwd, payload)
    if (not shadow and level in ('normal', 'total') and mode != 'plan'
            and pre_window not in ('ask', 'deny') and decision not in ('ask', 'deny')):
        _would_fire(perms, floor, tool, tin, cwd, mode, prot, payload)   # plan mode auto-allows nothing, so nothing there was let through
    if decision == 'none':
        return 0
    _log('%s | %s | %s | level=%s | %s' % (time.strftime('%Y-%m-%dT%H:%M:%S%z'), ('SHADOW-' if shadow else '') + decision.upper(), tool, level, reason[:200]))
    if shadow:
        return 0
    print(json.dumps({'hookSpecificOutput': {'hookEventName': 'PreToolUse',
                                             'permissionDecision': decision,
                                             'permissionDecisionReason': reason}}, separators=(',', ':')))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
