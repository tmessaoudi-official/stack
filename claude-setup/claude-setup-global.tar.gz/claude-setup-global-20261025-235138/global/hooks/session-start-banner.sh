#!/usr/bin/env bash
# SessionStart hook: print a session info banner to stderr.
# Reads stdin JSON: {session_id, transcript_path, cwd, hook_event_name}
# Output goes to stderr — zero tokens, Claude never sees it.
#
# ⚠ Testing note: this script writes per-session status-{context,banner}-<id>.txt for
# ALL sessions (P1-3), so even cwd=/tmp produces per-session files now. Only a git/main
# session ALSO dual-writes the global fixed-name files + Σ counters. For isolated dry
# runs use a throwaway HOME: HOME=$(mktemp -d) … echo '{"cwd":"/tmp","session_id":"t"}' | bash this.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true
# shellcheck disable=SC1091
source "$SCRIPT_DIR/session-status.sh" 2>/dev/null || true

# Read-only git must never take index.lock: `git status` otherwise rewrites the index whenever a
# file's stat info changed, contending with the user's commits, and a hook killed mid-write leaves
# the lock behind (18 h stale on 2026-09-25). Row 31.
export GIT_OPTIONAL_LOCKS=0

# Bounded: a bare `cat` blocks until EOF, so any caller that holds stdin open without
# writing hangs this hook indefinitely — and SessionStart runs before the session is
# usable. Measured 2026-09-02: `sleep 4 | bash session-start-banner.sh` exits 124 unbounded.
# Claude Code writes the payload then closes, so the bound is not reached in normal use.
INPUT=$(timeout 2 cat 2>/dev/null || true)

CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
[[ -z "$CWD" && -n "${CLAUDE_PROJECT_DIR:-}" ]] && CWD="$CLAUDE_PROJECT_DIR"
if [[ -z "$CWD" ]]; then
  CWD="$PWD"
  log_obs WARN session-start-banner "CLAUDE_PROJECT_DIR unset — falling back to PWD; git state may be wrong" 2>/dev/null || true
fi

# ── Model: actual (from last stop hook) → settings.json fallback ─────────────
SETTINGS="$HOME/.claude/settings.json"
_ACTUAL_MODEL_FILE="$HOME/.claude/run/actual-model.txt"
RAW_MODEL=""
if [[ -f "$_ACTUAL_MODEL_FILE" ]]; then
  RAW_MODEL=$(head -1 "$_ACTUAL_MODEL_FILE" 2>/dev/null | tr -d '[:space:]' || true)
fi
[[ -z "$RAW_MODEL" ]] && RAW_MODEL=$(jq -r '.model // "unknown"' "$SETTINGS" 2>/dev/null || echo 'unknown')
case "$RAW_MODEL" in
  opusplan)        DISP_MODEL='opus (plan)' ;;
  claude-opus-*)   DISP_MODEL="${RAW_MODEL#claude-}" ;;
  claude-sonnet-*) DISP_MODEL="${RAW_MODEL#claude-}" ;;
  claude-haiku-*)  DISP_MODEL="${RAW_MODEL#claude-}" ;;
  *)               DISP_MODEL="$RAW_MODEL" ;;
esac
# Window size (P0-1): prefer the authoritative size persisted by statusline
# (run/actual-window.txt); fall back to the model-string "[1m]" heuristic when absent
# (e.g. the very first session before any statusline render). ss_window_from_state is
# sourced from session-status.sh above.
_WIN_BYTES=$(ss_window_from_state "$RAW_MODEL" "$SESSION_ID" 2>/dev/null || printf '200000')
[[ "$_WIN_BYTES" =~ ^[0-9]+$ && "$_WIN_BYTES" -gt 0 ]] || _WIN_BYTES=200000
if [[ "$_WIN_BYTES" -ge 900000 ]]; then
  WIN_K='1M'
else
  WIN_K="$(( _WIN_BYTES / 1000 ))K"
fi
# Buffer = 16.5% of window capped at 40K — single source of truth in ss_buffer_size
# (sourced from session-status.sh above). Type-guarded like ss_age/ss_parse_transcript
# below: if the source ever fails the banner is already degraded, so the fallback uses
# the uncapped linear form rather than re-inlining the cap literal.
if type ss_buffer_size &>/dev/null; then
  _BUF_BYTES=$(ss_buffer_size "$_WIN_BYTES")
else
  _BUF_BYTES=$(( _WIN_BYTES * 165 / 1000 ))
fi
BUF_K="$(( _BUF_BYTES / 1000 ))K"

# ── Handoff age ───────────────────────────────────────────────────────────────
SLUG=$(printf '%s' "$CWD" | sed 's|/|-|g')
HANDOFF="$HOME/.claude/projects/${SLUG}/memory/sessions/handoff.md"
if [[ -f "$HANDOFF" && -s "$HANDOFF" ]]; then
  HANDOFF_MTIME=$(stat -c '%Y' "$HANDOFF" 2>/dev/null || echo 0)
  NOW=$(date +%s)
  HANDOFF_AGE=$(( NOW - HANDOFF_MTIME ))
  if   (( HANDOFF_AGE < 3600  )); then HANDOFF_STR="$((HANDOFF_AGE/60))m ago"
  elif (( HANDOFF_AGE < 86400  )); then HANDOFF_STR="$((HANDOFF_AGE/3600))h ago"
  elif (( HANDOFF_AGE < 604800 )); then HANDOFF_STR="$((HANDOFF_AGE/86400)) days ago"
  else                                   HANDOFF_STR="$((HANDOFF_AGE/604800)) wks ago"
  fi
  # Trailing stamp, never a match anywhere — a handoff quoting a previous one carries both
  # stamps in its body (_handoff_is_auto in log-helpers.sh, SPEC §6-51).
  _handoff_is_auto "$HANDOFF" && HANDOFF_STR="${HANDOFF_STR} auto"
else
  HANDOFF_STR='none'
fi

# ── Mega-analysis age ─────────────────────────────────────────────────────────
META_DIR="$HOME/.claude/projects/meta-reports"
ANALYSIS_STR='none'
if [[ -d "$META_DIR" ]]; then
  NEWEST=$(ls -d "$META_DIR"/[0-9]* 2>/dev/null | sort | tail -1 || true)
  if [[ -n "$NEWEST" ]]; then
    ANA_MTIME=$(stat -c '%Y' "$NEWEST" 2>/dev/null || echo 0)
    NOW=$(date +%s)
    ANA_AGE=$(( NOW - ANA_MTIME ))
    if   (( ANA_AGE < 3600  )); then ANALYSIS_STR="$((ANA_AGE/60))m ago"
    elif (( ANA_AGE < 86400  )); then ANALYSIS_STR="$((ANA_AGE/3600))h ago"
    elif (( ANA_AGE < 604800 )); then ANALYSIS_STR="$((ANA_AGE/86400)) days ago"
    else                               ANALYSIS_STR="$((ANA_AGE/604800)) wks ago"
    fi
    (( ANA_AGE > 604800 )) && ANALYSIS_STR="${ANALYSIS_STR} ⚠"
  fi
fi

# ── F6: Main-session gate — BEFORE git calls ──────────────────────────────────
# Subagent sessions typically run from /tmp (no git repo). Detect early so we
# skip all git work entirely for non-repo directories, saving ~300ms of silent
# failures. Also prevents subagent starts from overwriting the main session's
# status files (session-ID gate in stop-context-bar.sh would misfire).
# The git test alone is not enough: sr_call_haiku's cwd ~/.claude/llm-sandbox sits inside
# the $HOME repo, so every Haiku side call counted as main and reset the foreground's
# global status and lifetime Σ (5,325 times on 2026-09-27). GS_NO_AUTO_HANDOFF=1 marks a
# headless side call (review-remediation row 55).
_MAIN_SESSION=false
if [[ -z "${GS_NO_AUTO_HANDOFF:-}" ]] && command -v git &>/dev/null && timeout 2 git -C "$CWD" rev-parse --is-inside-work-tree &>/dev/null 2>&1; then
  _MAIN_SESSION=true
fi

# ── Git defaults (overwritten below when _MAIN_SESSION=true) ─────────────────
GIT_INFO='n/a'
GIT_BRANCH='' GIT_DIRTY=0 GIT_UNPUSHED=-1 GIT_STASHES=0 GIT_LAST='' CLAUDEMD_STATUS=''

# ── P0-2 / P1-3: per-session state paths — resolved for ALL sessions ──────────
# statusline reads its OWN session's status-{context,banner}-<id>.txt. Main (git)
# sessions additionally dual-write the global fixed-name file (external readers +
# fallback). P1-3: a non-git FOREGROUND session must still write its per-session
# files so the bar isn't stale; only the shared-state writes below stay gated.
_RUN_DIR="${HOME}/.claude/run"
mkdir -p "${_RUN_DIR}" 2>/dev/null || true
_CTX_GLOBAL="${_RUN_DIR}/status-context.txt"
_BNR_GLOBAL="${_RUN_DIR}/status-banner.txt"
if [[ -n "${SESSION_ID:-}" ]]; then
  _CTX_PATH="${_RUN_DIR}/status-context-${SESSION_ID}.txt"
  _BNR_PATH="${_RUN_DIR}/status-banner-${SESSION_ID}.txt"
else
  _CTX_PATH="$_CTX_GLOBAL"
  _BNR_PATH="$_BNR_GLOBAL"
fi

# ── Session uptime anchor: BASE read (no write). The write/reset stays gated on ──
# _MAIN_SESSION below, so a non-git subprocess never resets the foreground's uptime.
_STARTED_AT="$(date +%s)"
_GLOBAL_ANCHOR="${_RUN_DIR}/pane-started-at.txt"
if [[ -f "$_GLOBAL_ANCHOR" ]]; then
  _GA=$(head -1 "$_GLOBAL_ANCHOR" 2>/dev/null | tr -d '[:space:]' || true)
  [[ -n "$_GA" && "$_GA" =~ ^[0-9]+$ ]] && _STARTED_AT="$_GA"
fi

# ── Main session (git repo): shared-state writes — Σ counters, uptime-anchor write, ──
# global dual-writes, git data, early "loading…" writes. Gated on _MAIN_SESSION so the
# /tmp `claude -p` handoff subprocess (always non-git) can never corrupt these. The
# per-session writes for a non-git foreground session happen AFTER this block.
if [[ "$_MAIN_SESSION" == true ]]; then

  # ── Capture old session values BEFORE the early write overwrites status-context.txt ──
  # The early write replaces SESSION_ID immediately; reading after it always sees the new ID.
  _PRE_CTX="${_RUN_DIR}/status-context.txt"
  _PRE_SID=$(grep "^SESSION_ID:" "$_PRE_CTX" 2>/dev/null | head -1 | cut -d: -f2- || true)
  _PRE_SUM_K=$(grep "^SUM_K:" "$_PRE_CTX" 2>/dev/null | head -1 | cut -d: -f2- | tr -d '[:space:]' || echo 0)
  _PRE_SUM_K="${_PRE_SUM_K//[^0-9]/}"; _PRE_SUM_K="${_PRE_SUM_K:-0}"
  _PRE_TURNS=$(grep "^TURNS:" "$_PRE_CTX" 2>/dev/null | head -1 | cut -d: -f2- | tr -d '[:space:]' || echo 0)
  _PRE_TURNS="${_PRE_TURNS//[^0-9]/}"; _PRE_TURNS="${_PRE_TURNS:-0}"

  # BUG-3: write PCT:0 immediately so statusline doesn't flash stale % from previous session
  {
    printf 'SESSION_ID:%s\n' "${SESSION_ID}"
    printf 'PCT:0\n'
    printf 'INPUT_K:0\n'
    printf 'EFF_K:%s\n'    "$(( (_WIN_BYTES - _BUF_BYTES) / 1000 ))"
    printf 'FREE_K:%s\n'   "$(( (_WIN_BYTES - _BUF_BYTES) / 1000 ))"
    printf 'BUF_K:%s\n'    "$(( _BUF_BYTES / 1000 ))"
    printf 'SUM_K:0\n'
    printf 'URGENCY:\n'
    printf 'IS_ESTIMATE:true\n'
    printf 'TURNS:0\n'
    printf 'TURN_DUR:0\n'
    printf 'CLEAR_CTR:0\n'
  } > "$_CTX_PATH" 2>/dev/null || true
  [[ "$_CTX_PATH" != "$_CTX_GLOBAL" ]] && cp -f "$_CTX_PATH" "$_CTX_GLOBAL" 2>/dev/null || true

  # ── Session uptime anchor: write once on first SessionStart (base read hoisted above) ──
  if [[ ! -f "$_GLOBAL_ANCHOR" ]]; then
    printf '%s\n' "$_STARTED_AT" > "$_GLOBAL_ANCHOR" 2>/dev/null || true
    rm -f "${_RUN_DIR}/turns-total.txt" 2>/dev/null || true
  fi

  # ── Σ accumulators: accumulate across compaction boundaries ─────────────────
  # Uses _PRE_* captured before the early write (file now has new SESSION_ID).
  # Distinguish compaction (new SessionStart before delayed Stop) from normal exit
  # (Stop fires before new process → last-stop-session.txt matches → reset uptime+turns).
  if [[ -n "$_PRE_SID" && -n "$SESSION_ID" && "$_PRE_SID" != "$SESSION_ID" ]]; then
    _IS_NORMAL_EXIT=false
    _LAST_STOP_SID=$(head -1 "${_RUN_DIR}/last-stop-session.txt" 2>/dev/null | tr -d '[:space:]' || true)
    [[ "$_LAST_STOP_SID" == "$_PRE_SID" ]] && _IS_NORMAL_EXIT=true

    if [[ "$_IS_NORMAL_EXIT" == true ]]; then
      rm -f "${_RUN_DIR}/turns-total.txt" 2>/dev/null || true
      _STARTED_AT="$(date +%s)"
      printf '%s\n' "$_STARTED_AT" > "${_RUN_DIR}/pane-started-at.txt" 2>/dev/null || true
      log_obs INFO session-start-banner "normal exit → reset turns-total + fresh uptime anchor" 2>/dev/null || true
    fi

    # ── Lifetime output Σ — never auto-resets; delete lifetime-output.txt to reset ──
    if [[ "${_PRE_SUM_K:-0}" -gt 0 ]]; then
      _LIFETIME_FILE="${_RUN_DIR}/lifetime-output.txt"
      _PREV_LIFETIME=0
      if [[ -f "$_LIFETIME_FILE" ]]; then
        _PREV_LIFETIME=$(head -1 "$_LIFETIME_FILE" 2>/dev/null | tr -d '[:space:]' || true)
        _PREV_LIFETIME="${_PREV_LIFETIME//[^0-9]/}"; _PREV_LIFETIME="${_PREV_LIFETIME:-0}"
      fi
      printf '%s\n' "$(( _PREV_LIFETIME + _PRE_SUM_K ))" > "$_LIFETIME_FILE" 2>/dev/null || true
      log_obs INFO session-start-banner "lifetime Σ: +${_PRE_SUM_K}K → $(( _PREV_LIFETIME + _PRE_SUM_K ))K total" 2>/dev/null || true
    fi

    # ── Turns Σ (compaction only — normal exit resets above) ──
    if [[ "$_IS_NORMAL_EXIT" == false && "${_PRE_TURNS:-0}" -gt 0 ]]; then
      _TURNS_TOT_FILE="${_RUN_DIR}/turns-total.txt"
      _PREV_TURNS_TOT=0
      if [[ -f "$_TURNS_TOT_FILE" ]]; then
        _PREV_TURNS_TOT=$(head -1 "$_TURNS_TOT_FILE" 2>/dev/null | tr -d '[:space:]' || true)
        _PREV_TURNS_TOT="${_PREV_TURNS_TOT//[^0-9]/}"; _PREV_TURNS_TOT="${_PREV_TURNS_TOT:-0}"
      fi
      printf '%s\n' "$(( _PREV_TURNS_TOT + _PRE_TURNS ))" > "$_TURNS_TOT_FILE" 2>/dev/null || true
      log_obs INFO session-start-banner "turns Σ: +${_PRE_TURNS} → $(( _PREV_TURNS_TOT + _PRE_TURNS )) total" 2>/dev/null || true
    fi
  fi

  # ── F1: Early banner with git placeholder — status pane updates instantly ─────
  # Written before git calls start so the pane shows current model/handoff/cwd
  # immediately on compaction/restart, even while git runs in the background.
  _BANNER_TMP=$(mktemp "${_RUN_DIR}/.status-banner.XXXXXX" 2>/dev/null || mktemp)
  {
    printf 'MODEL:%s\n'      "${DISP_MODEL}"
    printf 'WIN:%s\n'        "${WIN_K}"
    printf 'BUF:%s\n'        "${BUF_K}"
    printf 'HANDOFF:%s\n'    "${HANDOFF_STR}"
    printf 'ANALYSIS:%s\n'   "${ANALYSIS_STR}"
    printf 'GIT:(loading…)\n'
    printf 'GIT_BRANCH:\n'
    printf 'GIT_DIRTY:0\n'
    printf 'GIT_UNPUSHED:-1\n'
    printf 'GIT_STASHES:0\n'
    printf 'GIT_LAST:\n'
    printf 'CLAUDEMD:\n'
    printf 'CWD:%s\n'        "${CWD}"
    printf 'STARTED_AT:%s\n' "${_STARTED_AT}"
  } > "$_BANNER_TMP" && mv -f "$_BANNER_TMP" "$_BNR_PATH" 2>/dev/null || true
  [[ "$_BNR_PATH" != "$_BNR_GLOBAL" ]] && cp -f "$_BNR_PATH" "$_BNR_GLOBAL" 2>/dev/null || true

  # ── Session CWD anchor: lets stop hook resolve correct project path even if ─────
  # shell CWD drifts during the session (cd commands, subagents, parallel sessions).
  # Keyed by SESSION_ID so multiple concurrent sessions don't collide.
  if [[ -n "${SESSION_ID:-}" ]]; then
    printf '%s\n' "${CWD}" > "${_RUN_DIR}/session-cwd-${SESSION_ID}.txt" 2>/dev/null || true
    # Prune per-session files older than 24h to avoid accumulation. Covers all FIVE
    # per-session families (touched-files-<sid>.txt added 2026-09-28, row 57 — backup-before-write's
    # per-session list of Edit/Write paths): session-cwd anchors, status-context, status-banner (the
    # last two accumulate from P1-3's /tmp `claude -p` subprocess litter) and the
    # suffix-less permission-mode-<sid> (written every Stop/PostToolUse since 2026-08-29
    # for the ⚠⚠⚠ BYPASS segment — a live session refreshes its mtime on every tool call,
    # so only dead sessions' files ever reach +1440). claude-cleanup.sh --run-files mirrors
    # this exact family list; keep the two in sync (test T23 / cleanup Section 25). The \( … \)
    # group is REQUIRED — without it, find's -a binds tighter than -o so -mmin would
    # apply only to the last -name, deleting the other families regardless of age.
    # The current session's status-context-<id>.txt (L163) and status-banner-<id>.txt
    # (L232) are written above with fresh mtime, so they are never in the +1440 set.
    # NOT reaped here: active-plan-<sid> (reaped below only when its target is gone — it is
    # the inherit signal) and any <family>-bypass-<sid> gate-bypass marker — autonomous-3c and,
    # since the 2026-08-30 /gates-bypass uniform model, the other 5 guard families too
    # (ask-gated self-mod path; manual removal — see claude-cleanup.sh's [protected] report).
    find "${_RUN_DIR}" -maxdepth 1 \
      \( -name "session-cwd-*.txt" -o -name "status-context-*.txt" -o -name "status-banner-*.txt" \
         -o -name "permission-mode-*" -o -name "touched-files-*.txt" \) \
      -mmin +1440 -delete 2>/dev/null || true
  fi

  # ── F2+F3: Five parallel git calls, each guarded by timeout 2 ────────────────
  # Wall-clock drops from ~5s (serial) to ~2s (parallel, hard-capped).
  # Each subshell writes its result to a temp file; collected after wait.
  # wait "$_pN" || true absorbs non-zero exits under set -euo pipefail.
  _TMP_GIT=$(mktemp -d /tmp/.gs-banner-git.XXXXXX 2>/dev/null || mktemp -d)

  ( _b=$(timeout 2 git -C "$CWD" branch --show-current 2>/dev/null || echo '?')
    printf '%s\n' "${_b:-?}" ) > "$_TMP_GIT/branch" &
  _p1=$!

  ( _d=$(timeout 2 git -C "$CWD" status --porcelain -- . 2>/dev/null | wc -l | tr -d ' ' || echo 0)
    printf '%s\n' "${_d:-0}" ) > "$_TMP_GIT/dirty" &
  _p2=$!

  ( _s=$(timeout 2 git -C "$CWD" stash list 2>/dev/null | wc -l | tr -d ' ' || echo 0)
    printf '%s\n' "${_s:-0}" ) > "$_TMP_GIT/stashes" &
  _p3=$!

  # Combined: last commit timestamp + CLAUDEMD staleness (avoids a 6th git call)
  (
    _ct=$(timeout 2 git -C "$CWD" log -1 --format='%ct' 2>/dev/null || echo 0)
    printf '%s\n' "${_ct:-0}" > "$_TMP_GIT/lastct"
    _CLAUDEMD_F="${CWD}/CLAUDE.md"
    if [[ -f "$_CLAUDEMD_F" ]]; then
      _CM_MTIME=$(stat -c '%Y' "$_CLAUDEMD_F" 2>/dev/null || echo 0)
      _CM_GAP=$(( ${_ct:-0} - ${_CM_MTIME:-0} ))
      if (( _CM_GAP > 259200 )); then
        printf '⚠ %sd behind HEAD\n' "$(( _CM_GAP / 86400 ))" > "$_TMP_GIT/claudemd"
      fi
    fi
  ) &
  _p4=$!

  # Unpushed: probe upstream first; -1 = no upstream configured
  (
    if timeout 2 git -C "$CWD" rev-parse '@{u}' &>/dev/null 2>&1; then
      _u=$(timeout 2 git -C "$CWD" log '@{u}..' --oneline 2>/dev/null | wc -l | tr -d ' ' || echo 0)
      printf '%s\n' "${_u:-0}"
    else
      printf '%s\n' '-1'
    fi
  ) > "$_TMP_GIT/unpushed" &
  _p5=$!

  wait "$_p1" || true
  wait "$_p2" || true
  wait "$_p3" || true
  wait "$_p4" || true
  wait "$_p5" || true

  # ── Collect results ───────────────────────────────────────────────────────────
  GIT_BRANCH=$(cat "$_TMP_GIT/branch" 2>/dev/null | head -1 | tr -d '[:space:]' || echo '?')
  [[ -z "$GIT_BRANCH" ]] && GIT_BRANCH='?'
  DIRTY_COUNT=$(cat "$_TMP_GIT/dirty" 2>/dev/null | head -1 | tr -d '[:space:]' || echo 0)
  DIRTY_COUNT="${DIRTY_COUNT//[^0-9]/}"; DIRTY_COUNT="${DIRTY_COUNT:-0}"
  GIT_DIRTY="$DIRTY_COUNT"
  GIT_STASHES=$(cat "$_TMP_GIT/stashes" 2>/dev/null | head -1 | tr -d '[:space:]' || echo 0)
  GIT_STASHES="${GIT_STASHES//[^0-9]/}"; GIT_STASHES="${GIT_STASHES:-0}"
  _LAST_CT=$(cat "$_TMP_GIT/lastct" 2>/dev/null | head -1 | tr -d '[:space:]' || echo 0)
  _LAST_CT="${_LAST_CT//[^0-9]/}"; _LAST_CT="${_LAST_CT:-0}"
  GIT_UNPUSHED=$(cat "$_TMP_GIT/unpushed" 2>/dev/null | head -1 | tr -d '[:space:]' || echo '-1')
  [[ "$GIT_UNPUSHED" =~ ^-?[0-9]+$ ]] || GIT_UNPUSHED='-1'
  CLAUDEMD_STATUS=$(cat "$_TMP_GIT/claudemd" 2>/dev/null | head -1 || true)
  rm -rf "$_TMP_GIT" 2>/dev/null || true

  # Last commit age string
  if (( _LAST_CT > 0 )) && type ss_age &>/dev/null; then
    _NOW_TS=$(date +%s)
    GIT_LAST=$(ss_age $(( _NOW_TS - _LAST_CT )))
  fi

  # Composite display string for plain stderr banner
  if (( DIRTY_COUNT > 0 )); then
    GIT_INFO="${GIT_BRANCH} · ${DIRTY_COUNT} uncommitted"
  else
    GIT_INFO="${GIT_BRANCH} · clean"
  fi
  if [[ "$GIT_UNPUSHED" != "-1" && "$GIT_UNPUSHED" -gt 0 ]]; then
    GIT_INFO+=" · ↑${GIT_UNPUSHED} to push"
  fi
  if (( GIT_STASHES > 0 )); then
    GIT_INFO+=" · ⚑${GIT_STASHES} stashed"
  fi
  [[ -n "$GIT_LAST" ]] && GIT_INFO+=" · ${GIT_LAST}"
fi
# ── end _MAIN_SESSION block (Σ counters, git data, early/global writes) ───────

# ── Initial context estimate (P1-3: runs for ALL sessions — no git dependency) ──
# 1. Try transcript: post-compaction sessions already have real token data.
# 2. Fallback: sum loaded config/memory file sizes + ~65K harness overhead
#    (tool schemas + CC framework unmeasurable from shell).
# stop-context-bar.sh overwrites with real API-reported values after first exchange.
_INIT_TOKENS=0
_IS_ESTIMATE=true
if [[ -n "${TRANSCRIPT:-}" ]] && type ss_parse_transcript &>/dev/null; then
  if ss_parse_transcript "$TRANSCRIPT" 2>/dev/null && [[ "${SS_INPUT_TOKENS:-0}" -gt 0 ]]; then
    _INIT_TOKENS="$SS_INPUT_TOKENS"
    _IS_ESTIMATE=false
  fi
fi
if [[ $_INIT_TOKENS -eq 0 ]]; then
  # Try self-calibrating baseline: saved by stop-context-bar.sh on first real ctx update.
  # Accurate because it captures actual startup ctx from the previous session.
  _BASELINE="${HOME}/.claude/run/startup-ctx-baseline.txt"
  if [[ -f "$_BASELINE" ]]; then
    _BASELINE_VAL=$(head -1 "$_BASELINE" 2>/dev/null | tr -d '[:space:]' || echo 0)
    _BASELINE_MODEL=$(sed -n '2p' "$_BASELINE" 2>/dev/null | tr -d '[:space:]' || true)
    _BASELINE_VAL="${_BASELINE_VAL//[^0-9]/}"
    # BUG-5: discard baseline if model changed (different context window size)
    if [[ -n "$_BASELINE_MODEL" && "$_BASELINE_MODEL" != "$RAW_MODEL" ]]; then
      _BASELINE_VAL=""
      log_obs INFO session-start-banner "baseline discarded: model changed (${_BASELINE_MODEL} → ${RAW_MODEL})" 2>/dev/null || true
    fi
    if [[ "${_BASELINE_VAL:-0}" -gt 0 ]]; then
      _INIT_TOKENS="$_BASELINE_VAL"
      _IS_ESTIMATE=true
    fi
  fi
fi
if [[ $_INIT_TOKENS -eq 0 ]]; then
  # Last resort: file-size estimate for first-ever session (no baseline saved yet).
  # Uses measurable config files + MEMORY.md + 50K harness overhead.
  _EST_BYTES=0
  for _f in "${HOME}/.claude/CLAUDE.md" \
             "${HOME}/.claude/RTK.md" \
             "${HOME}/.claude/RTK-local.md" \
             "${HOME}/.claude/THINKING.md" \
             "${HOME}/.claude/BLAST-RADIUS.md" \
             "${CWD}/CLAUDE.md" \
             "${HOME}/.claude/projects/${SLUG}/memory/MEMORY.md"; do
    if [[ -f "$_f" ]]; then
      _EST_BYTES=$(( _EST_BYTES + $(wc -c < "$_f" 2>/dev/null || echo 0) ))
    fi
  done
  # ~3.5 bytes/token; +80K for tool schemas, re-injected CLAUDE.md (system-reminder doubles it), skills
  _INIT_TOKENS=$(( _EST_BYTES * 2 / 7 + 80000 ))
  _IS_ESTIMATE=true
fi

_EFF_TOKENS=$(( _WIN_BYTES - _BUF_BYTES ))
[[ $_EFF_TOKENS -le 0 ]] && _EFF_TOKENS=1
_PCT_INIT=$(( _INIT_TOKENS * 100 / _EFF_TOKENS ))
[[ $_PCT_INIT -gt 100 ]] && _PCT_INIT=100
_INPUT_K_INIT=$(( _INIT_TOKENS / 1000 ))
_EFF_K=$(( _EFF_TOKENS / 1000 ))
_FREE_K_INIT=$(( _EFF_K - _INPUT_K_INIT ))
[[ $_FREE_K_INIT -lt 0 ]] && _FREE_K_INIT=0
_BUF_K_INT=$(( _BUF_BYTES / 1000 ))

# ── Final per-session writes (P1-3: ALL sessions). For non-git/non-main sessions
# GIT_* keep their 'n/a' defaults. Global dual-write happens ONLY for _MAIN_SESSION
# so a non-git foreground session — or the /tmp subprocess — never clobbers the
# global file that _PRE_CTX reads for cross-session lifetime carryover. ──────────
# Write per-session files when we have a real per-session target (session_id present) OR
# this is the git/main session (which legitimately owns the global fixed-name files). A
# non-git session with NO session_id has only the global path → skip, so it can never
# clobber the global file that _PRE_CTX reads for cross-session lifetime carryover.
# SessionStart always supplies session_id, so in practice this skips only malformed input.
# A headless side call (GS_NO_AUTO_HANDOFF=1) has no statusline to feed: its two files were
# ~10k/day of run/ litter (review-remediation row 56). It is never main, so nothing global is lost.
if [[ -z "${GS_NO_AUTO_HANDOFF:-}" ]] && [[ "$_MAIN_SESSION" == true || -n "${SESSION_ID:-}" ]]; then
  _BANNER_TMP=$(mktemp "${_RUN_DIR}/.status-banner.XXXXXX" 2>/dev/null || mktemp)
  {
    printf 'MODEL:%s\n'      "${DISP_MODEL}"
    printf 'WIN:%s\n'        "${WIN_K}"
    printf 'BUF:%s\n'        "${BUF_K}"
    printf 'HANDOFF:%s\n'    "${HANDOFF_STR}"
    printf 'ANALYSIS:%s\n'   "${ANALYSIS_STR}"
    printf 'GIT:%s\n'           "${GIT_INFO}"
    printf 'GIT_BRANCH:%s\n'    "${GIT_BRANCH}"
    printf 'GIT_DIRTY:%s\n'     "${GIT_DIRTY}"
    printf 'GIT_UNPUSHED:%s\n'  "${GIT_UNPUSHED}"
    printf 'GIT_STASHES:%s\n'   "${GIT_STASHES}"
    printf 'GIT_LAST:%s\n'      "${GIT_LAST}"
    printf 'CLAUDEMD:%s\n'      "${CLAUDEMD_STATUS}"
    printf 'CWD:%s\n'        "${CWD}"
    printf 'STARTED_AT:%s\n' "${_STARTED_AT}"
  } > "$_BANNER_TMP" && mv -f "$_BANNER_TMP" "$_BNR_PATH" 2>/dev/null || true
  [[ "$_MAIN_SESSION" == true && "$_BNR_PATH" != "$_BNR_GLOBAL" ]] && cp -f "$_BNR_PATH" "$_BNR_GLOBAL" 2>/dev/null || true

  {
    printf 'SESSION_ID:%s\n'  "${SESSION_ID}"
    printf 'PCT:%s\n'         "${_PCT_INIT}"
    printf 'INPUT_K:%s\n'     "${_INPUT_K_INIT}"
    printf 'EFF_K:%s\n'       "${_EFF_K}"
    printf 'FREE_K:%s\n'      "${_FREE_K_INIT}"
    printf 'BUF_K:%s\n'       "${_BUF_K_INT}"
    printf 'SUM_K:0\n'
    printf 'URGENCY:\n'
    if [[ "$_IS_ESTIMATE" == true ]]; then
      printf 'IS_ESTIMATE:true\n'
    else
      printf 'IS_ESTIMATE:false\n'
    fi
    printf 'TURNS:%s\n'    "${SS_TURNS:-0}"
    printf 'TURN_DUR:0\n'
    printf 'CLEAR_CTR:0\n'
  } > "$_CTX_PATH" 2>/dev/null || true
  [[ "$_MAIN_SESSION" == true && "$_CTX_PATH" != "$_CTX_GLOBAL" ]] && cp -f "$_CTX_PATH" "$_CTX_GLOBAL" 2>/dev/null || true
fi

# Global agent/notification resets: foreground (git) only — a non-git subprocess must
# not blank the foreground session's agents display or reset its notification level.
# ctx-notified is keyed per session (2026-08-30) — reset only THIS session's file, never
# the shared global one or another session's: a fresh SessionStart (including compact and
# resume) must not silently re-arm a different, still-running session's notification guard.
if [[ "$_MAIN_SESSION" == true ]]; then
  : > "${_RUN_DIR}/status-agents.txt" 2>/dev/null || true
  if [[ -n "${SESSION_ID:-}" ]]; then
    rm -f "${_RUN_DIR}/ctx-notified-${SESSION_ID}.txt" 2>/dev/null || true
  else
    rm -f "${_RUN_DIR}/ctx-notified.txt" 2>/dev/null || true
  fi
fi

# ── Daily safe sweep (row 26zc, AGREED 2026-10-16) ───────────────────────────
# Main sessions only (a headless side call is not one). Detached: its own session and none of this hook's fds, or
# Claude Code waits for EOF on SessionStart. The 24 h gate, the lock and CLAUDE_CLEANUP_AUTO_OFF live in
# `claude-cleanup.sh --auto`. Resolved through $HOME, not this hook's dir: a test under a fake HOME never sweeps /tmp.
# `|| true`: a failed fork must not fail SessionStart under set -e; the sweep logs its own errors.
if [[ "$_MAIN_SESSION" == true && -f "$HOME/.claude/bin/claude-cleanup.sh" ]]; then
  if command -v setsid >/dev/null 2>&1; then
    ( setsid bash "$HOME/.claude/bin/claude-cleanup.sh" --auto </dev/null >/dev/null 2>&1 & ) || true
  else
    ( bash "$HOME/.claude/bin/claude-cleanup.sh" --auto </dev/null >/dev/null 2>&1 & ) || true
  fi
fi

# ── Banner: box of INNER=68 inner chars (70 total with borders) ───────────────
INNER=68
_row() {
  # Note: uses printf %-*s which pads by byte count — fine for ASCII content
  printf "│%-${INNER}s│\n" "$1"
}
_hline() { local _h='' _i; for (( _i=0; _i<INNER; _i++ )); do _h+='─'; done; printf '%s%s%s\n' "$1" "$_h" "$2"; }

# _ps_elapsed <sentinel-file> — "Xm ago"/"Xh ago"/"X days ago"/"X wks ago" from the
# sentinel's activated_at field. Same age-bucketing convention as HANDOFF_STR /
# ANALYSIS_STR above, applied to permission-swap sentinels for the armed-since warning.
_ps_elapsed() {
  local sentinel="$1" activated_at now age
  activated_at=$(jq -r '.activated_at // empty' "$sentinel" 2>/dev/null || true)
  [[ -z "$activated_at" ]] && { printf 'unknown'; return; }
  now=$(date +%s)
  age=$(( now - activated_at ))
  if   (( age < 3600  )); then printf '%sm ago' "$((age/60))"
  elif (( age < 86400  )); then printf '%sh ago' "$((age/3600))"
  elif (( age < 604800 )); then printf '%s days ago' "$((age/86400))"
  else                          printf '%s wks ago' "$((age/604800))"
  fi
}

{
  _hline '┌' '┐'
  _row "  model   : ${DISP_MODEL} · ${WIN_K} · buffer ~${BUF_K}"
  _row "  handoff : ${HANDOFF_STR}  ·  analysis : ${ANALYSIS_STR}"
  _row "  git     : ${GIT_INFO}"
  [[ -n "$CLAUDEMD_STATUS" ]] && _row "  claude.md: ${CLAUDEMD_STATUS}" || true
  # Permission-swap armed warnings — global and project are independent, both can be
  # armed at once, so each gets its own conditional row. Inside this group deliberately
  # (before the closing border, not after) so the >&2 redirect makes it user-visible —
  # unlike the active-plan notice further below, which is stdout/context-injection.
  if [[ -f "$HOME/.claude/state/permission-profile-permissive.json" ]]; then
    _ps_ago="$(_ps_elapsed "$HOME/.claude/state/permission-profile-permissive.json")"
    _row "  ⚠ permission-swap ARMED ${_ps_ago}: permission-swap.sh off"
  fi
  if [[ -f "$HOME/.claude/projects/${SLUG}/state/permission-profile-project-added.json" ]]; then
    _pp_ago="$(_ps_elapsed "$HOME/.claude/projects/${SLUG}/state/permission-profile-project-added.json")"
    _row "  ⚠ project ARMED ${_pp_ago}: permission-swap-project.sh off"
  fi
  _hline '└' '┘'
} >&2

log_obs INFO session-start-banner "banner printed (main=${_MAIN_SESSION} cwd=${CWD} handoff=${HANDOFF_STR} analysis=${ANALYSIS_STR})" 2>/dev/null || true

# Row 56 follow-up (AGREED 2026-09-28 10:18): a headless side call's stdout is injected into its
# Haiku prompt, so it gets no spotlight, plan note or MODE line. Keyed on GS_NO_AUTO_HANDOFF (the
# side-call marker), NOT on main=false — that also covers foreground sessions outside git (T10d).
# Only stdout is dropped: the pointer reap and the mode log below still run.
if [[ -n "${GS_NO_AUTO_HANDOFF:-}" ]]; then exec >/dev/null; fi

# ── Rotating skill spotlight: dynamic discovery from skill frontmatter ──
# Scans global skills, installed plugin skills, and project skills.
# Skills opt-in with `spotlight: true` in SKILL.md frontmatter.
# Output goes to stdout → Claude Code injects it as system-reminder content.
_SKILLS=()

# One grep for a whole batch of SKILL.md paths (stdin, sorted) instead of one fork per file: the per-file form cost ~1,000 processes and pushed the banner
# past its 5 s hook timeout (hook_cancelled, 2026-10-03). Order is preserved (grep -l prints in argument order).
_add_skills_from_find() {
  local -a _all=() _hit=(); local _sf
  mapfile -t _all
  (( ${#_all[@]} )) || return 0
  mapfile -t _hit < <(grep -l "^spotlight: true" -- "${_all[@]}" 2>/dev/null || true)
  for _sf in "${_hit[@]}"; do _add_skill_from_file "$_sf"; done
}

_add_skill_from_file() {
  local skill_file="$1"
  grep -q "^spotlight: true" "$skill_file" 2>/dev/null || return 0
  local skill_name desc _ln
  # Builtins only (no basename/dirname/grep/sed/tr/cut forks): ~6 processes per spotlighted skill used to be spent here.
  skill_name="${skill_file%/SKILL.md}"; skill_name="${skill_name##*/}"
  desc=""
  while IFS= read -r _ln || [[ -n "$_ln" ]]; do
    if [[ "$_ln" == description:* ]]; then desc="${_ln#description:}"; break; fi
  done < "$skill_file" 2>/dev/null
  desc="${desc#"${desc%%[![:space:]]*}"}"; desc="${desc//\"/}"; desc="${desc:0:120}"
  [[ -z "$desc" || "$desc" == ">" || "$desc" == "|" ]] && return
  _SKILLS+=("/$skill_name — $desc")
}

# Global skills
_add_skills_from_find \
  < <(timeout 3 find "$HOME/.claude/skills" -maxdepth 2 -name "SKILL.md" 2>/dev/null | sort)

# Installed plugin skills
if [[ -f "$HOME/.claude/plugins/installed_plugins.json" ]]; then
  while IFS= read -r _install_path; do
    [[ -d "$_install_path" ]] || continue
    _add_skills_from_find \
      < <(timeout 3 find "$_install_path" -maxdepth 3 -name "SKILL.md" 2>/dev/null | sort)
  done < <(timeout 3 jq -r '.plugins | to_entries[] | .value[] | .installPath' \
    "$HOME/.claude/plugins/installed_plugins.json" 2>/dev/null)
fi

# Project skills (nearest .claude/skills/ walking up from CWD)
_proj_dir="${CWD:-$(pwd)}"
while [[ "$_proj_dir" != "/" ]]; do
  if [[ -d "$_proj_dir/.claude/skills" ]]; then
    _add_skills_from_find \
      < <(timeout 3 find "$_proj_dir/.claude/skills" -maxdepth 2 -name "SKILL.md" 2>/dev/null | sort)
    break
  fi
  _proj_dir=$(dirname "$_proj_dir")
done
unset _f _install_path _proj_dir

_SKILL_COUNT="${#_SKILLS[@]}"
if (( _SKILL_COUNT > 0 )); then
  # Per-session stable spotlight: seed the index by session_id (not RANDOM, which re-rolled
  # on every SessionStart — including mid-session /compact + resume events). The highlighted
  # skill now stays fixed for a whole session and only changes when a NEW session starts.
  # Stateless: no marker file, and the /tmp `claude -p` subprocess uses its own session_id so
  # it cannot perturb another session's choice. Falls back to day-of-year when no session_id
  # is supplied (SESSION_ID is optional — cf. the `${SESSION_ID:-}` guard above) so the
  # spotlight rotates daily rather than freezing on one skill.
  _spot_seed="${SESSION_ID:-$(date +%Y%j 2>/dev/null)}"
  _spot_num=$(printf '%s' "$_spot_seed" | cksum 2>/dev/null | cut -d' ' -f1)
  _spot_num="${_spot_num//[^0-9]/}"; _spot_num="${_spot_num:-0}"
  _SKILL_IDX=$(( _spot_num % _SKILL_COUNT ))
  printf '\nSkill spotlight: %s\n' "${_SKILLS[$_SKILL_IDX]}"
  unset _spot_seed _spot_num
fi

# ── Active-plan AUTO-INHERIT (Rule 17 backstop) — crash-isolated ───────────────
# Continuation "just works": an UNATTACHED session (no run/active-plan-<sid>) in a project
# with exactly ONE plan file auto-attaches (writes its own pointer → the statusline shows `plan <topic>`).
# With ≥2 plans it can't disambiguate, so it nudges. Logic is FILE-based (globs the project's
# .plan.md files), so a dead session's leftover pointer is irrelevant — it neither suppresses
# this nor needs special handling. Also reaps pointers whose target file no longer exists.
# Wrapped in ( … ) || true so a failure here can NEVER break session start (all critical
# writes already happened above).
( set +e
  # Reap stale pointers whose target plan file is gone (cleanliness; statusline self-heals too).
  for _ap in "${_RUN_DIR}"/active-plan-*; do
    [[ -e "$_ap" ]] || continue
    _t=""; IFS= read -r _t < "$_ap" 2>/dev/null || true
    [[ -n "$_t" && -f "$_t" ]] || rm -f "$_ap" 2>/dev/null
  done
  # A headless side call (GS_NO_AUTO_HANDOFF=1) never attaches a plan (row 56); the reap above still runs.
  if [[ -z "${GS_NO_AUTO_HANDOFF:-}" && -n "${SESSION_ID:-}" && ! -f "${_RUN_DIR}/active-plan-${SESSION_ID}" ]]; then
    # (1) PRIMARY: inherit the MOST-RECENT prior pointer that targets a plan in THIS project.
    # A prior session that worked plan X (and ended without Phase 8) left active-plan-<that-sid>
    # → X; that leftover is the signal of which plan to continue — even among many plan files.
    # "In this project" = under $CWD or under this slug's plans dir.
    _best=""; _best_ap=""; _rslug=""
    for _ap in "${_RUN_DIR}"/active-plan-*; do
      [[ -e "$_ap" ]] || continue
      _t=""; IFS= read -r _t < "$_ap" 2>/dev/null || true
      [[ -n "$_t" && -f "$_t" ]] || continue
      # The slug arms decide FIRST: with cwd ~/.claude every projects/<other-slug>/plans/ file also matches "${CWD}"/*, and that arm
      # used to come first, so a ~/.claude session inherited another project's plan (row 26s, 2026-10-14; test T22b).
      # Our slug in both spellings: Claude Code's own also maps "." to "-" (-home-user--claude; test T22d).
      case "$_t" in
        "${HOME}/.claude/projects/${SLUG}/plans/"*|"${HOME}/.claude/projects/${SLUG//./-}/plans/"*) ;;
        "${HOME}/.claude/projects/"*/plans/*)
          # An ANCESTOR project's plans dir counts too. /progress files plans under the ROOT
          # slug, so a ~/.claude/hooks session must inherit the plan stored under the
          # ~/.claude slug; matching only $CWD and this slug never found it (SPEC §6 item 47).
          # "Ancestor" = the PROJECT ROOT, by the collector's own clamp (cert_schedule_root = bin/project-state.sh's ROOT), in
          # either slug spelling. A slug PREFIX test passed the ~ slug from ~/.claude and sibling proj for proj-api, plans the
          # collector then ignored (row 26s; tests T22e-T22g). Resolved once, on the first pointer that reaches this arm.
          _ps="${_t#"${HOME}/.claude/projects/"}"; _ps="${_ps%%/plans/*}"
          if [[ -z "${_rslug:-}" ]]; then
            # No 2>/dev/null: cert_schedule_root silences its own git call, and a missing library should show. If it cannot be
            # sourced, the root defaults to $CWD = own-slug-only matching, which the first arm already covers (one try, no retry).
            _rr=""; source "$SCRIPT_DIR/cert-schedule.sh" && _rr=$(cert_schedule_root "$CWD")
            _rr="${_rr:-$CWD}"; _rslug="${_rr//\//-}"
          fi
          [[ "$_ps" == "$_rslug" || "$_ps" == "${_rslug//./-}" ]] || continue ;;
        "${CWD}"/*)
          # The collector's _in_project question (bin/project-state.sh), so the banner never attaches a pointer the collector then
          # ignores (panel 26s): a cwd outside ~/.claude never adopts a file under it (~/.claude is its own project by the root clamp,
          # yet has no .git: A-P3-3, T22i), and a nested repo between cwd and the plan makes it that child's (B-P2-2, T22h).
          if [[ "$CWD" != "${HOME}/.claude" && "$CWD" != "${HOME}/.claude/"* && "$_t" == "${HOME}/.claude/"* ]]; then continue; fi
          _d="${_t%/*}"; _nest=0
          while [[ "$_d" == "$CWD"/* ]]; do [[ -e "$_d/.git" ]] && { _nest=1; break; }; _d="${_d%/*}"; done
          (( _nest )) && continue ;;
        *) continue ;;
      esac
      # newest pointer wins; ties go to the later glob entry (as before). -nt needs no stat fork per pointer.
      if [[ -z "$_best_ap" ]] || ! [[ "$_best_ap" -nt "$_ap" ]]; then _best="$_t"; _best_ap="$_ap"; fi
    done
    if [[ -n "$_best" ]]; then
      printf '%s\n' "$_best" > "${_RUN_DIR}/active-plan-${SESSION_ID}" 2>/dev/null
      printf '\n▸ Active-plan (Rule 17): auto-attached this session to plan '\''%s'\'' (inherited from the most recent prior session). Clear/repoint if doing other work.\n' \
        "$(basename "$_best" .plan.md)"
    else
      # (2) FALLBACK: no prior pointer for this project → use the plan-file count.
      _pc=()
      while IFS= read -r _pf; do [[ -n "$_pf" && -f "$_pf" ]] && _pc+=("$_pf"); done < <(
        { ls "${CWD}/docs/plans/"*.plan.md 2>/dev/null
          ls "${HOME}/.claude/projects/${SLUG}/plans/"*.plan.md 2>/dev/null; } | sort -u || true)
      if (( ${#_pc[@]} == 1 )); then
        printf '%s\n' "${_pc[0]}" > "${_RUN_DIR}/active-plan-${SESSION_ID}" 2>/dev/null
        printf '\n▸ Active-plan (Rule 17): auto-attached this session to plan '\''%s'\'' (only plan in this project). Clear/repoint if doing other work.\n' \
          "$(basename "${_pc[0]}" .plan.md)"
      elif (( ${#_pc[@]} > 1 )); then
        _names=(); for _pf in "${_pc[@]}"; do _names+=("$(basename "$_pf" .plan.md)"); done
        printf '\n⚠ Active-plan (Rule 17): %d candidate plans in this project and no prior pointer to inherit — can'\''t auto-attach: %s\n' \
          "${#_pc[@]}" "$(IFS=,; echo "${_names[*]}")"
        printf '   Continuing one? Write its abs path → ~/.claude/run/active-plan-$CLAUDE_CODE_SESSION_ID\n'
      fi
    fi
  fi
) || true

# ── MODE line + certification schedule (CLAUDE.md § Mode) — crash-isolated, stdout ──────
# The model cannot see the statusline, so this stdout line is how Claude learns the mode:
# the ask-human gate family decides it per cwd tree (bypassed = autonomous, armed = spec),
# resolved exactly as ask-human-gate-block.sh:36 does. In autonomous mode the per-project
# certification schedule (asked ONCE, stored next to plan-location) is printed so it is
# applied without asking again. Phase 0 re-checks: bypass state can change mid-session.
( set +e
  _mode="spec"
  if ( source "$SCRIPT_DIR/bypass-resolve.sh" \
       && BYPASS_SESSION_ID="${SESSION_ID:-}" bypass_applies ah "$CWD" ) 2>/dev/null; then
    _mode="autonomous"
  fi
  # Confident picks (family cf, row 26zg) are resolved first: under cf the MODE line must not promise the default pick (panel round 3 C-P3-4).
  _cf=0
  if ( source "$SCRIPT_DIR/bypass-resolve.sh" && BYPASS_SESSION_ID="${SESSION_ID:-}" bypass_applies cf "$CWD" ) 2>/dev/null; then _cf=1; fi
  if [[ "$_mode" == "autonomous" ]]; then
    _amb='recommended option logged as ASSUMED (review)'; (( _cf )) && _amb='the confident-picks rule below (no default pick)'
    printf '\n▸ MODE: autonomous — ask-human gate bypassed for this tree: announce and run, no stops; ambiguity → %s; destructive steps still ask (CLAUDE.md § Mode).\n' "$_amb"
    # Project-scoped, walked up from cwd to the root: the same helper /next's collector uses,
    # so the banner and /next can never disagree on which file holds the answer.
    source "$SCRIPT_DIR/cert-schedule.sh"
    _root=$(cert_schedule_root "$CWD")
    if _hit=$(cert_schedule_find "$CWD" "$_root"); then
      _sf="${_hit#*$'\t'}"
      printf '▸ Certification schedule (%s): %s — apply it without asking.\n' \
        "$(basename "$(dirname "$_sf")")" "${_hit%%$'\t'*}"
    else
      _cs=$(cert_schedule_file "$_root")
      printf '▸ Certification schedule (%s): not set — ask once (recommended: advisor() per task + one panel at the end), then write the answer to %s\n' \
        "$(basename "$(dirname "$_cs")")" "$_cs"
    fi
  else
    printf '\n▸ MODE: spec — ask-human gate armed for this tree: every gate fires (size question, plan gate, tier question) (CLAUDE.md § Mode).\n'
  fi
  # Confident picks: an independent enable, resolved like ah (above); the tiered rule text is the resolver's own (bypass_cf_text).
  if (( _cf )); then
    ( source "$SCRIPT_DIR/bypass-resolve.sh" && bypass_cf_text "$_mode" ) 2>/dev/null
    # Record what the model was told, so hooks/ask-human-gate-arm.sh prints "OFF now" if cf ends before the first prompt (same record it keeps).
    _cfd="${GATE_DIR_OVERRIDE:-$HOME/.claude/run/ask-human-gate}/cf"
    [[ -n "${SESSION_ID:-}" ]] && { mkdir -p "$_cfd" && printf '1' > "$_cfd/$SESSION_ID"; } 2>/dev/null
  fi
  log_obs INFO session-start-banner "mode=$_mode cf=$_cf slug=$SLUG" 2>/dev/null
) || true

# ── Expertise line (docs/SPEC.md 2.20): where THIS project's own expertise lives — the global config carries none. Crash-isolated, stdout. ──
# Silent unless the cwd has a CLAUDE.md or an index, so non-project directories (/tmp, $HOME) get no noise.
( set +e
  _ex="$CWD/.claude/expertise.md"; _shown=0; _head=$(git -C "$CWD" rev-parse --short HEAD 2>/dev/null)
  _slug="${CWD//[\/.]/-}"; _si="$HOME/.claude/projects/$_slug/expertise/index.md"
  # In-tree store (plan spa-rac-in-tree-expertise): the directory's own .claude/expertise/ (index.md), or its container's entry for this unit (mirror of expertise_gate.intree_home).
  _ti=""; _tp="$(dirname "$CWD")/.claude/expertise"; _tn="$(basename "$CWD")"
  if [[ -f "$CWD/.claude/expertise/index.md" ]]; then _ti="$CWD/.claude/expertise"
  elif [[ -f "$_tp/index.md" && ( -f "$_tp/$_tn/index.md" || -f "$_tp/$_tn/practices.md" ) ]]; then _ti="$_tp/$_tn"; fi
  if [[ -n "$_ti" ]]; then
    _shown=1
    if [[ -f "$_ti/practices.md" ]]; then
      printf '▸ Expertise: in-tree %s — read %s/practices.md (do-not-repeat list, ask-first rule) before assuming this project'"'"'s conventions.\n' "$_ti" "$_ti"
    else
      printf '▸ Expertise: in-tree %s (a container: index.md here, practices.md per unit under it) — read the unit'"'"'s practices.md before working in it.\n' "$_ti"
    fi
  fi
  if [[ -f "$_ex" ]]; then
    _built=$(sed -n 's/^- built from: //p' "$_ex" 2>/dev/null | head -n 1); _shown=1
    if [[ -n "$_head" && "$_built" == "$_head" ]]; then
      printf '▸ Expertise: %s (fresh @ %s) — read it before assuming this project'"'"'s conventions.\n' "$_ex" "$_head"
    else
      printf '▸ Expertise: %s is stale (built from %s, HEAD %s) — run /discover-expertise --write-repo.\n' "$_ex" "${_built:-unknown}" "${_head:-none}"
    fi
  fi
  if [[ -f "$_si" ]]; then
    _built=$(sed -n 's/^- built from: //p' "$_si" 2>/dev/null | head -n 1); _shown=1
    if [[ "$_built" == not\ a\ git\ repository\ root* ]]; then
      printf '▸ Expertise: global store ~/.claude/projects/%s/expertise/ (a container: index.md here, practices.md per unit) — read the unit'"'"'s practices.md before working in it.\n' "$_slug"
    elif [[ -n "$_head" && "$_built" == "$_head" ]]; then
      printf '▸ Expertise: global store ~/.claude/projects/%s/expertise/ (fresh @ %s) — read practices.md (do-not-repeat list, ask-first rule) before assuming this project'"'"'s conventions.\n' "$_slug" "$_head"
    else
      printf '▸ Expertise: global store for this project is stale (built from %s, HEAD %s) — run /discover-expertise --write.\n' "${_built:-unknown}" "${_head:-none}"
    fi
  fi
  if [[ -f "$CWD/.claude/rules/expertise-core.md" || -f "$CWD/.claude/EXPERTISE-REFERENCE.md" ]]; then
    printf '▸ Expertise: installed pack (.claude/rules/expertise-core.md is loaded every session; reference .claude/EXPERTISE-REFERENCE.md) — /discover-expertise lists it.\n'; _shown=1
  fi
  if [[ $_shown -eq 0 ]]; then
    if [[ -f "$CWD/CLAUDE.md" ]]; then
      printf '▸ Expertise: CLAUDE.md (no index yet — /discover-expertise --write builds one in ~/.claude/projects/<slug>/expertise/).\n'
    elif [[ ! -e "$CWD/.git" && "$CWD" != "/" && "$CWD" != "/tmp" && "$CWD" != "/var/tmp" && "$CWD" != "$HOME" ]]; then
      _units=0
      for _u in "$CWD"/*/; do [[ -e "${_u}.git" ]] && _units=$((_units+1)); done
      [[ $_units -gt 1 ]] && printf '▸ Expertise: %d repositories here and no project expertise — run /discover-expertise (per unit: --dir <unit>) before research or agents.\n' "$_units"
    fi
  fi
) || true
