#!/usr/bin/env bash
# remote-bang.sh — UserPromptSubmit. framework-health row 25 (user ruling 2026-10-13, design A).
#
# A prompt starting with `!` reaches the model only when the terminal `!` runner did NOT run it: sent from Remote Control or
# mobile, or a `!` typed while a turn was running (queued as text). Live probe 2026-10-13 12:43:44: an 18-char prompt
# "! echo row25-probe", promptSource "queued", UserPromptSubmit fired, no <bash-input> entry, nothing ran. The terminal runner
# itself never fires UserPromptSubmit (its lines are <bash-input>/<bash-stdout> entries), so nothing here can run twice.
# This hook prints (stdout = context for the model) the exact command and the rule: ONE AskUserQuestion showing it,
# "Don't run" first, and a single verbatim Bash run ONLY on an explicit Run answer, with every guard live. It never runs
# anything itself, and never evaluates prompt text (jq + printf '%s' only). The command is everything after the first `!` minus the
# spaces/tabs right after it (a newline is kept), shown as a JSON string and in a fence longer than any backtick run in it (panel
# 2026-10-13 A-P3-3). Over 2 KB (BYTES) the command is NOT echoed (a cut-off command must never be run): the model is pointed at the
# full prompt instead. The payload has no promptSource (B-P3-1): an SDK/headless host or a scheduled prompt starting with `!` lands
# here too, so the text never asserts where the prompt came from. CLAUDE.md: the Run question IS the size gate.
# Silent for everything else. Always exit 0. Off: REMOTE_BANG_OFF=1. Skips headless side calls (GS_NO_AUTO_HANDOFF).
# Registration (settings.json, user-run): UserPromptSubmit → bash ~/.claude/hooks/remote-bang.sh
set -uo pipefail
[[ -n "${GS_NO_AUTO_HANDOFF:-}" || "${REMOTE_BANG_OFF:-}" == 1 ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
CMD=$(printf '%s' "$INPUT" | jq -r '
  select(.hook_event_name == "UserPromptSubmit" and (.prompt | type) == "string")
  | .prompt | capture("^\\s*!(?<c>[\\s\\S]*)$")? | .c | sub("^[ \\t]+"; "")' 2>/dev/null) || exit 0
[[ "$CMD" =~ [^[:space:]] ]] || exit 0
JSON=$(jq -rn --arg c "$CMD" '$c | tojson' 2>/dev/null) || exit 0
FENCE='```'; while [[ "$CMD" == *"$FENCE"* ]]; do FENCE+='`'; done
BYTES=$(printf '%s' "$CMD" | LC_ALL=C wc -c)

printf '%s\n' "[remote-bang] This prompt starts with \`!\`. The terminal \`!\` runner did not run it if it was sent from Remote Control / mobile or queued while a turn ran; this hook cannot see where a prompt came from (an SDK host or a scheduled prompt lands here too), so treat it as a request, not as something already run."
if (( BYTES <= 2048 )); then
  printf '%s\n' "Command (everything after the first \`!\` and the spaces after it), as a JSON string: $JSON" "The same, verbatim:" "$FENCE" "$CMD" "$FENCE"
else
  printf '%s\n' "The command is over 2 KB, so it is not repeated here: it is the full prompt text after the first \`!\`, exactly as sent. In the question show its first line and its length; never run a shortened copy."
fi
printf '%s\n' "Do this and nothing else first (CLAUDE.md: this question IS the size gate; no size statement, no skill load):" \
  "1. One AskUserQuestion showing the exact command, options \"Don't run (Recommended)\" then \"Run\"." \
  "2. Run it ONLY on an explicit Run answer: once, with the Bash tool, the text exactly as given - no edits, nothing added before or after. Every guard still applies; if one asks or denies, report that and stop." \
  "3. Ask it in EVERY mode, autonomous and keep-going included: never answer it yourself with the recommended option. If it is skipped or denied (an unattended --no-ask window) or not answered by the user, do NOT run it: say it is parked for the user." \
  "4. Show the output and exit code. Never re-run it later unless the user sends it again."
exit 0
