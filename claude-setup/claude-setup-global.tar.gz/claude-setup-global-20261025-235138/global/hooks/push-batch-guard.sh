#!/usr/bin/env bash
# push-batch-guard.sh - PreToolUse(Bash) shim for hooks/push_batch_guard.py: refuse a Claude `git push` below the push batch
# (CLAUDE.md Rule 10, 30 unpushed commits; user ruling 2026-10-08). The logic, the escape (`git -c push.reason=... push`) and the
# limits are documented in push_batch_guard.py. Off-switch: PUSH_BATCH_OFF=1 at launch. Registered by bin/push-batch-apply.sh.
[[ "${PUSH_BATCH_OFF:-}" == 1 ]] && exit 0
exec /usr/bin/python3 "$(dirname "${BASH_SOURCE[0]}")/push_batch_guard.py"
