#!/usr/bin/env bash
# PreToolUse: Edit|Write — backstop for CLAUDE.md Phase 3C (PRE-WORK INDEPENDENT CHECK).
# Phase 6C has advisor-completion-guard.sh; Phase 3C had NO mechanical enforcement at all until
# this hook (2026-08-22 audit finding). This closes that asymmetry.
#
# WHAT IT ENFORCES: visibility, not the advisor() call itself. The turn must show ONE of:
#   - the string "3C" anywhere in the assistant's text this turn (the Rule 16 sequence declaration
#     "Phases: 3C → 5 → …", a "── Phase 3C ──" marker, a "3C round N →" line, or an explicit
#     "Phase 3C — skipped (trivial single-line edit)"), or
#   - an `advisor` tool call, or
#   - a reviewer-panel `Agent` spawn (the certification-ladder fallback).
# Deliberately generous. CLAUDE.md already requires a visible phase marker for EVERY task including
# Small, so any turn following the workflow trips one of these without extra effort. The design
# target is not airtightness — it is that Phase 3C can no longer be omitted SILENTLY.
#
# WHY SO LOOSE: the 2026-08-22 audit found four projects running with all four gate families
# bypassed, because gates that nag get switched off. A per-edit blocker is the noisiest surface in
# this config; its realistic failure mode is abandonment, not evasion. Every knob below is tuned
# against that: main-session only, one verdict per turn, generous accept-check.
#
# Bypasses (three scopes, parity with the other guard families):
#   PREWORK_OFF=1 | ~/.claude/state/advisor-prework-guard-bypass
#                 | ~/.claude/projects/<cwd-slug>/state/advisor-prework-guard-bypass
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

[[ "${PREWORK_OFF:-}" == "1" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$SESSION_ID" ]] || exit 0

PW_CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
# This guard matches Edit|Write, so it always has a real target — pass it so except-lists work.
# "Bypass this project, but keep asking me before you touch api/vendor" is exactly this line.
PW_TARGET=$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null || true)

# Shared resolver, SUBSHELL-invoked: this hook runs `set -u` and Claude Code blocks only on exit 2,
# so a crash evaluated in our own shell would exit 1 and fail OPEN. See bypass-resolve.sh.
# Bypassed = ADVISORY (framework-health step 7): the same check runs and never blocks; a turn without 3C evidence gets ONE
# in-context note (PreToolUse additionalContext: stderr with exit 0 never reaches the model) and ONE pw review event, then the
# turn is cached like a pass. PREWORK_OFF=1 above stays a full off.
ADV=0
if ( BYPASS_SESSION_ID="$SESSION_ID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
     bypass_applies pw "$PW_CWD" "$PW_TARGET" ) 2>/dev/null; then
  ADV=1
fi

GATE_DIR="${GATE_DIR_OVERRIDE:-$HOME/.claude/run/ask-human-gate}"  # GATE_DIR_OVERRIDE: test-only injection point
if [[ "$ADV" == 1 ]]; then
  # No turn token exists while ah is bypassed (ask-human-gate-arm.sh writes none then): key the turn on the prompt stamp it
  # writes in every mode; a separate cache so an advisory verdict never satisfies an armed turn.
  TURN_TOKEN="$GATE_DIR/prompts/${SESSION_ID}"
  CACHE="$GATE_DIR/prework-adv/${SESSION_ID}"
else
  TURN_TOKEN="$GATE_DIR/turns/${SESSION_ID}"
  # ah bypassed + pw armed: ask-human-gate-arm.sh writes no turn token then, so the armed guard never fired (test P1), and after a
  # mid-session spec -> autonomous switch the old token stops moving, so a pass cached against it cleared every later turn (P4).
  # The prompt stamp the same UserPromptSubmit hook writes in every mode is never older: take the newer of the two. Digits only,
  # because [[ -gt ]] evaluates its operands as arithmetic. Still no file at all = not interactive (P3).
  PSTAMP="$GATE_DIR/prompts/${SESSION_ID}"
  T_EP=$(cat "$TURN_TOKEN" 2>/dev/null); P_EP=$(cat "$PSTAMP" 2>/dev/null)
  [[ "$T_EP" =~ ^[0123456789]{1,12}$ ]] || T_EP=0; [[ "$P_EP" =~ ^[0123456789]{1,12}$ ]] || P_EP=0
  (( 10#$P_EP > 10#$T_EP )) && TURN_TOKEN="$PSTAMP"
  CACHE="$GATE_DIR/prework/${SESSION_ID}"
fi

# No turn token (nor prompt stamp) = not an interactive main session (subagent, tool runner) -> allow through.
# The contract ask-human-gate-block.sh relies on for turns/; the prompt stamp extends it to the ah-bypassed case.
[[ -f "$TURN_TOKEN" ]] || exit 0
# Stamp and cache contents are DATA: [[ a -ge b ]] evaluates its operands, so a stamp holding NAME[$(cmd)] ran cmd here and a crash
# exited 1 (= no block; milestone panel B-P1-3). Digits only - an explicit list, since [0-9] is a locale RANGE that matches U+0665 - and at
# most 12 of them; anything else = no usable turn key, so no cached pass (the transcript decides).
TURN_TIME=$(cat "$TURN_TOKEN" 2>/dev/null)
[[ "$TURN_TIME" =~ ^[0123456789]{1,12}$ ]] || TURN_TIME=""

# Subagent carve-out: subagents share the parent session_id, so the turn token exists for them too,
# yet they run their own 3C internally and cannot emit markers into the parent transcript turn.
# While any FRESH SubagentStart marker exists for this session, allow through (mirrors gate-block).
SUBAGENT_MARK_DIR="$GATE_DIR/subagent/${SESSION_ID}"
if [[ -d "$SUBAGENT_MARK_DIR" ]] \
   && find "$SUBAGENT_MARK_DIR" -type f -mmin -120 -print -quit 2>/dev/null | grep -q .; then
  exit 0
fi

# One verdict per turn: re-parsing the transcript on every Edit of a long turn is pure waste.
# Cache holds the turn epoch that was cleared; only PASS verdicts are cached (a block must stay
# re-checkable, so the next Edit re-reads the transcript after the marker is emitted).
if [[ -f "$CACHE" ]]; then
  CACHED=$(cat "$CACHE" 2>/dev/null)
  # pass_turn stores exactly this turn's epoch: equality, so a far-future value is no standing pass.
  [[ -n "$TURN_TIME" && "$CACHED" == "$TURN_TIME" ]] && exit 0
fi

TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
# Fail OPEN: no transcript means we cannot judge, and blocking on ignorance is the abandonment path.
[[ -n "$TRANSCRIPT" && -f "$TRANSCRIPT" ]] || exit 0

# Turn anchoring shared byte-for-byte with advisor-completion-guard.sh and ask-human-question-guard.sh. Commit 5701e37b skipped
# tool_result entries ("guards could not see advisor() and mis-anchored the turn"). Three more type:user entries are not prompts:
# a skill body loaded mid-turn (isMeta), a compact summary (isCompactSummary) and a background task's notification (origin.kind
# task-notification; Claude Code gives it the human prompt's promptIndex). Anchoring on a notification AND then a skill body hid the
# turn's 3C and advisor() (3 false Write blocks, transcript 1096c8e6 lines 688-697, 2026-10-10; neither exclusion alone clears them).
# The exclusions are keep-going-guard.sh's (its fallback branch). Tests M1-M6.
# Nor are the plain-string entries the user's `!` runner (<bash-input>, <bash-stdout>/<bash-stderr>) and a built-in local command
# (<command-name>, <local-command-stdout>) write: none fires UserPromptSubmit, so the prompt stamp this guard keys its cache on never
# moves for them, yet they re-anchored the turn and hid its 3C (4 false blocks after `!` commit hand-offs, 2026-10-11). A skill the user
# types (<command-message>…) IS a prompt. Tests B1-B4 (2026-10-13).
# Not fixable here: 3C text in the SAME assistant message as this Edit is not on disk yet when PreToolUse fires (3 blocks, `own_tu`
# false, line count unchanged over 1 s, 2026-10-11/12) - the block message says to put it in an earlier message.
FILTER='
  . as $a
  | ([range(0; ($a|length)) | select($a[.].type=="user"
       and ($a[.].isMeta // false) != true and ($a[.].isCompactSummary // false) != true
       and ($a[.].origin.kind // "") != "task-notification"
       and (($a[.].message.content|type)!="string" or ($a[.].message.content|test("^\\s*<(bash-(input|stdout|stderr)|local-command-[a-z]+|command-name)>")|not))
       and (($a[.].message.content|type)=="string"
            or ([$a[.].message.content[]?|select(.type=="tool_result")]|length)==0))] | last) as $u0
  | (($u0 // -1) + 1) as $start
  | {
      certified: ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="tool_use" or .type=="server_tool_use") ]
                   | any( .name == "advisor"
                          or ( .name == "Agent"
                               and ( ((.input.subagent_type // "") + " " + (.input.description // "")
                                      + " " + (.input.prompt // ""))
                                     | test("review|certif|adversarial|lens|audit|critique"; "i") ) ) )),
      text:     ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="text") | .text ] | join("\n"))
    }'
RES=$(tail -n 800 "$TRANSCRIPT" 2>/dev/null | jq -Rc 'fromjson? // empty' 2>/dev/null | jq -s "$FILTER" 2>/dev/null || true)
[[ -z "$RES" ]] && exit 0

CERTIFIED=$(printf '%s' "$RES" | jq -r '.certified' 2>/dev/null || echo false)
TEXT=$(printf '%s' "$RES" | jq -r '.text' 2>/dev/null || echo "")

pass_turn() {
  mkdir -p "$(dirname "$CACHE")" 2>/dev/null || true
  printf '%s' "$TURN_TIME" > "$CACHE" 2>/dev/null || true
  exit 0
}

[[ "$CERTIFIED" == "true" ]] && pass_turn
# A 3C marker anywhere in the turn text satisfies the gate — including an explicit skip marker.
printf '%s' "$TEXT" | grep -q '3C' && pass_turn

if [[ "$ADV" == 1 ]]; then
  # Queue first, output second; the queue call's own output is discarded and its status ignored (no `set -e` here), so a queue
  # failure still prints the note and exits 0.
  python3 "$SCRIPT_DIR/../bin/lib/bypass_review.py" add --gate pw --tool "$(printf '%s' "$INPUT" | jq -r '.tool_name // "Edit"' 2>/dev/null)" \
    --would block --action told --rule 'no 3C evidence this turn' --detail "$PW_TARGET" --cwd "$PW_CWD" --sid "$SESSION_ID" >/dev/null 2>&1
  jq -nc --arg c "Phase 3C (advisory: the prework guard is bypassed here, so this edit was NOT blocked): this turn shows no 3C marker, no advisor() call and no reviewer spawn before editing. If the change is non-trivial, run the 3C check now (advisor(), or state the skip). Queued for the user's review." \
    '{hookSpecificOutput:{hookEventName:"PreToolUse",additionalContext:$c}}'
  log_obs INFO advisor-prework-guard "advisory: told + queued an Edit/Write with no Phase 3C evidence session=${SESSION_ID}" 2>/dev/null || true
  pass_turn
fi

{
  echo "⛔ EDIT/WRITE BEFORE PHASE 3C"
  echo "   CLAUDE.md Phase 3C (PRE-WORK INDEPENDENT CHECK) runs before implementation."
  echo "   This turn shows no 3C marker, no advisor() call, and no reviewer-panel spawn."
  echo "   Satisfy it by doing ONE of:"
  echo "     • emit the Rule 16 sequence declaration / phase marker (any text containing '3C')"
  echo "     • call advisor() to certify the plan"
  echo "     • declare the skip: '── Phase 3C — skipped (trivial single-line edit) ──'"
  echo "   Only VISIBLE text counts (not thinking), and only text already written: put it in a message BEFORE the one that"
  echo "   carries this Edit/Write - text in the same message is not on disk yet when this hook runs."
  echo "   Bypass — env: PREWORK_OFF=1   |   scoped: ask the USER to run /gates-bypass (a user-only skill; root-only or recursive, with"
  echo "            an optional except-list; it writes the rule for you — do not hand-touch sentinels)"
} >&2
log_obs WARN advisor-prework-guard "blocked Edit/Write with no Phase 3C evidence session=${SESSION_ID}" 2>/dev/null || true
exit 2
