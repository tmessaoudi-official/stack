#!/usr/bin/env bash
# SubagentStart hook: inject project-specific context brief into subagent initial system-reminder.
# Claude Code delivers stdout to the subagent as a system-reminder block.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
# Payload field is .agent_type (+.agent_id); .agent_name does NOT exist (verified via SubagentStart keys)
AGENT=$(printf '%s' "$INPUT" | jq -r '.agent_type // .agent_name // empty' 2>/dev/null || true)
CWD=$(  printf '%s' "$INPUT" | jq -r '.cwd          // empty' 2>/dev/null || true)
SID=$(  printf '%s' "$INPUT" | jq -r '.session_id   // empty' 2>/dev/null || true)
AID=$(  printf '%s' "$INPUT" | jq -r '.agent_id      // empty' 2>/dev/null || true)

log_obs INFO subagent-start-context "agent=${AGENT:-?} cwd=${CWD:-?}" 2>/dev/null || true

# ask-human gate: drop a per-agent_id bypass marker so this subagent's tool calls aren't blocked
# (it shares the parent session_id but can't clear the gate interactively). Removed by SubagentStop.
if [[ -n "$SID" && -n "$AID" ]]; then
  _GATE_DIR="${GATE_DIR_OVERRIDE:-$HOME/.claude/run/ask-human-gate}"
  mkdir -p "$_GATE_DIR/subagent/$SID" 2>/dev/null || true
  : > "$_GATE_DIR/subagent/$SID/$AID" 2>/dev/null || true
  log_obs INFO subagent-start-context "gate bypass marker set sid=$SID aid=$AID" 2>/dev/null || true
fi

# Project brief: the project's OWN .claude/subagent-brief.md, found from its repo root (docs/SPEC.md 2.20 — the global hook carries no
# project's text; the /path/to/your/project briefing that used to be hard-coded here matched every path under /path/to/your/project, including unrelated projects).
# `git rev-parse` failing means cwd is not in a git repository (measured: a plain directory) — the directory itself is then the project root.
_PROOT=""
if [[ -n "$CWD" && -d "$CWD" ]]; then
  _PROOT=$(git -C "$CWD" rev-parse --show-toplevel 2>/dev/null || true)
  [[ -n "$_PROOT" ]] || _PROOT="$CWD"
fi
if [[ -n "$_PROOT" && -r "$_PROOT/.claude/subagent-brief.md" ]]; then
  cat "$_PROOT/.claude/subagent-brief.md"
  log_obs INFO subagent-start-context "project brief injected root=$_PROOT" 2>/dev/null || true
fi

# Expertise inheritance (plan expertise-any-project step 7): the pack of the project the agent starts in. Convenience only: any failure injects nothing.
if [[ -n "$CWD" && -z "${EXPERTISE_GATE_OFF:-}" ]]; then
  _EXP=$(timeout 3 python3 -B "$SCRIPT_DIR/../bin/lib/expertise_gate.py" --inherit "$CWD" 2>/dev/null || true)
  if [[ -n "$_EXP" ]]; then printf '%s' "$_EXP"; log_obs INFO subagent-start-context "expertise pack injected cwd=$CWD" 2>/dev/null || true; fi
fi

# ── Mode (CLAUDE.md § Mode): the ask-human gate family decides it, per cwd tree ──────────
# Bypassed `ah` = autonomous, armed = spec. Same resolver call and subshell idiom as
# ask-human-gate-block.sh:36, so a subagent and its parent can never disagree on the mode.
# The subagent cannot see the statusline; this line is how it learns the mode. No cwd ⇒ spec
# (the safe default: nothing is waived). stderr is dropped because a SubagentStart hook's
# stderr is never shown to the model and the resolver already logs rule-file faults itself.
MODE="spec"
if [[ -n "$CWD" ]] && ( source "$SCRIPT_DIR/bypass-resolve.sh" \
     && BYPASS_SESSION_ID="$SID" bypass_applies ah "$CWD" ) 2>/dev/null; then
  MODE="autonomous"
fi
# Confident picks (family cf, row 26zg): an independent enable resolved like ah; it replaces the mid-task question policy of either mode.
CF=0
if [[ -n "$CWD" ]] && ( source "$SCRIPT_DIR/bypass-resolve.sh" \
     && BYPASS_SESSION_ID="$SID" bypass_applies cf "$CWD" ) 2>/dev/null; then
  CF=1
fi
log_obs INFO subagent-start-context "mode=$MODE cf=$CF cwd=${CWD:-?}" 2>/dev/null || true

if [[ "$MODE" == "autonomous" ]]; then
  echo 'MODE: autonomous (ask-human gate bypassed for this tree; auto-injected by SubagentStart hook):'
  if (( CF )); then
    echo '- On a question or ambiguity, follow the CONFIDENT PICKS rule below and report every pick to the parent as `ASSUMED (review): <choice> — because <basis>. Alternatives: <…>`'
  else
    echo '- Do not stop to ask. On a question or ambiguity, take the recommended option (project context, rules, quality) and report it to the parent as `ASSUMED (review): <choice> — because <reason>. Alternatives: <…>`'
  fi
  cat <<'BRIEF'
- Destructive or irreversible steps still stop: report them to the parent instead of running them
- Commits: leave committing to the parent unless its prompt tells you to commit (Rule 10, autonomous mode)
BRIEF
else
  cat <<'BRIEF'
MODE: spec (ask-human gate armed for this tree; auto-injected by SubagentStart hook):
- Task categorization + ask-human gate apply in all agents; you cannot ask the user, so state assumptions and defaults for the parent to confirm (ask-human Pattern 6)
- Commits: only when the user explicitly asks (Rule 10, spec mode)
BRIEF
fi
if (( CF )); then
  ( source "$SCRIPT_DIR/bypass-resolve.sh" && bypass_cf_text "$MODE" ) 2>/dev/null
  echo '- In a subagent, ASK means: stop that branch and report it to the parent (you cannot ask the user). Without advisor() a grey case is reported, never picked.'
fi

# Both modes — output parity: what SHOWS never depends on the mode, only what STOPS does
cat <<'BRIEF'
Global rules (both modes):
- Phase markers, evidence grades and named thinking frameworks are shown in both modes
- Phase 3C and 6C certification gates are mandatory before implementation and before declaring done
- Rule 6 Completion Gate: Coverage, Docs, Config, Blast-radius evidence required for every task
BRIEF
exit 0
