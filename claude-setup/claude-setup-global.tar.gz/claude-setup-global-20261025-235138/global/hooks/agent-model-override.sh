#!/usr/bin/env bash
# agent-model-override.sh - PreToolUse(Agent): enforce the user's model-override table (state/model-overrides.json, `agent-types` section) on EVERY Agent call
# (plan model-policy-bypass, user ruling 2026-10-01 "override everything"). Probed 2026-10-01: an updatedInput {model} rewrite sets the subagent's model and beats a
# frontmatter `model:` pin. Precedence: a SPECIFIC agent-types.<subagent_type> entry forces; else a call that already carries an explicit model is left alone (a spawner
# skill resolved it from the table); else agent-types."*" (else agents."*") is injected. `agents` keys are the spawner skills' LABELS and are never forced here:
# a label and a subagent_type are two namespaces (sonnet-audit B-F5, user ruling 2026-10-06 "split the keys"). as-is = the session model (alias via bin/session-model.sh). Only the aliases sonnet|opus|haiku are injected (the only form proven). FAIL OPEN: any problem
# (no jq, no/invalid/symlinked table, garbage input) prints nothing and exits 0, so the harness proceeds unchanged. Tests: hooks/tests/test-agent-model-override.sh.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1090
. "${MO_LOGH:-$HERE/log-helpers.sh}" 2>/dev/null || log_obs() { :; }
command -v jq >/dev/null 2>&1 || exit 0
TABLE="${MODEL_OVERRIDES_FILE:-$HOME/.claude/state/model-overrides.json}"
[[ -f "$TABLE" && ! -L "$TABLE" ]] || exit 0
in=$(cat 2>/dev/null) || exit 0
[[ "$(printf '%s' "$in" | jq -r '.tool_name // empty' 2>/dev/null)" == Agent ]] || exit 0
# the table must be valid in every respect model-override.sh checks (one bad field voids every override)
bash "$HERE/../bin/model-override.sh" lint >/dev/null 2>&1 || exit 0
# as-is = inherit the SESSION model: resolve its alias only when the table actually says as-is (session-model.sh reads the transcript, so not on every call)
sess=""
if jq -e '[(.["agent-types"] // {})[], (.agents // {})["*"]] | any(. == "as-is")' "$TABLE" >/dev/null 2>&1; then
  sid=$(printf '%s' "$in" | jq -r '.session_id // empty' 2>/dev/null)
  # Only with the LIVE model file (the statusline writes run/session-model-<sid> on every render): without it session-model.sh can only fall back to the saved default in
  # settings.json, which a headless run or a first tool call mistakes for the real model (measured live 2026-10-01), so as-is skips rather than guesses.
  live="${AMO_RUN_DIR:-$HOME/.claude/run}/session-model-$sid"
  if [[ "$sid" =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$ && -f "$live" && ! -L "$live" ]]; then
    sess=$(CLAUDE_CODE_SESSION_ID="$sid" bash "${AMO_SESSION_MODEL:-$HERE/../bin/session-model.sh}" 2>/dev/null | head -n1)
  fi
fi
out=$(printf '%s' "$in" | jq -c --arg sess "$sess" --slurpfile tbl "$TABLE" '
  (.tool_input // {}) as $ti
  | ($ti.subagent_type // "") as $t
  | ($tbl[0]["agent-types"] // {}) as $a
  | ($a["*"] // ($tbl[0].agents // {})["*"]) as $def
  | (if ($t|type) == "string" and ($t|test("^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$")) and ($a[$t] != null) then {v: $a[$t], forced: true}
     elif $ti.model != null then empty
     elif $def != null then {v: $def, forced: false}
     else empty end) as $r
  | (if $r.v == "as-is" then $sess else $r.v end) as $v
  | select($v | test("^(sonnet|opus|haiku)$"))
  | select($ti.model != $v)
  | {hookSpecificOutput: {hookEventName: "PreToolUse", permissionDecision: "allow", permissionDecisionReason: "agent-model-override: \($ti.subagent_type // "agent") -> \($v)", updatedInput: ($ti + {model: $v})}}' 2>/dev/null) || exit 0
[[ -n "$out" ]] || exit 0
log_obs INFO agent-model-override "$(printf '%s' "$out" | jq -r '.hookSpecificOutput.permissionDecisionReason' 2>/dev/null)" 2>/dev/null || true
printf '%s\n' "$out"
exit 0
