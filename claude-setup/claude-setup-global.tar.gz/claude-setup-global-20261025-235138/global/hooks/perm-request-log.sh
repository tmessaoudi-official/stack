#!/usr/bin/env bash
# PermissionRequest hook - LOGS every prompt the harness really raises (plan permission-unification, step 7). Prints nothing, decides nothing:
# no stdout means the normal prompt proceeds. Register as:  bash "$HOME/.claude/hooks/perm-request-log.sh"  (bin/perm-shadow-apply.sh does it).
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY=/usr/bin/python3; [[ -x $PY ]] || PY=python3
"$PY" "$D/perm_shadow.py" request 2>/dev/null
exit 0
