#!/usr/bin/env bash
# session-status.sh — shared library for session status display hooks
# Source this file. All display goes to stderr (zero tokens, Claude never sees it).
# Requires: jq, bash 4.3+

[[ -n "${_SS_LIB_LOADED:-}" ]] && return 0
readonly _SS_LIB_LOADED=1

# shellcheck disable=SC1090
source "$HOME/.claude/hooks/log-helpers.sh" 2>/dev/null || true

# ── Colors (only when stderr is a terminal and NO_COLOR is unset) ─────────────
if [[ -t 2 && -z "${NO_COLOR:-}" ]]; then
  _SS_GREEN='\033[0;32m'
  _SS_YELLOW='\033[1;33m'
  _SS_ORANGE='\033[0;33m'
  _SS_RED='\033[0;31m'
  _SS_DIM='\033[2m'
  _SS_RESET='\033[0m'
else
  _SS_GREEN='' _SS_YELLOW='' _SS_ORANGE='' _SS_RED='' _SS_DIM='' _SS_RESET=''
fi

# ── Repeat a character N times ────────────────────────────────────────────────
_ss_chars() {
  local char="$1" n="$2" result=''
  local i
  for (( i=0; i<n; i++ )); do result+="$char"; done
  printf '%s' "$result"
}

# ── Model → context window (tokens) ──────────────────────────────────────────
# The "[1m]" suffix heuristic below this comment used to be the whole function, and was
# structurally dead: session transcripts strip the "[1m]" tag from .message.model, so
# every model — including 1M-context Opus/Sonnet — matched the *opus*/*sonnet*/*haiku*
# fallthrough and always resolved 200000. It was masked only by run/actual-window.txt
# (see ss_window_from_state below). Replaced with an explicit table extracted from the
# CLI binary's embedded model-capabilities (that file is not readable at runtime — it is
# baked into the binary, not written to disk — hence a table, not a lookup). This table
# is only a COLD-START fallback: ss_window_from_state's per-session payload value always
# wins when present, so table drift on a future model self-corrects after the first
# statusline render of that session. Family match, not exact match, so new point
# releases inherit the right default without a table update.
# Known limitation: a session transcript also strips "[1m]" from the recorded model, so
# a transcript-recorded "claude-sonnet-5" cannot by itself distinguish the 1M variant
# from a 200K one where both exist for the same base name — this table is a heuristic,
# not ground truth, which is exactly why the payload-derived value ranks above it.
ss_window_for_model() {
  local model="${1:-}"
  case "$model" in
    *opus-4-6*|*opus-4-7*|*opus-4-8*|*opus-5*)     printf '1000000' ;;
    *sonnet-4-6*|*sonnet-5*)                       printf '1000000' ;;
    *fable-5*|*mythos-5*)                          printf '1000000' ;;
    *opus-4-1*|*opus-4-5*)                         printf '200000'  ;;
    *sonnet-4-0*|*sonnet-4-5*)                     printf '200000'  ;;
    *haiku-5*)                                     printf '1000000' ;;   # Haiku 5.5: 1M (models overview, 2026-10-08)
    *haiku*)                                       printf '200000'  ;;
    *)                                              printf '200000'  ;;
  esac
}

# ── Urgency tier — proportional with an absolute floor ────────────────────────────────────
# Single source of truth for all three urgency call sites (stop-context-bar._URGENCY,
# statusline.sh's live F6 recompute, and the notify-send cutoffs) — previously each carried
# its own hardcoded absolute 10K/30K(/60K) cutoffs. On a 1M window those left only ~3% of
# runway before the critical alert (930K/960K effective) and were functionally unreachable
# under normal autocompact behavior (2026-08-30 investigation: ctx crossed 930K exactly
# twice in 5+ weeks of logs). Proportional-with-floor scales the runway with window size
# while leaving 200K behavior byte-for-byte unchanged, because the floor dominates there
# (5% of 167K=8K<10K, 12%=20K<30K, 20%=33K<60K — all below the old absolute cutoffs).
ss_urgency() {
  local free_k="${1:-0}" eff_k="${2:-0}"
  local crit=$(( eff_k * 5  / 100 )); (( crit   < 10 )) && crit=10
  local warn=$(( eff_k * 12 / 100 )); (( warn   < 30 )) && warn=30
  local yellow=$(( eff_k * 20 / 100 )); (( yellow < 60 )) && yellow=60
  if   (( free_k < crit ));   then printf '🔴'
  elif (( free_k < warn ));   then printf '⚠'
  elif (( free_k < yellow )); then printf '🟡'
  else printf ''
  fi
}

# ── Authoritative window: prefer the per-session size persisted by statusline ─────────
# statusline.sh is the only hook whose payload carries context_window_size; it writes
# that to run/actual-window-<session_id>.txt. Stop/SessionStart read it here so they
# compute against the real window (1M vs 200K) instead of the model-string heuristic.
# (P0-1, corrected 2026-08-30 — see below)
#
# The per-session file is preferred over any global file BY DESIGN: a global
# run/actual-window.txt (the original P0-1 fix) meant one session's window silently set
# the basis for every other concurrent session — a Haiku (200K) session reading a
# 1M-session's global file could never warn even when genuinely full, and conversely a
# 200K main session could downgrade a concurrent 1M session to false "context almost
# full" alarms. A subagent never renders its own statusline and so never gets a
# per-session file of its own — under a chain that fell back to the global file, that
# gap alone would keep the cross-contamination bug alive. So the global file is no
# longer consulted as a general fallback: when no per-session value exists, resolution
# goes straight to the model table (ss_window_for_model), which is per-invocation and
# cannot leak across sessions.
ss_window_from_state() {
  local model="${1:-}" session_id="${2:-}" win_file="" w=""
  if [[ -n "$session_id" ]]; then
    win_file="${HOME}/.claude/run/actual-window-${session_id}.txt"
    [[ -r "$win_file" ]] && w=$(tr -d '[:space:]' < "$win_file" 2>/dev/null || true)
  fi
  if [[ "$w" =~ ^[0-9]+$ && "$w" -gt 0 ]]; then
    printf '%s' "$w"
  else
    ss_window_for_model "$model"
  fi
}

# ── Buffer = 16.5% of window, capped at 40K ───────────────────────────────────
# The reserve protects against fixed overhead (max output tokens per turn + the
# autocompact trigger margin), which does NOT scale with window size. A flat 16.5%
# over-reserves on large windows (1M → 165K, ~5× the real need). Cap at 40K so the
# curve stays linear up to a ~242K knee (every standard window ≤200K is unchanged:
# 200K → 33K) and bounds the tail above it (1M → 40K). Single source of truth — the
# banner and stop hook both call this; do not re-inline the formula elsewhere.
ss_buffer_size() {
  local window="$1"
  local buf=$(( window * 165 / 1000 ))
  (( buf > 40000 )) && buf=40000
  printf '%d' "$buf"
}

# ── Parse transcript JSONL ────────────────────────────────────────────────────
# Usage: ss_parse_transcript <path>
# Exports: SS_INPUT_TOKENS, SS_OUTPUT_SUM, SS_MODEL, SS_TURNS (integers / string)
ss_parse_transcript() {
  local path="$1"
  SS_INPUT_TOKENS=0
  SS_OUTPUT_SUM=0
  SS_MODEL=""
  SS_TURNS=0

  [[ -f "$path" ]] || return 1
  command -v jq &>/dev/null || return 1

  local result
  result=$(jq -Rs '
    split("\n") |
    map(select(length > 0) | try fromjson catch null) |
    map(select(. != null)) |
    {
      input:  ([.[] | select(.type? == "assistant") | ((.message?.usage?.input_tokens? // 0) + (.message?.usage?.cache_read_input_tokens? // 0) + (.message?.usage?.cache_creation_input_tokens? // 0))] | last // 0),
      output: ([.[] | select(.type? == "assistant") | (.message?.usage?.output_tokens? // 0)] | add // 0),
      model:  ([.[] | select(.type? == "assistant") | .message?.model?] | map(select(. != null)) | last // ""),
      turns:  ([.[] | select(.type? == "assistant")] | length)
    }
  ' < "$path" 2>/dev/null) || return 1

  # SC2034: vars set here are consumed by sourcing scripts (stop-context-bar, subagent-stop-status)
  # shellcheck disable=SC2034
  SS_INPUT_TOKENS=$(printf '%s' "$result" | jq -r '.input  // 0' 2>/dev/null || echo 0)
  # shellcheck disable=SC2034
  SS_OUTPUT_SUM=$(printf '%s'   "$result" | jq -r '.output // 0' 2>/dev/null || echo 0)
  # shellcheck disable=SC2034
  SS_MODEL=$(printf '%s'        "$result" | jq -r '.model  // ""' 2>/dev/null || echo '')
  # shellcheck disable=SC2034
  SS_TURNS=$(printf '%s'        "$result" | jq -r '.turns  // 0'  2>/dev/null || echo 0)
}

# ── Context bar ───────────────────────────────────────────────────────────────
# Usage: ss_context_bar <input_tokens> <window> <buffer> <output_sum>
# Prints the bar line to stdout; caller redirects to stderr.
ss_context_bar() {
  local input="$1" window="$2" buffer="$3" output_sum="$4"
  local effective=$(( window - buffer ))
  [[ $effective -le 0 ]] && effective=1
  local free=$(( effective - input ))
  [[ $free -lt 0 ]] && free=0
  local pct=$(( input * 100 / effective ))
  [[ $pct -gt 100 ]] && pct=100

  # Display in K (round down)
  local input_k=$(( input / 1000 ))
  local eff_k=$(( effective / 1000 ))
  local free_k=$(( free / 1000 ))
  local buf_k=$(( buffer / 1000 ))
  local sum_k=$(( output_sum / 1000 ))

  # Bar: 24 chars total = buffer zone (▒) + usable zone (█ used + ░ free)
  local bar_total=24
  local buf_chars=$(( window > 0 ? buffer * bar_total / window : 0 ))
  [[ $buf_chars -lt 1 ]] && buf_chars=1
  [[ $buf_chars -gt 6 ]] && buf_chars=6
  local usable_chars=$(( bar_total - buf_chars ))
  local used_chars=$(( effective > 0 ? input * usable_chars / effective : 0 ))
  [[ $used_chars -gt $usable_chars ]] && used_chars=$usable_chars
  local free_chars=$(( usable_chars - used_chars ))

  local used_bar free_bar buf_bar
  used_bar=$(_ss_chars '█' "$used_chars")
  free_bar=$(_ss_chars '░' "$free_chars")
  buf_bar=$(_ss_chars  '▒' "$buf_chars")

  # Color based on free space (absolute K)
  local color urgency=''
  if   (( free > 60000 )); then color="$_SS_GREEN"
  elif (( free > 30000 )); then color="$_SS_YELLOW"
  elif (( free > 10000 )); then color="$_SS_ORANGE"; urgency='  ⚠ consider /handoff'
  else                          color="$_SS_RED";    urgency='  🔴 run /handoff NOW'
  fi

  printf '── ctx %d%% [%b%s%b%b%s%b%b%s%b] %dK/%dK  free %dK  ▒%dK buf  · session ∑ %dK%s ──\n' \
    "$pct" \
    "$color"    "$used_bar" "$_SS_RESET" \
    "$_SS_DIM"  "$free_bar" "$_SS_RESET" \
    "$_SS_DIM"  "$buf_bar"  "$_SS_RESET" \
    "$input_k" "$eff_k" "$free_k" "$buf_k" "$sum_k" \
    "$urgency"
}

# ── Age formatter: seconds → "2h 3m ago" / "5 days ago" ──────────────────────
ss_age() {
  local secs="$1"
  if   (( secs < 3600  )); then printf '%dm ago'    $(( secs / 60 ))
  elif (( secs < 86400  )); then printf '%dh ago'    $(( secs / 3600 ))
  elif (( secs < 604800 )); then printf '%d days ago' $(( secs / 86400 ))
  else                          printf '%d wks ago'   $(( secs / 604800 ))
  fi
}
