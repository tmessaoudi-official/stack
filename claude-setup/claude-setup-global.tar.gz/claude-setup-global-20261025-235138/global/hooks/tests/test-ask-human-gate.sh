#!/usr/bin/env bash
# Tests for ask-human-gate triplet: reset / track / block
# Requires GATE_DIR_OVERRIDE support in each gate script (patched via this TDD cycle).
set -uo pipefail

HOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESET_SH="$HOOKS_DIR/ask-human-gate-arm.sh"
TRACK_SH="$HOOKS_DIR/ask-human-gate-track.sh"
BLOCK_SH="$HOOKS_DIR/ask-human-gate-block.sh"

C_GREEN='\033[0;32m'; C_RED='\033[0;31m'; C_YELLOW='\033[1;33m'; C_RESET='\033[0m'
PASS=0; FAIL=0
declare -a FAILURES=()

pass()          { PASS=$((PASS+1)); printf "${C_GREEN}✓${C_RESET} %s\n" "$1"; }
fail()          { FAIL=$((FAIL+1)); FAILURES+=("$1: $2"); printf "${C_RED}✗${C_RESET} %s\n  ${C_YELLOW}→ %s${C_RESET}\n" "$1" "$2"; }
assert_equals() { [[ "$2" == "$3" ]] && pass "$1" || fail "$1" "expected='$2' got='$3'"; }
assert_contains() { printf '%s' "$3" | grep -qF "$2" && pass "$1" || fail "$1" "expected to contain '$2'"; }
assert_not_contain() { printf '%s' "$3" | grep -qF "$2" && fail "$1" "should NOT contain '$2'" || pass "$1"; }

mk_home() { local h; h=$(mktemp -d); mkdir -p "$h/.claude/state" "$h/.claude/logs"; echo "$h"; }

# ── ask-human-gate-arm.sh ────────────────────────────────────────────────────
printf '\n=== ask-human-gate-arm.sh ===\n'

# T1: basic — turn token written into the override gate dir (not real /tmp/ask-human-gate)
T1_G=$(mktemp -d); T1_H=$(mk_home)
printf '{"session_id":"t1"}' | HOME="$T1_H" GATE_DIR_OVERRIDE="$T1_G" bash "$RESET_SH"
assert_equals "T1: turn token written to override dir" "t1" "$(ls "$T1_G/turns/" 2>/dev/null)"
rm -rf "$T1_G" "$T1_H"

# T2: bypass file present — skip write
T2_G=$(mktemp -d); T2_H=$(mk_home)
touch "$T2_H/.claude/state/ask-human-gate-bypass"
printf '{"session_id":"t2"}' | HOME="$T2_H" GATE_DIR_OVERRIDE="$T2_G" bash "$RESET_SH"
assert_equals "T2: bypass skips write" "" "$(ls "$T2_G/turns/" 2>/dev/null)"
rm -rf "$T2_G" "$T2_H"

# T3: empty stdin — no write, exit 0
T3_G=$(mktemp -d); T3_H=$(mk_home)
printf '' | HOME="$T3_H" GATE_DIR_OVERRIDE="$T3_G" bash "$RESET_SH"
assert_equals "T3: empty input no write" "" "$(ls "$T3_G/turns/" 2>/dev/null)"
rm -rf "$T3_G" "$T3_H"

# T4: JSON with no session_id field — no write
T4_G=$(mktemp -d); T4_H=$(mk_home)
printf '{"other":"value"}' | HOME="$T4_H" GATE_DIR_OVERRIDE="$T4_G" bash "$RESET_SH"
assert_equals "T4: no session_id no write" "" "$(ls "$T4_G/turns/" 2>/dev/null)"
rm -rf "$T4_G" "$T4_H"

# ── ask-human-gate-track.sh ───────────────────────────────────────────────────
printf '\n=== ask-human-gate-track.sh ===\n'

# T5: basic — sentinel written into override dir
T5_G=$(mktemp -d); T5_H=$(mk_home)
printf '{"session_id":"t5"}' | HOME="$T5_H" GATE_DIR_OVERRIDE="$T5_G" bash "$TRACK_SH"
assert_equals "T5: sentinel written to override dir" "t5" "$(ls "$T5_G/" 2>/dev/null)"
rm -rf "$T5_G" "$T5_H"

# T6: empty stdin — no sentinel written
T6_G=$(mktemp -d); T6_H=$(mk_home)
printf '' | HOME="$T6_H" GATE_DIR_OVERRIDE="$T6_G" bash "$TRACK_SH"
assert_equals "T6: empty input no sentinel" "" "$(ls "$T6_G/" 2>/dev/null)"
rm -rf "$T6_G" "$T6_H"

# T7: JSON with no session_id — no sentinel written
T7_G=$(mktemp -d); T7_H=$(mk_home)
printf '{"other":"value"}' | HOME="$T7_H" GATE_DIR_OVERRIDE="$T7_G" bash "$TRACK_SH"
assert_equals "T7: no session_id no sentinel" "" "$(ls "$T7_G/" 2>/dev/null)"
rm -rf "$T7_G" "$T7_H"

# ── ask-human-gate-block.sh ───────────────────────────────────────────────────
# Timestamps are hardcoded integers to avoid same-second collisions with real date +%s.
printf '\n=== ask-human-gate-block.sh ===\n'

# T8: neither a turn token nor a prompt stamp = arm never ran (a headless run, a tool runner) → exit 0, as before
T8_G=$(mktemp -d); T8_H=$(mk_home)
printf '{"session_id":"t8"}' | HOME="$T8_H" GATE_DIR_OVERRIDE="$T8_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T8: no turn token, no prompt stamp → exit 0 (headless)" "0" "$?"
rm -rf "$T8_G" "$T8_H"
# T8b: prompt stamp but NO turn token = the token was deleted → FAIL CLOSED (user rulings 2026-10-11): blocked, a turn is started,
# one AskUserQuestion clears it
T8_G=$(mktemp -d); T8_H=$(mk_home); mkdir -p "$T8_G/prompts"; printf '%s' "$(date +%s)" > "$T8_G/prompts/t8b"
printf '{"session_id":"t8b"}' | HOME="$T8_H" GATE_DIR_OVERRIDE="$T8_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T8b: stamp but no turn token → blocked (2, fail closed)" "2" "$?"
assert_equals "T8b: ... and a turn token was started" "1" "$([[ -f "$T8_G/turns/t8b" ]] && echo 1 || echo 0)"
sleep 1; printf '{"session_id":"t8b"}' | HOME="$T8_H" GATE_DIR_OVERRIDE="$T8_G" bash "$TRACK_SH" 2>/dev/null
printf '{"session_id":"t8b"}' | HOME="$T8_H" GATE_DIR_OVERRIDE="$T8_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T8b: ... which one AskUserQuestion clears (0)" "0" "$?"
rm -rf "$T8_G" "$T8_H"
# T8c: the token cannot be written (the gate dir is a regular FILE) → still blocked (2), never a crash (exit 1 = fail open)
T8_G=$(mktemp -d); T8_H=$(mk_home); mkdir -p "$T8_G/prompts"; printf '1' > "$T8_G/prompts/t8c"; : > "$T8_G/turns"
printf '{"session_id":"t8c"}' | HOME="$T8_H" GATE_DIR_OVERRIDE="$T8_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T8c: unwritable turn token → still blocked (2)" "2" "$?"
rm -rf "$T8_G" "$T8_H"

# T9: sentinel time = turn time (boundary: -ge) → exit 0 (gate cleared)
T9_G=$(mktemp -d); T9_H=$(mk_home)
mkdir -p "$T9_G/turns"
printf '100' > "$T9_G/turns/t9"
printf '100' > "$T9_G/t9"
printf '{"session_id":"t9"}' | HOME="$T9_H" GATE_DIR_OVERRIDE="$T9_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T9: sentinel=turn → exit 0 (cleared, boundary)" "0" "$?"
rm -rf "$T9_G" "$T9_H"

# T10: sentinel time < turn time → exit 2 (stale gate)
T10_G=$(mktemp -d); T10_H=$(mk_home)
mkdir -p "$T10_G/turns"
printf '100' > "$T10_G/turns/t10"
printf '50'  > "$T10_G/t10"
printf '{"session_id":"t10"}' | HOME="$T10_H" GATE_DIR_OVERRIDE="$T10_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T10: sentinel<turn → exit 2 (stale)" "2" "$?"
rm -rf "$T10_G" "$T10_H"

# T11: turn token exists, no sentinel → exit 2 (gate never cleared this turn)
T11_G=$(mktemp -d); T11_H=$(mk_home)
mkdir -p "$T11_G/turns"
printf '100' > "$T11_G/turns/t11"
printf '{"session_id":"t11"}' | HOME="$T11_H" GATE_DIR_OVERRIDE="$T11_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T11: no sentinel → exit 2 (never cleared)" "2" "$?"
rm -rf "$T11_G" "$T11_H"

# T12: bypass file → exit 0 even with stale gate
T12_G=$(mktemp -d); T12_H=$(mk_home)
touch "$T12_H/.claude/state/ask-human-gate-bypass"
mkdir -p "$T12_G/turns"
printf '100' > "$T12_G/turns/t12"
printf '{"session_id":"t12"}' | HOME="$T12_H" GATE_DIR_OVERRIDE="$T12_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T12: bypass → exit 0 despite stale gate" "0" "$?"
rm -rf "$T12_G" "$T12_H"

# T13: empty stdin → exit 0
T13_G=$(mktemp -d); T13_H=$(mk_home)
printf '' | HOME="$T13_H" GATE_DIR_OVERRIDE="$T13_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T13: empty input → exit 0" "0" "$?"
rm -rf "$T13_G" "$T13_H"

# T14: JSON with no session_id → exit 0
T14_G=$(mktemp -d); T14_H=$(mk_home)
printf '{"other":"val"}' | HOME="$T14_H" GATE_DIR_OVERRIDE="$T14_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T14: no session_id → exit 0" "0" "$?"
rm -rf "$T14_G" "$T14_H"

# ── per-project bypass (sentinel: $HOME/.claude/projects/<slug>/state/ask-human-gate-bypass) ──
printf '\n=== per-project bypass ===\n'

# T15 (arm): per-project sentinel present → skip turn token write
T15_G=$(mktemp -d); T15_H=$(mk_home)
mkdir -p "$T15_H/.claude/projects/-stack-projects-phorge/state"
touch "$T15_H/.claude/projects/-stack-projects-phorge/state/ask-human-gate-bypass"
printf '{"session_id":"t15","cwd":"/stack/projects/phorge"}' | HOME="$T15_H" GATE_DIR_OVERRIDE="$T15_G" bash "$RESET_SH"
assert_equals "T15: per-project bypass skips turn token" "" "$(ls "$T15_G/turns/" 2>/dev/null)"
rm -rf "$T15_G" "$T15_H"

# T16 (block): per-project sentinel + stale gate → exit 0
T16_G=$(mktemp -d); T16_H=$(mk_home)
mkdir -p "$T16_H/.claude/projects/-stack-projects-phorge/state" "$T16_G/turns"
touch "$T16_H/.claude/projects/-stack-projects-phorge/state/ask-human-gate-bypass"
printf '100' > "$T16_G/turns/t16"
printf '50'  > "$T16_G/t16"
printf '{"session_id":"t16","cwd":"/stack/projects/phorge"}' | HOME="$T16_H" GATE_DIR_OVERRIDE="$T16_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T16: per-project bypass → exit 0 despite stale gate" "0" "$?"
rm -rf "$T16_G" "$T16_H"

# T17 (block): sentinel for a DIFFERENT project → gate still enforces (exit 2)
T17_G=$(mktemp -d); T17_H=$(mk_home)
mkdir -p "$T17_H/.claude/projects/-stack-projects-other/state" "$T17_G/turns"
touch "$T17_H/.claude/projects/-stack-projects-other/state/ask-human-gate-bypass"
printf '100' > "$T17_G/turns/t17"   # turn token, no sentinel → would be exit 2
printf '{"session_id":"t17","cwd":"/stack/projects/phorge"}' | HOME="$T17_H" GATE_DIR_OVERRIDE="$T17_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T17: bypass for other project → still enforces (exit 2)" "2" "$?"
rm -rf "$T17_G" "$T17_H"

# ── subagent-driven bypass (markers: $GATE_DIR/subagent/<sid>/<agent_id>) ──
printf '\n=== subagent-driven bypass ===\n'

# T18 (block): fresh subagent marker + stale gate → exit 0 (subagent active)
T18_G=$(mktemp -d); T18_H=$(mk_home)
mkdir -p "$T18_G/turns" "$T18_G/subagent/t18"
printf '100' > "$T18_G/turns/t18"; printf '50' > "$T18_G/t18"   # stale gate
: > "$T18_G/subagent/t18/agentA"                                 # fresh marker
printf '{"session_id":"t18","cwd":"/x"}' | HOME="$T18_H" GATE_DIR_OVERRIDE="$T18_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T18: fresh subagent marker → exit 0 despite stale gate" "0" "$?"
rm -rf "$T18_G" "$T18_H"

# T19 (block): STALE subagent marker (>120min) → gate still enforces (exit 2)
T19_G=$(mktemp -d); T19_H=$(mk_home)
mkdir -p "$T19_G/turns" "$T19_G/subagent/t19"
printf '100' > "$T19_G/turns/t19"; printf '50' > "$T19_G/t19"
: > "$T19_G/subagent/t19/agentStale"; touch -d '3 hours ago' "$T19_G/subagent/t19/agentStale"
printf '{"session_id":"t19","cwd":"/x"}' | HOME="$T19_H" GATE_DIR_OVERRIDE="$T19_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T19: stale marker (>120min) → still enforces (exit 2)" "2" "$?"
rm -rf "$T19_G" "$T19_H"

# T20 (block): two parallel markers, one removed, other still fresh → exit 0
T20_G=$(mktemp -d); T20_H=$(mk_home)
mkdir -p "$T20_G/turns" "$T20_G/subagent/t20"
printf '100' > "$T20_G/turns/t20"; printf '50' > "$T20_G/t20"
: > "$T20_G/subagent/t20/agentB"   # agentA already stopped/removed; agentB still active
printf '{"session_id":"t20","cwd":"/x"}' | HOME="$T20_H" GATE_DIR_OVERRIDE="$T20_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T20: one of two parallel markers still active → exit 0" "0" "$?"
rm -rf "$T20_G" "$T20_H"

# T21 (start): SubagentStart creates a marker keyed by session_id/agent_id
T21_G=$(mktemp -d); T21_H=$(mk_home)
printf '{"session_id":"t21","agent_id":"aid21","agent_type":"Explore","cwd":"/x"}' \
  | HOME="$T21_H" GATE_DIR_OVERRIDE="$T21_G" bash "$HOOKS_DIR/subagent-start-context.sh" >/dev/null 2>&1
assert_equals "T21: SubagentStart creates marker" "1" "$([[ -f "$T21_G/subagent/t21/aid21" ]] && echo 1 || echo 0)"
rm -rf "$T21_G" "$T21_H"

# T22 (stop): SubagentStop removes the marker even when transcript is missing
T22_G=$(mktemp -d); T22_H=$(mk_home)
mkdir -p "$T22_G/subagent/t22"; : > "$T22_G/subagent/t22/aid22"
printf '{"session_id":"t22","agent_id":"aid22","agent_type":"Explore","cwd":"/x"}' \
  | HOME="$T22_H" GATE_DIR_OVERRIDE="$T22_G" bash "$HOOKS_DIR/subagent-stop-status.sh" >/dev/null 2>&1
assert_equals "T22: SubagentStop removes marker (no transcript)" "0" "$([[ -f "$T22_G/subagent/t22/aid22" ]] && echo 1 || echo 0)"
rm -rf "$T22_G" "$T22_H"

# ── per-session bypass (sentinel: $HOME/.claude/run/ask-human-gate-bypass-<sid>) ──
# Added 2026-08-30 for the /gates-bypass uniform sentinel model.
printf '\n=== per-session bypass ===\n'

# T23 (arm): per-session sentinel present → skip turn token write
T23_G=$(mktemp -d); T23_H=$(mk_home)
mkdir -p "$T23_H/.claude/run"
touch "$T23_H/.claude/run/ask-human-gate-bypass-t23"
printf '{"session_id":"t23","cwd":"/x"}' | HOME="$T23_H" GATE_DIR_OVERRIDE="$T23_G" bash "$RESET_SH"
assert_equals "T23: per-session bypass skips turn token" "" "$(ls "$T23_G/turns/" 2>/dev/null)"
rm -rf "$T23_G" "$T23_H"

# T24 (block): per-session sentinel + stale gate → exit 0
T24_G=$(mktemp -d); T24_H=$(mk_home)
mkdir -p "$T24_H/.claude/run" "$T24_G/turns"
touch "$T24_H/.claude/run/ask-human-gate-bypass-t24"
printf '100' > "$T24_G/turns/t24"
printf '50'  > "$T24_G/t24"
printf '{"session_id":"t24","cwd":"/x"}' | HOME="$T24_H" GATE_DIR_OVERRIDE="$T24_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T24: per-session bypass → exit 0 despite stale gate" "0" "$?"
rm -rf "$T24_G" "$T24_H"

# T25 (block): sentinel for a DIFFERENT session id → gate still enforces (exit 2)
T25_G=$(mktemp -d); T25_H=$(mk_home)
mkdir -p "$T25_H/.claude/run" "$T25_G/turns"
touch "$T25_H/.claude/run/ask-human-gate-bypass-other-session"
printf '100' > "$T25_G/turns/t25"   # turn token, no sentinel for t25 → would be exit 2
printf '{"session_id":"t25","cwd":"/x"}' | HOME="$T25_H" GATE_DIR_OVERRIDE="$T25_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T25: bypass for other session → still enforces (exit 2)" "2" "$?"
rm -rf "$T25_G" "$T25_H"

# ── prompt stamp (framework-health step 7): written in EVERY mode, so advisory guards can key "once per turn" while ah is bypassed ──
# T26 (arm): ah bypassed -> prompts/<sid> stamp written, still NO turn token (block.sh contract unchanged)
T26_G=$(mktemp -d); T26_H=$(mk_home)
touch "$T26_H/.claude/state/ask-human-gate-bypass"
printf '{"session_id":"t26"}' | HOME="$T26_H" GATE_DIR_OVERRIDE="$T26_G" bash "$RESET_SH"
assert_equals "T26: ah bypassed -> prompt stamp written" "t26" "$(ls "$T26_G/prompts/" 2>/dev/null)"
assert_equals "T26: ah bypassed -> still no turn token" "" "$(ls "$T26_G/turns/" 2>/dev/null)"
rm -rf "$T26_G" "$T26_H"
# T27 (arm): armed -> both the stamp and the turn token
T27_G=$(mktemp -d); T27_H=$(mk_home)
printf '{"session_id":"t27"}' | HOME="$T27_H" GATE_DIR_OVERRIDE="$T27_G" bash "$RESET_SH"
assert_equals "T27: armed -> prompt stamp written" "t27" "$(ls "$T27_G/prompts/" 2>/dev/null)"
assert_equals "T27: armed -> turn token written" "t27" "$(ls "$T27_G/turns/" 2>/dev/null)"
rm -rf "$T27_G" "$T27_H"
# T28 (arm): the stamp cannot be written (prompts is a FILE) -> set -e must not kill the hook before the turn token (that would open the armed gate)
T28_G=$(mktemp -d); T28_H=$(mk_home)
printf 'x' > "$T28_G/prompts"
printf '{"session_id":"t28"}' | HOME="$T28_H" GATE_DIR_OVERRIDE="$T28_G" bash "$RESET_SH" 2>/dev/null
assert_equals "T28: stamp write fails -> exit 0" "0" "$?"
assert_equals "T28: stamp write fails -> turn token still written" "t28" "$(ls "$T28_G/turns/" 2>/dev/null)"
rm -rf "$T28_G" "$T28_H"

# T29-T32: stamp and sentinel contents are data, never arithmetic (milestone panel B-P1-3 class, 2026-10-09): [[ a -ge b ]]
# evaluated NAME[$(cmd)] (cmd ran in the hook; the crash exited 1 = no block); a far-future sentinel was a standing clearance.
TX_G=$(mktemp -d); TX_H=$(mk_home); mkdir -p "$TX_G/turns"
printf 'SESSION_ID[$(touch %s/EXEC.t)]' "$TX_G" > "$TX_G/turns/t29"; printf '100' > "$TX_G/t29"
printf '{"session_id":"t29"}' | HOME="$TX_H" GATE_DIR_OVERRIDE="$TX_G" bash "$BLOCK_SH" 2>/dev/null; rc=$?
assert_equals "T29: a turn token holding a command substitution is not run, gate blocks (2)" "2 absent" "$rc $([[ -e $TX_G/EXEC.t ]] && echo ran || echo absent)"
printf '100' > "$TX_G/turns/t30"; printf 'SESSION_ID[$(touch %s/EXEC.s)]' "$TX_G" > "$TX_G/t30"
printf '{"session_id":"t30"}' | HOME="$TX_H" GATE_DIR_OVERRIDE="$TX_G" bash "$BLOCK_SH" 2>/dev/null; rc=$?
assert_equals "T30: a sentinel holding a command substitution is not run, gate blocks (2)" "2 absent" "$rc $([[ -e $TX_G/EXEC.s ]] && echo ran || echo absent)"
printf '100' > "$TX_G/turns/t31"; printf '%s' "$(( $(date +%s) + 86400 ))" > "$TX_G/t31"
printf '{"session_id":"t31"}' | HOME="$TX_H" GATE_DIR_OVERRIDE="$TX_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T31: a sentinel a day in the future is no standing clearance (2)" "2" "$?"
printf '100' > "$TX_G/turns/t32"; printf '%s' "$(date +%s)" > "$TX_G/t32"
printf '{"session_id":"t32"}' | HOME="$TX_H" GATE_DIR_OVERRIDE="$TX_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T32: a sentinel stamped now, after the turn, clears (0)" "0" "$?"
printf '100' > "$TX_G/turns/t33"; printf '18446744073709551716' > "$TX_G/t33"   # wraps to 100 in bash arithmetic
printf '{"session_id":"t33"}' | HOME="$TX_H" GATE_DIR_OVERRIDE="$TX_G" bash "$BLOCK_SH" 2>/dev/null
assert_equals "T33: a 20-digit sentinel (wraps to the turn epoch) is not a timestamp (2)" "2" "$?"
# T34 (milestone panel 2026-10-13 A-P2-3, row 26b): a sentinel that exists but cannot be read made `cat` fail inside the assignment;
# under set -e the hook exited 1 = no block. The same `|| true` covers a delete between the -f test and the cat, but that race is NOT
# exercised here (re-round C2-P3-8): only the unreadable file is. Precondition: the cat really fails (not root).
printf '100' > "$TX_G/turns/t34"; printf '%s' "$(date +%s)" > "$TX_G/t34"; chmod 000 "$TX_G/t34"
if cat "$TX_G/t34" >/dev/null 2>&1; then echo "SKIP T34: the sentinel is still readable (running as root?)"; else
  out=$(printf '{"session_id":"t34"}' | HOME="$TX_H" GATE_DIR_OVERRIDE="$TX_G" bash "$BLOCK_SH" 2>&1 >/dev/null); rc=$?
  assert_equals "T34: an unreadable sentinel is not cleared, gate blocks (2)" "2" "$rc"
fi
chmod 600 "$TX_G/t34"
rm -rf "$TX_G" "$TX_H"

# ── notifications are not user turns (2026-10-10) ─────────────────────────────
# A background task's completion notification fires UserPromptSubmit too; its prompt is nothing but <task-notification> blocks
# (125 of 125 in 40 real transcripts). Re-arming on it blocked the next tool call with "a new user message arrived" when none had.
# Stamps are SEEDED old (turn now-200, sentinel now-100, prompt stamp now-200): a re-arm in the same second as a fresh token would
# leave the value unchanged and let an "unchanged" assertion pass without the fix.
printf '\n=== notifications ===\n'
NT_G=$(mktemp -d); NT_H=$(mk_home)
NOTE='<task-notification>\n<task-id>b1</task-id>\n<status>completed</status>\n</task-notification>'
seed() { mkdir -p "$NT_G/turns" "$NT_G/prompts"; printf '%s' "$(( $(date +%s) - 200 ))" > "$NT_G/turns/$1"; printf '%s' "$(( $(date +%s) - 100 ))" > "$NT_G/$1"; printf '%s' "$(( $(date +%s) - 200 ))" > "$NT_G/prompts/$1"; }
arm() { printf '%s' "$2" | HOME="$NT_H" GATE_DIR_OVERRIDE="$NT_G" bash "$RESET_SH" >"$NT_G/stdout.$1" 2>/dev/null; }
blk() { printf '{"session_id":"%s","tool_name":"Read","tool_input":{"file_path":"/x"}}' "$1" | HOME="$NT_H" GATE_DIR_OVERRIDE="$NT_G" bash "$BLOCK_SH" 2>/dev/null; echo $?; }
seed n1; t0=$(cat "$NT_G/turns/n1"); p0=$(cat "$NT_G/prompts/n1")
arm n1 "{\"session_id\":\"n1\",\"hook_event_name\":\"UserPromptSubmit\",\"prompt\":\"$NOTE\"}"
assert_equals "N1: a notification does not re-arm the gate - the next tool call passes (0)" "0" "$(blk n1)"
assert_equals "N2: a notification moves neither the turn token nor the prompt stamp" "$t0 $p0" "$(cat "$NT_G/turns/n1") $(cat "$NT_G/prompts/n1")"
assert_equals "N2b: the skip prints nothing (UserPromptSubmit stdout reaches the model)" "" "$(cat "$NT_G/stdout.n1")"
seed n3; arm n3 "{\"session_id\":\"n3\",\"prompt\":\"please look at this: $NOTE\"}"
assert_equals "N3: a typed prompt that merely CONTAINS a notification re-arms (2)" "2" "$(blk n3)"
seed n4; arm n4 "{\"session_id\":\"n4\",\"prompt\":\"$NOTE\\nand now do X\"}"
assert_equals "N4: a notification followed by typed text re-arms (2)" "2" "$(blk n4)"
seed n5; arm n5 '{"session_id":"n5","prompt":["<task-notification></task-notification>"]}'
assert_equals "N5: a non-string prompt re-arms (2)" "2" "$(blk n5)"
seed n6; arm n6 '{"session_id":"n6"}'
assert_equals "N6: no prompt field re-arms (2)" "2" "$(blk n6)"
seed n7; arm n7 "{\"session_id\":\"n7\",\"prompt\":\"$NOTE\\n$NOTE\"}"
assert_equals "N7: two notification blocks in one prompt still do not re-arm (0)" "0" "$(blk n7)"
# N9: typed text BETWEEN two blocks. A lazy [\s\S]*? body still backtracks across the first closing tag to reach the last one, so
# block-text-block matched as "all notifications" and a typed prompt went ungated (6C round 1, 2026-10-10). It must re-arm.
seed n9; arm n9 "{\"session_id\":\"n9\",\"prompt\":\"$NOTE do X $NOTE\"}"
assert_equals "N9: typed text between two notification blocks re-arms (2)" "2" "$(blk n9)"
# N8: the notification check itself fails (a jq that dies on it; every other jq call is real). Under set -e an unguarded failure
# would end the hook BEFORE the turn token is written - the gate left open for a typed prompt. It must re-arm instead.
mkdir -p "$NT_G/fakebin"; REALJQ=$(command -v jq)
printf '#!/usr/bin/env bash\ncase "$*" in *task-notification*) exit 3 ;; esac\nexec %s "$@"\n' "$REALJQ" > "$NT_G/fakebin/jq"; chmod +x "$NT_G/fakebin/jq"
seed n8; printf '{"session_id":"n8","prompt":"do X"}' | PATH="$NT_G/fakebin:$PATH" HOME="$NT_H" GATE_DIR_OVERRIDE="$NT_G" bash "$RESET_SH" >/dev/null 2>&1
assert_equals "N8: a failing notification check re-arms, never kills the hook first (2)" "2" "$(blk n8)"
rm -rf "$NT_G" "$NT_H"

# ── DEFAULT state dir (P1 sentinel hole, 2026-10-11): NO GATE_DIR_OVERRIDE, a scratch HOME. Every writer (arm, track, SubagentStart)
# must meet every reader (block, prework, SubagentStop) in $HOME/.claude/run/ask-human-gate - a hook left on the old /tmp default
# turns one of D1-D7 red (sabotaged one site at a time).
printf '\n=== default state dir: $HOME/.claude/run/ask-human-gate ===\n'
DH=$(mk_home); DG="$DH/.claude/run/ask-human-gate"
dblk() { printf '{"session_id":"%s","cwd":"/x","tool_name":"Read","tool_input":{"file_path":"/x"}}' "$1" | HOME="$DH" bash "$BLOCK_SH" 2>/dev/null; echo $?; }
printf '{"session_id":"d1","cwd":"/x","prompt":"do X"}' | HOME="$DH" bash "$RESET_SH" >/dev/null 2>&1
assert_equals "D1: arm writes the turn token under run/" "1" "$([[ -f "$DG/turns/d1" ]] && echo 1 || echo 0)"
assert_equals "D2: block reads it there: not cleared (2)" "2" "$(dblk d1)"
sleep 1; printf '{"session_id":"d1"}' | HOME="$DH" bash "$TRACK_SH" >/dev/null 2>&1
assert_equals "D3: track's sentinel under run/ clears block (0)" "0" "$(dblk d1)"
printf '{"session_id":"d4","cwd":"/x","prompt":"do Y"}' | HOME="$DH" bash "$RESET_SH" >/dev/null 2>&1
printf '{"session_id":"d4","agent_id":"a4","agent_type":"Explore","cwd":"/x"}' | HOME="$DH" bash "$HOOKS_DIR/subagent-start-context.sh" >/dev/null 2>&1
assert_equals "D4: SubagentStart's marker under run/ lets block through (0)" "0" "$(dblk d4)"
TRD=$(mktemp); printf '%s\n' '{"type":"user","message":{"role":"user","content":[{"type":"text","text":"go"}]}}' > "$TRD"
dpw() { jq -nc --arg t "$TRD" '{session_id:"d4",cwd:"/x",transcript_path:$t,tool_name:"Edit",tool_input:{file_path:"/x/a"}}' | HOME="$DH" bash "$HOOKS_DIR/advisor-prework-guard.sh" >/dev/null 2>&1; echo $?; }
assert_equals "D5: the prework guard sees the same marker (0, no 3C in the turn)" "0" "$(dpw)"
printf '{"session_id":"d4","agent_id":"a4","agent_type":"Explore","cwd":"/x"}' | HOME="$DH" bash "$HOOKS_DIR/subagent-stop-status.sh" >/dev/null 2>&1
assert_equals "D6: SubagentStop removes it under run/: block again (2)" "2" "$(dblk d4)"
assert_equals "D6b: ... and the prework guard blocks again (2)" "2" "$(dpw)"
mkdir -p "$DG/turns" "$DG/subagent/old"; : > "$DG/turns/old"; : > "$DG/subagent/old/a"; : > "$DG/turns/d7"
touch -d '10 days ago' "$DG/turns/old" "$DG/subagent/old/a" "$DG/turns/d7"
printf '{"session_id":"d7","cwd":"/x","prompt":"do Z"}' | HOME="$DH" bash "$RESET_SH" >/dev/null 2>&1
assert_equals "D7: arm prunes other sessions' files older than 7 days" "00" "$([[ -f "$DG/turns/old" ]] && echo 1 || echo 0)$([[ -f "$DG/subagent/old/a" ]] && echo 1 || echo 0)"
assert_equals "D7b: ... never its own session's" "1" "$([[ -f "$DG/turns/d7" ]] && echo 1 || echo 0)"
rm -f "$DG/turns/d1"; sleep 1   # the restarted token must be NEWER than D3's sentinel (same second = cleared)
assert_equals "D8: a deleted turn token does not open the gate (fail closed, 2)" "2" "$(dblk d1)"
rm -rf "$DH" "$TRD"

# ── confident picks (row 26zg): the cf state is injected on EVERY real prompt ─────────────────────────────────────────────
# While cf is on, the full tiered rule (the resolver's bypass_cf_text) goes to stdout, which UserPromptSubmit adds to the model's context.
# When it goes off (toggle removed, rule expired) after it was seen on in this session (an earlier prompt, or the SessionStart banner),
# ONE "OFF now" line; then silence. A notification prints nothing, cf or not.
printf '\n=== confident picks ===\n'
CF_G=$(mktemp -d); CF_H=$(mk_home); mkdir -p "$CF_H/.claude/run" "$CF_H/.claude/state"
carm() { printf '{"session_id":"%s","cwd":"/x","prompt":"%s"}' "$1" "${2:-do it}" | HOME="$CF_H" GATE_DIR_OVERRIDE="$CF_G" bash "$RESET_SH" 2>/dev/null; }
cblk() { printf '{"session_id":"%s","tool_name":"Read","tool_input":{"file_path":"/x"}}' "$1" | HOME="$CF_H" GATE_DIR_OVERRIDE="$CF_G" bash "$BLOCK_SH" >/dev/null 2>&1; echo $?; }
assert_equals "C1: cf off, never seen -> the prompt prints nothing" "" "$(carm c1)"
: > "$CF_H/.claude/run/confident-pick-c1"
O=$(carm c1); assert_contains "C2: cf on (session file) -> the tiered rule is injected" "▸ CONFIDENT PICKS (cf): on" "$O"
assert_contains "C2b: ... worded for spec mode" "the size gate still asks" "$O"
assert_equals "C2c: ... and the spec gate still arms the turn (2)" "2" "$(cblk c1)"
O=$(carm c1); assert_contains "C2d: injected again on the NEXT prompt (every prompt, not once)" "▸ CONFIDENT PICKS (cf): on" "$O"
assert_equals "C2e: a notification prints nothing even while cf is on" "" "$(carm c1 '<task-notification><task-id>b</task-id></task-notification>')"
rm -f "$CF_H/.claude/run/confident-pick-c1"
O=$(carm c1); assert_contains "C3: cf turned off since -> ONE OFF-now line" "CONFIDENT PICKS (cf): OFF now" "$O"
assert_not_contain "C3b: ... without the rule text" "PICK when an objective test" "$O"
assert_equals "C3c: the prompt after that prints nothing" "" "$(carm c1)"
assert_equals "C3d: another session that never saw cf gets no OFF line" "" "$(carm c3other)"
: > "$CF_H/.claude/state/ask-human-gate-bypass"; : > "$CF_H/.claude/state/confident-pick"
O=$(carm c4); assert_contains "C4: autonomous + cf (global) -> autonomous wording" "the recommended option is no longer taken by default" "$O"
assert_equals "C4b: ... and no turn token in autonomous mode (gate open, 0)" "0" "$(cblk c4)"
rm -f "$CF_H/.claude/state/ask-human-gate-bypass" "$CF_H/.claude/state/confident-pick"
printf '{"version":1,"rules":[{"path":"/x","recursive":true,"guards":["cf"],"expires":"%s"}]}\n' "$(date -u -d '+1 hour' +%Y-%m-%dT%H:%M:%SZ)" > "$CF_H/.claude/state/gates-bypass-rules.json"
O=$(carm c5); assert_contains "C5: a live cf rule -> on" "▸ CONFIDENT PICKS (cf): on" "$O"
printf '{"version":1,"rules":[{"path":"/x","recursive":true,"guards":["cf"],"expires":"%s"}]}\n' "$(date -u -d '-1 minute' +%Y-%m-%dT%H:%M:%SZ)" > "$CF_H/.claude/state/gates-bypass-rules.json"
O=$(carm c5); assert_contains "C5b: the rule EXPIRED -> OFF now" "CONFIDENT PICKS (cf): OFF now" "$O"
rm -f "$CF_H/.claude/state/gates-bypass-rules.json"
# C6: the SessionStart banner records what it showed, so cf going off BEFORE the first prompt still gets its OFF line
: > "$CF_H/.claude/run/confident-pick-c6"
printf '{"cwd":"/x","session_id":"c6"}' | HOME="$CF_H" GATE_DIR_OVERRIDE="$CF_G" bash "$HOOKS_DIR/session-start-banner.sh" >/dev/null 2>&1
rm -f "$CF_H/.claude/run/confident-pick-c6"
O=$(carm c6); assert_contains "C6: on in the banner, off before the first prompt -> OFF now" "CONFIDENT PICKS (cf): OFF now" "$O"
rm -rf "$CF_G" "$CF_H"

# ── an explicit "ask me" lifts no_ask for that turn (row 26zj, user ruling 2026-10-16 00:25, option a) ──────────────────────────
# The user asked for a question while a no_ask window denied every one ("I told you to ask me ! or does the ask not work while we are on those
# bypasses ?", 2026-10-15). The arm hook marks the REAL prompt that asks (run/ask-human-gate/unattended-ask-<sid>; bin/lib/unattended.py
# ask_lifted reads it for the engine and keep-going); the next real prompt that does not ask removes it. Phrases from this machine's transcripts.
printf '\n=== explicit ask marker ===\n'
AK_G=$(mktemp -d); AK_H=$(mk_home)
aka() { jq -nc --arg s "$1" --arg p "$2" '{session_id:$s,cwd:"/x",hook_event_name:"UserPromptSubmit",prompt:$p}' | HOME="$AK_H" GATE_DIR_OVERRIDE="$AK_G" bash "$RESET_SH" >/dev/null 2>&1; }
akm() { [[ -f "$AK_G/unattended-ask-$1" ]] && echo yes || echo no; }
for p in 'answer me now and ask me !' 'Why do i see BYPASS-EXPIRES 6h ! investigate and ask me !' 'Ask me to decide !' 'answerme now qnd ask me !' \
         'challenge me on everything and ask me about everything you find ! let me decide !' 'ask me!' 'Let me decide what to do next' \
         'no, ask me first' 'if not sure, ask me'; do
  rm -f "$AK_G"/unattended-ask-*; aka ak1 "$p"; assert_equals "AK1 '$p' -> marker" "yes" "$(akm ak1)"
done
for p in "don't ask me again" 'no need to ask me' 'do not ask me anything' 'never ask me, just do it' 'asking me is pointless' 'mask me' 'task meeting notes' 'just continue'; do
  rm -f "$AK_G"/unattended-ask-*; aka ak2 "$p"; assert_equals "AK2 '$p' -> no marker" "no" "$(akm ak2)"
done
# Final delivery panel A-P2-2: the negation list is keep-going's _stop_intent list ("you can't ask me" lifted no_ask).
for p in "you can't ask me" 'you cannot ask me now' "you shouldn't ask me" "you won't ask me" "you mustn't ask me" 'you must not ask me' \
         "he doesn't let me decide" 'it does not ask me' "you can’t ask me"; do
  rm -f "$AK_G"/unattended-ask-*; aka ak2b "$p"; assert_equals "AK2b '$p' -> no marker" "no" "$(akm ak2b)"
done
# Milestone panel A-P2-1 (2026-10-16): the A-P2-2 words negate only DIRECTLY before `ask me` (the old five keep their two-word window), and
# a question about not being asked is a request to be asked.
for p in 'if you are not sure ask me' 'why did you not ask me' 'not now ask me later' "why didn't you ask me" "why don't you ask me" \
         "no time to lose, ask me"; do
  rm -f "$AK_G"/unattended-ask-*; aka ak1b "$p"; assert_equals "AK1b '$p' -> marker" "yes" "$(akm ak1b)"
done
for p in "you can't ask me" "don't need to ask me" "do not ever ask me" "you need not ask me"; do
  rm -f "$AK_G"/unattended-ask-*; aka ak2c "$p"; assert_equals "AK2c '$p' -> no marker" "no" "$(akm ak2c)"
done
# Re-round A3-P2-1 (2026-10-16): a tier-2 word may skip a closed set of modal gap words (optionally an adverb, then need/have/got/
# necessary/point/reason with an optional `to`, a participle predicate required/supposed/allowed/... with `to`, or a bare `to`, round 3-4) - "you won't need to ask me" grants autonomy; an open gap stays lifting (AK1b above).
for p in "you won't need to ask me" "you won't have to ask me" "you shouldn't need to ask me" 'you should not have to ask me' \
         'it is not necessary to ask me' "it doesn't need to ask me" "you can't just ask me" "you won't ever ask me" \
         "you mustn't ever ask me" 'there is no point to ask me' 'there is no reason to ask me' 'i told you not to ask me' \
         'you should not ever ask me' "you didn't even ask me" 'it does not just ask me' \
         'you are not required to ask me' "you're not supposed to ask me" 'you are not allowed to ask me' \
         'you are not going to ask me' 'you should not try to ask me' "you won't want to ask me" \
         "you needn't ask me" 'you are not meant to ask me'; do
  rm -f "$AK_G"/unattended-ask-*; aka ak2d "$p"; assert_equals "AK2d '$p' -> no marker" "no" "$(akm ak2d)"
done
# Round 3 B4-P2-1: an adverb gap (just/really/even/ever) negates only after a modal tier word, never after a bare no/not
# ("no just ask me" asks); "not ever" stays a negation.
# Re-round A3-P3-1/C3-P3-5/A3-P3-2: a negated "forget/hesitate/fail/be afraid to" and "never mind" are requests to ask; so is
# "why do you not ask me". The declarative complaint "you didn't ask me" stays a negation (a user ruling, not a code guess).
for p in "don't forget to ask me before pushing" 'never forget to ask me' 'do not hesitate to ask me' "don't hesitate to ask me" \
         'do not fail to ask me' "don't be afraid to ask me" 'never mind, ask me' 'never mind ask me' 'why do you not ask me' \
         "don't stop, but ask me before pushing" 'not really, ask me' 'why not ask me' 'why not just ask me' \
         'no just ask me' 'no just ask me first' 'no really ask me this time' 'if not just ask me' \
         'if it fails or not just ask me' 'no ever ask me' 'not just ask me but also check the logs' \
         'no reason not to ask me' 'there is no reason not to ask me' 'there is no need not to ask me' \
         'whether or not to ask me, you decide' 'why would you not ask me' 'why do you never ask me' \
         'why did you never ask me' "how come you didn't ask me" "why wouldn't you ask me" \
         'no i want you to ask me' 'no just remember to ask me'; do
  rm -f "$AK_G"/unattended-ask-*; aka ak1c "$p"; assert_equals "AK1c '$p' -> marker" "yes" "$(akm ak1c)"
done
for p in "never mind, don't ask me" "don't forget: you need not ask me" "don't hesitate, never ask me" \
         "why? don't ask me" "why bother, never ask me"; do
  rm -f "$AK_G"/unattended-ask-*; aka ak2e "$p"; assert_equals "AK2e '$p' -> no marker" "no" "$(akm ak2e)"
done
# Round 4 (user ruling 2026-10-17 00:30: narrow fixes, then the phrase list is a closed heuristic). A why/how-come complaint lifts only
# at a clause start followed by an auxiliary/subject (A5-P2-1/B5-P2-2/C5-P2-1); a participle predicate negates only with `to`
# (A5-P2-2); an inverted "are you not ... ask me" is a question = a request (B5-P3-1).
for p in 'if a merge is not allowed ask me' 'when force push is not permitted ask me' 'if a review is not required ask me' \
         'if the result is not expected ask me' 'are you not going to ask me' 'were you not supposed to ask me' \
         'are you not allowed to ask me' 'is it not required to ask me first' 'ok. why do you never ask me' \
         "so, how come you didn't ask me"; do
  rm -f "$AK_G"/unattended-ask-*; aka ak1d "$p"; assert_equals "AK1d '$p' -> marker" "yes" "$(akm ak1d)"
done
# ...and a relative `why` statement stays a negation; an uncontracted modal + not + adverb negates (C5-P3-3); "not even/ever to"
# negates (A5-P3-1).
for p in 'explain why and never ask me again' 'that is why you should never ask me' "this is why you shouldn't ask me" \
         "which is why i said don't ask me" "the reason why you won't ask me is the window" "i don't know why but don't ask me" \
         'no matter why you never ask me again' 'why bother never ask me' 'you should not just ask me' \
         'you must not just ask me, use your judgement' 'you should not really ask me' 'you will not just ask me' \
         'you could not just ask me' 'you would not even ask me' 'i told you not even to ask me' 'not ever to ask me'; do
  rm -f "$AK_G"/unattended-ask-*; aka ak2f "$p"; assert_equals "AK2f '$p' -> no marker" "no" "$(akm ak2f)"
done
rm -f "$AK_G"/unattended-ask-*; aka ak3 'investigate and ask me !'; aka ak3 'continue with the plan'
assert_equals "AK3 the next real prompt that does not ask removes it (that turn only)" "no" "$(akm ak3)"
aka ak4 'ask me first'; aka ak4 '<task-notification><task-id>b</task-id></task-notification>'
assert_equals "AK4 a notification keeps it (not a new user turn)" "yes" "$(akm ak4)"
aka ak5 'ask me'; assert_equals "AK5 another session's prompt never writes this session's marker" "no" "$(akm ak5other)"
: > "$AK_H/.claude/state/ask-human-gate-bypass"; rm -f "$AK_G"/unattended-ask-*; aka ak6 'answer me and ask me !'
assert_equals "AK6 autonomous mode (ah bypassed) still writes it" "yes" "$(akm ak6)"
aka ak6 'go on'; assert_equals "AK6b ...and removes it" "no" "$(akm ak6)"
rm -f "$AK_H/.claude/state/ask-human-gate-bypass"
mkdir -p "$AK_G/turns"; printf 'x' > "$AK_G/unattended-ask-ak7"; mv "$AK_G/unattended-ask-ak7" "$AK_G/unattended-ask-ak7.f"; mkdir "$AK_G/unattended-ask-ak7"
aka ak7 'just continue'; assert_equals "AK7 a marker path that cannot be removed (a dir) never stops the turn token" "ak7" "$(ls "$AK_G/turns/" | grep -x ak7)"
rm -rf "$AK_G" "$AK_H"

# ── Summary ───────────────────────────────────────────────────────────────────
printf '\n─────────────────────────────────────────────\n'
TOTAL=$((PASS + FAIL))
if [[ $FAIL -eq 0 ]]; then
  printf "${C_GREEN}All %d tests passed${C_RESET}\n" "$TOTAL"
else
  printf "${C_RED}%d/%d tests FAILED${C_RESET}\n" "$FAIL" "$TOTAL"
  for f in "${FAILURES[@]}"; do printf '  • %s\n' "$f"; done
  exit 1
fi
