#!/usr/bin/env bash
# Tests for ask-human-question-guard.sh (Stop-hook backstop)
set -uo pipefail

HOOK="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/ask-human-question-guard.sh"
C_G='\033[0;32m'; C_R='\033[0;31m'; C_0='\033[0m'
PASS=0; FAIL=0; declare -a FAILS=()
TMP=$(mktemp -d); TR="$TMP/t.jsonl"

U='{"type":"user","message":{"role":"user","content":[{"type":"text","text":"go"}]}}'
think='{"type":"assistant","message":{"role":"assistant","content":[{"type":"thinking","thinking":"hm"}]}}'
atext(){ jq -nc --arg t "$1" '{type:"assistant",message:{role:"assistant",content:[{type:"text",text:$t}]}}'; }
auq='{"type":"assistant","message":{"role":"assistant","content":[{"type":"tool_use","name":"AskUserQuestion","input":{}}]}}'

mk(){ : > "$TR"; for l in "$@"; do printf '%s\n' "$l" >> "$TR"; done; }
run(){ jq -n --arg t "$1" --argjson s "${2:-false}" '{transcript_path:$t,stop_hook_active:$s}' | bash "$HOOK" >/dev/null 2>&1; echo $?; }
ec(){ local d="$1" exp="$2" got="$3"; if [[ "$got" == "$exp" ]]; then PASS=$((PASS+1)); printf "${C_G}✓${C_0} %s\n" "$d"; else FAIL=$((FAIL+1)); FAILS+=("$d"); printf "${C_R}✗${C_0} %s (exp $exp got $got)\n" "$d"; fi; }

printf '\n=== BLOCK: free-text question, no AskUserQuestion ===\n'
mk "$U" "$(atext 'Shall I proceed?')";                         ec "trailing question → block (2)" 2 "$(run "$TR")"
E=$(jq -n --arg t "$TR" '{transcript_path:$t,stop_hook_active:false}' | bash "$HOOK" 2>&1 >/dev/null)
[[ "$E" == *'Final line: "Shall I proceed?"'* ]] && ec "the block message quotes a SHORT final line (was empty: \${x: -100} of a shorter string)" ok ok || ec "the block message quotes a short final line" ok "$E"
mk "$U" "$(atext 'Some explanation here.\nWhich option do you want?')"; ec "multi-line ending in ? → block" 2 "$(run "$TR")"

printf '\n=== PASS: not a free-text question ===\n'
mk "$U" "$(atext 'Done. All 27 tests pass.')";                 ec "statement → pass (0)" 0 "$(run "$TR")"
mk "$U" "$(atext 'Pick one?')" "$auq";                          ec "AskUserQuestion used → pass" 0 "$(run "$TR")"
mk "$U" "$think" "$(atext 'ok.')";                              ec "thinking block ignored → pass" 0 "$(run "$TR")"
mk "$U" "$(atext 'See:\n```\nis this code?\n```')";             ec "last line code fence → pass" 0 "$(run "$TR")"
mk "$U" "$(atext '> a quoted question?')";                      ec "blockquote line → pass" 0 "$(run "$TR")"

printf '\n=== guards ===\n'
mk "$U" "$(atext 'proceed?')";                                  ec "stop_hook_active=true → pass (no loop)" 0 "$(run "$TR" true)"
ec "missing transcript → pass" 0 "$(run "$TMP/nope.jsonl")"

printf '\n=== OFF: sentinel bypass (parity with gate/firewall) ===\n'
FAKEHOME="$TMP/home"; mkdir -p "$FAKEHOME/.claude/state" "$FAKEHOME/.claude/projects/-proj/state"
run_home(){ jq -n --arg t "$1" --arg w "${2:-}" '{transcript_path:$t,stop_hook_active:false} + (if $w!="" then {cwd:$w} else {} end)' | HOME="$FAKEHOME" bash "$HOOK" >/dev/null 2>&1; echo $?; }
mk "$U" "$(atext 'proceed?')"
touch "$FAKEHOME/.claude/state/ask-human-question-guard-bypass"
ec "global sentinel -> pass (0)" 0 "$(run_home "$TR")"
rm -f "$FAKEHOME/.claude/state/ask-human-question-guard-bypass"
touch "$FAKEHOME/.claude/projects/-proj/state/ask-human-question-guard-bypass"
ec "per-project sentinel (matching cwd) -> pass" 0 "$(run_home "$TR" /proj)"
ec "per-project sentinel does NOT affect other cwd -> block" 2 "$(run_home "$TR" /other)"
rm -f "$FAKEHOME/.claude/projects/-proj/state/ask-human-question-guard-bypass"

# ── per-session bypass (sentinel: $HOME/.claude/run/ask-human-question-guard-bypass-<sid>) ──
# Added 2026-08-30 for the /gates-bypass uniform sentinel model.
mkdir -p "$FAKEHOME/.claude/run"
run_home_sess(){ jq -n --arg t "$1" --arg s "$2" '{transcript_path:$t,stop_hook_active:false,session_id:$s}' | HOME="$FAKEHOME" bash "$HOOK" >/dev/null 2>&1; echo $?; }
mk "$U" "$(atext 'proceed?')"
touch "$FAKEHOME/.claude/run/ask-human-question-guard-bypass-sqg1"
ec "per-session sentinel (matching session_id) -> pass" 0 "$(run_home_sess "$TR" sqg1)"
ec "per-session sentinel does NOT affect other session_id -> block" 2 "$(run_home_sess "$TR" other-session)"
rm -f "$FAKEHOME/.claude/run/ask-human-question-guard-bypass-sqg1"

printf '\n=== ADVISORY: qg bypassed -> never blocks; a free-text closing question is queued (framework-health step 7) ===\n'
Q="$FAKEHOME/.claude/logs/bypass-review.ndjson"
nq(){ local n; n=$(cat "$Q" 2>/dev/null | wc -l); echo $(( n )); }
rm -f "$Q"   # the sentinel cases above are bypassed too, so they queued advisory events already (counted from here)
# runa <sid> [stop_hook_active] -> exit code; HOME = the fake home (session sentinels live there)
runa(){ jq -n --arg t "$TR" --arg s "$1" --argjson a "${2:-false}" '{transcript_path:$t,stop_hook_active:$a,session_id:$s,cwd:"/proj"}' | HOME="$FAKEHOME" bash "$HOOK" >/dev/null 2>&1; echo $?; }
sess(){ touch "$FAKEHOME/.claude/run/$1-bypass-$2"; }
bash_call(){ jq -nc --arg c "$1" '{type:"assistant",message:{role:"assistant",content:[{type:"tool_use",name:"Bash",input:{command:$c}}]}}'; }
edit_call(){ jq -nc --arg s "$1" '{type:"assistant",message:{role:"assistant",content:[{type:"tool_use",name:"Edit",input:{file_path:"/p/x.plan.md",old_string:"a",new_string:$s}}]}}'; }
mk "$U" "$(atext 'Shall I proceed?')"; sess ask-human-question-guard q1
ec "Q1 bypassed + free-text question: exit 0" 0 "$(runa q1)"
[[ "$(nq)" == 1 ]] && grep -q '"gate": "qg"' "$Q" && grep -q 'Shall I proceed' "$Q" && ec "Q1 one qg review event with the line" ok ok || ec "Q1 one qg review event" ok "$(cat "$Q" 2>/dev/null)"
mk "$U" "$(atext 'Pick one?')" "$auq"; sess ask-human-question-guard q2
runa q2 >/dev/null; [[ "$(nq)" == 1 ]] && ec "Q2 bypassed + AskUserQuestion: nothing queued" ok ok || ec "Q2 AUQ: nothing queued" ok "q=$(nq)"
mk "$U" "$(atext 'Shall I proceed?')"
ec "Q3 ARMED behaviour unchanged: block (2)" 2 "$(runa q3)"
[[ "$(nq)" == 1 ]] && ec "Q3 armed: nothing queued" ok ok || ec "Q3 armed: nothing queued" ok "q=$(nq)"

printf '\n=== unlogged-choice detector (an ah producer; runs only while ah is bypassed) ===\n'
CH1='I went with option B because it keeps the armed path untouched.'
ahq(){ grep -c '"gate": "ah"' "$Q" 2>/dev/null | head -1; }
mk "$U" "$(atext "$CH1")"; sess ask-human-gate d1; sess ask-human-question-guard d1
runa d1 >/dev/null; [[ "$(ahq)" == 1 ]] && grep -q 'choice without an ASSUMED entry' "$Q" && grep -q 'went with option B' "$Q" && ec "D1 autonomous + first-person choice, nothing logged: one ah event" ok ok || ec "D1 one ah event" ok "$(cat "$Q" 2>/dev/null)"
mk "$U" "$(atext "$CH1")" "$(bash_call 'bash ~/.claude/bin/project-state.sh --append-decision p.plan.md ASSUMED "option B"')"; sess ask-human-gate d2; sess ask-human-question-guard d2
runa d2 >/dev/null; [[ "$(ahq)" == 1 ]] && ec "D2 the choice was logged (--append-decision): nothing queued" ok ok || ec "D2 logged: nothing queued" ok "ah=$(ahq)"
mk "$U" "$(atext "$CH1")" "$(edit_call '- [2026-10-08 18:00] ASSUMED (review): option B')"; sess ask-human-gate d8; sess ask-human-question-guard d8
runa d8 >/dev/null; [[ "$(ahq)" == 1 ]] && ec "D8 the choice was logged by an edit carrying ASSUMED (review): nothing queued" ok ok || ec "D8 logged by edit: nothing queued" ok "ah=$(ahq)"
mk "$U" "$(atext "$CH1")"; sess ask-human-question-guard d3
runa d3 >/dev/null; [[ "$(ahq)" == 1 ]] && ec "D3 ah ARMED (spec mode): no detector" ok ok || ec "D3 ah armed: no detector" ok "ah=$(ahq)"
mk "$U" "$(atext "$CH1"$'\n''Shall I proceed?')"; sess ask-human-gate d4
R=$(runa d4); [[ "$R" == 2 && "$(ahq)" == 2 ]] && ec "D4 ah bypassed + qg ARMED: the detector runs BEFORE the qg block (exit 2, one ah event)" ok ok || ec "D4 detector before the qg verdict" ok "rc=$R ah=$(ahq)"
mk "$U" "$(atext 'The user chose option B, so that is what was built.')"; sess ask-human-gate d5; sess ask-human-question-guard d5
runa d5 >/dev/null; [[ "$(ahq)" == 2 ]] && ec "D5 not first person: nothing queued" ok ok || ec "D5 not first person" ok "ah=$(ahq)"
mk "$U" "$(atext "$CH1")" "$auq"; sess ask-human-gate d6; sess ask-human-question-guard d6
runa d6 >/dev/null; [[ "$(ahq)" == 2 ]] && ec "D6 AskUserQuestion used (the user decided): nothing queued" ok ok || ec "D6 AUQ" ok "ah=$(ahq)"
mk "$U" "$(atext "$CH1")"; sess ask-human-gate d7; sess ask-human-question-guard d7
R=$(jq -n --arg t "$TR" '{transcript_path:$t,stop_hook_active:false,session_id:"d7",cwd:"/proj"}' | QGUARD_OFF=1 HOME="$FAKEHOME" bash "$HOOK" >/dev/null 2>&1; echo $?)
[[ "$R" == 0 && "$(ahq)" == 2 ]] && ec "D7 QGUARD_OFF=1 is a FULL off, detector included" ok ok || ec "D7 QGUARD_OFF full off" ok "rc=$R ah=$(ahq)"

mk "$U" "$(atext '| 4 | the table says I chose B |'$'\n''> I went with A, quoted')"; sess ask-human-gate d9; sess ask-human-question-guard d9
runa d9 >/dev/null; [[ "$(ahq)" == 2 ]] && ec "D9 table rows and blockquotes are not choices" ok ok || ec "D9 table/blockquote skipped" ok "ah=$(ahq)"
mk "$U" "$(atext "The run is still going; I'll pick it up when it reports.")"; sess ask-human-gate d10; sess ask-human-question-guard d10
runa d10 >/dev/null; [[ "$(ahq)" == 2 ]] && ec "D10 \"I'll pick it up\" is narration, not a choice" ok ok || ec "D10 I'll pick it up" ok "ah=$(ahq)"

printf '\n=== Turn anchor: a skill body or compact summary is not a new turn (framework-health row 19, 2026-10-10) ===\n'
# Same anchor as advisor-prework-guard.sh (real shapes from transcript 1096c8e6).
H1='{"type":"user","origin":{"kind":"human"},"message":{"role":"user","content":"go"}}'
H2='{"type":"user","origin":{"kind":"human"},"message":{"role":"user","content":"next"}}'
SKL='{"type":"user","isMeta":true,"sourceToolUseID":"toolu_1","message":{"role":"user","content":[{"type":"text","text":"Base directory for this skill: /x"}]}}'
SKS='{"type":"user","isMeta":true,"message":{"role":"user","content":"(Re-invocation of /certify)"}}'
CMP='{"type":"user","isCompactSummary":true,"isVisibleInTranscriptOnly":true,"message":{"role":"user","content":"This session is being continued from a previous conversation."}}'
mk "$H1" "$auq" "$SKL" "$(atext 'Shall I go on?')";  ec "M1 AskUserQuestion, then a skill body (list), then a bare ?: pass (0)" 0 "$(run "$TR")"
mk "$H1" "$auq" "$SKS" "$(atext 'Shall I go on?')";  ec "M2 AskUserQuestion, then a skill body (string): pass (0)" 0 "$(run "$TR")"
mk "$H1" "$auq" "$CMP" "$(atext 'Shall I go on?')";  ec "M3 AskUserQuestion, then a compact summary: pass (0)" 0 "$(run "$TR")"
mk "$H1" "$auq" "$H2" "$(atext 'Shall I go on?')";   ec "M4 AskUserQuestion only in the PREVIOUS human turn: block (2)" 2 "$(run "$TR")"
mk "$H1" "$auq" "$H2" "$SKL" "$(atext 'Shall I go on?')"; ec "M4b previous turn's AskUserQuestion, new prompt, then a skill body: block (2)" 2 "$(run "$TR")"
mk "$auq" "$SKL" "$(atext 'Shall I go on?')";        ec "M5 no human prompt in the window, AskUserQuestion before a skill body: pass (0)" 0 "$(run "$TR")"
# A background task's notification is not a new prompt either (real fields, 1096c8e6 line 591).
NT='{"type":"user","origin":{"kind":"task-notification","producer":"session-task","runId":"r1"},"turnOrigin":"task_notification","promptSource":"system","message":{"role":"user","content":"<task-notification>\n<task-id>b1</task-id>\n</task-notification>"}}'
mk "$H1" "$auq" "$NT" "$SKL" "$(atext 'Shall I go on?')"; ec "M6 AskUserQuestion, a task notification, a skill body, then a bare ?: pass (0)" 0 "$(run "$TR")"
mk "$H1" "$auq" "$H2" "$NT" "$(atext 'Shall I go on?')";  ec "M6-pin previous turn's AskUserQuestion, new prompt, then a notification: block (2)" 2 "$(run "$TR")"
# A `!` line (<bash-input>, <bash-stdout>) or a built-in local command (<command-name>, <local-command-stdout>) fires no
# UserPromptSubmit and is not a new turn (2026-10-13; real shapes, transcript 93a99dbc). A typed skill (<command-message>) is: B4.
BI='{"type":"user","isSidechain":false,"message":{"role":"user","content":"<bash-input> git commit -F m -- p</bash-input>"}}'
BO='{"type":"user","isSidechain":false,"turnOrigin":"human","message":{"role":"user","content":"<bash-stdout>[master 1a2b3c4] x</bash-stdout><bash-stderr></bash-stderr>"}}'
LC='{"type":"user","isSidechain":false,"message":{"role":"user","content":"<command-name>/effort</command-name>\n            <command-message>effort</command-message>\n            <command-args>medium</command-args>"}}'
LO='{"type":"user","isSidechain":false,"message":{"role":"user","content":"<local-command-stdout>Set effort level to medium</local-command-stdout>"}}'
SKC='{"type":"user","origin":{"kind":"human"},"turnOrigin":"human","message":{"role":"user","content":"<command-message>gates-bypass</command-message>\n<command-name>/gates-bypass</command-name>\n<command-args>status</command-args>"}}'
mk "$H1" "$auq" "$BI" "$BO" "$(atext 'Shall I go on?')";  ec "B1 AskUserQuestion, then a \`!\` line, then a bare ?: pass (0)" 0 "$(run "$TR")"
mk "$H1" "$auq" "$LC" "$LO" "$(atext 'Shall I go on?')";  ec "B2 AskUserQuestion, then a built-in local command, then a bare ?: pass (0)" 0 "$(run "$TR")"
mk "$H1" "$auq" "$H2" "$BI" "$BO" "$(atext 'Shall I go on?')"; ec "B3-pin previous turn's AskUserQuestion, new prompt, then a \`!\` line: block (2)" 2 "$(run "$TR")"
mk "$H1" "$auq" "$SKC" "$(atext 'Shall I go on?')";       ec "B4-pin AskUserQuestion, then the user types a skill (a real prompt): block (2)" 2 "$(run "$TR")"

rm -rf "$TMP"
printf '\n─────────────────────────────\n'
if [[ $FAIL -eq 0 ]]; then printf "${C_G}All %d question-guard tests passed${C_0}\n" "$PASS"
else printf "${C_R}%d/%d FAILED${C_0}\n" "$FAIL" "$((PASS+FAIL))"; for f in "${FAILS[@]}"; do printf '  • %s\n' "$f"; done; exit 1; fi
