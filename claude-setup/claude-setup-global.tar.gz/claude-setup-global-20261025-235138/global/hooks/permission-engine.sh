#!/usr/bin/env bash
# PreToolUse — PERMISSION ENGINE wrapper (plan: permission-unification; design: docs/research/perm-engine-design-20260930/DESIGN.md).
# Register as:  bash "$HOME/.claude/hooks/permission-engine.sh"   (run through bash: no exec-bit failure class, probe X3)
#
# FAILURE POLICY (user ruling): a hook that crashes, hangs, prints garbage or is missing FAILS OPEN in the harness
# (probes F2/F3/F4b/X1/X2). This wrapper therefore turns EVERY failure of the engine into ONE constant line, an `ask`, or a
# `deny` for an Edit-family call under bypassPermissions or with no permission_mode key (row 26a: that mode applies an Edit ask with
# no dialog, bp_edit below): nothing leaks, nothing seals shut (the user can approve the repair), and it needs neither jq nor python.
# Price (stated in the design): under auto mode, headless and subagents an ask is a hard deny, so an engine failure
# stalls an unattended run until the user returns. Failures are logged to hooks-errors.log (log_obs).
# EXCEPTION (plan perm-engine-stall-failopen, user ruling 2026-10-01, narrowed to TIMEOUT-only by the 6C advisor: a crash, missing rules or no python is a broken engine, not a stall): a TIMEOUT (124) at level `total` stays SILENT
# (the harness default applies; the 60 settings.json denies and the firewall's deny floor still hold). 2026-09-30 night: 23 engine
# timeouts under load printed 23 asks that nobody could answer. The level is NOT cached: the wrapper asks the same resolver the engine
# uses (bypass_level perm <top-level cwd>) so scope, expiry and except cannot drift. Garbage output, empty stdin, no jq, an
# unresolvable cwd, a resolver timeout and every level but exactly `total` keep the constant ask. This overrides the protected tier
# (F2/PR4) for the stall window only. Every fail-open is logged FAIL-OPEN. The bypass-edit deny is checked FIRST, so a bypass edit is
# denied during a stall at `total` too (it would otherwise be applied with no dialog; user ruling 2026-10-13, framework-health C2-P3-3).
# A MISSING or disabled wrapper cannot report itself — the HOOK-DOWN canary and the static backstop cover that.
#
# The engine itself resolves the `perm` bypass level (none|normal|total) from the PARSED top-level cwd via the shared resolver;
# anything unexpected resolves to none (strict). PERM_ENGINE_MODE=shadow: log only, never print, never ask (also on failure).
# Test knobs (all fail toward ask, or toward deny for a bypass edit): PERM_ENGINE_RULES, PERM_ENGINE_LOG, PERM_ENGINE_TIMEOUT, PERM_ENGINE_PY, PERM_ENGINE_FAULT.

D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ASK='{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"ask","permissionDecisionReason":"permission engine failure - constant ask (fail policy); repair: bin/perm-engine-doctor.sh"}}'
IN=$(cat 2>/dev/null)

_log() { # never fatal; log_obs is optional
  # shellcheck source=/dev/null
  { . "$D/log-helpers.sh" && log_obs ERROR permission-engine "$*"; } 2>/dev/null || true
}
SHADOW=0; [[ "${PERM_ENGINE_MODE:-}" == shadow ]] && SHADOW=1     # shadow: log only, never prompt (also on failure)
# total_now: 0 only when the shared resolver says exactly `total` for the TOP-LEVEL cwd (jq reads .cwd, never a nested key). Any trouble -> 1.
total_now() {
  command -v jq >/dev/null 2>&1 || return 1
  local cwd lvl
  cwd=$(printf '%s' "$IN" | timeout 2 jq -r 'if (.cwd|type)=="string" then .cwd else empty end' 2>/dev/null) || return 1
  [[ "$cwd" == /* ]] || return 1
  lvl=$(timeout "${PERM_ENGINE_FALLBACK_TIMEOUT:-4}" bash -c '. "$1/bypass-resolve.sh" 2>/dev/null && bypass_level perm "$2"' _ "$D" "$cwd" 2>/dev/null) || return 1
  [[ "$lvl" == total ]]
}
# bp_edit: 0 for an Edit-family call in bypassPermissions, or one with no permission_mode key. Claude Code applies an Edit/Write hook
# ASK with no dialog in that mode (framework-health row 16a, 3 of 3), so on an engine failure the constant ask let the edit through
# (milestone panel 2026-10-13 B-P1-1, row 26a). Raw-text match, no jq: inside a JSON string a quote is \", so only a real key
# matches. A spoofed nested key only pushes toward deny WHEN the top-level permission_mode key is present (every real payload carries
# it); a payload with no top-level key but a real nested "permission_mode": object key reads as keyed and gets the constant ask, not the
# no-key deny (round-2 B2-P3-1; not reachable today: Edit-family inputs are flat). Unquoted $RX after =~ (a quoted pattern matches literally).
BP_TOOL_RX='"tool_name"[[:space:]]*:[[:space:]]*"(Edit|Write|NotebookEdit|MultiEdit)"'
BP_MODE_RX='"permission_mode"[[:space:]]*:[[:space:]]*"bypassPermissions"'
BP_KEY_RX='"permission_mode"[[:space:]]*:'
BP_TOOL=''
bp_edit() {
  [[ $IN =~ $BP_TOOL_RX ]] || return 1
  BP_TOOL=${BASH_REMATCH[1]}
  [[ $IN =~ $BP_MODE_RX ]] && return 0
  [[ $IN =~ $BP_KEY_RX ]] && return 1
  return 0
}
DENY='{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"permission engine failure under bypassPermissions - this edit would be applied without a prompt, so it is denied: needs a human; do not retry or work around it; repair: bin/perm-engine-doctor.sh"}}'
fail() {
  _log "$1"
  [[ $SHADOW -eq 1 ]] && exit 0
  if bp_edit; then _log "bypass edit denied on engine failure: $BP_TOOL"; printf '%s\n' "$DENY"; else printf '%s\n' "$ASK"; fi
  exit 0
}
# fail_stall: timeout (124) only - silent at total, constant ask otherwise; a bypass edit is denied first (silence = allow there)
fail_stall() { if [[ $SHADOW -eq 0 ]] && ! bp_edit && total_now; then _log "FAIL-OPEN at total: $1"; exit 0; fi; fail "$1"; }

[[ -n "$IN" ]] || fail "empty stdin"

PY="${PERM_ENGINE_PY:-}"
[[ -n "$PY" ]] || { [[ -x /usr/bin/python3 ]] && PY=/usr/bin/python3 || PY=python3; }

OUT=$(printf '%s' "$IN" | timeout "${PERM_ENGINE_TIMEOUT:-20}" "$PY" "$D/permission_engine.py" 2>/dev/null)
RC=$?
[[ $RC -eq 0 ]] || { [[ $RC -eq 124 ]] && fail_stall "engine exit 124 (timeout)"; fail "engine exit $RC (124 = timeout)"; }

if [[ -z "$OUT" ]]; then
  exit 0                                            # no decision: the harness default applies
fi
RX='^\{"hookSpecificOutput":\{"hookEventName":"PreToolUse","permissionDecision":"(allow|ask|deny)","permissionDecisionReason":"([^"\\]|\\.)*"\}\}$'
[[ "$OUT" != *$'\n'* && "$OUT" =~ $RX ]] || fail "engine output not a valid decision"
printf '%s\n' "$OUT"
exit 0
