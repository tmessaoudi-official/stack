#!/usr/bin/env bash
# bypass-resolve.sh — the single shared resolver for every safety-gate bypass.
#
# Sourced by the five guard hooks (and statusline.sh) the same way log-helpers.sh is.
# Replaces five hand-copied 3-scope resolution blocks.
#
#   bypass_applies <family> <cwd> [target_path]
#     exit 0        -> bypass: the gate is OFF here (for `fw`: boundary FRICTION lifted only — deny, self-mod
#                      and other guard findings still fire; see ask-bash-firewall.sh, 2026-09-23)
#     exit non-zero -> the gate STAYS ARMED
#
#   bypass_level <family> <cwd>
#     prints none | normal | total — the LEVEL of the bypass in force at <cwd> (TOTAL plan, 2026-09-24).
#     A rule carries it as "level"; a legacy sentinel as its file content (`total`; anything else = normal).
#     Grants exactly when bypass_applies <family> <cwd> does; any covering total grant wins.
#
# family: ah | fw | qg | ac | pw | auto3c | perm | eg | kg | cf   (same codes /gates-bypass uses)
#   eg = the expertise gate's OFF switch (a true bypass: grant => gate off).
#   kg = keep-going's ON switch (OPPOSITE polarity: grant => the Stop hook is armed). The resolver only says "this condition
#        holds here"; the caller gives it meaning. kg is never part of an `all`/`gates` group (a bypass-everything command must not
#        arm it), and the lint below keeps a kg rule pure: no level, no other guard in the same rule. An except is allowed (row 26zu):
#        it is a hole in the kg rule's reach like any other rule's.
#   cf = confident-pick ON (row 26zg, user ruling 2026-10-15 12:42): an enable like kg - grant => mid-task questions follow the tiered
#        rule (hooks/ask-human-gate-arm.sh injects it on every prompt). Same purity as kg; never in `all`; the mode (--run/--spec)
#        never moves it. A resolver without cf (a rollback) simply ignores a cf rule: the lint tolerates unknown codes (probed).
# target_path: the file/path the tool is about to touch, when the guard knows it.
#   Stop hooks (qg, ac) have no target and MUST pass nothing — the except lists are then matched against the CWD.
#
# EXCEPT = A HOLE IN ITS OWN RULE (row 26zu, user rulings 2026-10-17 01:02; before: matched against a target only, and the
#   cross-family union let an ancestor's except veto a deeper project's own grant). The POINT is the target when one is given
#   (pw, fw, perm, ah file tools), else the cwd (kg cf eg qg ac auto3c, ah prompts, bypass_level). Among the live rules covering
#   the cwd (any family), a point is HOLED when some rule's except matches it and no STRICTLY DEEPER covering rule reaches it
#   (covers it, its own except does not match). Holed = armed for every family, and the firewall/engine's except hit (an ask).
#   Not holed: the longest rule of the family whose except does not match the point decides, as before. So a deeper project rule
#   inside an ancestor's except decides there; a same-path or shallower rule (a global one) never fills a hole - the 2026-09-22
#   perm/fw union fix stands. A cwd that drifts into an excepted subtree is armed there: that is the hole working.
#
# THE P0 INVARIANT: every failure path resolves to ARMED. Missing file, malformed
# JSON, wrong-typed field, absent jq, bad args — all leave the gate on. A bypass is
# only ever granted by an affirmative, fully-validated match.
#
# CALL IT IN A SUBSHELL. Guards run `set -u`/`set -e`; Claude Code blocks only on
# exit 2 and lets any other non-zero through. A resolver crash inside the guard's own
# shell would abort the guard with status 1 and the tool would proceed — fail-OPEN.
#   if ( bypass_applies "$fam" "$cwd" "$tgt" ) 2>/dev/null; then exit 0; fi
#
# Session id comes from $BYPASS_SESSION_ID (guards export it). Empty is never matched
# — a file literally named "<family>-bypass-" must not bypass anything (SPEC reg. F4).

_bypass_file_for() {
  case "${1:-}" in
    ah)     printf 'ask-human-gate-bypass' ;;
    fw)     printf 'ask-bash-firewall-bypass' ;;
    qg)     printf 'ask-human-question-guard-bypass' ;;
    ac)     printf 'advisor-completion-guard-bypass' ;;
    pw)     printf 'advisor-prework-guard-bypass' ;;
    auto3c) printf 'autonomous-3c-bypass' ;;
    # eg/kg reuse the sentinel names that already existed (state/expertise-gate-off, run/keep-going-<sid>) so nothing a user
    # armed before the families were registered stops working. NOTE the shape: <file>[-<sid>], not <family>-bypass[-<sid>].
    eg)     printf 'expertise-gate-off' ;;
    kg)     printf 'keep-going' ;;
    cf)     printf 'confident-pick' ;;
    # `perm` is a KNOWN family with NO legacy sentinel: the permission layer is armed by
    # bin/permission-swap.sh, and its blacklists come from `perm` rules compiled into synthesized
    # ask rules. It prints nothing and returns 0 — callers use this function as the family-validity
    # check, so returning 1 here would make every `perm` rule silently inert, and inventing a
    # sentinel filename would advertise a file-based off-switch that nothing reads.
    perm)   return 0 ;;
    *)      return 1 ;;
  esac
}

# Canonicalise without requiring the path to exist. Payload cwd may carry symlinks, `..`, or a
# trailing slash; matching is component-wise so it must be normalised first.
#
# Returns NON-ZERO if the path cannot be canonicalised, and callers MUST treat that as "no bypass".
# There is deliberately NO raw-string fallback: an uncanonicalised
#   /path/to/your/project/projects/twes-in/api/../../other
# string-prefix-matches a rule on /path/to/your/project/projects/twes-in and would bypass a path that has ESCAPED
# the project entirely. realpath resolves it to /path/to/your/project/projects/other, which correctly stays armed.
# Verified fail-open 2026-09-22 — the earlier `|| printf '%s' "${p%/}"` fallback was wrong.
_bypass_canon() {
  local p="${1:-}"
  [[ -n "$p" ]] || return 1
  command -v realpath >/dev/null 2>&1 || return 1
  realpath -m -- "$p" 2>/dev/null || return 1
}

# Shared validation predicate. A rule must pass EVERY check to be usable.
# `.except // []` on the string "api/vendor" yields a truthy non-array whose [] expansion is
# empty — which would silently unprotect exactly the tree the user meant to protect. Hence
# explicit type checks rather than `//` defaults, and hence `all(.except[]; type=="string")`:
# "except": [123] must not read as "no exceptions".
_BYPASS_VRULE='
    # Segment-scoped glob -> regex. "*" matches exactly ONE path segment, never crossing "/".
    # That restriction is the whole safety property: a "*" that crossed slashes would make
    # /c/projects/*/state also match /c/projects/a/b/state and arm far more than intended, while
    # a mis-escaped metacharacter could silently match nothing and UNPROTECT the tree. Every
    # regex metacharacter is escaped first; only then is the bare "*" expanded.
    def globre:
      gsub("(?<c>[.^$+?()\\[\\]{}|\\\\])"; "\\" + .c)
      | gsub("\\*"; "[^/]*");

    def vrule0:
      (type == "object")
      and ((.guards | type) == "array")
      and (all(.guards[]; type == "string"))
      # kg (keep-going ON) and cf (confident-pick ON) must stay pure: their own rule, no level (an except is fine since row 26zu). See the family note at the top of this file.
      and (((.guards | index("kg")) == null)
           or ((.guards == ["kg"]) and (has("level") | not)))
      and (((.guards | index("cf")) == null)
           or ((.guards == ["cf"]) and (has("level") | not)))
      # expires: YYYY-MM-DD (valid through that local day) or YYYY-MM-DDTHH:MM:SSZ (a UTC instant). No offset form: the jq
      # fromdateiso8601 builtin rejects +02:00 and this machine runs {{TZ}}. Both are also parsed, so 2030-13-45 is invalid.
      and ((has("expires") | not)
           or (((.expires | type) == "string")
               and (.expires | test("^[0-9]{4}-[0-9]{2}-[0-9]{2}(T[0-9]{2}:[0-9]{2}:[0-9]{2}Z)?$"))
               and (.expires | (if length == 10 then . + "T00:00:00Z" else . end) | try (fromdateiso8601 | true) catch false)))
      # TOTAL plan D1: an optional bypass LEVEL. Absent = normal. Any other value (a typo, a boolean)
      # invalidates the WHOLE file like every other bad field - a mistyped "total" must never quietly
      # read as either level. bin/permission-swap.sh delegates to this predicate (step 5), so there is one copy.
      and ((has("level") | not) or (.level == "normal") or (.level == "total"))
      # Two shapes: a GLOBAL rule ({"global":true}, covers every cwd and target, takes no path / recursive / except) or a PATH rule.
      and (
        ( (.global == true) and (has("path") | not) and (has("recursive") | not) and (has("except") | not) )
        or
        ( (has("global") | not)
          and ((.path | type) == "string")
          and (.path | startswith("/"))
          and (.path != "/")
          and ((.path | contains("*")) | not)
          and ((has("recursive") | not) or ((.recursive | type) == "boolean"))
          and ((has("except") | not)
               or (((.except | type) == "array") and (all(.except[]; type == "string")))) )
      );

    # Every except entry is absolute, in normal form (no ., .. or empty component, no trailing /) and STRICTLY inside the rule
    # path (row 26zu): an entry outside it can never match a covered point, so it would be a silent no-op the user believes protects.
    def vexc: (has("except") | not) or (. as $r | all(.except[];
      startswith($r.path + "/") and (test("//|/\\.\\.?(/|$)|/$") | not)));
    def vrule: vrule0 and vexc;

    # Shared rule predicates. `. as $r` first: inside startswith(...) a bare .path is evaluated against the string being tested.
    def alive($today; $now): . as $r | ($r | has("expires") | not)
      or ($r.expires | if length == 10 then . >= $today else . > $now end);
    def cov($c): . as $r | ($r.global == true) or ($c == $r.path)
      or (($r.recursive // false) and ($c | startswith($r.path + "/")));
    def tcov($t): . as $r | ($r.global == true) or ($t == $r.path) or ($t | startswith($r.path + "/"));
    def plen: (.path // "") | length;

    # Except matching (row 26zu). exhit: on an except entry, does it match point $t (a glob: one segment per "*", anchored, the entry
    # and everything beneath; a literal: byte-identical to the pre-glob rule). exhits: on a rule. reach: the rule covers $t and its
    # except does not match it. holed: on the array of covering rules - some rule excepts $t and no strictly deeper one reaches it.
    def exhit($t): . as $e
      | if ($e | contains("*")) then ($t | test("^" + ($e | globre) + "(/.*)?$"))
        else ($t == $e or ($t | startswith($e + "/"))) end;
    def exhits($t): any((.except // [])[] | select(type == "string"); exhit($t));
    def reach($t): tcov($t) and (exhits($t) | not);
    def holed($t): . as $C | any($C[]; . as $r | ($r | exhits($t)) and (any($C[]; (plen > ($r | plen)) and reach($t)) | not));
'

# Print one human-readable line per problem; print nothing when the file is clean.
# Used by the statusline, by /gates-bypass --status, and runnable by hand:
#   bash -c '. ~/.claude/hooks/bypass-resolve.sh; bypass_rules_lint'
bypass_rules_lint() {
  local rules="${1:-${HOME:-}/.claude/state/gates-bypass-rules.json}"
  [[ -f "$rules" ]] || return 0
  command -v jq >/dev/null 2>&1 || { printf 'jq unavailable - rules cannot be validated\n'; return 0; }
  if ! jq -e . "$rules" >/dev/null 2>&1; then
    printf 'file is not valid JSON - every gate stays ARMED\n'; return 0
  fi
  jq -r '
    '"$_BYPASS_VRULE"'
    if (.rules | type) != "array" then "top-level .rules is missing or not an array"
    else
      ( [ .rules | to_entries[]
          | select((.value | vrule0) | not)
          # A glob in `path` gets its own, more precise line below; do not also report it here.
          # Two messages for one typo makes the alarm harder to act on, not louder.
          | select(((((.value | type) == "object") and ((.value.path | type) == "string")
                     and (.value.path | contains("*")))) | not)
          | "rule[\(.key)] (path=\(.value.path // "?")): bad type - a rule is EITHER {\"global\":true} (no path/recursive/except) OR a path rule: path an absolute string and not \"/\", recursive boolean, guards array of strings, except array of strings, expires YYYY-MM-DD, level \"normal\" or \"total\"" ] )
      +
      ( [ .rules | to_entries[]
          | select(((.value | type) == "object") and ((.value.path | type) == "string") and (.value.path | contains("*")))
          | "rule[\(.key)]: path \(.value.path) contains a glob - a rule root must be a concrete absolute path (globs are allowed only in except)" ] )
      +
      ( [ .rules | to_entries[] | select((.value | vrule0) and ((.value | vexc) | not)) | .key as $k | .value as $r
          | ($r.except[] | select((startswith($r.path + "/") and (test("//|/\\.\\.?(/|$)|/$") | not)) | not))
          | "rule[\($k)] (path=\($r.path)): except entry \(.) must be absolute, in normal form and strictly inside the rule path" ] )
      +
      ( [ (.rules | map(select(vrule)))
          | group_by(.path)[]
          | select(length > 1)
          | . as $g
          | ($g | map(.guards[])) as $all
          | select(($all | length) != ($all | unique | length))
          | "conflict: path \($g[0].path // "*global*") is declared more than once for the same guard - which rule wins is undefined" ] )
      | .[]
    end' "$rules" 2>/dev/null || printf 'rules could not be parsed - every gate stays ARMED\n'
}

_bypass_rules_ok() { [[ -z "$(bypass_rules_lint "${1:-}" 2>/dev/null)" ]]; }

# Log once per distinct rules-file state, not once per hook invocation — these hooks fire on
# every Bash/Edit call and would otherwise flood the log with the same line.
_bypass_log_invalid() {
  local rules="${1:-}" stamp sig
  sig=$(stat -c '%Y-%s' -- "$rules" 2>/dev/null || printf 'unknown')
  stamp="${HOME:-}/.claude/run/bypass-rules-invalid"
  [[ "$(cat "$stamp" 2>/dev/null || true)" == "$sig" ]] && return 0
  printf '%s' "$sig" > "$stamp" 2>/dev/null || true
  local why; why=$(bypass_rules_lint "$rules" 2>/dev/null | head -3 | tr '\n' ' ')
  if command -v log_obs >/dev/null 2>&1; then
    log_obs ERROR bypass-resolve "gates-bypass-rules.json INVALID - all gates stay armed: $why" 2>/dev/null || true
  else
    printf '%s | ERROR | bypass-resolve | gates-bypass-rules.json INVALID - all gates stay armed: %s\n' \
      "$(date +%Y-%m-%dT%H:%M:%S)" "$why" >> "${HOME:-}/.claude/logs/hooks-errors.log" 2>/dev/null || true
  fi
}

# Raise or retract the RULES-INVALID alarm. Idempotent, cheap, and the ONLY place that owns the
# marker file, so raise and clear can never disagree about it.
_bypass_rules_health() {
  local home="${HOME:-}" rules stamp
  [[ -n "$home" ]] || return 0
  rules="$home/.claude/state/gates-bypass-rules.json"
  stamp="$home/.claude/run/bypass-rules-invalid"
  if [[ ! -f "$rules" ]]; then
    [[ -f "$stamp" ]] && rm -f "$stamp" 2>/dev/null
    return 0
  fi
  if _bypass_rules_ok "$rules"; then
    [[ -f "$stamp" ]] && rm -f "$stamp" 2>/dev/null
  else
    _bypass_log_invalid "$rules"
  fi
  return 0
}

bypass_applies() {
  local fam="${1:-}" cwd_in="${2:-}" tgt_in="${3:-}"
  local home="${HOME:-}" sid="${BYPASS_SESSION_ID:-}"
  [[ -n "$fam" && -n "$home" ]] || return 1

  local file
  file=$(_bypass_file_for "$fam") || return 1

  # ── Rules health, evaluated BEFORE anything can short-circuit ───────────────────
  # This MUST come first. The legacy checks below return 0 on a sentinel hit, and on a machine
  # where every project carries legacy sentinels that return would mean an invalid rules file was
  # never linted, never logged and never surfaced — "strict and loud" would be strict and silent.
  # Costs one jq (~3 ms) per call, and only when a rules file exists at all.
  _bypass_rules_health

  # ── Legacy scopes (dual-read: existing sentinels keep working, byte-identically) ─
  # These key on the RAW payload cwd, exactly as the five hand-rolled blocks always did.
  # Do not "improve" them by canonicalising: that would silently change which sentinel
  # an existing project resolves to.
  # The walk itself lives in _bypass_grants so that bypass_level (below) can never disagree with it.
  local g
  g=$(_bypass_grants "$fam" "$cwd_in" "$tgt_in" first) || return 1
  [[ -n "$g" ]]
}

# The level a legacy sentinel carries in its CONTENT (TOTAL plan D1): exactly `total` after removing
# whitespace; empty or anything else = normal. Presence alone still GRANTS — content never withdraws a
# grant, so every sentinel written before levels existed means exactly what it meant.
_bypass_sentinel_level() {
  local c
  c=$(tr -d '[:space:]' < "$1" 2>/dev/null) || c=""
  [[ "$c" == "total" ]] && printf 'total\n' || printf 'normal\n'
}

# _bypass_grants <family> <cwd> <target> <first|all>
# Prints one line per applicable grant — its level, `normal` or `total` — and nothing when none applies.
# `first` stops at the first grant (bypass_applies needs only yes/no, and must not pay for the rules jq
# when a legacy sentinel already answers); `all` walks every source (bypass_level folds them).
_bypass_grants() {
  local fam="${1:-}" cwd_in="${2:-}" tgt_in="${3:-}" mode="${4:-first}"
  local home="${HOME:-}" sid="${BYPASS_SESSION_ID:-}" file f v
  file=$(_bypass_file_for "$fam") || return 1

  # ── Legacy scopes (dual-read: existing sentinels keep working, byte-identically) ─
  # These key on the RAW payload cwd, exactly as the five hand-rolled blocks always did.
  # Do not "improve" them by canonicalising: that would silently change which sentinel
  # an existing project resolves to.
  # A family with no sentinel filename (perm) has no legacy scopes at all — skip all three rather
  # than testing paths that would end in a bare directory name.
  if [[ -n "$file" ]]; then
    local -a cands=("$home/.claude/state/$file")
    [[ -n "$cwd_in" ]] && cands+=("$home/.claude/projects/$(printf '%s' "$cwd_in" | tr '/' '-')/state/$file")
    # Empty sid must never match — guards against a stray "<family>-bypass-" file.
    [[ -n "$sid" ]] && cands+=("$home/.claude/run/$file-$sid")
    for f in "${cands[@]}"; do
      if [[ -f "$f" ]]; then
        _bypass_sentinel_level "$f"
        [[ "$mode" == "first" || "$mode" == "sentinel" ]] && return 0
      fi
    done
  fi
  # mode `sentinel` (row 26zk): legacy scopes only - bypass_expiring asks whether a grant outlives its rules.
  [[ "$mode" == "sentinel" ]] && return 1

  # ── Rules file ─────────────────────────────────────────────────────────────────
  v=$(_bypass_rule_eval "$fam" "$cwd_in" "$tgt_in") || v=""
  [[ "$v" == BYPASS\ * ]] && printf '%s\n' "${v#BYPASS }"
  return 0
}

# bypass_level <family> <cwd>   ->  prints none | normal | total   (TOTAL plan, step 1)
# The level of the bypass in force for <family> at <cwd>. TOTAL is cwd-based (D2), so there is no target.
# ANY covering grant at total makes the cwd total — the four sources are an independent OR. Among rules
# the longest-path match decides, exactly as for the grant: a narrow normal rule carves a normal subtree
# out of a broad total one. Every failure path prints `none` or `normal`, never `total`.
# Invariant (pinned by test-bypass-resolve.sh): bypass_applies <fam> <cwd> grants  <=>  level != none.
bypass_level() {
  local fam="${1:-}" cwd_in="${2:-}" g
  if [[ -z "$fam" || -z "${HOME:-}" ]] || ! _bypass_file_for "$fam" >/dev/null; then
    printf 'none\n'; return 0
  fi
  _bypass_rules_health
  g=$(_bypass_grants "$fam" "$cwd_in" "" all) || g=""
  if [[ -z "$g" ]]; then printf 'none\n'
  elif grep -qx total <<<"$g"; then printf 'total\n'
  else printf 'normal\n'; fi
}

# Rules ONLY — ignores legacy sentinels entirely.
# /gates-bypass --status needs this to report a HONEST "rule" column: with dual-read, asking
# bypass_applies would answer "yes" whenever a legacy sentinel exists, making the grid claim a
# rule is in force when none is. Same matching, different question.
bypass_rule_applies() {
  local v
  v=$(_bypass_rule_eval "${1:-}" "${2:-}" "${3:-}") || return 1
  [[ "$v" == BYPASS\ * ]]
}

# Prints `BYPASS <level>` when a rule grants, `ARMED` (or nothing, non-zero) otherwise.
_bypass_rule_eval() {
  local fam="${1:-}" cwd_in="${2:-}" tgt_in="${3:-}"
  local home="${HOME:-}"
  [[ -n "$fam" && -n "$home" ]] || return 1
  _bypass_file_for "$fam" >/dev/null || return 1

  # Rules do component-wise prefix matching, which is only sound on canonical paths.
  # If canonicalisation is unavailable, grant nothing.
  local cwd tgt=""
  cwd=$(_bypass_canon "$cwd_in") || return 1
  if [[ -n "$tgt_in" ]]; then
    tgt=$(_bypass_canon "$tgt_in") || return 1
  fi

  local rules="$home/.claude/state/gates-bypass-rules.json"
  [[ -f "$rules" && -r "$rules" ]] || return 1
  command -v jq >/dev/null 2>&1 || return 1

  local today verdict
  today=$(date +%Y-%m-%d 2>/dev/null) || return 1
  local now; now=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null) || return 1

  # STRICT: any lint problem invalidates the WHOLE file and nothing is granted. A partially
  # understood safety config is more dangerous than none — a typo must never quietly narrow
  # protection. LOUD: see bypass_rules_lint + _bypass_log_invalid below; hook stderr is
  # swallowed by the calling subshell, so the signal goes to the obs log and the statusline.
  if ! _bypass_rules_ok "$rules"; then
    _bypass_log_invalid "$rules"
    return 1
  fi

  verdict=$(jq -r --arg fam "$fam" --arg cwd "$cwd" --arg tgt "$tgt" --arg today "$today" --arg now "$now" '
    '"$_BYPASS_VRULE"'
    if (.rules | type) != "array" then "ARMED"
    else
      [ .rules[]
        | select(vrule)
        | . as $r
        | select($r | alive($today; $now))
        # NOTE: $r.path, never .path. Inside startswith(...) the argument is evaluated
        # against the INPUT of startswith ($cwd, a string) — a bare .path there raises
        # "Cannot index string with string" and the whole filter dies.
        | select($r | cov($cwd))
      ] as $C
      # The point: the target when the guard knows one, else the cwd (row 26zu).
      | (if $tgt != "" then $tgt else $cwd end) as $p
      | [ $C[] | . as $r | select(any($r.guards[]; . == $fam)) | select(($r | exhits($p)) | not) ] as $m
      | if ($C | holed($p)) then "ARMED"
        elif ($m | length) == 0 then "ARMED"
        else
          ($m | sort_by(plen) | last) as $best
          # A rule scopes the TARGET as well as the cwd. Without this, standing in a bypassed
          # project and editing /etc/passwd (or ../other/x) would be ungated — the bypass would
          # leak to the whole filesystem. Verified fail-open 2026-09-22.
          | if ($tgt != "") and (($best | tcov($tgt)) | not)
            then "ARMED" else ("BYPASS " + ($best.level // "normal")) end
        end
    end' "$rules" 2>/dev/null) || return 1

  printf '%s\n' "$verdict"
}

# ── Cross-family except union ──────────────────────────────────────────────────
# bypass_except_hit <cwd> <target>
#   0 = <target> lies inside the except list of SOME rule covering <cwd>, in ANY family
#   non-zero = it does not (and every failure path lands here too)
#
# THE INVARIANT: a bypass GRANT is family-scoped; an `except` is PROTECTIVE and unions across
# families. A `perm` rule that blacklists api/vendor means "this subtree is protected", and a Bash
# write into it must not be waved through by the `fw` family merely because fw's own rule carries
# no except of its own. Concretely this closed a confirmed hole: without the union a synthesized `ask`
# rule made the Edit tool prompt while `sed -i .../api/vendor/foo.php` stayed silent.
# PRODUCTION NOTE (2026-09-24): the firewall no longer calls this per target — `bypass_batch` answers every
# target in one pass and its X column MUST equal this function (parity pinned in test-bypass-resolve.sh).
# This is the reference semantics; keep them in lockstep.
#
# Direction of error matters and is deliberate: the union can only ever ADD friction. A false 0
# here re-arms a gate that would otherwise be bypassed (annoying, safe); a false non-zero leaves
# the caller exactly where it already was (no protection is removed by this function).
#
# Deliberately NOT the same shape as bypass_applies:
#   - no family filter — that is the whole point;
#   - no longest-match "best rule" — protection is a union, so EVERY covering rule contributes.
#     Taking only the narrowest rule's except would let a narrow grant silently drop a broad
#     rule's blacklist. The one exception (row 26zu): a STRICTLY DEEPER covering rule that reaches the
#     target decides there - an ancestor's except is a hole in the ancestor, not a veto over that rule (holed).
# Expiry still applies: an expired rule is simply absent, so it contributes no except either.
# bypass_any_except <cwd>
#   0 = SOME rule covering <cwd>, in ANY family, carries a non-empty except list
#
# The target-less companion to bypass_except_hit: before the classifier runs no target exists, so the
# firewall asks this to decide whether the classifier must EXPORT its target list for the per-target
# except check. (The tokeniser itself always runs since the fast path was removed, 2026-09-23.) Without
# this, a `perm` rule's except could never reach the Bash path.
bypass_any_except() {
  local cwd_in="${1:-}" home="${HOME:-}"
  [[ -n "$home" ]] || return 1
  local rules="$home/.claude/state/gates-bypass-rules.json"
  [[ -f "$rules" && -r "$rules" ]] || return 1
  command -v jq >/dev/null 2>&1 || return 1
  local cwd; cwd=$(_bypass_canon "$cwd_in") || return 1
  _bypass_rules_ok "$rules" || return 1
  local today; today=$(date +%Y-%m-%d 2>/dev/null) || return 1
  local now; now=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null) || return 1

  local n
  n=$(jq -r --arg cwd "$cwd" --arg today "$today" --arg now "$now" '
    '"$_BYPASS_VRULE"'
    if (.rules | type) != "array" then 0
    else
      [ .rules[]
        | select(vrule)
        | . as $r
        | select($r | alive($today; $now))
        | select($r | cov($cwd))
        | (($r.except // [])[])
        | select(type == "string")
      ] | length
    end' "$rules" 2>/dev/null) || return 1

  [[ "$n" =~ ^[0-9]+$ && "$n" -gt 0 ]]
}

bypass_except_hit() {
  local cwd_in="${1:-}" tgt="${2:-}" home="${HOME:-}"
  [[ -n "$home" && -n "$tgt" ]] || return 1
  local rules="$home/.claude/state/gates-bypass-rules.json"
  [[ -f "$rules" && -r "$rules" ]] || return 1
  command -v jq >/dev/null 2>&1 || return 1
  local cwd; cwd=$(_bypass_canon "$cwd_in") || return 1
  local tgtc; tgtc=$(_bypass_canon "$tgt") || return 1
  _bypass_rules_ok "$rules" || return 1
  local today; today=$(date +%Y-%m-%d 2>/dev/null) || return 1
  local now; now=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null) || return 1

  local n
  n=$(jq -r --arg cwd "$cwd" --arg tgt "$tgtc" --arg today "$today" --arg now "$now" '
    '"$_BYPASS_VRULE"'
    if (.rules | type) != "array" then 0
    else
      [ .rules[]
        | select(vrule)
        | . as $r
        | select($r | alive($today; $now))
        | select($r | cov($cwd))
      ]
      # Union over every covering rule, minus what a strictly deeper rule reaches (row 26zu).
      | if holed($tgt) then 1 else 0 end
    end' "$rules" 2>/dev/null) || return 1

  [[ "$n" =~ ^[0-9]+$ && "$n" -gt 0 ]]
}

# ── Batched resolver (2026-09-23, firewall-hardening step 6) ─────────────────────
# bypass_batch <family> <cwd> <targets-file>
#   prints ONE line per target line, in order: <G|A><X|->
#     G/A = what `bypass_applies <family> <cwd> <target>` answers (G = bypass, A = armed)
#     X/- = what `bypass_except_hit <cwd> <target>` answers (X = inside SOME family's except)
#   exit non-zero = the batch could not be computed; the CALLER MUST FAIL CLOSED (no bypass, and an
#   ask when an except list is in play — a missed blacklist hit is the failure being guarded against).
# Why it exists: the per-target functions cost ~2 jq calls per target (~27 ms each under load), and a
# PreToolUse hook that outruns its timeout FAILS OPEN — "doesn't block the tool call" (hooks.md). One
# lint + one realpath + one jq for the whole command. Parity with the per-target functions is the
# contract, pinned by test-bypass-resolve.sh; do not change the semantics here without changing both.
bypass_batch() {
  local fam="${1:-}" cwd_in="${2:-}" list="${3:-}" home="${HOME:-}" sid="${BYPASS_SESSION_ID:-}"
  [[ -n "$fam" && -n "$home" && -n "$list" && -r "$list" ]] || return 1
  local file; file=$(_bypass_file_for "$fam") || return 1
  _bypass_rules_health
  local -a tg=() canon=()
  mapfile -t tg < "$list" || return 1
  local n=${#tg[@]}
  (( n )) || return 0

  # Legacy scopes grant EVERY target (they never scoped targets) — same order and keys as bypass_applies.
  local legacy=0
  if [[ -n "$file" ]]; then
    if [[ -f "$home/.claude/state/$file" ]]; then legacy=1
    elif [[ -n "$cwd_in" && -f "$home/.claude/projects/$(printf '%s' "$cwd_in" | tr '/' '-')/state/$file" ]]; then legacy=1
    elif [[ -n "$sid" && -f "$home/.claude/run/$file-$sid" ]]; then legacy=1
    fi
  fi
  local g0='A'; (( legacy )) && g0='G'

  local rules="$home/.claude/state/gates-bypass-rules.json" cwd today out
  # Anything that makes the per-target functions answer "no rule grant, no except hit" yields the same
  # here, line for line: no rules file, no jq, an uncanonicalisable cwd, an invalid rules file.
  if [[ ! -f "$rules" || ! -r "$rules" ]] || ! command -v jq >/dev/null 2>&1 \
     || ! cwd=$(_bypass_canon "$cwd_in") || ! _bypass_rules_ok "$rules"; then
    [[ -f "$rules" ]] && command -v jq >/dev/null 2>&1 && ! _bypass_rules_ok "$rules" && _bypass_log_invalid "$rules"
    printf "${g0}-\n%.0s" $(seq "$n"); return 0
  fi
  today=$(date +%Y-%m-%d 2>/dev/null) || return 1
  local now; now=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null) || return 1
  command -v realpath >/dev/null 2>&1 || return 1
  mapfile -t canon < <(realpath -m -- "${tg[@]}" 2>/dev/null) || return 1
  (( ${#canon[@]} == n )) || return 1          # never shift an answer onto the wrong target

  out=$(jq -r --arg fam "$fam" --arg cwd "$cwd" --arg today "$today" --arg now "$now" --arg g0 "$g0" '
    '"$_BYPASS_VRULE"'
    (if (.rules | type) != "array" then []
     else [ .rules[] | select(vrule) | . as $r
            | select($r | alive($today; $now))
            | select($r | cov($cwd)) ]
     end) as $cov
    | [ $cov[] | . as $r | select(any($r.guards[]; . == $fam)) ] as $fm
    | $ARGS.positional[] as $t
    | ($cov | holed($t)) as $h
    | [ $fm[] | select(exhits($t) | not) ] as $m
    | (if $g0 == "G" then "G"
       elif $h or ($m | length) == 0 then "A"
       elif ((($m | sort_by(plen) | last) | tcov($t)) | not) then "A"
       else "G" end)
      + (if $h then "X" else "-" end)' "$rules" --args "${canon[@]}" 2>/dev/null) || return 1
  [[ $(printf '%s\n' "$out" | wc -l) -eq $n ]] || return 1
  printf '%s\n' "$out"
}

# ── Pre-expiry warning feed (permission-unification step 5) ─────────────────────────────────────────────
# bypass_expiring <horizon-seconds>
#   prints "<expires>\t<path|*global*>\t<guards,comma-joined>" (soonest first) for every valid, still-live rule whose TIMESTAMP expiry lies
#   within the horizon. Date-only expiries (no time of day) and rules without an expiry are never listed. Prints nothing and returns
#   non-zero on any failure: a warning feed must never break the caller (the statusline). MACHINE-wide: gates-status / gates-bypass.
# bypass_expiring <horizon-seconds> <cwd> <family>...                                    (cwd mode, row 26zk, user 2026-10-16 00:37)
#   prints "<expires>\t<path|*global*>\t<family>" (soonest first) for each asked family whose RULE grant at <cwd> ends inside the horizon:
#   the latest expiry among the covering live rules (rule scopes OR, same selection as bypass_rule_expiry), when that is a timestamp.
#   Nothing for a family when a covering rule has no expiry or a legacy sentinel grants it here (_bypass_grants sentinel mode): the grant
#   does not end. Except lists apply to the cwd (row 26zu): a holed cwd lists nothing, an excepting rule is skipped. Which families count is the
#   caller's meaning (the statusline badge asks the gates + eg, never the enables kg/cf). An empty cwd or an unknown family -> nothing, non-zero.
bypass_expiring() {
  local h="${1:-}" home="${HOME:-}" rules now nowiso lim cwd="" raw="" today f
  local -a fams=()
  [[ "$h" =~ ^[0-9]{1,9}$ ]] || return 1
  if (( $# >= 2 )); then
    raw="${2:-}"
    cwd=$(_bypass_canon "$raw") || return 1
    shift 2
    (( $# > 0 )) || return 1
    for f in "$@"; do
      _bypass_file_for "$f" >/dev/null || return 1
      # The RAW cwd, as bypass_applies passes it: legacy scopes are never canonicalised (_bypass_grants), the rules are.
      _bypass_grants "$f" "$raw" "" sentinel >/dev/null || fams+=("$f")
    done
    (( ${#fams[@]} > 0 )) || return 0
  fi
  [[ -n "$home" ]] || return 1
  rules="$home/.claude/state/gates-bypass-rules.json"
  [[ -f "$rules" && -r "$rules" ]] || return 1
  command -v jq >/dev/null 2>&1 || return 1
  _bypass_rules_ok "$rules" || return 1
  now=$(date -u +%s 2>/dev/null) || return 1
  [[ "$now" =~ ^[0-9]{1,12}$ ]] || return 1
  nowiso=$(date -u -d "@$now" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null) || return 1
  lim=$(date -u -d "@$(( now + 10#$h ))" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null) || return 1
  if [[ -n "$cwd" ]]; then
    today=$(date +%Y-%m-%d 2>/dev/null) || return 1
    jq -r --arg cwd "$cwd" --arg today "$today" --arg now "$nowiso" --arg lim "$lim" '
      '"$_BYPASS_VRULE"'
      if (.rules | type) != "array" then empty
      else
        [ .rules[] | select(vrule) | . as $r | select($r | alive($today; $now)) | select($r | cov($cwd)) ] as $c
        | ($c | holed($cwd)) as $h
        | [ $ARGS.positional[] as $f
            | select($h | not)
            | [ $c[] | . as $r | select(any($r.guards[]; . == $f)) | select(($r | exhits($cwd)) | not) ] as $m
            | select(($m | length) > 0 and all($m[]; has("expires")))
            | ($m | max_by(.expires | if length == 10 then . + "T23:59:59Z" else . end)) as $last
            | select(($last.expires | length) == 20 and $last.expires > $now and $last.expires <= $lim)
            | [$last.expires, ($last.path // "*global*"), $f] ]
        | sort_by(.[0], .[2])[] | @tsv
      end' "$rules" --args "${fams[@]}" 2>/dev/null
    return
  fi
  jq -r --arg now "$nowiso" --arg lim "$lim" '
    '"$_BYPASS_VRULE"'
    if (.rules | type) != "array" then empty
    else
      [ .rules[] | select(vrule) | select(has("expires") and (.expires | length) == 20)
        | select(.expires > $now and .expires <= $lim) ]
      | sort_by(.expires)[]
      | [.expires, (.path // "*global*"), (.guards | join(","))] | @tsv
    end' "$rules" 2>/dev/null
}

# bypass_rule_expiry <family> <cwd>
#   prints the LATEST `expires` among the valid, live rules that grant <family> at <cwd> — the moment the RULE-based grant ends
#   (rule scopes are an OR, so the grant lasts until the last covering rule expires). Prints nothing when no rule covers, when ANY
#   covering rule has no expiry (the grant never ends) or on any failure: it feeds a badge (the keep-going `rule,4d`), never a gate.
#   Sentinels have no expiry and are the caller's business. A date-only expiry is valid through that local day, so for ranking it
#   counts as 23:59:59Z; the value printed is the rule's own string. Same selection as _bypass_rule_eval's covering set: a rule whose
#   except matches the cwd is not in it, and a holed cwd prints nothing (row 26zu).
bypass_rule_expiry() {
  local fam="${1:-}" cwd_in="${2:-}" home="${HOME:-}" rules cwd today now
  [[ -n "$fam" && -n "$home" ]] || return 1
  _bypass_file_for "$fam" >/dev/null || return 1
  cwd=$(_bypass_canon "$cwd_in") || return 1
  rules="$home/.claude/state/gates-bypass-rules.json"
  [[ -f "$rules" && -r "$rules" ]] || return 1
  command -v jq >/dev/null 2>&1 || return 1
  _bypass_rules_ok "$rules" || return 1
  today=$(date +%Y-%m-%d 2>/dev/null) || return 1
  now=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null) || return 1
  jq -r --arg fam "$fam" --arg cwd "$cwd" --arg today "$today" --arg now "$now" '
    '"$_BYPASS_VRULE"'
    if (.rules | type) != "array" then empty
    else
      [ .rules[] | select(vrule) | . as $r
        | select($r | alive($today; $now))
        | select($r | cov($cwd)) ] as $c
      | [ $c[] | . as $r | select(any($r.guards[]; . == $fam)) | select(($r | exhits($cwd)) | not) ] as $m
      | if ($c | holed($cwd)) or ($m | length) == 0 or any($m[]; has("expires") | not) then empty
        else ($m | map(.expires | {e: ., k: (if length == 10 then . + "T23:59:59Z" else . end)}) | max_by(.k) | .e) end
    end' "$rules" 2>/dev/null
}

# bypass_cf_text <spec|autonomous>
#   prints the confident-pick (cf) tiered rule as ONE line, worded for the mode (row 26zg; user rulings 2026-10-15 12:10 / 12:42 and the
#   no_ask window ruling). The single source for every surface that tells the model: the SessionStart banner, the subagent brief and the
#   per-prompt injection (hooks/ask-human-gate-arm.sh) - so they cannot drift. Pure text: no state read here; the caller resolves `cf`.
bypass_cf_text() {
  local lead
  if [[ "${1:-}" == autonomous ]]; then
    lead="replaces autonomous mode's mid-task question policy (the recommended option is no longer taken by default):"
  else
    lead="replaces spec mode's mid-task question policy (the size gate still asks):"
  fi
  printf '%s %s %s\n' "▸ CONFIDENT PICKS (cf): on - $lead" \
    "PICK when an objective test decides (a recorded ruling dictates it, or it is the only option that passes a rule or test); when none does but the choice is reversible and in scope, pick only if advisor() agrees; otherwise ASK. Log every pick as ASSUMED (review) citing its basis." \
    "Always ask: destructive steps, the 5-round certification cap, and grey cases when advisor() is unavailable. Under a no_ask unattended window a grey case advisor() did not settle is PARKED (logged to logs/unattended-parked.ndjson, that branch skipped), never auto-picked."
}
