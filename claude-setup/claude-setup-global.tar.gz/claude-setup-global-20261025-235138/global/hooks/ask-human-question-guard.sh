#!/usr/bin/env bash
# Stop hook: backstop for the AskUserQuestion rule (global CLAUDE.md "Presenting options"). If the
# assistant's final user-facing text ends with a question ('?') but AskUserQuestion was NOT used in the
# turn, block the stop with a reminder so the question is re-asked via AskUserQuestion.
# Conservative by design (false-NEGATIVE-leaning): only inspects the last non-blank, non-code line;
# honors stop_hook_active (no loop); QGUARD_OFF=1 disables. Transcript schema: one content-block per
# JSONL line, so a turn = all lines after the last 'user' entry.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

[[ "${QGUARD_OFF:-}" == "1" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

QG_CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
QG_SID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)

# All three legacy sentinel scopes PLUS recursive path rules now resolve in one shared place.
# Called in a SUBSHELL on purpose: this hook runs `set -u`, and Claude Code blocks only on exit 2 —
# any other non-zero lets the stop through. A resolver crash evaluated in our own shell would abort
# the guard with status 1 and fail OPEN. The subshell keeps every failure path at "gate stays armed".
# Stop hooks have no target path, so except-lists are skipped by construction (deliberate: a
# cwd-keyed except would re-create the self-sealing cwd-drift stall).
# Bypassed = ADVISORY (framework-health step 7): the same check runs and never blocks; a free-text closing question becomes one
# qg review event. QGUARD_OFF=1 above stays a full off (it also stops the unlogged-choice detector below).
ADV=0
if ( BYPASS_SESSION_ID="$QG_SID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
     bypass_applies qg "$QG_CWD" ) 2>/dev/null; then
  ADV=1
fi
# The unlogged-choice detector is an ah producer (AGREED 2026-10-07 21:34) living in this Stop hook so that no new registration
# is needed: it runs only while ah is bypassed (autonomous mode), where a choice must be logged as ASSUMED (review).
AH_ADV=0
if ( BYPASS_SESSION_ID="$QG_SID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
     bypass_applies ah "$QG_CWD" ) 2>/dev/null; then
  AH_ADV=1
fi
queue() {   # queue <gate> <would> <rule> <detail> - fire and forget: its output is discarded, its status ignored (no set -e)
  python3 "$SCRIPT_DIR/../bin/lib/bypass_review.py" add --gate "$1" --tool Stop --would "$2" --action allowed --rule "$3" \
    --detail "$4" --cwd "$QG_CWD" --sid "$QG_SID" >/dev/null 2>&1
}

# Avoid loops: if we already blocked once this stop-cycle, let it through.
[[ "$(printf '%s' "$INPUT" | jq -r '.stop_hook_active // false' 2>/dev/null)" == "true" ]] && exit 0

TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
[[ -n "$TRANSCRIPT" && -f "$TRANSCRIPT" ]] || exit 0

# Parse the last turn (lines after the last prompt-like 'user' entry: not a tool_result, a skill body (isMeta), a compact summary or
# a task notification, a `!` line or a built-in local command): gather assistant text + tool names. Anchor shared byte-for-byte with advisor-prework-guard.sh (why: its comment).
# tail bounds cost; jq -R fromjson? tolerates a partial first line from tail.
FILTER='
  . as $a
  | ([range(0; ($a|length)) | select($a[.].type=="user"
       and ($a[.].isMeta // false) != true and ($a[.].isCompactSummary // false) != true
       and ($a[.].origin.kind // "") != "task-notification"
       and (($a[.].message.content|type)!="string" or ($a[.].message.content|test("^\\s*<(bash-(input|stdout|stderr)|local-command-[a-z]+|command-name)>")|not))
       and (($a[.].message.content|type)=="string"
            or ([$a[.].message.content[]?|select(.type=="tool_result")]|length)==0))] | last) as $u0
  | (($u0 // -1) + 1) as $start
  | {
      used_auq: ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="tool_use") | .name ] | any(. == "AskUserQuestion")),
      logged:   ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="tool_use") | (.input | tostring) ]
                   | any(test("--append-decision|ASSUMED \\(review\\)"))),
      text:     ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="text") | .text ] | join("\n"))
    }'
RES=$(tail -n 800 "$TRANSCRIPT" 2>/dev/null | jq -Rc 'fromjson? // empty' 2>/dev/null | jq -s "$FILTER" 2>/dev/null || true)
[[ -z "$RES" ]] && exit 0

USED_AUQ=$(printf '%s' "$RES" | jq -r '.used_auq' 2>/dev/null || echo false)
TEXT=$(printf '%s' "$RES" | jq -r '.text' 2>/dev/null || echo "")

# Unlogged-choice detector - BEFORE the qg verdict, because an armed qg exits 2 below and "ah bypassed, qg armed" is a legal
# config. A first-person choice in the turn text, no AskUserQuestion (the user decided) and no tool input carrying
# --append-decision or "ASSUMED (review)" -> one ah candidate; false positives are rejected in review.
if [[ "$AH_ADV" == 1 && "$USED_AUQ" != "true" && "$(printf '%s' "$RES" | jq -r '.logged' 2>/dev/null)" != "true" ]]; then
  # Table rows and blockquotes are skipped (as for the qg last line), and "I'll pick/choose" is not matched: replayed over a
  # 87-prompt autonomous session (2026-10-08) those gave 8 of 9 hits and none was a design choice ("I'll pick it up when ...").
  CHOICE=$(printf '%s\n' "$TEXT" | grep -vE '^[[:space:]]*(\||>)' | grep -m1 -iE "\bI('ve| have)? (chose|chosen|picked|went with|opted for|decided|settled on)\b|\bI('m| am) (going|choosing|picking) with\b|\bI('ll| will) (go with|opt for)\b" | cut -c1-160)
  if [[ -n "$CHOICE" ]]; then
    queue ah ask 'choice without an ASSUMED entry' "$CHOICE"
    log_obs INFO ask-human-question-guard "advisory: queued a choice without an ASSUMED entry" 2>/dev/null || true
  fi
fi

# If AskUserQuestion was used this turn, the rule was honored → pass.
[[ "$USED_AUQ" == "true" ]] && exit 0
[[ -z "$TEXT" || "$TEXT" == "null" ]] && exit 0

# Last non-blank line; skip code fences / blockquotes / table rows / indented code (false positives).
last_line=$(printf '%s\n' "$TEXT" | sed 's/[[:space:]]*$//' | grep -v '^[[:space:]]*$' | tail -1)
case "$last_line" in
  '```'* | '>'* | '|'* | '    '*) exit 0 ;;
esac

# The last 100 characters. `${x: -100}` is EMPTY for a shorter line (bash yields nothing when a negative offset exceeds the
# length), which is why the block message used to print `Final line: ""` for every short question.
TAIL=$last_line; (( ${#TAIL} > 100 )) && TAIL=${TAIL: -100}

if [[ "$last_line" == *'?' ]]; then
  if [[ "$ADV" == 1 ]]; then
    queue qg block 'free-text closing question' "$TAIL"
    log_obs INFO ask-human-question-guard "advisory: queued a free-text question: $TAIL" 2>/dev/null || true
    exit 0
  fi
  {
    echo "⛔ END-OF-TURN QUESTION NOT ASKED VIA AskUserQuestion"
    echo "   Final line: \"$TAIL\""
    echo "   CLAUDE.md (Presenting options): ALL user-facing questions MUST use AskUserQuestion — zero exceptions."
    echo "   Re-ask this via AskUserQuestion (recommended option first). Disable backstop: QGUARD_OFF=1"
  } >&2
  log_obs WARN ask-human-question-guard "blocked free-text question: $TAIL" 2>/dev/null || true
  exit 2
fi
exit 0
