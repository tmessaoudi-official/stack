#!/usr/bin/env bash
# PreCompact hook (matcher: auto): auto-generate handoff note before compaction.
# Reads stdin JSON: {session_id, transcript_path, cwd, compact_type, hook_event_name}
# Calls claude -p (model: SR_MODEL_HANDOFF > table hooks.precompact-handoff > SR_MODEL > claude-haiku-5-5) to write handoff.md. Exits 0 to allow compaction.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
CWD=$(printf '%s'        "$INPUT" | jq -r '.cwd           // empty' 2>/dev/null || true)
SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id    // empty' 2>/dev/null || true)
[[ -z "$CWD" && -n "${CLAUDE_PROJECT_DIR:-}" ]] && CWD="$CLAUDE_PROJECT_DIR"
if [[ -z "$CWD" ]]; then
  CWD="$PWD"
  log_obs WARN precompact-handoff "CLAUDE_PROJECT_DIR unset — falling back to PWD ($CWD); handoff may be misrouted" 2>/dev/null || true
fi

log_obs INFO precompact-handoff "triggered (cwd=$CWD)" 2>/dev/null || true

if [[ -z "$TRANSCRIPT" || ! -f "$TRANSCRIPT" ]]; then
  log_obs WARN precompact-handoff "no transcript — skipping handoff generation" 2>/dev/null || true
  exit 0
fi

# ── Derive handoff path from cwd ──────────────────────────────────────────────
SLUG=$(printf '%s' "$CWD" | sed 's|/|-|g')
HANDOFF_DIR="$HOME/.claude/projects/${SLUG}/memory/sessions"
HANDOFF_FILE="$HANDOFF_DIR/handoff.md"
mkdir -p "$HANDOFF_DIR" || { log_obs ERROR precompact-handoff "mkdir failed for $HANDOFF_DIR — handoff lost" 2>/dev/null || true; exit 0; }

# A handoff whose LAST line is <!-- manual --> is human-curated. stop-context-bar.sh honours
# the same rule; this writer did not, so a /handoff saved deliberately just before a /compact
# was replaced by the Haiku summary (SPEC §6 item 45). Checked before the model call, so it
# also saves the round-trip. The rule is the trailing stamp, never a match anywhere in the
# file — see _handoff_is_manual in log-helpers.sh for why grep-anywhere froze 25 handoffs.
if [[ -f "$HANDOFF_FILE" ]] && _handoff_is_manual "$HANDOFF_FILE"; then
  log_obs INFO precompact-handoff "manual handoff present — left untouched: $HANDOFF_FILE" 2>/dev/null || true
  exit 0
fi

# ── Extract the last 40 TEXT turns from the transcript ───────────────────────
# Empty turns are dropped BEFORE the tail: in a tool-heavy session most entries are a bare tool_use (assistant) or tool_result (user), and
# taking the last 30 ENTRIES left 28 of them empty (measured 2026-10-09). `-r` emits raw text: without it the excerpt was one JSON-encoded
# string with literal \n escapes. The 8000-character cap keeps the NEWEST end and slices by codepoint (a byte `tail -c` could split a UTF-8 character). Tests T14/T14b.
EXCERPT=$(jq -Rrs '
  def txt: [.message?.content? |
      if type == "string" then .
      elif type == "array" then (.[] | select(.type? == "text") | .text)
      else "" end] | join(" ");
  split("\n") |
  map(select(length > 0) | try fromjson catch null) |
  map(select(. != null)) |
  map(select(.type? == "user" or .type? == "assistant")) |
  map(if .type == "user" then {w: "USER", t: (txt | .[0:400])} else {w: "CLAUDE", t: (txt | .[0:300])} end) |
  map(select(.t | test("\\S"))) |
  map(.w + ": " + .t) |
  .[(-40):] |
  join("\n---\n") |
  .[(-8000):]
' < "$TRANSCRIPT" 2>/dev/null || true)

if [[ -z "$EXCERPT" ]]; then
  log_obs WARN precompact-handoff "empty excerpt — skipping handoff generation" 2>/dev/null || true
  exit 0
fi

# ── Build prompt from handoff skill (single source of truth for the note's FORMAT and RULES) ───────
# Only the slice from the skill's `Format:` line up to (not including) `After writing the file` is sent: the rest is the INTERACTIVE
# procedure (derive a path, write the file, append <!-- manual -->, say "Saved."), which a tool-less model copied INTO the note
# (framework-health known issue, 2026-10-08). Either anchor missing -> the built-in format below (hooks/tests T11-T13).
HANDOFF_SKILL="$HOME/.claude/skills/handoff/SKILL.md"
PROMPT_FILE=$(mktemp /tmp/precompact-handoff-XXXXXX.txt)
trap 'rm -f "$PROMPT_FILE"' EXIT
HANDOFF_FORMAT=""
if [[ -f "$HANDOFF_SKILL" ]] && grep -q '^Format:$' "$HANDOFF_SKILL" && grep -q '^After writing the file' "$HANDOFF_SKILL"; then
  HANDOFF_FORMAT=$(awk '/^Format:$/{on=1} /^After writing the file/{on=0} on' "$HANDOFF_SKILL")
fi

{
  printf 'You are generating a session handoff note from a transcript excerpt (not a live session).\n'
  printf 'Follow the format and rules below exactly. Output ONLY the handoff note — no confirmation, no "Saved.", nothing else.\n'
  printf 'Your own permission mode (plan mode included) belongs to this note-writing call, not to the session: never mention it.\n\n'
  if [[ -n "$HANDOFF_FORMAT" ]]; then
    printf '%s\n' "$HANDOFF_FORMAT"
  else
    printf '## State\n{done/not done, files modified}\n\n## Next\n{1-3 items, priority order}\n\n'
    printf 'Rules: under 25 lines. Forward-looking only. If nothing to hand off: "No active work."\n'
  fi
  printf '\n\nHere is the recent session transcript:\n---\n'
  printf '%s\n' "$EXCERPT"
  printf '\n---\nWrite the handoff note now:\n'
} > "$PROMPT_FILE"

# ── Call Haiku ────────────────────────────────────────────────────────────────
_MO="$(dirname "${BASH_SOURCE[0]}")/../bin/model-override.sh"   # the user's override table (hooks.precompact-handoff): env knob > table > SR_MODEL > haiku
_mo_get() { [[ -f "$_MO" ]] || return 0; bash "$_MO" get hook "$1" 2>/dev/null; }   # returns 0 when the helper is missing: under set -e a bare `[[ ]] && …` in $( ) killed the hook (reproduced)
HANDOFF_MODEL="${SR_MODEL_HANDOFF:-$(_mo_get precompact-handoff)}"
HANDOFF_MODEL="${HANDOFF_MODEL:-${SR_MODEL:-claude-haiku-5-5}}"  # D12.3: haiku by default (headless, cannot ask); raise this one class with SR_MODEL_HANDOFF if handoffs lose state
# claude-haiku-5-5 since 2026-10-09 (held on 4.5 from 2026-10-08): this headless call inherits settings.json defaultMode "plan", and the
# prompt USED TO BE the whole interactive /handoff skill, so 5.5 wrote "plan mode is active, nothing written" into the note. The prompt is now
# the Format..Rules slice plus a line saying the call's own mode is not the session's (a mode flag on a Claude-launched claude is refused by
# the permission engine's deny rule, and a hook must not dodge it). A/B on this session's transcript: 5.5 18 specific lines, no fence, no
# "Saved.", no marker, no plan-mode text; 4.5 12 lines wrapped in a fence (the sanitiser below strips it).

log_obs INFO precompact-handoff "calling $HANDOFF_MODEL for handoff generation" 2>/dev/null || true

RESULT=""
# Guard: tell the Stop hook not to spawn another handoff generation for this Haiku turn.
# Without this, stop-context-bar.sh sees the Haiku Stop event and re-spawns → loop.
# The same var tells session-start-banner.sh the child is not a main session.
export GS_NO_AUTO_HANDOFF=1
# Retry up to 3×: Haiku API can fail transiently (network hiccup, rate limit, API cold-start).
for attempt in 1 2 3; do
  # cd /tmp: prevents the claude subprocess from inheriting CLAUDE_PROJECT_DIR,
  # which would trigger project-level SessionStart hooks and pick up wrong context.
  RAW=$(cd /tmp && env -u CLAUDE_PROJECT_DIR timeout 60 claude -p \
    --model "$HANDOFF_MODEL" \
    --max-turns 1 \
    --output-format json \
    --tools "" \
    --no-session-persistence \
    < "$PROMPT_FILE" 2>/dev/null) && break
  [[ $attempt -lt 3 ]] && sleep $(( attempt * 3 ))
  [[ $attempt -eq 3 ]] && {
    log_obs ERROR precompact-handoff "handoff model call failed after 3 attempts" 2>/dev/null || true
    exit 0
  }
done

# Sanitise BEFORE the emptiness check (a result of only "Saved." or an empty fenced block must write nothing): drop blank lines,
# whole-line code fences (a model wraps the note in ```markdown; an inner code block loses its fence lines, its text stays), and a
# BARE "Saved." or <!-- manual --> line (a prose mention mid-line stays; the reader only checks the last line anyway - T8/T9).
RESULT=$(printf '%s' "$RAW" | jq -r '.result // empty' 2>/dev/null \
  | sed -e '/^[[:space:]]*$/d' -e '/^[[:space:]]*```[[:alnum:]_-]*[[:space:]]*$/d' \
        -e '/^[[:space:]]*Saved\.[[:space:]]*$/d' -e '/^[[:space:]]*<!-- manual -->[[:space:]]*$/d')

if [[ -z "$RESULT" ]]; then
  log_obs WARN precompact-handoff "empty handoff-model result — handoff not written" 2>/dev/null || true
  exit 0
fi

# ── Write handoff ─────────────────────────────────────────────────────────────
# IMP-9: append auto-generated marker so statusline can show ⟳ auto vs ⟳ (manual)
printf '%s\n\n<!-- auto-generated by precompact -->\n' "$RESULT" > "$HANDOFF_FILE"
log_obs INFO precompact-handoff "handoff written: $HANDOFF_FILE" 2>/dev/null || true

# Update status-banner.txt HANDOFF field immediately so the statusline shows "auto"
# without waiting for the next session start (which would otherwise miss the async write).
_RUN_DIR="$HOME/.claude/run"
_BNR_GLOBAL="${_RUN_DIR}/status-banner.txt"
# P0-2: update this session's per-session banner when present (created by session-start-banner.sh);
# dual-write the global fixed-name file. SESSION_ID comes from the PreCompact stdin payload.
if [[ -n "$SESSION_ID" && -f "${_RUN_DIR}/status-banner-${SESSION_ID}.txt" ]]; then
  _BNR="${_RUN_DIR}/status-banner-${SESSION_ID}.txt"
else
  _BNR="$_BNR_GLOBAL"
fi
if [[ -f "$_BNR" ]]; then
  _BNR_TMP=$(mktemp "${_RUN_DIR}/.status-banner.XXXXXX" 2>/dev/null || true)
  if [[ -n "$_BNR_TMP" ]]; then
    sed 's|^HANDOFF:.*|HANDOFF:just now auto|' "$_BNR" \
      > "$_BNR_TMP" 2>/dev/null \
      && mv -f "$_BNR_TMP" "$_BNR" 2>/dev/null \
      || rm -f "$_BNR_TMP" 2>/dev/null || true
    [[ "$_BNR" != "$_BNR_GLOBAL" ]] && cp -f "$_BNR" "$_BNR_GLOBAL" 2>/dev/null || true
    log_obs INFO precompact-handoff "status-banner HANDOFF updated to 'just now auto'" 2>/dev/null || true
  fi
fi

printf '\n[auto-handoff saved before compaction]\n' >&2
