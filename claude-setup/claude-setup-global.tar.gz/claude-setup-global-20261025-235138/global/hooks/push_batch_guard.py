#!/usr/bin/env python3
"""push_batch_guard.py - PreToolUse(Bash): refuse a Claude `git push` below the push batch (CLAUDE.md Rule 10, user ruling 2026-10-08).

Why: CI runs on every push and the private repos' Actions minutes are metered; Rule 10 pushes at 30 unpushed commits, at a milestone
end, before a stop or hand-off, or when the user asks. This hook makes the count mechanical: for every `git [-C dir] push` segment of a
Bash command it counts `git rev-list --count @{u}..HEAD` in that repo and DENIES below the batch, naming the escape:
    git -c push.reason=milestone|stop|handoff|user push ...
git ignores the unknown `-c push.reason` key, so `git` stays the verb and the firewall's force-push deny is untouched. A marked push
below the batch is ALLOWED and queued for review (bypass_review gate pb, MEDIUM: the raw command is not stored).
Batch: PUSH_BATCH (env) or <repo>/.claude/push-batch (one integer 1-999, a project's own count), else 30.
Always allowed (no CI run on the branch, or nothing to count): --dry-run/-n, --delete/-d or a `:ref` deletion, --tags or refs/tags/ only
pushes, a branch with no upstream yet, a count git cannot give.
Fails OPEN on any error (a cost guard, not a safety guard): ERROR line in logs/hooks-errors.log, exit 0. A deny is an INFO line.
Known limits: a push inside `bash -c` / a script, or after a heredoc in the same command, is not seen; the count is the CURRENT branch's, so `git push origin other` is
judged by the checked-out branch. Off-switch: PUSH_BATCH_OFF=1 at launch (hooks/push-batch-guard.sh).
Tests: hooks/tests/test-push-batch-guard.sh. Registration: bin/push-batch-apply.sh (settings.json is protected).
"""
import json, os, shlex, subprocess, sys, time

DEFAULT_BATCH = 30
REASONS = ('milestone', 'stop', 'handoff', 'user')
CH = os.environ.get('CLAUDE_HOME') or os.path.join(os.path.expanduser('~'), '.claude')
LOG = os.path.join(CH, 'logs', 'hooks-errors.log')
OPS = {'&&', '||', ';', '|', '&', '\n', ';;', '(', ')', '|&'}


def log(level, msg):
    try:
        with open(LOG, 'a') as f:
            f.write('%s | %s | push-batch-guard | %s\n' % (time.strftime('%Y-%m-%dT%H:%M:%S'), level, msg))
    except OSError:
        pass


def segments(cmd):
    # A newline ends a command like `;` does, so it is a separator - except when the command holds a heredoc: its body lines would
    # then be judged as commands and a body that merely mentions `git push` would be denied (a wedge). With `<<` present the scan
    # stays joined (a push AFTER a heredoc is not seen: a documented limit). Newlines inside quotes stay inside their token.
    if '<<' in cmd:
        lx = shlex.shlex(cmd, posix=True, punctuation_chars=True)
    else:
        lx = shlex.shlex(cmd, posix=True, punctuation_chars='();<>|&\n')
        lx.whitespace = ' \t\r'
    lx.whitespace_split = True
    seg = []
    for tok in lx:
        if tok in OPS:
            if seg: yield seg
            seg = []
        else:
            seg.append(tok)
    if seg: yield seg


def strip_wrappers(t):
    while t:
        if '=' in t[0] and t[0].split('=', 1)[0].isidentifier():
            t = t[1:]
        elif t[0] == 'rtk':
            t = t[2:] if len(t) > 1 and t[1] == 'proxy' else t[1:]
        elif t[0] in ('command', 'env', 'nice', 'nohup'):
            t = t[1:]
        elif t[0] == 'timeout':
            t = t[1:]
            while t and t[0].startswith('-'): t = t[1:]
            t = t[1:]   # the duration
        else:
            break
    return t


def git(cwd, *args):
    r = subprocess.run(['git', '-C', cwd] + list(args), capture_output=True, text=True, timeout=5)
    return r.returncode, r.stdout.strip()


def batch_for(top):
    v = os.environ.get('PUSH_BATCH', '')
    if not v:
        try: v = open(os.path.join(top, '.claude', 'push-batch')).read().strip()
        except OSError: v = ''
    return int(v) if v.isdigit() and 1 <= int(v) <= 999 else DEFAULT_BATCH


def judge(t, cwd):
    """t = a segment starting at `git`. -> None (not a counted push) or (repo, count, batch, reason)."""
    i, reason = 1, None
    while i < len(t) and t[i].startswith('-'):
        a = t[i]
        if a == '-C' and i + 1 < len(t):
            cwd = os.path.join(cwd, os.path.expanduser(t[i + 1])); i += 2; continue
        if a == '-c' and i + 1 < len(t):
            k, _, v = t[i + 1].partition('=')
            if k.lower() == 'push.reason': reason = v
            i += 2; continue
        i += 1
    if i >= len(t) or t[i] != 'push':
        return None
    args = t[i + 1:]
    if any(a in ('--dry-run', '-n', '--delete', '-d', '--tags') for a in args):
        return None
    refs = [a for a in args if not a.startswith('-')][1:]
    if refs and all(r.startswith(':') or 'refs/tags/' in r for r in refs):
        return None
    rc, top = git(cwd, 'rev-parse', '--show-toplevel')
    if rc != 0: return None
    rc, n = git(top, 'rev-list', '--count', '@{u}..HEAD')
    if rc != 0 or not n.isdigit(): return None          # no upstream yet, or a count git cannot give
    return top, int(n), batch_for(top), reason


def record(top, n, b, reason, payload):
    try:
        sys.path.insert(0, os.path.join(CH, 'bin', 'lib'))
        import bypass_review
        bypass_review.record('pb', 'Bash', 'deny', 'allowed', rule='push below batch: reason=%s' % reason,
                             detail='repo %s: %d unpushed < %d' % (top, n, b), cwd=payload.get('cwd', ''),
                             sid=payload.get('session_id', ''), wait=False)
    except Exception as e:
        log('ERROR', 'review record failed: %s' % e)


def main():
    payload = json.loads(sys.stdin.read() or 'null') or {}
    if payload.get('tool_name') != 'Bash': return
    cmd = (payload.get('tool_input') or {}).get('command') or ''
    if 'push' not in cmd: return
    cwd = payload.get('cwd') or os.getcwd()
    for seg in segments(cmd):
        t = strip_wrappers(seg)
        if not t: continue
        if t[0] == 'cd' and len(t) > 1:
            cwd = os.path.join(cwd, os.path.expanduser(t[1])); continue
        if t[0] != 'git': continue
        v = judge(t, cwd)
        if v is None: continue
        top, n, b, reason = v
        if n >= b: continue
        if reason in REASONS:
            record(top, n, b, reason, payload); log('INFO', 'allowed marked push (%s) below batch: %s %d < %d' % (reason, top, n, b)); continue
        bad = ' (push.reason=%s is not one of %s)' % (reason, '|'.join(REASONS)) if reason is not None else ''
        msg = ('push-batch guard: %s has %d unpushed commit(s); the push batch is %d (CLAUDE.md Rule 10 - every push runs CI)%s. '
               'Keep committing and push at %d. If this push ends a milestone, precedes a stop or hand-off, or the user asked for it, mark it: '
               'git -c push.reason=milestone|stop|handoff|user push ... (the override is queued for review). Off-switch: PUSH_BATCH_OFF=1 at launch.'
               % (top, n, b, bad, b))
        log('INFO', 'denied push below batch: %s %d < %d' % (top, n, b))
        print(json.dumps({'hookSpecificOutput': {'hookEventName': 'PreToolUse', 'permissionDecision': 'deny',
                                                 'permissionDecisionReason': msg}}))
        return


if __name__ == '__main__':
    try:
        main()
    except Exception as e:      # fail OPEN: a cost guard must never wedge a session
        log('ERROR', 'fail-open: %s: %s' % (type(e).__name__, e))
    sys.exit(0)
