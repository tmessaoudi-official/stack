#!/usr/bin/env bash
# expertise-gate.sh - PreToolUse(Agent): refuse to start an agent on a project that has no expertise yet (plan expertise-any-project step 6).
# BYPASSED (family eg) it runs the same check in ADVISORY mode (framework-health step 6): never a deny; it amends the agent's prompt via
# updatedInput and queues a review event. Must stay registered AFTER agent-model-override.sh (updatedInput merges per key, later hook wins).
# Decision logic and rationale: bin/lib/expertise_gate.py. Fails OPEN (convenience gate); user off-switches: EXPERTISE_GATE_OFF=1, or the resolver family eg (state/expertise-gate-off and the other five scopes).
# Tests: hooks/tests/test-expertise-gate.sh.
set -uo pipefail
H="${CLAUDE_HOME:-$HOME/.claude}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1090
. "$HERE/log-helpers.sh" 2>/dev/null || log_obs() { :; }
PY=/usr/bin/python3; [[ -x $PY ]] || PY=python3
# stderr is kept (not /dev/null): a broken gate fails OPEN, so without a log line it looks exactly like a working one (panel 2026-10-03).
ERRF=$(mktemp 2>/dev/null) || ERRF=/dev/null; trap '[[ "$ERRF" == /dev/null ]] || rm -f "$ERRF"' EXIT
# Off? The shared resolver, family eg: the same six scopes as every gate (global / project / session sentinels, tree / exact / global
# rules). Read from the payload's cwd and session. Subshell, and any resolver failure reads as "not off" (the gate stays on); the env
# var and the python-side sentinel (EXPERTISE_GATE_OFF, state/expertise-gate-off) keep working underneath.
IN=$(cat 2>/dev/null || true)
_cwd=$(jq -r '.cwd // empty' <<<"$IN" 2>/dev/null || true); _sid=$(jq -r '.session_id // empty' <<<"$IN" 2>/dev/null || true)
ADV=(); if ( BYPASS_SESSION_ID="$_sid"; . "$HERE/bypass-resolve.sh" && bypass_applies eg "$_cwd" ) 2>/dev/null; then ADV=(--advise); fi
out=$(printf '%s' "$IN" | CLAUDE_HOME="$H" "$PY" -B "$H/bin/lib/expertise_gate.py" "${ADV[@]}" 2>"$ERRF"); rc=$?
if [[ $rc -ne 0 || -s "$ERRF" ]]; then log_obs ERROR expertise-gate "internal failure, failing open (rc=$rc): $(head -c 300 "$ERRF" 2>/dev/null | tr '\n' ' ')" 2>/dev/null || true; fi
[[ $rc -eq 0 ]] || exit 0
if [[ -n "$out" ]]; then
  if [[ ${#ADV[@]} -gt 0 ]]; then log_obs INFO expertise-gate "advisory (eg bypassed): amended an Agent prompt with the project expertise" 2>/dev/null || true
  else log_obs INFO expertise-gate "denied an Agent start: no project expertise yet" 2>/dev/null || true; fi
  printf '%s\n' "$out"
fi
exit 0
