#!/usr/bin/env bash
# PreToolUse: Bash|Read|Edit|Write|Agent|Glob|Grep — hard-block if ask-human gate not cleared.
# Gate is enforced ONCE PER USER TURN (not once per session).
# Turn token written by ask-human-gate-arm.sh (UserPromptSubmit hook).
# Sentinel written by ask-human-gate-track.sh (PostToolUse: AskUserQuestion).
# Subagents are let through by their SubagentStart markers (below). A turn token MISSING while the prompt stamp exists (the token was
# deleted) fails CLOSED; no stamp and no token = arm never ran (a headless run) = allowed, as before (user rulings 2026-10-11).
# Emergency bypass: touch ~/.claude/state/ask-human-gate-bypass to disable globally.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$SESSION_ID" ]] || exit 0

CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)

# This hook matches a broad tool set. Only the file-shaped tools carry a target an except-list can
# be judged against; Bash/Agent/Glob/Grep deliberately pass NONE, so except is skipped for them
# rather than guessed at. (Bash target extraction belongs in the firewall, which already tokenises.)
AHG_TOOL=$(printf '%s' "$INPUT" | jq -r '.tool_name // empty' 2>/dev/null || true)
AHG_TARGET=""
case "$AHG_TOOL" in
  Edit|Write|Read|NotebookEdit)
    AHG_TARGET=$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null || true) ;;
esac

# Shared resolver, SUBSHELL-invoked. This hook runs `set -euo pipefail`; Claude Code blocks only on
# exit 2, so a resolver crash in our own shell would abort with status 1 and fail OPEN.
if ( BYPASS_SESSION_ID="$SESSION_ID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
     bypass_applies ah "$CWD" "$AHG_TARGET" ) 2>/dev/null; then
  exit 0
fi

GATE_DIR="${GATE_DIR_OVERRIDE:-$HOME/.claude/run/ask-human-gate}"  # GATE_DIR_OVERRIDE: test-only injection point

# Subagent-driven bypass: subagents share the parent session_id (verified) so the turn token
# exists for them, yet they cannot clear the gate via AskUserQuestion. SubagentStart drops a marker
# per agent_id; while any FRESH marker exists for this session, allow tool calls. SubagentStop
# removes each marker; the 120-min staleness window backstops a crashed subagent that never fired
# SubagentStop (caps any leak instead of holding the gate open all session).
SUBAGENT_MARK_DIR="$GATE_DIR/subagent/${SESSION_ID}"
if [[ -d "$SUBAGENT_MARK_DIR" ]] \
   && find "$SUBAGENT_MARK_DIR" -type f -mmin -120 -print -quit 2>/dev/null | grep -q .; then
  exit 0
fi

SENTINEL="$GATE_DIR/${SESSION_ID}"
TURN_TOKEN="$GATE_DIR/turns/${SESSION_ID}"

# No turn token. arm writes the prompt stamp (prompts/<sid>) in every mode BEFORE the token, so stamp-without-token while ah is armed
# means the token was deleted: fail CLOSED - start a turn now, so one AskUserQuestion
# clears it; if the token cannot be written, TURN_TIME stays empty below and the call is blocked. Neither file = arm never ran for
# this session: a headless run (0 of 33 tool-using sdk-cli sessions had a token, 2026-10-11) or a tool runner - allowed, as before.
if [[ ! -f "$TURN_TOKEN" ]]; then
  [[ -f "$GATE_DIR/prompts/${SESSION_ID}" ]] || exit 0
  { mkdir -p "$GATE_DIR/turns" && printf '%s' "$(date +%s)" > "$TURN_TOKEN"; } 2>/dev/null || true
  log_obs WARN ask-human-gate-block "no turn token: started one (fail closed) session=${SESSION_ID}" || true
fi

# Stamp contents are DATA: [[ a -ge b ]] evaluates its operands, so a file holding NAME[$(cmd)] ran cmd here and the crash exited 1
# (= no block; milestone panel B-P1-3 class, 2026-10-09). Digits only (an explicit list: [0-9] is a locale range; at most 12, so no wrap), and a sentinel more than 60 s in the future (the ask-human
# skill stamps `date +%s`) is no standing clearance. Anything else = not cleared.
TURN_TIME=$(cat "$TURN_TOKEN" 2>/dev/null || true); [[ "$TURN_TIME" =~ ^[0123456789]{1,12}$ ]] || TURN_TIME=""

if [[ -f "$SENTINEL" ]]; then
  SENTINEL_TIME=$(cat "$SENTINEL" 2>/dev/null || true); [[ "$SENTINEL_TIME" =~ ^[0123456789]{1,12}$ ]] || SENTINEL_TIME=""
  if [[ -n "$TURN_TIME" && -n "$SENTINEL_TIME" ]] && (( 10#$SENTINEL_TIME >= 10#$TURN_TIME && 10#$SENTINEL_TIME <= $(date +%s) + 60 )); then
    exit 0  # Sentinel is same second or newer than current turn → gate cleared for this turn
  fi
  # Sentinel exists but predates current turn → new request, needs re-clearing
  {
    echo "⛔ ASK-HUMAN GATE NOT CLEARED FOR THIS TURN"
    echo "   A new user message arrived since last ask-human invocation."
    echo "   State task size (Small/Medium/Large) + invoke ask-human skill FIRST."
    echo "   CLAUDE.md ⛔ STOP: auto-mode does NOT override. 'It looks small' is rationalization #1."
    echo "   Bypass — ask the USER to run /gates-bypass (a user-only skill; root-only or recursive, with an optional except-list;"
    echo "            it writes the rule for you — do not hand-touch sentinel files)"
    echo "   (Subagents auto-bypass while running — no action needed for subagent-driven dev.)"
  } >&2
  log_obs WARN ask-human-gate-block "gate STALE (new turn) session=${SESSION_ID}" || true
  exit 2
fi

# No sentinel at all for this session
{
  echo "⛔ ASK-HUMAN GATE NOT CLEARED"
  echo "   State task size (Small/Medium/Large) + invoke ask-human skill FIRST."
  echo "   CLAUDE.md ⛔ STOP: mandatory before Bash/Read/Edit/Write/Agent. Auto-mode does NOT override."
  echo "   Bypass — ask the USER to run /gates-bypass (a user-only skill; root-only or recursive, with an optional except-list;"
  echo "            it writes the rule for you — do not hand-touch sentinel files)"
  echo "   (Subagents auto-bypass while running — no action needed for subagent-driven dev.)"
} >&2
log_obs WARN ask-human-gate-block "gate NOT CLEARED session=${SESSION_ID}" || true
exit 2
