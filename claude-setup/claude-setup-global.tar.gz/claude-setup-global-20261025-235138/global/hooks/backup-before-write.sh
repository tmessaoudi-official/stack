#!/usr/bin/env bash
# PreToolUse hook: enforce Rule 8 backup policy for Edit and Write tool calls.
#
# Non-git files that exist: create a timestamped backup and tell Claude its path. If the backup
# fails, BLOCK the edit (exit 2 — Claude Code blocks only on exit 2; the exit 1 used before
# 2026-09-28 let the edit through) — proceeding without a backup defeats the purpose of this hook.
# Git files: warn when the file was dirty BEFORE this session touched it (git is the backup, so
# never block). Gitignored files inside a work tree: warn once that there is no history and no
# backup, but make no .bak (plan files are edited dozens of times a session).
# New files or clean git files: silent, always allow.
#
# Visibility (row 57, AGREED 2026-09-28 10:18): PreToolUse stderr with exit 0 never reaches Claude
# (probe 2026-09-28), so every notice is JSON hookSpecificOutput.additionalContext on stdout.
# "Touched by this session" = recorded in run/touched-files-<session_id>.txt: every Edit/Write
# path is appended here, created files included. Caveats: a later hook that denies the edit
# still leaves the path recorded (at worst one missed warning); subagents share the parent's
# session_id, so their edits count as the session's. No session_id → cannot track → warn every time.
# The list is reaped at 24 h by session-start-banner.sh and claude-cleanup.sh --run-files.

set -eEuo pipefail

# shellcheck source=log-helpers.sh
source "$(dirname "${BASH_SOURCE[0]}")/log-helpers.sh" 2>/dev/null || true

# Read-only git must never take index.lock: `git status -- FILE` otherwise rewrites the index when
# the file's stat info changed — before every Edit/Write, racing the user's commits (row 31).
export GIT_OPTIONAL_LOCKS=0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

TOOL=$(printf '%s' "$INPUT" | jq -r '.tool_name // empty' 2>/dev/null || true)
FILE=$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // empty' 2>/dev/null || true)
SID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)

[[ "$TOOL" == "Edit" || "$TOOL" == "Write" ]] || exit 0
[[ -n "$FILE" ]] || exit 0

# Normalize BEFORE the new-file exit, so a created file and its later edits record the same string.
# A path whose directory does not exist yet makes realpath exit 1 → the raw path is used (a
# Write creates the directory, so its later edits may normalize differently — one extra warning).
FILE=$(realpath "$FILE" 2>/dev/null || echo "$FILE")

emit_ctx() {  # the one channel Claude sees on exit 0
  jq -nc --arg c "$1" '{hookSpecificOutput:{hookEventName:"PreToolUse",additionalContext:$c}}'
}

LIST=""
if [[ "$SID" =~ ^[A-Za-z0-9_-]+$ ]]; then
  LIST="$HOME/.claude/run/touched-files-${SID}.txt"
fi
TOUCHED=false
# Keep this grep INSIDE the `if`: bare, a missing list makes it exit 2 and set -e would turn that
# into a BLOCK of the session's first edit. The -f test only keeps "No such file" off stderr —
# sabotage 2026-09-28: removing it changed no test result, as expected inside an `if`.
if [[ -n "$LIST" && -f "$LIST" ]] && grep -qxF -- "$FILE" "$LIST"; then TOUCHED=true; fi
record() {
  [[ -n "$LIST" && "$TOUCHED" == false ]] || return 0
  mkdir -p "$(dirname "$LIST")" && printf '%s\n' "$FILE" >> "$LIST" \
    || log_obs ERROR backup-before-write "could not record $FILE in $LIST"
}

# New file being created — no backup needed; recorded so its later edits are not "untracked"
if [[ ! -f "$FILE" ]]; then record; exit 0; fi

DIR=$(dirname "$FILE")
if git -C "$DIR" rev-parse --is-inside-work-tree &>/dev/null 2>&1; then
    # Inside git: warn once per session, never block (git is the backup)
    if [[ "$TOUCHED" == false ]]; then
        if git -C "$DIR" check-ignore -q -- "$FILE" 2>/dev/null; then
            emit_ctx "[Rule 8] '$FILE' is gitignored: no git history and no backup — this file is the only copy. Shown once per session."
        else
            STATUS=$(git -C "$DIR" status --porcelain -- "$FILE" 2>/dev/null || true)
            if [[ -n "$STATUS" ]]; then
                emit_ctx "[Rule 8] '$FILE' had uncommitted/untracked changes in git BEFORE this session touched it (someone else's work?). Consider asking the user to commit or stash first. Shown once per file per session."
            fi
        fi
    fi
    record
    exit 0
fi

# The session scratchpad is throwaway by design: no copy (framework-health step 21, AGREED 2026-10-11 D1).
# BBW_SKIP_PREFIX is a test seam; the trailing slash keeps /tmp/claude-1000x/ from matching.
SKIP_PREFIX="${BBW_SKIP_PREFIX:-/tmp/claude-$(id -u)/}"
if [[ "$FILE" == "$SKIP_PREFIX"* ]]; then record; exit 0; fi

# Outside git: copy into the central store ~/.claude/backups/rule8/<sid>/<ns>-XXXX/<basename> (mode 700;
# the basename is kept so credential-path rules still match a copy of .env) and add a ledger row
# (ns, original, copy). Nothing is written beside the file. Every failure before the copy exists is exit 2
# (a crash exits 1, and exit 1 lets the edit through with no copy); a ledger failure after a good copy
# is exit 0 + ERROR, because the copy is what makes the edit safe. claude-cleanup.sh --rule8 lists,
# ages (14 d, by the ns in the directory name) and deletes these copies.
block() {
    echo "[BLOCKED] Rule 8: Could not create a backup of '$FILE' ($1)." >&2
    echo "   The store is $HOME/.claude/backups/rule8/ (disk full? permissions?). Fix it, then retry the edit." >&2
    log_obs ERROR backup-before-write "backup failed for $FILE: $1"
    exit 2
}
[[ "$SID" =~ ^[A-Za-z0-9_-]+$ ]] && SDIR="$SID" || SDIR=nosession
STORE="$HOME/.claude/backups/rule8"
( umask 077; mkdir -p "$STORE/$SDIR" ) 2>/dev/null || block "cannot create $STORE/$SDIR"
chmod 700 "$STORE" 2>/dev/null || block "cannot make $STORE private"
NS=$(date +%s%N) && [[ "$NS" =~ ^[0-9]{19}$ ]] || block "date +%s%N gave '$NS'"
CDIR=$(mktemp -d "$STORE/$SDIR/$NS-XXXX" 2>/dev/null) || block "cannot create a copy directory"
BACKUP="$CDIR/$(basename "$FILE")"
if ! cp -a "$FILE" "$BACKUP" 2>/dev/null; then
    rmdir "$CDIR" 2>/dev/null || log_obs ERROR backup-before-write "could not remove empty $CDIR"
    block "cp -a failed"
fi
if ! printf '%s\t%s\t%s\n' "$NS" "$FILE" "$BACKUP" >> "$STORE/$SDIR/ledger.tsv" 2>/dev/null; then
    log_obs ERROR backup-before-write "ledger append failed for $BACKUP ($STORE/$SDIR/ledger.tsv)"
fi
OBS_LOG="$HOME/.claude/logs/backups.log" log_obs INFO backup-before-write "backed up $FILE → $BACKUP"
record
emit_ctx "[Rule 8] backup created: $BACKUP — restore: cp -a '$BACKUP' '$FILE'"
exit 0
