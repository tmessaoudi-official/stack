#!/usr/bin/env python3
"""perm_shadow.py - shared pieces of shadow mode (plan permission-unification, step 7).

The engine (PERM_ENGINE_MODE=shadow) records what it WOULD decide for every tool call, INCLUDING "none", to logs/permission-shadow.ndjson.
A PermissionRequest hook (hooks/perm-request-log.sh -> `perm_shadow.py request`) records every prompt the harness REALLY raised to
logs/permission-requests.ndjson. bin/perm-shadow-diff.sh joins the two on (session id, key): the ground truth is the harness, not the port.
key = hash of (tool, tool_input). PermissionRequest has NO tool_use_id and carries the RTK-REWRITTEN command (probed 2026-09-30), so the engine record also stores `alt`
(the `rtk `-prefixed form) and, in schema 2, the replayable input; the MISS check replays each real prompt instead of joining.
Nothing here ever prints a decision or raises: a logger that could block or crash a tool call would be worse than the gap it closes.
"""
import hashlib, json, os, sys, time

HOME = os.environ.get('HOME', '')
LOGS = os.environ.get('PERM_SHADOW_DIR') or os.path.join(HOME, '.claude', 'logs')
DECISIONS = 'permission-shadow.ndjson'
REQUESTS = 'permission-requests.ndjson'
MAX_BYTES = int(os.environ.get('PERM_SHADOW_MAX_BYTES') or 5 * 1024 * 1024)


def key(tool, tin):
    return hashlib.sha1(json.dumps([tool, tin], sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')).hexdigest()[:16]


def record(name, rec):
    try:
        os.makedirs(LOGS, exist_ok=True)
        path = os.path.join(LOGS, name)
        try:                                    # size cap: one generation kept (.1); the diff tool reads only the live file, so rotation forgets old samples
            if os.path.getsize(path) > MAX_BYTES: os.replace(path, path + '.1')
        except OSError:
            pass
        with open(path, 'a') as f:
            f.write(json.dumps(rec, separators=(',', ':'), ensure_ascii=False) + '\n')
    except OSError:
        pass


def _ts():
    return time.strftime('%Y-%m-%dT%H:%M:%S%z')


def _trim(tin):
    """tool_input with every long string cut, so a Write of a big file cannot bloat the log; enough text to REPLAY a rule match."""
    if isinstance(tin, dict):
        return {k: (v[:2000] if isinstance(v, str) else v) for k, v in tin.items() if k in ('command', 'file_path', 'path', 'pattern', 'url', 'notebook_path')}
    return {}


def rtk_form(tool, tin):
    """The input the harness sees AFTER the RTK PreToolUse hook rewrote it (verified 2026-09-30, probe prq2/prq3: `git status` -> `rtk git status`;
    PermissionRequest and the static rules see the rewritten command, PreToolUse hooks in parallel see the original)."""
    if tool == 'Bash' and isinstance(tin, dict) and isinstance(tin.get('command'), str) and not tin['command'].startswith('rtk '):
        return dict(tin, command='rtk ' + tin['command'])
    return tin


def rtk_rewrite(tool, tin):
    """The command the RTK hook REALLY rewrites this input to (None = untouched or rtk unavailable). Used at diff time, never in a hook."""
    if tool != 'Bash' or not isinstance(tin, dict) or not isinstance(tin.get('command'), str):
        return None
    try:
        import subprocess
        r = subprocess.run(['rtk', 'hook', 'claude'], input=json.dumps({'hook_event_name': 'PreToolUse', 'tool_name': tool, 'tool_input': tin}),
                           capture_output=True, text=True, timeout=5)
        new = json.loads(r.stdout).get('hookSpecificOutput', {}).get('updatedInput', {}).get('command')
        return new if isinstance(new, str) and new != tin['command'] else None
    except Exception:
        return None


def swap_armed():
    return os.path.exists(os.path.join(HOME, '.claude', 'state', 'permission-profile-permissive.json'))


# schema 2: records carry the (trimmed) input, so the diff tool can REPLAY them; older lines are ignored by the diff.
def record_decision(payload, decision, level, reason):
    tool = payload.get('tool_name', '')
    tin = payload.get('tool_input') or {}
    record(DECISIONS, {'schema': 2, 'ts': _ts(), 'sid': payload.get('session_id', ''), 'tool': tool, 'key': key(tool, tin),
                       'alt': key(tool, rtk_form(tool, tin)), 'input': _trim(tin), 'cwd': payload.get('cwd', ''),
                       'mode': payload.get('permission_mode') or 'default', 'decision': decision, 'level': level,
                       'swap': swap_armed(), 'reason': (reason or '')[:200]})


def record_request(payload):
    tool = payload.get('tool_name', '')
    tin = payload.get('tool_input') or {}
    record(REQUESTS, {'schema': 2, 'ts': _ts(), 'sid': payload.get('session_id', ''), 'tool': tool, 'key': key(tool, tin),
                      'input': _trim(tin), 'cwd': payload.get('cwd', ''), 'prompt_id': payload.get('prompt_id', ''),
                      'mode': payload.get('permission_mode') or 'default'})


if __name__ == '__main__':
    try:
        if len(sys.argv) > 1 and sys.argv[1] == 'request':
            record_request(json.load(sys.stdin))
    except Exception:
        pass
    sys.exit(0)
