#!/usr/bin/env bash
# skill-invocation-log.sh — PreToolUse (matcher Skill) + UserPromptSubmit. Review-remediation row 29 (WS5.8).
#
# Appends one TSV line per skill invocation to ~/.claude/logs/skill-invocations.log:
#   <ISO time> \t <model|typed> \t <skill name> \t <cwd>
# It is the number framework-v2 P4 asked for before any skill is split or trimmed ("no invocation log exists
# to check how often `bundle` is actually called"). BOTH events are needed and neither double-counts: a
# typed /name is expanded by the harness and never produces a Skill tool_use (0 of 130 typed commands in
# 30 days of transcripts, 2026-09-28), and UserPromptSubmit's `prompt` is the raw "/name args" (live probe,
# same night). A typed name may be a built-in (/compact) — the log keeps it; filter when counting.
#
# Never logs arguments or prompt text. Prints NOTHING: UserPromptSubmit stdout is injected into the model's
# context. Always exit 0. Skips headless side calls (GS_NO_AUTO_HANDOFF — row 55/56).
# Registration (settings.json, user-run): PreToolUse matcher "Skill" and UserPromptSubmit →
#   "$HOME"/.claude/hooks/skill-invocation-log.sh
set -uo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/log-helpers.sh" 2>/dev/null || log_obs() { :; }
[[ -n "${GS_NO_AUTO_HANDOFF:-}" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
LINE=$(printf '%s' "$INPUT" | jq -r '
  if .hook_event_name == "PreToolUse" and .tool_name == "Skill" and ((.tool_input.skill // "") != "") then
    ["model", .tool_input.skill, (.cwd // "")]
  elif .hook_event_name == "UserPromptSubmit" then
    ((.prompt // "") | capture("^/(?<n>[A-Za-z0-9][A-Za-z0-9:_-]*)(\\s|$)")?) as $m
    | if $m then ["typed", $m.n, (.cwd // "")] else empty end
  else empty end
  | @tsv' 2>/dev/null) || exit 0
[[ -n "$LINE" ]] || exit 0

LOG="$HOME/.claude/logs/skill-invocations.log"
if ! printf '%s\t%s\n' "$(date +%Y-%m-%dT%H:%M:%S)" "$LINE" >> "$LOG" 2>/dev/null; then
  log_obs ERROR skill-invocation-log "cannot append to $LOG" || true
fi
exit 0
