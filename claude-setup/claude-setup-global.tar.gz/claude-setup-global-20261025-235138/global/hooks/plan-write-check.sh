#!/usr/bin/env bash
# plan-write-check.sh — PostToolUse (Edit|Write) on *.plan.md. Review-remediation row 10b (WS1.6b).
#
# Warn-only (always exit 0). The warning goes to stdout as hookSpecificOutput.additionalContext —
# with exit 0 that is the only channel that reaches the model (stderr, plain stdout and
# systemMessage never do; measured 2026-09-28, row 33) — and to stderr for the transcript.
#
#  1. Location (Rule 17). A plan belongs in <repo>/docs/plans/ or ~/.claude/projects/<slug>/plans/,
#     whichever the project's plan-location sentinel names. project-state.sh warns when it next
#     READS the plans; this warns at the write, while moving the file is still free.
#  2. Stamps. A NEW Decisions-Log bullet `- [YYYY-MM-DD HH:MM] AGREED|ASSUMED …` stamped more than
#     5 min off the clock, or below a newer bullet. Invented stamps recurred in 6 project slugs even
#     after the memory warning about them existed (research F, candidate 6; this session did it too),
#     because the agent does not know it is guessing at the moment it writes — so check the write.
#     "New" = a stamp prefix the Edit's new_string has more of than its old_string (a reworded
#     bullet keeps its stamp and is not new). A whole-file Write's old content is unknown, so there
#     only FUTURE stamps are flagged: a past stamp may be genuine history. A range [HH:MM–HH:MM] is
#     judged by its end. The fix it points to: bin/project-state.sh --append-decision.
#     Scope: a stamped `- [..] AGREED|ASSUMED` bullet ANYWHERE in the file counts (not only under
#     `## Decisions Log`), so such a bullet in another section is ordered against the log's too.
#
# Test seam: PLAN_CHECK_NOW="YYYY-MM-DD HH:MM" pins the clock. Registration (settings.json, user-run):
#   PostToolUse matcher "Edit|Write" → "$HOME"/.claude/hooks/plan-write-check.sh (MB4)
set -uo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/log-helpers.sh" 2>/dev/null || log_obs() { :; }

INPUT=$(cat 2>/dev/null || true)
[[ "$INPUT" == *'.plan.md'* ]] || exit 0          # cheap pre-filter: most writes are not plans
TMPIN=$(mktemp) || exit 0
TMPERR=$(mktemp) || { rm -f "$TMPIN"; exit 0; }
trap 'rm -f "$TMPIN" "$TMPERR"' EXIT
printf '%s' "$INPUT" > "$TMPIN"

MSG=$(HOME="$HOME" PLAN_CHECK_NOW="${PLAN_CHECK_NOW:-}" /usr/bin/python3 - "$TMPIN" <<'PY' 2>"$TMPERR"
import collections, datetime as dt, json, os, re, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(0)
tool = d.get("tool_name", ""); ti = d.get("tool_input") or {}
fp = ti.get("file_path") or ""
if not fp.endswith(".plan.md"):
    sys.exit(0)
ch = os.path.join(os.environ["HOME"], ".claude")
out = []

# 1. location
m = re.match(re.escape(ch) + r"/projects/([^/]+)/plans/[^/]+\.plan\.md$", fp)
if m:
    slug, loc = m.group(1), "global"
else:
    m = re.match(r"(/.+)/docs/plans/[^/]+\.plan\.md$", fp)
    slug, loc = (m.group(1).replace("/", "-"), "repo") if m else (None, None)
if loc is None:
    out.append(f"plan-write-check: {fp} is not in a plan location — Rule 17 puts plans in "
               "<repo>/docs/plans/ or ~/.claude/projects/<slug>/plans/ (the project's plan-location "
               "sentinel says which). Move it before it collects more history.")
else:
    sf = os.path.join(ch, "projects", slug, "plan-location")
    try:
        want = open(sf).readline().strip()
    except OSError:
        want = ""
    if want in ("repo", "global") and want != loc:
        out.append(f"plan-write-check: {fp} is in the {loc} location, but {sf} says '{want}' — "
                   "move it (Rule 17).")

# 2. stamps
BUL = re.compile(r"^- \[(\d{4}-\d\d-\d\d) (\d\d:\d\d)(?:[–-](\d\d:\d\d))?\] (AGREED|ASSUMED)\b", re.M)
def parse(text):
    r = []
    for b in BUL.finditer(text or ""):
        end = b.group(3) or b.group(2)
        try:
            t = dt.datetime.strptime(f"{b.group(1)} {end}", "%Y-%m-%d %H:%M")
        except ValueError:
            continue
        r.append((b.group(0), t))
    return r
now_s = os.environ.get("PLAN_CHECK_NOW") or dt.datetime.now().strftime("%Y-%m-%d %H:%M")
now = dt.datetime.strptime(now_s, "%Y-%m-%d %H:%M")
if tool == "Edit":
    # A bullet is identified by its STAMP alone: rewriting `ASSUMED (review)` to `AGREED (ratified ASSUMED)` under the
    # same stamp is the documented ratification of an old entry, not a new entry (panel F1, 2026-09-28).
    stamp = lambda k: k.rsplit(" ", 1)[0]
    old = collections.Counter(stamp(k) for k, _ in parse(ti.get("old_string", "")))
    new, seen = [], collections.Counter()
    for k, t in parse(ti.get("new_string", "")):
        seen[stamp(k)] += 1
        if seen[stamp(k)] > old[stamp(k)]:
            new.append((k, t))
    past_too = True
elif tool == "Write":
    new, past_too = parse(ti.get("content", "")), False
else:
    new, past_too = [], False
FIX = "stamp from the clock: bash ~/.claude/bin/project-state.sh --append-decision <plan> <AGREED|ASSUMED> \"<text>\""
for k, t in new:
    delta = (t - now).total_seconds() / 60
    if delta > 5:
        out.append(f"plan-write-check: new entry {k!r} is stamped {int(delta)} min in the FUTURE "
                   f"(clock {now:%Y-%m-%d %H:%M}) — an invented stamp is a forged ruling; {FIX}.")
    elif past_too and delta < -5:
        out.append(f"plan-write-check: new entry {k!r} is stamped {int(-delta)} min in the past "
                   f"(clock {now:%Y-%m-%d %H:%M}) — a new entry carries the time it is written; if it "
                   f"records an earlier ruling, say so in its text. {FIX}.")
# order: a new bullet must not sit below a NEWER one — judged against the newest bullet anywhere
# above it, not just its neighbour (a tail of 09-22, 09-20, 09-21 is out of order at 09-21 too)
if new:
    try:
        allb = parse(open(fp).read())
    except OSError:
        allb = []
    keys = {k for k, _ in new}
    # A Write sees every bullet as new, and old mid-file disorder is common (15 of 21 real repo
    # plans, 2026-09-28) — re-flagging it on every Write is a warning that cries wolf. So a Write
    # judges only the LAST bullet: that is where the collector's `tail -1` would misreport.
    last = len(allb) - 1
    top = 0                                  # index of the newest bullet seen so far
    for i in range(1, len(allb)):
        if (tool == "Edit" or i == last) and allb[i][0] in keys and allb[i][1] < allb[top][1]:
            out.append(f"plan-write-check: {'new ' if tool == 'Edit' else ''}entry {allb[i][0]!r} sits below the newer "
                       f"{allb[top][0]!r} — the Decisions Log must stay in time order "
                       "(the collector reads the LAST bullet as the latest).")
        if allb[i][1] > allb[top][1]:
            top = i
print("\n".join(out))
PY
)
rc=$?
if (( rc != 0 )); then   # a crashed checker checks nothing: say so in the log (Rule 13), never block
  log_obs ERROR plan-write-check "checker failed rc=$rc: $(tail -1 "$TMPERR" | cut -c1-200)" || true
  exit 0
fi
[[ -n "$MSG" ]] || exit 0
log_obs WARN plan-write-check "$(printf '%s' "$MSG" | head -1 | cut -c1-240)" || true
printf '%s\n' "$MSG" >&2
jq -n --arg m "$MSG" '{hookSpecificOutput: {hookEventName: "PostToolUse", additionalContext: $m}}'
exit 0
