#!/usr/bin/env bash
# Stop hook: backstop for CLAUDE.md Rule 6C (PRE-COMPLETION INDEPENDENT CHECK). If the assistant's
# turn contains the Rule 6 Completion Gate evidence-table signature (both "coverage" and "blast
# radius" present — the Medium/Large table or the Small inline-sentence form) but the turn shows no
# independent certification, block the stop with a reminder to call advisor() first.
# Certification = an `advisor` call OR a reviewer-panel `Agent` spawn. The panel arm exists because
# CLAUDE.md's certification ladder prescribes fresh-context reviewer subagents when advisor() is
# unavailable; keying on the literal tool name alone would block the very fallback it mandates.
# The panel match is loose (review|certif|adversarial|lens|audit|critique over subagent_type +
# description + prompt) but NOT blanket — an ordinary Explore/search Agent spawn still blocks,
# which is what keeps the widening from swallowing every turn that happens to spawn an agent.
# Conservative by design (false-NEGATIVE-leaning): fires only on this one well-defined, mechanical
# co-occurrence signal, not a fuzzy "sounds like done" heuristic. Does NOT trigger on a later
# "STATUS: Committed" confirmation turn (that's just reporting git state, not re-claiming
# completeness, and usually has no new advisor() call to make). Honors stop_hook_active (no loop);
# ACGUARD_OFF=1 disables. Transcript schema: one content-block per JSONL line, so a turn = all
# lines after the last prompt-like 'user' entry (see FILTER). Mirrors ask-human-question-guard.sh.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

[[ "${ACGUARD_OFF:-}" == "1" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

ACG_CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
ACG_SID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)

# Shared resolver: legacy sentinels (global/project/session) + recursive path rules, one place.
# SUBSHELL is required — see bypass-resolve.sh: this hook runs `set -u` and Claude Code blocks only
# on exit 2, so a resolver crash in our own shell would exit 1 and fail OPEN.
# Stop hook: no target path, so except-lists are skipped by construction.
# Bypassed = ADVISORY (framework-health step 7): the same check runs and never blocks; an uncertified completion claim becomes
# one ac review event (one per Stop; a continued stop is skipped below exactly as when armed). ACGUARD_OFF=1 stays a full off.
ADV=0
if ( BYPASS_SESSION_ID="$ACG_SID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
     bypass_applies ac "$ACG_CWD" ) 2>/dev/null; then
  ADV=1
fi

# Avoid loops: if we already blocked once this stop-cycle, let it through.
[[ "$(printf '%s' "$INPUT" | jq -r '.stop_hook_active // false' 2>/dev/null)" == "true" ]] && exit 0

TRANSCRIPT=$(printf '%s' "$INPUT" | jq -r '.transcript_path // empty' 2>/dev/null || true)
[[ -n "$TRANSCRIPT" && -f "$TRANSCRIPT" ]] || exit 0

# Parse the last turn (lines after the last prompt-like 'user' entry: not a tool_result, a skill body (isMeta), a compact summary or
# a task notification, a `!` line or a built-in local command): gather assistant text + tool names used. Anchor shared byte-for-byte with advisor-prework-guard.sh (why: its comment).
FILTER='
  . as $a
  | ([range(0; ($a|length)) | select($a[.].type=="user"
       and ($a[.].isMeta // false) != true and ($a[.].isCompactSummary // false) != true
       and ($a[.].origin.kind // "") != "task-notification"
       and (($a[.].message.content|type)!="string" or ($a[.].message.content|test("^\\s*<(bash-(input|stdout|stderr)|local-command-[a-z]+|command-name)>")|not))
       and (($a[.].message.content|type)=="string"
            or ([$a[.].message.content[]?|select(.type=="tool_result")]|length)==0))] | last) as $u0
  | (($u0 // -1) + 1) as $start
  | {
      used_advisor: ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="tool_use" or .type=="server_tool_use") ]
                   | any( .name == "advisor"
                          or ( .name == "Agent"
                               and ( ((.input.subagent_type // "") + " " + (.input.description // "")
                                      + " " + (.input.prompt // ""))
                                     | test("review|certif|adversarial|lens|audit|critique"; "i") ) ) )),
      text:     ([ $a[$start:][] | select(.type=="assistant") | (.message.content[]?)
                   | select(.type=="text") | .text ] | join("\n"))
    }'
RES=$(tail -n 800 "$TRANSCRIPT" 2>/dev/null | jq -Rc 'fromjson? // empty' 2>/dev/null | jq -s "$FILTER" 2>/dev/null || true)
[[ -z "$RES" ]] && exit 0

USED_ADVISOR=$(printf '%s' "$RES" | jq -r '.used_advisor' 2>/dev/null || echo false)
TEXT=$(printf '%s' "$RES" | jq -r '.text' 2>/dev/null || echo "")

# If advisor() ran — or a reviewer panel was spawned — Phase 6C was honored → pass.
[[ "$USED_ADVISOR" == "true" ]] && exit 0
[[ -z "$TEXT" || "$TEXT" == "null" ]] && exit 0

# Completion Gate evidence-table signature: both "coverage" and "blast radius" present.
# Co-occurrence keeps false positives near zero; neither term alone is distinctive enough.
if printf '%s' "$TEXT" | grep -qi 'coverage' && printf '%s' "$TEXT" | grep -qi 'blast radius'; then
  if [[ "$ADV" == 1 ]]; then
    python3 "$SCRIPT_DIR/../bin/lib/bypass_review.py" add --gate ac --tool Stop --would block --action allowed \
      --rule 'completion claim without advisor()' --detail "$(printf '%s' "$TEXT" | grep -im1 -e 'blast radius' | cut -c1-160)" \
      --cwd "$ACG_CWD" --sid "$ACG_SID" >/dev/null 2>&1
    log_obs INFO advisor-completion-guard "advisory: queued a completion-gate claim without advisor() call" 2>/dev/null || true
    exit 0
  fi
  {
    echo "⛔ COMPLETION GATE EVIDENCE PRESENTED WITHOUT advisor() CERTIFICATION"
    echo "   This turn looks like a Rule 6 Completion Gate claim (coverage + blast-radius evidence)"
    echo "   but the advisor tool was not called."
    echo "   CLAUDE.md Phase 6C (PRE-COMPLETION INDEPENDENT CHECK): call advisor() before declaring done."
    echo "   Disable backstop: ACGUARD_OFF=1"
  } >&2
  log_obs WARN advisor-completion-guard "blocked completion-gate claim without advisor() call" 2>/dev/null || true
  exit 2
fi
exit 0
