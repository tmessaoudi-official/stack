#!/usr/bin/env bash
# statusLine hook: prints the status line below each assistant turn.
# Input: JSON payload on stdin (full schema in templates/tips/statusline.md).
# Output: two lines to stdout (Claude Code renders each as a separate status row), plus a `↳` continuation line under a line that does not
# fit COLUMNS (plan statusline-redesign, user rulings 2026-10-19 14:34-14:39; spec in that plan's "Render spec").
# Line 1: the meters - model, context, usage, cache, place (cwd + git + git lock), agent, cost, lines, turns - then the session tail
#   (up, Σ lifetime, handoff age, CLAUDE.md / analysis flags), least urgent last so it spills first.
# Line 2: the rules - WARNINGS most severe first (_l2rank: ⚠⚠⚠ BYPASS, PERM-DOWN/OPEN, RULES/MODELS-INVALID, UNATTENDED, AUTO-3C, the
#   `⚠ bypassed …` gates group with its ⏳ expiry, ADVISOR, MODELS, PERM-PROJ, perm-shadow), then the working state - mode(+cf),
#   keep-going, advisor, plan@location, review, expertise, memory.
# Items are separated by ` │ `; with a known width each line is fitted: full forms, then long names shortened in the middle, then short
#   labels, then the right end spills to a `↳` line - nothing is ever cut. COLUMNS absent: full forms, no spill.
set -euo pipefail
source "${BASH_SOURCE[0]%/*}/log-helpers.sh" 2>/dev/null || log_obs() { :; }
# ss_urgency() (proportional-with-floor tiers) — pure function library, no side effects on
# source, same pattern stop-context-bar.sh already uses. 2026-08-30: F6 below used to read a
# hardcoded "167" fallback instead of the resolved window; this is what makes the real fix
# possible.
source "${BASH_SOURCE[0]%/*}/session-status.sh" 2>/dev/null || true
trap 'log_obs ERROR statusline.sh "Unexpected error at line $LINENO" 2>/dev/null || true' ERR

payload=$(cat)

# Set STATUSLINE_PROBE=1 to dump payload: env STATUSLINE_PROBE=1 claude ...
[[ "${STATUSLINE_PROBE:-}" == "1" ]] && echo "$payload" > /tmp/statusline-probe.json

# --- Payload fields — single jq fork for all 19 fields ---
# cache_read_input_tokens is nested inside current_usage (null before first API call)
# rate_limits.{five_hour,seven_day}.used_percentage drive the session/weekly usage segments
# (same data /usage shows). Present only for Pro/Max auth, and only after the first API
# response — null/absent otherwise, so the segments self-hide.
model="unknown" thinking="false" effort_level="" cost_usd="0"
lines_added="0" lines_removed="0" cwd="" agent=""
cache_reads="0" total_ctx_tokens="0" ctx_pct="0" is_estimate="true" _ctx_window_size="200000"
_sess_id="" _transcript="" _win_present="false" _proj_dir=""
sess_usage_pct="" week_usage_pct=""
if _jq_out=$(jq -r '
  # context_window_size is NOT guaranteed to be a number. `//` only replaces null/false, so a
  # string value survived it and then hit the division below — jq aborted, the `if` failed,
  # and EVERY field silently fell back to its default: model "unknown", cost $0.00, no cwd.
  # One bad field blanked the entire statusline. SPEC §6-25.
  def winsize: .context_window.context_window_size;
  def winnum:  (winsize as $w | if ($w|type) == "number" and $w > 0 then $w else 200000 end);
  def winok:   (winsize as $w | (($w|type) == "number" and $w > 0));
  .model.id // "unknown",
  (.thinking.enabled // false | tostring),
  (.effort.level // ""),
  (.cost.total_cost_usd // 0 | tostring),
  (.cost.total_lines_added // 0 | tostring),
  (.cost.total_lines_removed // 0 | tostring),
  (.workspace.current_dir // .cwd // ""),
  (.agent.name // ""),
  (.context_window.current_usage.cache_read_input_tokens // 0 | tostring),
  (.context_window.total_input_tokens // 0 | tostring),
  (if .context_window.used_percentage != null then .context_window.used_percentage
   elif (.context_window.total_input_tokens // 0) > 0 then
     (.context_window.total_input_tokens / winnum * 100)
   else 0
   end | tostring),
  (if .context_window.used_percentage != null then "false" else "true" end),
  (winnum | tostring),
  (.session_id // ""),
  (.transcript_path // ""),
  (.rate_limits.five_hour.used_percentage // "" | tostring),
  (.rate_limits.seven_day.used_percentage // "" | tostring),
  (winok | tostring),
  (.workspace.project_dir // "")
' <<< "$payload" 2>/dev/null); then
  mapfile -t _jq_fields <<< "$_jq_out"
  model="${_jq_fields[0]:-unknown}"
  thinking="${_jq_fields[1]:-false}"
  effort_level="${_jq_fields[2]:-}"
  cost_usd="${_jq_fields[3]:-0}"
  lines_added="${_jq_fields[4]:-0}"
  lines_removed="${_jq_fields[5]:-0}"
  cwd="${_jq_fields[6]:-}"
  agent="${_jq_fields[7]:-}"
  cache_reads="${_jq_fields[8]:-0}"
  total_ctx_tokens="${_jq_fields[9]:-0}"
  ctx_pct="${_jq_fields[10]:-0}"
  is_estimate="${_jq_fields[11]:-true}"
  _ctx_window_size="${_jq_fields[12]:-200000}"
  _sess_id="${_jq_fields[13]:-}"
  _transcript="${_jq_fields[14]:-}"
  sess_usage_pct="${_jq_fields[15]:-}"
  week_usage_pct="${_jq_fields[16]:-}"
  _win_present="${_jq_fields[17]:-false}"
  _proj_dir="${_jq_fields[18]:-}"
fi

# Belt-and-braces for the no-jq path: jq now guarantees a positive number (see winnum), but
# when the jq block is skipped entirely these keep the value out of the arithmetic at
# :220-222 and out of the persist at :136. Garbage is treated as ABSENT, not as 200000, so
# the persisted per-session window is still consulted. SPEC §6-25.
if ! [[ "${_ctx_window_size:-}" =~ ^[0-9]+$ ]] || [[ "${_ctx_window_size:-0}" -le 0 ]]; then
  _ctx_window_size="200000"
  _win_present="false"
fi

# --- Model short name ---
case "$model" in
  *opus*)   model_short="opus"   ;;
  *sonnet*) model_short="sonnet" ;;
  *haiku*)  model_short="haiku"  ;;
  *)        model_short="${model%%@*}" ;;
esac

# Mode prefix: 💭 think + optional effort suffix
mode_prefix=""
effort_suffix=""
[[ "$thinking" == "true" ]] && mode_prefix="💭 "
# EVERY effort level shows (low/medium were dropped by a high|max|xhigh-only case, and the whole suffix sat inside the thinking
# branch) — but only a plain lowercase word, so an odd payload value can never put junk on the bar.
[[ "$effort_level" =~ ^[a-z]{2,12}$ ]] && effort_suffix=" ${effort_level}"

# --- Status files written by SessionStart + Stop hooks ---
ctx_dir="$HOME/.claude/run"

kv() { grep -m1 "^${1}:" "${2}" 2>/dev/null | cut -d: -f2- | sed 's/^[[:space:]]*//' || echo ""; }

# P0-2: session key, moved ahead of the window block below so both can key off it.
# Key by session_id; fall back to the transcript filename (named <session_id>.jsonl) when
# the payload omits it — the Stop/SessionStart hooks key by the same id.
_sess_key="$_sess_id"
[[ -z "$_sess_key" && -n "$_transcript" ]] && _sess_key=$(basename "$_transcript" .jsonl 2>/dev/null || true)

# Live model for THIS session: run/session-model-<sid>, read by bin/session-model.sh (model-policy hooks). A PreToolUse hook can fire
# before the transcript holds the new model, and a switch not typed as /model leaves no "Set model to" line, so the transcript alone
# read sonnet on an opus session (2026-09-29). The payload is the one source that is always current. Written atomically; never
# for an unknown model or an id that is not a plain token (no '/', no '.'); the statusline stays silent if the write fails.
if [[ "$model" != "unknown" && "$_sess_key" =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$ ]]; then
  _lm_tmp="${ctx_dir}/.session-model-${_sess_key}.$$"
  if mkdir -p "$ctx_dir" 2>/dev/null && printf '%s\n' "$model" > "$_lm_tmp" 2>/dev/null; then
    mv -f "$_lm_tmp" "${ctx_dir}/session-model-${_sess_key}" 2>/dev/null || rm -f "$_lm_tmp" 2>/dev/null
  fi
fi

# P0-3: resolve the authoritative window. The payload's context_window_size is truth WHEN
# PRESENT; when the payload omits it (jq defaulted field 12 to 200000), prefer THIS
# session's own persisted value from a prior turn — never another session's — so a
# field-less payload can't downgrade a 1M session to 200K. Corrected 2026-08-30: the
# original fix read a single global file, which meant one session's window silently set
# the basis for every other concurrent session (the inverse bug — a 200K session's write
# could downgrade a concurrent 1M session to false "context full" alarms). Falling back to
# the global file is retained only when this session has no key at all (payload omitted
# both session_id and transcript_path) — an edge case, not the common path.
if [[ "${_win_present:-false}" != "true" ]]; then
  _persisted_win=""
  # `2>/dev/null` silences tr, but a failing `<` redirect is the SHELL's error and was never
  # suppressed — a missing file printed "line 122: ...: No such file or directory" onto the
  # statusline. Test for the file first. SPEC §6-25.
  _win_file="${ctx_dir}/actual-window.txt"
  [[ -n "$_sess_key" ]] && _win_file="${ctx_dir}/actual-window-${_sess_key}.txt"
  [[ -f "$_win_file" ]] && _persisted_win=$(tr -d '[:space:]' < "$_win_file" 2>/dev/null || true)
  [[ "$_persisted_win" =~ ^[0-9]+$ && "$_persisted_win" -gt 0 ]] && _ctx_window_size="$_persisted_win"
fi

# P0-1: persist the authoritative context window size from the payload. The Stop and
# SessionStart hooks have no window field in their stdin (only session_id/transcript/cwd),
# so they otherwise guess it from the model string via ss_window_for_model() — which cannot
# tell a 1M window from 200K. Statusline is the only hook that receives context_window_size,
# so it writes it here for the others to read. Written per-session (authoritative — this is
# what ss_window_from_state now reads) and, best-effort, to the global fixed-name file too
# (kept for the no-session-key edge case above and any external reader; no longer consulted
# by Stop/SessionStart's per-session resolution). (|| true: status-file IO is non-fatal by
# the same convention as every other state write — a full disk must never break the session.)
if [[ "${_win_present:-false}" == "true" && "${_ctx_window_size:-0}" =~ ^[0-9]+$ && "${_ctx_window_size:-0}" -gt 0 ]]; then
  mkdir -p "$ctx_dir" 2>/dev/null || true
  if [[ -n "$_sess_key" ]]; then
    _win_tmp=$(mktemp "${ctx_dir}/.actual-window.XXXXXX" 2>/dev/null || mktemp)
    printf '%s\n' "${_ctx_window_size}" > "$_win_tmp" 2>/dev/null \
      && mv -f "$_win_tmp" "${ctx_dir}/actual-window-${_sess_key}.txt" 2>/dev/null || true
  fi
  _win_tmp_g=$(mktemp "${ctx_dir}/.actual-window.XXXXXX" 2>/dev/null || mktemp)
  printf '%s\n' "${_ctx_window_size}" > "$_win_tmp_g" 2>/dev/null \
    && mv -f "$_win_tmp_g" "${ctx_dir}/actual-window.txt" 2>/dev/null || true
fi

# P0-3: the estimate-% must track the resolved window, not the jq 200000 default — otherwise
# a field-less payload on a 1M session reads ~80% when it is really ~16%.
if [[ "${is_estimate:-true}" == "true" && "${total_ctx_tokens:-0}" -gt 0 && "${_ctx_window_size:-0}" -gt 0 ]] 2>/dev/null; then
  ctx_pct=$(( total_ctx_tokens * 100 / _ctx_window_size ))
fi

# P0-2: per-session state files. statusline reads its OWN session's context/banner files
# so concurrent or stale sessions never show each other's data. The global fixed-name files
# remain as a fallback for the first turn (before any per-session write) and for external
# readers.
# SPEC §6-25 (P1): when this session HAS a key, use its own files unconditionally — never
# fall back to the fixed-name file. The old `&&` form only switched when the per-session file
# already existed, so a brand-new session's first render (before its Stop hook has ever run)
# displayed the PREVIOUS session's turn count and duration as its own. The actual-window
# block above already keys strictly; this is the same bug in the file it forgot. A session
# with no key at all still uses the fixed names, and every reader below is `-f` guarded, so a
# not-yet-written per-session file simply renders nothing — blank beats another session's data.
ctx_file="${ctx_dir}/status-context.txt"
banner_file="${ctx_dir}/status-banner.txt"
if [[ -n "$_sess_key" ]]; then
  ctx_file="${ctx_dir}/status-context-${_sess_key}.txt"
  banner_file="${ctx_dir}/status-banner-${_sess_key}.txt"
fi

# Context priority:
#   1. file IS_ESTIMATE:false  → transcript-confirmed real data, always wins
#   2. payload is_estimate=false (used_percentage present) → real API data beats stale file estimate
#   3. file IS_ESTIMATE:true + payload also estimate → file startup estimate (has size-aware baseline)
input_k="" urgency=""
if [[ -f "$ctx_file" ]]; then
  file_pct=$(kv PCT "$ctx_file")
  file_est=$(kv IS_ESTIMATE "$ctx_file")
  input_k=$(kv INPUT_K "$ctx_file")
  urgency=$(kv URGENCY "$ctx_file")
  if [[ -n "$file_pct" ]]; then
    if [[ "$is_estimate" == "false" ]]; then
      # Payload has real data (used_percentage present) — always authoritative.
      # Never override with file: file is shared across concurrent sessions.
      : # ctx_pct and is_estimate stay as-is from payload
    elif [[ "${file_est:-true}" == "false" ]]; then
      # Payload is an estimate; file has real data from a previous/stopped session.
      # Use it as a startup baseline — overridden by payload after first API turn.
      ctx_pct="$file_pct"; is_estimate="false"
    elif [[ "$is_estimate" == "true" && "${total_ctx_tokens:-0}" -eq 0 ]]; then
      # Both are startup estimates AND the payload has no token data yet (pre-first-API turn):
      # the file's size-aware startup baseline is the best we have, so prefer it.
      # P0-1: once the payload carries real tokens (total_ctx_tokens > 0), its percentage is
      # computed against the true context_window_size — do NOT override it with the file
      # estimate, which may have been written against the wrong (200K) window by a Stop hook.
      ctx_pct="$file_pct"
    fi
  fi
fi

# F5: Claude Code transcripts omit cache_read_input_tokens, so ss_parse_transcript gives only
# new non-cached tokens (~19K), not the full context (~131K). The payload's total_input_tokens
# field includes all categories. Override file's INPUT_K when payload has a larger value.
if [[ "${total_ctx_tokens:-0}" -gt 0 ]] 2>/dev/null; then
  _payload_k=$(( total_ctx_tokens / 1000 ))
  if [[ "$is_estimate" == "false" ]]; then
    input_k="$_payload_k"   # real payload data — always authoritative (multi-session safe)
  else
    _file_k="${input_k//[^0-9]/}"; _file_k="${_file_k:-0}"
    [[ "$_payload_k" -gt "$_file_k" ]] && input_k="$_payload_k"
  fi
fi

# F6: stop hook urgency is set from wrong token count (transcript omits cache reads →
# computed free ≈ 148K → no urgency). Recompute from real effective free space.
# P0 (2026-08-30): _eff_k_for_urg used to come from the status-context file's EFF_K key,
# which is only written by the Stop hook AFTER a turn completes — so the FIRST render of
# any session (before any Stop has fired) found no key and fell back to a hardcoded "167"
# (the 200K-window effective size) regardless of the real window. On a 1M session that made
# free = 167 - input_k go negative at ANY usage above ~167K, clamping to 0 free → 🔴 at as
# little as 19% actual usage. Fix: derive the effective size from the already-resolved
# _ctx_window_size (same formula as ss_buffer_size) instead of a separately-read,
# possibly-absent/stale file value, and drive the tier from the shared ss_urgency() helper
# so this can never drift from stop-context-bar's own thresholds again.
if [[ "$is_estimate" == "false" && -n "$input_k" ]] 2>/dev/null; then
  _buf_for_urg=$(( _ctx_window_size * 165 / 1000 ))
  (( _buf_for_urg > 40000 )) && _buf_for_urg=40000
  _eff_k_for_urg=$(( (_ctx_window_size - _buf_for_urg) / 1000 ))
  _input_k_num="${input_k//[^0-9]/}"; _input_k_num="${_input_k_num:-0}"
  _free_k_real=$(( _eff_k_for_urg - _input_k_num ))
  [[ $_free_k_real -lt 0 ]] && _free_k_real=0
  if command -v ss_urgency &>/dev/null; then
    urgency=$(ss_urgency "$_free_k_real" "$_eff_k_for_urg")
  else
    # Defensive fallback only — session-status.sh failed to source (should never happen;
    # stop-context-bar.sh sources the same file the same way). Keeps the old absolute
    # cutoffs rather than crash, so a 200K session still degrades correctly.
    if   (( _free_k_real >= 30 && _free_k_real < 60 )); then urgency="🟡"
    elif (( _free_k_real <  30 && _free_k_real >= 10 )); then urgency="⚠"
    elif (( _free_k_real <  10 ));                        then urgency="🔴"
    else urgency=""
    fi
  fi
fi

ctx_int=$(LC_NUMERIC=C awk "BEGIN{printf \"%d\", ${ctx_pct}+0.5}" 2>/dev/null || echo "${ctx_pct%.*}")
ctx_tilde=""; [[ "$is_estimate" == "true" ]] && ctx_tilde="~"

# IMP-1: inline progress bar ▕█████░░░░▏ — 9 cells (the old trailing ▒ "buffer" cell was constant: no information)
_bar_width=9
_bar_used=$(( ctx_int * _bar_width / 100 ))
[[ $_bar_used -gt $_bar_width ]] && _bar_used=$_bar_width
_bar_free=$(( _bar_width - _bar_used ))
_used_str=""; _free_str=""
for (( _bi=0; _bi<_bar_used; _bi++ )); do _used_str+="█"; done
for (( _bi=0; _bi<_bar_free; _bi++ )); do _free_str+="░"; done
ctx_bar="▕${_used_str}${_free_str}▏"
ctx_str="${ctx_bar} ${ctx_tilde}${ctx_int}%"
[[ -n "$input_k" && "$input_k" != "0" ]] && ctx_str="${ctx_str} ${input_k}K"

# Urgency prefix (prepended to model name for maximum visibility)
# BUG-7: added 🟡 third level (30-60K free)
urgency_prefix=""
case "${urgency:-}" in
  *🔴*) urgency_prefix="🔴 " ;;
  *⚠*)  urgency_prefix="⚠ "  ;;
  *🟡*) urgency_prefix="🟡 " ;;
esac

# Window size tag — from batched jq parse above
win_tag=""
[[ "${_ctx_window_size:-200000}" -ge 900000 ]] 2>/dev/null && win_tag=" 1M"

# --- Git from stop-context-bar.sh / stop-git-status.sh status-banner.txt ---
branch="" git_dirty="" git_unpushed="" git_stash="" git_last=""
if [[ -f "$banner_file" ]]; then
  branch=$(kv GIT_BRANCH "$banner_file")
  dirty_val=$(kv GIT_DIRTY "$banner_file")
  unpushed_val=$(kv GIT_UNPUSHED "$banner_file")
  stash_val=$(kv GIT_STASHES "$banner_file")
  git_last=$(kv GIT_LAST "$banner_file")
  [[ "${dirty_val:-0}" -gt 0 ]]    2>/dev/null && git_dirty="✎${dirty_val}"
  [[ "${unpushed_val:-0}" -gt 0 ]] 2>/dev/null && git_unpushed="↑${unpushed_val}"
  [[ "${stash_val:-0}" -gt 0 ]]    2>/dev/null && git_stash="⚑${stash_val}"
fi
# Fallback: read branch directly from git when claux files absent
[[ -z "$branch" && -n "$cwd" ]] && branch=$(git -C "$cwd" rev-parse --abbrev-ref HEAD 2>/dev/null || echo "")

# "1 days ago" -> "1d ago" (the banner writes git's relative date); anything else is shown as written.
if [[ "$git_last" =~ ^([0-9]+)\ (sec|second|min|minute|hour|day|wk|week|mo|month|yr|year)s?\ ago$ ]]; then
  case "${BASH_REMATCH[2]}" in sec|second) _gu=s ;; min|minute) _gu=m ;; hour) _gu=h ;; day) _gu=d ;; wk|week) _gu=w ;; mo|month) _gu=mo ;; *) _gu=y ;; esac
  git_last="${BASH_REMATCH[1]}${_gu} ago"
fi
# The git tail after the branch (space-separated); the branch itself is a fitted variable (_it_place).
git_parts=()
[[ -n "$git_dirty" ]]    && git_parts+=("$git_dirty")
[[ -n "$git_unpushed" ]] && git_parts+=("$git_unpushed")
[[ -n "$git_stash" ]]    && git_parts+=("$git_stash")
[[ -n "$git_last" ]]     && git_parts+=("$git_last")
git_rest="${git_parts[*]}"

# --- Stale git lock (review-remediation row 31) ---
# A lock left by a killed git (SIGKILL/OOM) blocks every later commit, yet read-only git succeeds
# with it present, so nothing else notices (an 18 h lock on 2026-09-25). Detection is a stat
# check: index.lock older than 10 min and no git process running → a badge beside git on line 1, one WARN per lock.
# Never deleted here — removal is the user's call (backup, rm, restore to roll back).
git_lock=""
if [[ -n "$cwd" ]]; then
  _gd=$(GIT_OPTIONAL_LOCKS=0 git -C "$cwd" rev-parse --absolute-git-dir 2>/dev/null || true)
  _lk_mt=$([[ -n "$_gd" ]] && stat -c %Y "$_gd/index.lock" 2>/dev/null || true)
  if [[ -n "$_lk_mt" ]]; then
    _lk_age=$(( $(date +%s) - _lk_mt ))
    if (( _lk_age > 600 )) && ! pgrep -x git >/dev/null 2>&1; then
      if (( _lk_age >= 3600 )); then git_lock="⚠ git-lock $(( _lk_age / 3600 ))h"
      else git_lock="⚠ git-lock $(( _lk_age / 60 ))m"; fi
      if [[ "$(cat "$ctx_dir/git-lock-warned" 2>/dev/null)" != "$_gd/index.lock $_lk_mt" ]]; then
        log_obs WARN statusline.sh "stale git lock: $_gd/index.lock ($(( _lk_age / 60 )) min, no git process) — remove it by hand after checking" 2>/dev/null || true
        printf '%s\n' "$_gd/index.lock $_lk_mt" > "$ctx_dir/git-lock-warned" 2>/dev/null || true
      fi
    fi
  fi
fi

# --- Session cost ---
cost_str="\$$(LC_NUMERIC=C awk "BEGIN{printf \"%.2f\", ${cost_usd}+0}" 2>/dev/null || echo "0.00")"

# --- Plan usage: session (5h block) + weekly (7d window) from rate_limits ---
# Same figures /usage shows. used_percentage may be a float (e.g. 23.5) → round via awk
# before any integer compare (bare $(( )) would crash on a float under set -e). Empty
# input → empty segment (self-hides), matching every other optional segment.
fmt_usage() {  # $1=label  $2=raw_percentage  → prints "<label> NN%" (⚠-prefixed if ≥80%) or nothing
  local label="$1" raw="$2" pct warn=""
  [[ -z "$raw" ]] && return 0
  pct=$(LC_NUMERIC=C awk "BEGIN{printf \"%d\", ${raw}+0.5}" 2>/dev/null || echo "")
  [[ -z "$pct" ]] && return 0
  [[ "$pct" -ge 80 ]] 2>/dev/null && warn="⚠"
  printf '%s%s %s%%' "$warn" "$label" "$pct"
}
sess_usage_str=$(fmt_usage "5h" "$sess_usage_pct")
week_usage_str=$(fmt_usage "week" "$week_usage_pct")

# --- Lines changed (only shown when nonzero) ---
lines_str=""
if [[ "${lines_added:-0}" -gt 0 || "${lines_removed:-0}" -gt 0 ]] 2>/dev/null; then
  [[ "${lines_added:-0}" -gt 0 ]] && lines_str="+${lines_added}"
  [[ "${lines_removed:-0}" -gt 0 ]] && lines_str="${lines_str:+${lines_str}/}-${lines_removed}"
fi

# --- Handoff age (from claux banner, falls back to direct file) ---
handoff_age=""
if [[ -f "$banner_file" ]]; then
  handoff_val=$(kv HANDOFF "$banner_file")
  [[ -n "$handoff_val" && "$handoff_val" != "none" ]] && handoff_age="⟳ ${handoff_val}"
fi
if [[ -z "$handoff_age" && -n "${CLAUDE_PROJECT_DIR:-}" ]]; then
  _proj="$CLAUDE_PROJECT_DIR"
  _slug=$(echo "$_proj" | sed 's|^/|-|; s|/|-|g')
  handoff_path="$HOME/.claude/projects/${_slug}/memory/sessions/handoff.md"
  if [[ -f "$handoff_path" && -s "$handoff_path" ]]; then
    now=$(date +%s)
    mtime=$(stat -c '%Y' "$handoff_path" 2>/dev/null || echo "$now")
    age_s=$(( now - mtime ))
    if   (( age_s < 3600   )); then handoff_age="⟳ $((age_s/60))m"
    elif (( age_s < 86400  )); then handoff_age="⟳ $((age_s/3600))h"
    else                            handoff_age="⟳ $((age_s/86400))d"
    fi
    # IMP-9: distinguish auto (precompact) vs manual (/handoff) — tag written by precompact-handoff.sh.
    # The test is the TRAILING stamp, never a match anywhere: a handoff quoting a previous one
    # carries both stamps in its body (_handoff_is_auto in log-helpers.sh, SPEC §6-51).
    if [[ -n "$handoff_age" ]]; then
      _handoff_is_auto "$handoff_path" && handoff_age="${handoff_age/⟳/⟳ auto}"
    fi
  fi
fi

# --- Mega-analysis staleness (⚠ only when flagged stale by claux hooks) ---
ana_flag=""
if [[ -f "$banner_file" ]]; then
  analysis_val=$(kv ANALYSIS "$banner_file")
  [[ "$analysis_val" == *"⚠"* ]] && ana_flag="ana⚠"
fi

# --- CLAUDEMD staleness ---
md_flag=""
if [[ -f "$banner_file" ]]; then
  claudemd_val=$(kv CLAUDEMD "$banner_file")
  [[ "$claudemd_val" == *"⚠"* ]] && md_flag="md⚠"
fi

# --- Session uptime (from STARTED_AT in status-banner.txt) ---
uptime_str=""
if [[ -f "$banner_file" ]]; then
  started_at=$(kv STARTED_AT "$banner_file")
  if [[ -n "$started_at" && "$started_at" =~ ^[0-9]+$ ]]; then
    _now=$(date +%s)
    _elapsed=$(( _now - started_at ))
    if (( _elapsed > 60 )); then
      if (( _elapsed >= 3600 )); then
        _upt_h=$(( _elapsed / 3600 ))
        _upt_m=$(( (_elapsed % 3600) / 60 ))
        (( _upt_m > 0 )) && uptime_str="⏱ ${_upt_h}h${_upt_m}m" || uptime_str="⏱ ${_upt_h}h"
      else
        uptime_str="⏱ $(( _elapsed / 60 ))m"
      fi
    fi
  fi
fi

# --- IMP-2: Lifetime Σ accumulator (grows indefinitely; delete file to reset) ---
lifetime_str=""
_lt_raw=$(head -1 "${ctx_dir}/lifetime-output.txt" 2>/dev/null | tr -d '[:space:]' || true)
_lt_raw="${_lt_raw//[^0-9]/}"
if [[ -n "$_lt_raw" && "$_lt_raw" -gt 0 ]] 2>/dev/null; then
  # K tokens -> 1 decimal in M / B (Σ 5612629K made line 1 too wide); integer math, no forks
  _lt_raw=$((10#$_lt_raw))
  if   (( _lt_raw >= 1000000 )); then lifetime_str="Σ $((_lt_raw/1000000)).$((_lt_raw%1000000/100000))B"
  elif (( _lt_raw >= 1000 ));    then lifetime_str="Σ $((_lt_raw/1000)).$((_lt_raw%1000/100))M"
  else lifetime_str="Σ ${_lt_raw}K"; fi
fi

# --- IMP-3: Cache hit rate ---
cache_pct_str=""
if [[ "${total_ctx_tokens:-0}" -gt 0 ]] 2>/dev/null; then
  _cpct=$(( cache_reads * 100 / total_ctx_tokens ))
  [[ "${_cpct:-0}" -gt 0 ]] 2>/dev/null && cache_pct_str="${_cpct}%"
fi

# --- IMP-4/5/10: turn counter, last turn duration, /clear indicator from status-context.txt ---
turns_str="" turn_dur_str="" clear_str=""
if [[ -f "$ctx_file" ]]; then
  # Strip non-digits: an out-of-range octal like "08" tripped
  # `line 409: 08: value too great for base`. turns-total.txt (:407) and lifetime-output.txt
  # (:389) were already sanitised this way; TURNS from kv was not. SPEC §6-25.
  _turns=$(kv TURNS    "$ctx_file"); _turns="${_turns//[^0-9]/}"; _turns="${_turns#"${_turns%%[!0]*}"}"
  _tdur=$( kv TURN_DUR "$ctx_file")
  _clear_ctr=$(kv CLEAR_CTR "$ctx_file")
  _turns_total=0
  _tt_raw=$(head -1 "${ctx_dir}/turns-total.txt" 2>/dev/null | tr -d '[:space:]' || true)
  _tt_raw="${_tt_raw//[^0-9]/}"
  [[ -n "$_tt_raw" && "$_tt_raw" -gt 0 ]] 2>/dev/null && _turns_total="$_tt_raw"
  _turns_display=$(( ${_turns:-0} + ${_turns_total:-0} ))
  [[ "${_turns_display:-0}" -gt 0 ]] 2>/dev/null && turns_str="T:${_turns_display}"
  if [[ "${_tdur:-0}" -gt 3 ]]  2>/dev/null; then
    if (( _tdur >= 3600 )); then
      _tdur_h=$(( _tdur / 3600 ))
      _tdur_m=$(( (_tdur % 3600) / 60 ))
      (( _tdur_m > 0 )) && turn_dur_str="~${_tdur_h}h${_tdur_m}m" || turn_dur_str="~${_tdur_h}h"
    elif (( _tdur >= 60 )); then
      _tdur_s=$(( _tdur % 60 ))
      (( _tdur_s > 0 )) && turn_dur_str="~$(( _tdur / 60 ))m${_tdur_s}s" || turn_dur_str="~$(( _tdur / 60 ))m"
    else
      turn_dur_str="~${_tdur}s"
    fi
  fi
  [[ "${_clear_ctr:-0}" -gt 0 ]] 2>/dev/null && clear_str="↩"
fi

# --- IMP-6/7: token velocity and cost rate (after 10min uptime) ---
velocity_str="" cost_rate_str=""
if [[ -f "$banner_file" ]]; then
  _metric_started=$(kv STARTED_AT "$banner_file")
  if [[ -n "$_metric_started" && "$_metric_started" =~ ^[0-9]+$ ]]; then
    _metric_elapsed=$(( $(date +%s) - _metric_started ))
    if (( _metric_elapsed > 600 )); then
      if [[ -n "$input_k" && "${input_k:-0}" -gt 0 ]] 2>/dev/null; then
        _vh=$(LC_NUMERIC=C awk "BEGIN{printf \"%d\", ${input_k} * 3600 / ${_metric_elapsed}}" 2>/dev/null || echo 0)
        [[ "${_vh:-0}" -gt 0 ]] 2>/dev/null && velocity_str="↑${_vh}K/h"
      fi
      _rate=$(LC_NUMERIC=C awk "BEGIN{printf \"%.2f\", ${cost_usd} * 3600 / ${_metric_elapsed}}" 2>/dev/null || true)
      [[ -n "$_rate" && "$_rate" != "0.00" ]] && cost_rate_str="\$${_rate}/h"
    fi
  fi
fi

# --- CWD segment: tilde-collapsed, last 2 components for deep paths ---
cwd_str=""
if [[ -n "$cwd" ]]; then
  _d="${cwd/#$HOME/\~}"; _d="${_d%/}"
  _depth=$(awk -F'/' '{print NF-1}' <<< "$_d" 2>/dev/null || echo 0)
  if [[ "${_depth:-0}" -gt 2 ]] 2>/dev/null; then
    _b="${_d##*/}"; _p="${_d%/*}"; _p="${_p##*/}"
    cwd_str="…/${_p}/${_b}"
  else
    cwd_str="$_d"
  fi
fi

# ── Layout (plan statusline-redesign, user rulings 2026-10-19 14:34-14:39) ──
# Each line is a list of items in three parallel arrays <NAME>_F (full form), <NAME>_S (short form) and <NAME>_K (a builder for an item that holds
# a long variable - place, agent, plan - or empty). _fit_print takes the first stage that fits the width: 0 full; 1 long variables shortened
# (cwd to its base name, branch / agent / plan to 32 characters, cut in the MIDDLE so both ends stay readable); 2 short labels; 3 variables to
# 16; past that, items move from the right end onto a `↳` line under it. Nothing is ever cut. The width is COLUMNS - 2 (Claude Code sets
# COLUMNS for this script: code.claude.com/docs/en/statusline, "Size output to the terminal"; seen 239 live on 2026-10-19). No valid COLUMNS:
# full forms and no spill, the pre-2026-10-19 behaviour.
_SL_W=0
if [[ "${COLUMNS:-}" =~ ^[1-9][0-9]{0,4}$ ]] && (( 10#$COLUMNS > 2 )); then _SL_W=$(( 10#$COLUMNS - 2 )); fi
# _dw <text> -> _W: display width = characters (counted in UTF-8) + 1 for each wide glyph this script prints (the terminal draws them 2 cells).
_dw() {
  local LC_ALL=C.UTF-8 s="$1" t g n
  n=${#s}
  for g in 💭 💾 🔴 🟡 ⏳; do t="${s//"$g"/}"; n=$(( n + ${#s} - ${#t} )); done
  _W=$n
}
# _mid <text> <max> -> _M: the text, or its first and last characters around one `…` when longer than max.
_mid() {
  local LC_ALL=C.UTF-8 s="$1" m="$2" h t
  if (( ${#s} <= m || m < 5 )); then _M="$s"; return 0; fi
  h=$(( m / 2 )); t=$(( m - 1 - h ))
  _M="${s:0:h}…${s:${#s}-t}"
}
_cap() { if (( $1 >= 3 )); then _C=16; else _C=32; fi; }   # $1 = stage -> _C: the length a long variable is shortened to (stage >= 1)
_it_place() {  # cwd + branch + git tail (+ git lock)
  local st="$1" c="$cwd_str" b="$branch"
  if (( st >= 1 )); then
    _cap "$st"
    if [[ "$c" == */* && "$c" != "~" ]]; then c="${c##*/}"; fi
    _mid "$c" "$_C"; c="$_M"; _mid "$b" "$_C"; b="$_M"
  fi
  _I="$c"
  if [[ -n "$b" ]]; then _I+="${_I:+ }$b"; fi
  if [[ -n "$git_rest" ]]; then _I+="${_I:+ }$git_rest"; fi
  if [[ -n "$git_lock" ]]; then _I+="${_I:+ }$git_lock"; fi
  return 0
}
_it_agent() {
  local st="$1" a="$agent"
  if (( st >= 1 )); then _cap "$st"; _mid "$a" "$_C"; a="$_M"; fi
  if (( st >= 2 )); then _I="[$a]"; else _I="agent $a"; fi
}
_it_plan() {  # plan <name>@<location>; `—` when this session has no active plan but the project has a plan location
  local st="$1" n="${_st_plan:-—}"
  if (( st >= 1 )); then _cap "$st"; _mid "$n" "$_C"; n="$_M"; fi
  _I="plan $n${_st_ploc:+@$_st_ploc}"
}
_item() {  # $1 full $2 short $3 kind $4 stage -> _I
  if [[ -n "$3" ]]; then "_it_$3" "$4"; return 0; fi
  if (( $4 >= 2 )); then _I="$2"; else _I="$1"; fi
}
_fit_print() {  # $1 = array name prefix
  local -n _ff="${1}_F" _fs="${1}_S" _fk="${1}_K"
  local n=${#_ff[@]} st i tot out w iw
  local -a txt=()
  (( n > 0 )) || return 0
  for st in 0 1 2 3; do
    txt=(); tot=$(( 3 * (n - 1) ))
    for (( i = 0; i < n; i++ )); do _item "${_ff[i]}" "${_fs[i]}" "${_fk[i]}" "$st"; txt+=("$_I"); _dw "$_I"; tot=$(( tot + _W )); done
    if (( _SL_W == 0 || tot <= _SL_W )); then break; fi
  done
  out="" w=0
  for (( i = 0; i < n; i++ )); do
    _dw "${txt[i]}"; iw=$_W
    if (( i == 0 )); then out="${txt[i]}"; w=$iw
    elif (( _SL_W > 0 && w + 3 + iw > _SL_W )); then printf '%s\n' "$out"; out="↳ ${txt[i]}"; w=$(( 2 + iw ))
    else out+=" │ ${txt[i]}"; w=$(( w + 3 + iw )); fi
  done
  printf '%s\n' "$out"
}

# --- Line 1: the meters, the place, the session tail ---
model_label="${urgency_prefix}${mode_prefix}${model_short}${win_tag}${effort_suffix}"
L1_F=(); L1_S=(); L1_K=()
_l1() { L1_F+=("$1"); L1_S+=("${2:-$1}"); L1_K+=("${3:-}"); }
_l1 "$model_label"
_ctx_v="${ctx_tilde}${ctx_int}%"
if [[ -n "$input_k" && "$input_k" != "0" ]]; then _ctx_v+=" ${input_k}K"; fi
if [[ -n "$clear_str" ]]; then _ctx_v+=" ${clear_str}"; fi
_l1 "${ctx_bar} ${_ctx_v}" "$_ctx_v"
_usage="${sess_usage_str}"
if [[ -n "$week_usage_str" ]]; then _usage+="${_usage:+ }${week_usage_str}"; fi
if [[ -n "$_usage" ]]; then _l1 "$_usage" "${_usage/week /wk }"; fi
if [[ -n "$cache_pct_str" ]]; then _l1 "cache ${cache_pct_str}" "💾${cache_pct_str}"; fi
if [[ -n "$cwd_str" || -n "$branch" || -n "$git_rest" || -n "$git_lock" ]]; then _l1 "" "" place; fi
if [[ -n "$agent" ]]; then _l1 "" "" agent; fi
_cost_f="$cost_str" _cost_s="$cost_str"
if [[ -n "$cost_rate_str" ]]; then _cost_f+=" $cost_rate_str"; _cost_s+=" $cost_rate_str"; fi
if [[ -n "$velocity_str" ]]; then _vel="${velocity_str#↑}"; _cost_f+=" ${_vel%/h} tok/h"; _cost_s+=" $velocity_str"; fi   # ↑6K/h -> 6K tok/h
_l1 "$_cost_f" "$_cost_s"
if [[ -n "$lines_str" ]]; then _l1 "$lines_str"; fi
_tdv="${turn_dur_str#\~}"
if [[ -n "$turns_str" ]]; then _l1 "turn ${turns_str#T:}${_tdv:+ ($_tdv)}" "T${turns_str#T:}${turn_dur_str:+ $turn_dur_str}"
elif [[ -n "$turn_dur_str" ]]; then _l1 "last turn $_tdv" "$turn_dur_str"; fi
if [[ -n "$uptime_str" ]]; then _l1 "up ${uptime_str#⏱ }" "⏱${uptime_str#⏱ }"; fi
if [[ -n "$lifetime_str" ]]; then _l1 "$lifetime_str" "Σ${lifetime_str#Σ }"; fi
if [[ -n "$handoff_age" ]]; then _hv="${handoff_age#⟳ }"; _hv="${_hv/ ago/}"; _l1 "handoff $_hv" "⟳$_hv"; fi
if [[ -n "$md_flag" ]]; then _l1 "CLAUDE.md⚠" "md⚠"; fi
if [[ -n "$ana_flag" ]]; then _l1 "analysis⚠" "ana⚠"; fi
_fit_print L1

# ── Line 2: warnings — relaxed gates and control state (self-hides when everything is default; printed most severe first) ──
# Surfaces which safety guards are bypassed this session and other control state,
# so a relaxed gate is never invisible. Each segment self-hides when inactive.
line2_parts=()
_st_mem="" _st_ploc="" _st_plan=""   # working state: the state half of line 2, collected while its warnings are built
_slug2=""
[[ -n "$cwd" ]] && _slug2=$(printf '%s' "$cwd" | tr '/' '-')
PB="$HOME/.claude/projects/${_slug2}"

# Gate bypasses — show only when bypassed, annotated by HOW (env var / global / per-project /
# per-session). Session scope added 2026-08-30 alongside /gates-bypass — every guard family gets
# the same three file-scopes autonomous-3c always had, uniform filename shape <family>-bypass[-<sid>].
#
# A SIXTH source was added 2026-09-22: recursive path rules in state/gates-bypass-rules.json.
# Those are exactly the bypasses the old per-project sentinel could not express, so leaving them
# off this line would make the most powerful scope the least visible — the failure that left AC
# silent in four projects. Rules are consulted through the same resolver the guards use, so the
# statusline can never disagree with the gate about whether this cwd is bypassed.
# Gate-resolution cache (plan statusline-redesign, AGREED 2026-10-19 14:39). Profiled 2026-10-19: the resolver's jq runs (a lint and a verdict per
# call, ~12 calls) were 43.5% of a render, and sharing one subshell saved nothing. So the RESOLVER OUTPUTS are memoized per session in
# run/statusline-gates-<sid>: a cached value is used only while the signature of every input the resolver reads is unchanged (canonical and raw
# cwd, session, local date, BYPASS_SESSION_ID, one stat - name, size, mtime, inode - of every top-level state/ file, this project's state/ and this
# session's run sentinels) AND before min(now + 60 s, the next rule-expiry instant or 48 h-horizon entry). Sentinel tests stay live. A session
# with no usable key never caches. Every failure falls back to calling the resolver, never to a cached guess.
_GC_INIT=0; _GC_FILE=""; _GC_SIG=""; _GC_DIRTY=0; _GC_NOW=0; _GC_VU=0; _GC_OUT=""
declare -A _GC=()
_gc_init() {
  (( _GC_INIT )) && return 0
  _GC_INIT=1
  printf -v _GC_NOW '%(%s)T' -1
  [[ "${_sess_key:-}" =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$ ]] || return 0
  _GC_FILE="$ctx_dir/statusline-gates-$_sess_key"
  local canon="" today f n stl="" k r v sig vu
  local -a fs=()
  canon=$(cd -P -- "${cwd:-/}" 2>/dev/null && pwd) || canon=""
  printf -v today '%(%F)T' -1
  for f in "$HOME/.claude/state"/*; do if [[ -f "$f" ]]; then fs+=("$f"); fi; done
  if [[ -n "${_slug2:-}" ]]; then for f in "$PB/state"/*; do if [[ -f "$f" ]]; then fs+=("$f"); fi; done; fi
  for n in ask-human-gate-bypass ask-bash-firewall-bypass ask-human-question-guard-bypass advisor-completion-guard-bypass advisor-prework-guard-bypass confident-pick keep-going expertise-gate-off; do
    if [[ -e "$ctx_dir/$n-$_sess_key" ]]; then fs+=("$ctx_dir/$n-$_sess_key"); fi
  done
  if (( ${#fs[@]} )); then stl=$(stat -c '%n %s %Y %i' -- "${fs[@]}" 2>/dev/null) || stl="stat-failed $_GC_NOW"; fi
  _GC_SIG="v1|$canon|${cwd:-}|$_sess_key|$today|${BYPASS_SESSION_ID:-}|${stl//$'\n'/|}"
  if [[ -f "$_GC_FILE" && ! -L "$_GC_FILE" ]]; then
    { IFS= read -r sig && IFS= read -r vu; } < "$_GC_FILE" 2>/dev/null || sig=""
    if [[ "$sig" == "$_GC_SIG" && "$vu" =~ ^[0-9]{1,12}$ ]] && (( _GC_NOW < vu )); then
      _GC_VU=$vu
      while IFS=$'\t' read -r k r v; do
        if [[ -n "$k" && "$r" =~ ^[0-9]{1,3}$ ]]; then _GC[$k]="$r"$'\t'"$v"; fi
      done < <(tail -n +3 "$_GC_FILE" 2>/dev/null)
    fi
  fi
  return 0
}
# _gc_call <key> <sid|-> <resolver function> <args...> -> _GC_OUT (first output line); returns the call's status. `sid` runs it with
# BYPASS_SESSION_ID set, as bypass_level / bypass_expiring were always called here.
_gc_call() {
  local key="$1" sm="$2" rc=0 v
  shift 2
  _gc_init
  if [[ -n "${_GC[$key]+x}" ]]; then v="${_GC[$key]}"; _GC_OUT="${v#*$'\t'}"; return "${v%%$'\t'*}"; fi
  # Script-relative, like log-helpers.sh above — NOT "$HOME/.claude/hooks/...". The resolver reads
  # $HOME to find the rules file, so a test (or a relocated install) points HOME elsewhere and an
  # $HOME-derived source path would silently find nothing and report "no bypass".
  if [[ "$sm" == sid ]]; then
    _GC_OUT=$(BYPASS_SESSION_ID="${_sess_key:-}"; source "${BASH_SOURCE[0]%/*}/bypass-resolve.sh" 2>/dev/null && "$@" 2>/dev/null) || rc=$?
  else
    _GC_OUT=$(source "${BASH_SOURCE[0]%/*}/bypass-resolve.sh" 2>/dev/null && "$@" 2>/dev/null) || rc=$?
  fi
  _GC_OUT="${_GC_OUT%%$'\n'*}"
  _GC[$key]="$rc"$'\t'"$_GC_OUT"
  _GC_DIRTY=1
  return "$rc"
}
# Persist after the render. A rebuilt cache gets a fresh validity: min(now + 60, the next instant a rule expires or enters the 48 h horizon of
# the ⏳ expiry warning); a date-only `expires` ends at the next local midnight, as the resolver's alive() reads it.
_gc_save() {
  [[ -n "$_GC_FILE" ]] && (( _GC_DIRTY )) || return 0
  local now=$_GC_NOW vu e b lst="" rules="$HOME/.claude/state/gates-bypass-rules.json" k tmp
  if (( _GC_VU > now )); then vu=$_GC_VU
  else
    vu=$(( now + 60 ))
    if [[ -f "$rules" ]]; then
      lst=$(jq -r '.rules[]? | .expires? // empty | strings | if test("^[0-9]{4}-[0-9]{2}-[0-9]{2}$") then . + " +1 day" else . end' "$rules" 2>/dev/null) || lst=""
      if [[ -n "$lst" ]]; then
        while read -r e; do
          [[ "$e" =~ ^[0-9]{1,12}$ ]] || continue
          for b in "$e" $(( e - 172800 )); do if (( b > now && b < vu )); then vu=$b; fi; done
        done < <(printf '%s\n' "$lst" | date -f - +%s 2>/dev/null)
      fi
    fi
  fi
  tmp="$_GC_FILE.$$"
  {
    printf '%s\n%s\n' "$_GC_SIG" "$vu"
    for k in "${!_GC[@]}"; do printf '%s\t%s\n' "$k" "${_GC[$k]}"; done
  } > "$tmp" 2>/dev/null && mv -f "$tmp" "$_GC_FILE" 2>/dev/null || rm -f "$tmp" 2>/dev/null || true
  return 0
}
_bypass_rule_hit() {  # $1=family code → 0 if a RULE (not a sentinel) bypasses this cwd
  local fam="$1"
  [[ -n "${cwd:-}" ]] || return 1
  [[ -f "$HOME/.claude/state/gates-bypass-rules.json" ]] || return 1
  # kg / eg / cf: a rule can only grant them if its text names the family, so skip the resolver (a jq subshell each, on every render) when nothing does.
  if [[ "$fam" == kg || "$fam" == eg || "$fam" == cf ]]; then grep -qF -e "\"$fam\"" "$HOME/.claude/state/gates-bypass-rules.json" 2>/dev/null || return 1; fi
  _gc_call "applies $fam" - bypass_applies "$fam" "$cwd"
}
# _fmt_left $1=var $2=seconds left (> 0): the ONE time-left format (plan statusline-time-left, user 2026-10-19 18:34) for the UNATTENDED window,
# the ⏳ expiry and the keep-going expiry - `<1m`, `Nm` under 1 h, `Nh` under 48 h, `Nd` from 48 h, always rounded DOWN: never more than is left,
# and one deadline reads the same in every item (it read `UNATTENDED(allow,1d)` beside `⏳42h`). Sets the named global: no $( ) subshell.
_fmt_left() {
  local _fs=$2 _fv
  if (( _fs >= 172800 )); then _fv="$(( _fs / 86400 ))d"; elif (( _fs >= 3600 )); then _fv="$(( _fs / 3600 ))h"
  elif (( _fs >= 60 )); then _fv="$(( _fs / 60 ))m"; else _fv="<1m"; fi
  printf -v "$1" '%s' "$_fv"
}
# _gate_bypass $1=label $2=envval $3=globalfile $4=projfile $5=sessionfile $6=family $7=non-empty → show a rule's expiry.
# Sets _GB ("label(how[,time left])", empty = not granted), _GB_HOW, _GB_LVL ("!" at level total) and _GB_X (time left) - globals, not
# stdout: a $( ) caller would run it in a subshell and lose the cache.
_gate_bypass() {
  local label="$1" envv="$2" gfile="$3" pfile="$4" sfile="$5" fam="${6:-}" showexp="${7:-}" how="" xtag="" _x="" _xe=0 _xl=0 _now
  _GB="" _GB_HOW="" _GB_LVL="" _GB_X=""
  if   [[ -n "$envv" ]];                 then how="env"
  elif [[ -f "$gfile" ]];                then how="g"
  elif [[ -n "$pfile" && -f "$pfile" ]]; then how="proj"
  elif [[ -n "$sfile" && -f "$sfile" ]]; then how="sess"
  elif [[ -n "$fam" ]] && _bypass_rule_hit "$fam"; then how="rule"
  fi
  # TOTAL level (2026-09-24): fw/perm grants at level total carry a `!`. The EFFECTIVE level, as the firewall computes it (any covering total
  # grant wins) — the session sentinel's content is read directly because the statusline's session file lives under its own ctx_dir. The -f
  # test comes first: a `<` on a missing file is the SHELL's error, printed before tr's 2>/dev/null applies (it leaked onto stderr).
  if [[ -n "$how" && "$how" != env && ( "$fam" == fw || "$fam" == perm ) ]]; then
    if [[ -n "$sfile" && -f "$sfile" && "$(tr -d '[:space:]' < "$sfile" 2>/dev/null)" == total ]] \
       || { _gc_call "level $fam" sid bypass_level "$fam" "${cwd:-}" || true; [[ "$_GC_OUT" == total ]]; }; then
      label="$label!"; _GB_LVL="!"
    fi
  fi
  # Expiry (keep-going, 2026-10-04): shown ONLY for a rule-armed grant that ends — the covering rules' latest `expires`; a rule without one is forever and shows nothing.
  # Only `rule` can carry it: a sentinel has no expiry field, and the precedence above reports a sentinel before a rule. Formatted by _fmt_left.
  if [[ "$how" == rule && -n "$showexp" ]]; then
    _gc_call "rexp $fam" - bypass_rule_expiry "$fam" "${cwd:-}" || true
    _x="$_GC_OUT"
    if [[ "$_x" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then _xe=$(date -d "$_x +1 day" +%s 2>/dev/null) || _xe=0   # valid through that LOCAL day
    elif [[ "$_x" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9:]{8}Z$ ]]; then _xe=$(date -u -d "$_x" +%s 2>/dev/null) || _xe=0; fi
    printf -v _now '%(%s)T' -1
    _xl=$(( _xe - _now )) || _xl=0
    if (( _xe > 0 && _xl > 0 )); then
      _fmt_left _GB_X "$_xl"
      xtag=",$_GB_X"
    fi
  fi
  if [[ -n "$how" ]]; then _GB_HOW="$how"; _GB="$label($how$xtag)"; fi
  return 0
}
_ah_sess="${_sess_key:+$ctx_dir/ask-human-gate-bypass-$_sess_key}"
_fw_sess="${_sess_key:+$ctx_dir/ask-bash-firewall-bypass-$_sess_key}"
_qg_sess="${_sess_key:+$ctx_dir/ask-human-question-guard-bypass-$_sess_key}"
_ac_sess="${_sess_key:+$ctx_dir/advisor-completion-guard-bypass-$_sess_key}"
_pw_sess="${_sess_key:+$ctx_dir/advisor-prework-guard-bypass-$_sess_key}"
# The gates group (line 2): one entry "<family>|<! or empty>|<source>" per granted family, in this order; eg (the expertise gate's off-switch)
# joins it below. Rendered as `⚠ bypassed ah fw! qg (rule) eg (sess)` - one (source) after the families it granted.
_gates=()
_gate_push() { if [[ -n "$_GB" ]]; then _gates+=("$1|$_GB_LVL|$_GB_HOW"); fi; return 0; }
_gate_bypass "ah" "" "$HOME/.claude/state/ask-human-gate-bypass" "${_slug2:+$PB/state/ask-human-gate-bypass}" "$_ah_sess" "ah"; _ahb="$_GB"; _gate_push ah
_gate_bypass "fw" "${CLAUDE_BASH_FIREWALL_OFF:-}" "$HOME/.claude/state/ask-bash-firewall-bypass" "${_slug2:+$PB/state/ask-bash-firewall-bypass}" "$_fw_sess" "fw"; _gate_push fw
_gate_bypass "qg" "${QGUARD_OFF:-}" "$HOME/.claude/state/ask-human-question-guard-bypass" "${_slug2:+$PB/state/ask-human-question-guard-bypass}" "$_qg_sess" "qg"; _gate_push qg
# AC = advisor-completion-guard (Rule 6C backstop). Same three-scope surface as the others;
# it was the one guard family with NO visibility, so a bypassed 6C gate was silent.
_gate_bypass "ac" "${ACGUARD_OFF:-}" "$HOME/.claude/state/advisor-completion-guard-bypass" "${_slug2:+$PB/state/advisor-completion-guard-bypass}" "$_ac_sess" "ac"; _gate_push ac
# PW = advisor-prework-guard (Rule 3C backstop). Added with the guard itself — a new gate family
# gets its statusline row in the same change, never as a follow-up (that omission is what left AC
# invisible in 4 projects until the 2026-08-22 audit).
_gate_bypass "pw" "${PREWORK_OFF:-}" "$HOME/.claude/state/advisor-prework-guard-bypass" "${_slug2:+$PB/state/advisor-prework-guard-bypass}" "$_pw_sess" "pw"; _gate_push pw
# PERM = the settings.json permission layer. RULES-ONLY: unlike the five above it has no env var
# and no sentinel files — a permission bypass is armed by permission-swap.sh, and its blacklists
# come from `perm` rules compiled into synthesized ask rules. The empty scope arguments are
# deliberate, not placeholders; _gate_bypass skips empty paths and falls through to the rule check.
_gate_bypass "perm" "" "" "" "" "perm"; _gate_push perm

# A malformed rules file disables EVERY rule-based bypass at once (strict-and-loud model).
# The resolver drops this marker; without it the only symptom would be gates mysteriously
# firing again, with no indication that the cause is one typo in the config.
[[ -f "$ctx_dir/bypass-rules-invalid" ]] && line2_parts+=("⚠⚠ RULES-INVALID")
# Memory mode, plan location and the active plan are WORKING STATE, not warnings: they render after the warnings on line 2 (plan statusline-redesign).

# Memory mode (session-remember). Mirrors common.sh precedence AND scope so a relaxed
# memory mode is never invisible — including the per-project lists, which were the gap:
#   OFF ← global DISABLED file        OR  this project in blacklist
#   RO  ← global READONLY file        OR  this project in readonly-list  OR  SR_READONLY=1 env
#   lean appended when DISABLED.lean exists.
# Annotated by HOW (g=global file · proj=per-project list · env=env var) for parity with the
# gate-bypass row above. The per-project lists key on CLAUDE_PROJECT_DIR — the SAME slug
# session-remember uses (common.sh:58) — which may differ from cwd; match it exactly, and only
# when CLAUDE_PROJECT_DIR is set (session-remember disables itself entirely when it is not).
_SR="$HOME/.claude/hooks/session-remember"
_sr_slug=""
[[ -n "${CLAUDE_PROJECT_DIR:-}" ]] && _sr_slug=$(printf '%s' "$CLAUDE_PROJECT_DIR" | tr '/' '-')
_sr_in_list() {  # $1=listfile → 0 if _sr_slug is a non-comment exact line (same parse as common.sh)
  local f="$1"
  [[ -n "$_sr_slug" && -f "$f" ]] || return 1
  # `--` terminates options: slugs start with '-' (path → tr '/' '-') and would otherwise
  # be parsed as grep flags.
  grep -vE '^[[:space:]]*(#|$)' "$f" 2>/dev/null | grep -qxF -- "$_sr_slug"
}
_mem=""
if   [[ -f "$_SR/DISABLED" ]];          then _mem="OFF(g)"
elif _sr_in_list "$_SR/blacklist";       then _mem="OFF(proj)"
elif [[ -f "$_SR/READONLY" ]];          then _mem="RO(g)"
elif _sr_in_list "$_SR/readonly-list";   then _mem="RO(proj)"
elif [[ "${SR_READONLY:-}" == "1" ]];   then _mem="RO(env)"
fi
[[ -f "$_SR/DISABLED.lean" ]] && _mem="${_mem:+$_mem }lean"
_st_mem="$_mem"

# Plan-location sentinel (repo|global) for this project.
if [[ -n "$_slug2" && -f "$PB/plan-location" ]]; then
  _ploc=$(head -1 "$PB/plan-location" 2>/dev/null | tr -d '[:space:]' || true)
  [[ -n "$_ploc" ]] && _st_ploc="${_ploc}"
fi

# Active plan (Rule 17): per-session pointer at run/active-plan-<session>, holding the
# absolute path of the plan THIS session adopted (written at Phase 4, cleared at Phase 8,
# re-written on Phase 0 restore). "Current plan" is session state, NOT a globbable location:
# plan files live under many project slugs (and a session may switch cwd), and concurrent
# sessions each have their own active plan — so keying on the payload session_id (the same
# contract autonomous-3c relies on, below) is the only correct signal. No glob fallback; the
# target must still exist, which self-heals a stale pointer left by a deleted plan file.
_planf=""
if [[ -n "$_sess_key" && -f "${ctx_dir}/active-plan-${_sess_key}" ]]; then
  _pp=$(head -1 "${ctx_dir}/active-plan-${_sess_key}" 2>/dev/null || true)
  [[ -n "$_pp" && -f "$_pp" ]] && _planf=$(basename "$_pp" .plan.md)
fi
[[ -n "$_planf" ]] && _st_plan="${_planf}"

# Line 2's STATE half (after its warnings; was line 3 until plan statusline-redesign): mode(+cf), keep-going, advisor, plan@location, review,
# expertise, memory. Mode + expertise (user ask 2026-10-03): the SessionStart banner's `▸ MODE` / `▸ Expertise` lines reach the model only, so the
# user never saw them. Mode = the ask-human (ah) family, the same signal the banner resolves ($_ahb is non-empty exactly when ah is bypassed).
# Expertise = file tests only (no git: the statusline renders constantly), same sources as the banner's line.
L2S_F=(); L2S_S=(); L2S_K=()
_l2s() { L2S_F+=("$1"); L2S_S+=("${2:-$1}"); L2S_K+=("${3:-}"); }
# Confident picks (family cf, row 26zg): an independent enable that changes the MID-TASK question policy of either mode, so it rides on the mode token
# (autonomous+cf / spec+cf). Same six scopes through the shared resolver; a rule is consulted only when its text names "cf".
_gate_bypass "cf" "" "$HOME/.claude/state/confident-pick" "${_slug2:+$PB/state/confident-pick}" "${_sess_key:+$ctx_dir/confident-pick-$_sess_key}" "cf"
_cf=""; if [[ -n "$_GB" ]]; then _cf="+cf"; fi
if [[ -n "$_ahb" ]]; then _l2s "autonomous$_cf"; else _l2s "spec$_cf"; fi
# keep-going (resolver family kg) and the expertise gate's off-switch (family eg): the same six scopes as every gate, annotated by HOW
# (env | g | proj | sess | rule). Both read the shared resolver, so the badge cannot disagree with the hook. eg joins the gates group.
_gate_bypass "keep-going" "" "$HOME/.claude/state/keep-going" "${_slug2:+$PB/state/keep-going}" "${_sess_key:+$ctx_dir/keep-going-$_sess_key}" "kg" 1
# Continuation badge (user ruling 2026-10-04): "↻n/CAP Nm" = the guard blocked a stop n times for the current prompt, the last one N minutes ago. Read from the
# counter the guard writes ("<key> <n>", run/keep-going-count-<sid>); shown only while armed AND the file is <= 10 minutes old, so an idle session shows nothing.
# The counter is "<key> <n> <cap>"; <cap> is the cap the guard resolved ("unlimited" shows ∞). A counter without a valid third field (written by an older
# guard) falls back to _KG_CAP, which duplicates hooks/keep-going-guard.sh DEFAULT_CAP; test-statusline.sh KC9 fails if they differ.
_KG_CAP=25
if [[ -n "$_GB" ]]; then
  _kgsrc="$_GB_HOW${_GB_X:+, $_GB_X}" _kgbadge=""
  if [[ -n "${_sess_key:-}" && -f "$ctx_dir/keep-going-count-$_sess_key" ]]; then
    _kgn=""; _kgm=0; _kgc=""
    read -r _ _kgn _kgc <"$ctx_dir/keep-going-count-$_sess_key" 2>/dev/null || _kgn=""
    if [[ "$_kgc" == unlimited ]]; then _kgc='∞'; elif [[ "$_kgc" =~ ^[0-9]{1,6}$ ]]; then _kgc=$((10#$_kgc)); else _kgc=$_KG_CAP; fi
    _kgm=$(stat -c %Y "$ctx_dir/keep-going-count-$_sess_key" 2>/dev/null) || _kgm=0
    if [[ "$_kgn" =~ ^[0-9]{1,3}$ && "$_kgm" =~ ^[0-9]+$ ]]; then
      _kga=$(( $(date +%s) - _kgm )) || _kga=-1
      if (( _kga >= 0 && _kga <= 600 )); then _kgbadge=" ↻$((10#$_kgn))/$_kgc $((_kga / 60))m"; fi
    fi
  fi
  _l2s "keep-going ($_kgsrc)$_kgbadge" "kg ($_kgsrc)$_kgbadge"
fi
_egenv=""; if [[ "${EXPERTISE_GATE_OFF:-}" == 1 ]]; then _egenv=1; fi
_gate_bypass "eg" "$_egenv" "$HOME/.claude/state/expertise-gate-off" "${_slug2:+$PB/state/expertise-gate-off}" "${_sess_key:+$ctx_dir/expertise-gate-off-$_sess_key}" "eg"; _gate_push eg
# Advisor (user pick 2026-10-16 13:13; settings said fable while every call in this session ran on opus, and nothing showed it). The payload has no advisor
# field (code.claude.com/docs/en/statusline); the transcript has three: every assistant entry carries a top-level requestedModel and, when Claude Code
# ATTACHED an advisor to that request, advisorModel (absent on a request sent without one - measured on 30 days of transcripts); an answered call adds a
# usage.iterations[] entry of type advisor_message with the model that answered; a failed call is an advisor_tool_result_error with an error_code and no
# such entry (checked on real records). Read from a 4 MB tail in ONE pass (2026-10-19: two tails were most of the 19% this block cost) with raw-JSON
# patterns only: a record quoted inside a tool result is escaped (\"type\") and never matches. grep -n keeps the line, so the LAST request line's
# advisorModel is told apart from older ones. Cached per session in run/advisor-last-<sid> ("<attached|none|-> <answered|->", - = not seen) so an
# older record still shows. CONFIGURED = advisorModel from settings, local > project > user, the project being workspace.project_dir (the launch dir;
# cwd drifts) - managed settings and the --advisor flag are not readable here.
# advisor <attached model><✓ answered | ✗code last call failed | nothing: no call yet> · advisor off = the last request carried no advisor, nothing is
# configured, or CLAUDE_CODE_DISABLE_ADVISOR_TOOL=1 · advisor <configured>? = no request seen yet. ⚠ ADVISOR(<configured>→<attached|off>) when the
# families differ (versions are not compared). Every step leaves the render intact.
_adfam() { if [[ "$1" =~ ^claude-([a-z]+)- ]]; then printf '%s' "${BASH_REMATCH[1]}"; elif [[ "$1" =~ ^[a-z]{2,20}$ ]]; then printf '%s' "$1"; fi; return 0; }
_adv=""
if [[ "${CLAUDE_CODE_DISABLE_ADVISOR_TOOL:-}" == 1 ]]; then
  _adv="off"
else
  _adc=""; _adpd="${_proj_dir:-$cwd}"
  for _adf in "${_adpd:+$_adpd/.claude/settings.local.json}" "${_adpd:+$_adpd/.claude/settings.json}" "$HOME/.claude/settings.json"; do
    if [[ -n "$_adf" && -f "$_adf" ]]; then
      _adc=$(jq -r '.advisorModel // empty | strings' "$_adf" 2>/dev/null) || _adc=""
      if [[ -n "$_adc" ]]; then break; fi
    fi
  done
  if [[ ! "$_adc" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$ ]]; then _adc=""; fi
  _adl=""; _adlm=""; _adrq=""
  if [[ -n "$_transcript" && -f "$_transcript" ]]; then
    # Out: line 1 = the last advisor event (message or error), line 2 = the last advisor_message, line 3 = REQ<space><advisorModel of the last
    # request line, or empty> when any request line was seen.
    _adscan=$(tail -c 4000000 "$_transcript" 2>/dev/null | command grep -a -n -o -E '"type":"advisor_message","model":"[A-Za-z0-9._-]{1,64}"|"type":"advisor_tool_result_error","error_code":"[a-z_]{1,40}"|"requestedModel"|"advisorModel":"[A-Za-z0-9._-]{1,64}"' 2>/dev/null \
      | awk '{ ln = $0; sub(/:.*/, "", ln); m = $0; sub(/^[0-9]+:/, "", m) }
             m ~ /^"type":"advisor_/ { ev = m; if (m ~ /advisor_message/) msg = m; next }
             m == "\"requestedModel\"" { rq = ln; next }
             m ~ /^"advisorModel"/ { am[ln] = m }
             END { print ev; print msg; if (rq != "") print "REQ " am[rq] }' 2>/dev/null) || _adscan=""
    _adarr=(); mapfile -t _adarr <<<"$_adscan"
    _adl="${_adarr[0]:-}"; _adlm="${_adarr[1]:-}"; _adrq="${_adarr[2]:-}"
  fi
  _adst=""; _adm=""; _adcode=""; _adat=""
  if [[ "$_adl" =~ \"error_code\":\"([a-z_]+)\" ]]; then _adst=err; _adcode="${BASH_REMATCH[1]}"
  elif [[ -n "$_adl" ]]; then _adst=ok; fi
  if [[ "$_adlm" =~ \"model\":\"([A-Za-z0-9._-]+)\" ]]; then _adm="${BASH_REMATCH[1]}"; fi
  if [[ "$_adrq" =~ \"advisorModel\":\"([A-Za-z0-9._-]+)\" ]]; then _adat="${BASH_REMATCH[1]}"
  elif [[ "$_adrq" == REQ* ]]; then _adat=none; fi
  _adk="${_sess_key:+$ctx_dir/advisor-last-$_sess_key}"
  if [[ -n "$_adk" && -f "$_adk" && ! -L "$_adk" ]]; then
    _adca=""; _adcm=""; read -r _adca _adcm < "$_adk" 2>/dev/null || true
    if [[ -z "$_adat" && "$_adca" != - && "$_adca" =~ ^[A-Za-z0-9._-]{1,64}$ ]]; then _adat="$_adca"; fi
    if [[ -z "$_adm" && "$_adcm" =~ ^[A-Za-z0-9._-]{1,64}$ && "$_adcm" != - ]]; then _adm="$_adcm"; [[ -n "$_adst" ]] || _adst=ok; fi
  fi
  if [[ -n "$_adk" && ( -n "$_adat" || -n "$_adm" ) ]]; then
    _adnew="${_adat:--} ${_adm:--}"
    if [[ "$(cat "$_adk" 2>/dev/null || true)" != "$_adnew" ]]; then
      { printf '%s\n' "$_adnew" > "$_adk.$$" && mv -f "$_adk.$$" "$_adk"; } 2>/dev/null || rm -f "$_adk.$$" 2>/dev/null || true
    fi
  fi
  _ada=$(_adfam "$_adm"); [[ -n "$_ada" ]] || _ada="$_adm"
  _adcf=$(_adfam "$_adc"); [[ -n "$_adcf" ]] || _adcf="$_adc"
  _admk=""; if [[ "$_adst" == ok ]]; then _admk="✓"; elif [[ "$_adst" == err ]]; then _admk="✗${_adcode}"; fi
  if [[ "$_adat" == none ]]; then
    _adv="off"
    if [[ -n "$_adcf" ]]; then line2_parts+=("⚠ ADVISOR(${_adcf}→off)"); fi
  elif [[ -n "$_adat" ]]; then
    _adaf=$(_adfam "$_adat"); [[ -n "$_adaf" ]] || _adaf="$_adat"
    _adv="${_adaf}${_admk}"
    if [[ -n "$_adcf" && "$_adcf" != "$_adaf" ]]; then line2_parts+=("⚠ ADVISOR(${_adcf}→${_adaf})"); fi
  elif [[ "$_adst" == ok ]]; then
    _adv="${_ada}✓"
    if [[ -n "$_adcf" && "$_adcf" != "$_ada" ]]; then line2_parts+=("⚠ ADVISOR(${_adcf}→${_ada})"); fi
  elif [[ "$_adst" == err ]]; then
    _adv="${_ada:-${_adcf:-?}}✗${_adcode}"
  elif [[ -n "$_adcf" ]]; then
    _adv="${_adcf}?"
  else
    _adv="off"
  fi
fi
_l2s "advisor $_adv" "adv $_adv"
if [[ -n "$_st_plan" || -n "$_st_ploc" ]]; then _l2s "" "" plan; fi
# Bypass-review queue (framework-health step 5.5): "review N !K ✗R" = N unreviewed events, K of them risky, R rejected groups waiting
# for a tightened rule. Read from the summary bin/bypass-review.sh writes (never the queue: this renders constantly); an absent or
# unreadable file, a non-integer count, or nothing to say shows no segment.
_rvf="$HOME/.claude/run/bypass-review-summary.json"
if [[ -f "$_rvf" ]]; then
  _rv=$(jq -r 'if ([.unreviewed, .risky, .rejected] | all(type == "number" and . >= 0 and . == floor)) then "\(.unreviewed) \(.risky) \(.rejected)" else empty end' "$_rvf" 2>/dev/null) || _rv=""
  if [[ "$_rv" =~ ^([0-9]{1,9})\ ([0-9]{1,9})\ ([0-9]{1,9})$ ]] && (( 10#${BASH_REMATCH[1]} + 10#${BASH_REMATCH[3]} > 0 )); then
    _rvs="$((10#${BASH_REMATCH[1]}))"
    if (( 10#${BASH_REMATCH[2]} > 0 )); then _rvs+=" !$((10#${BASH_REMATCH[2]}))"; fi
    if (( 10#${BASH_REMATCH[3]} > 0 )); then _rvs+=" ✗$((10#${BASH_REMATCH[3]}))"; fi
    _l2s "review $_rvs" "rv $_rvs"
  fi
fi
if [[ -n "$cwd" ]]; then
  _exs="none"
  _cw="${cwd%/}"; _cw="${_cw%/.}"; _tp="${_cw%/*}/.claude/expertise"; _tn="${_cw##*/}"   # parameter expansion, no forks (this renders constantly)
  if [[ -f "$cwd/.claude/expertise/index.md" ]] || { [[ -f "$_tp/index.md" ]] && [[ -f "$_tp/$_tn/index.md" || -f "$_tp/$_tn/practices.md" ]]; }; then _exs="tree"   # in-tree store: own, or the container's entry for this unit (mirror of expertise_gate.intree_home)
  elif [[ -f "$cwd/.claude/rules/expertise-core.md" || -f "$cwd/.claude/EXPERTISE-REFERENCE.md" ]]; then _exs="pack"
  elif [[ -f "$cwd/.claude/expertise.md" ]]; then _exs="repo"
  elif [[ -f "$HOME/.claude/projects/$(printf '%s' "$cwd" | tr '/.' '--')/expertise/index.md" ]]; then _exs="store"
  elif [[ -f "$cwd/CLAUDE.md" ]]; then _exs="CLAUDE.md"; fi
  _l2s "expertise ${_exs}" "xp ${_exs}"
fi
if [[ -n "$_st_mem" ]]; then _l2s "memory $_st_mem" "mem $_st_mem"; fi

# Autonomous-3C: safety gates suppressed. Persistent sentinels (state/, manual-removal,
# no expiry) outrank the per-session marker (run/, auto-cleared at Phase 8). Precedence
# g > proj > session — show the broadest active scope, double-warn for the sticky ones.
# Session filename renamed autonomous-3c-<sid> -> autonomous-3c-bypass-<sid> 2026-08-30 to match
# the uniform <family>-bypass[-<sid>] shape every other gate family now uses.
if   [[ -f "$HOME/.claude/state/autonomous-3c-bypass" ]];          then line2_parts+=("⚠⚠ AUTO-3C(g)")
elif [[ -n "$_slug2" && -f "$PB/state/autonomous-3c-bypass" ]];     then line2_parts+=("⚠⚠ AUTO-3C(proj)")
elif [[ -n "$_sess_key" && -f "${ctx_dir}/autonomous-3c-bypass-${_sess_key}" ]]; then line2_parts+=("⚠ AUTO-3C")
fi

# PERM-OPEN / PERM-PROJ: bin/permission-swap.sh / bin/permission-swap-project.sh armed.
# Sibling block to AUTO-3C above, deliberately NOT nested inside the BYPASS guard below —
# that guard only fires once run/permission-mode-<sid> exists (written by the Stop hook),
# which is absent on a session's first render, so nesting here would make the segment
# vanish exactly during the session-start window it exists to warn about. PERM-PROJ reuses
# the same raw-$PWD _slug2 the project script's own slug convention uses, so the two agree
# by construction.
# `!` = armed at level TOTAL (0 ask / 0 deny, blacklists ignored; project: its own files emptied too).
_lvl_mark() { [[ "$(jq -r '.level // "normal"' "$1" 2>/dev/null)" == total ]] && printf '!'; return 0; }
if [[ -f "$HOME/.claude/state/permission-profile-permissive.json" ]]; then
  line2_parts+=("⚠⚠⚠ PERM-OPEN$(_lvl_mark "$HOME/.claude/state/permission-profile-permissive.json")")
fi
if [[ -n "$_slug2" && -f "$PB/state/permission-profile-project-added.json" ]]; then
  line2_parts+=("⚠ PERM-PROJ$(_lvl_mark "$PB/state/permission-profile-project-added.json")")
fi

# UNATTENDED (was WINDOW until 2026-10-04): the unattended window (state/unattended.json, plan unattended-window). A LIVE window cannot be ended from inside a session (the marker Write is
# core-denied), so it must be visible at a glance. Mirrors bin/lib/unattended.py read_marker + select (the engine's reader; parity cases TW1-TW28 here and in
# hooks/tests/test-unattended-window.sh): one window {until|for, mode, path?, no_ask?, except?} or {"windows":[...]} (row 26z: at most 32, strict keys, no `for`); the
# most specific live window covering cwd shows, park beating allow at the same path; a cwd in a window's except is a hole only a strictly deeper window fills (26zu). ONE bad field, a path at $HOME or above or not in normal form (a . or .. component, a doubled /), an until more than 7 d + 1 h ahead,
# an empty file or a symlink voids the whole marker: the engine then sees NO window, so it shows as UNATTENDED(INVALID). An integer is told by its literal
# (`tojson`, jq >= 1.7 keeps it): `5.0` is a float to Python, so it is invalid here too. Never breaks the render.
_mp="$HOME/.claude/state/unattended.json"
if [[ -L "$_mp" || ( -e "$_mp" && ! -f "$_mp" ) ]]; then
  line2_parts+=("⚠ UNATTENDED(INVALID)")
elif [[ -f "$_mp" ]]; then
  _wnow=$(date +%s 2>/dev/null || echo 0); _wmt=$(stat -c %Y "$_mp" 2>/dev/null || echo 0)
  _wrow=$(jq -rs --argjson now "${_wnow:-0}" --argjson mt "${_wmt:-0}" --arg cwd "${cwd:-}" --arg home "${HOME%/}" '
    def bad: error("bad");
    def root: sub("/+$"; "");
    def depth: if .r == null then -1 else (.r | length) end;
    def globre: gsub("(?<c>[.^$+?()\\[\\]{}|\\\\])"; "\\" + .c) | gsub("\\*"; "[^/]*");
    def exh($c): any(.x[]; . as $e | if ($e | contains("*")) then ($c | test("^" + ($e | globre) + "(/.*)?$")) else ($c == $e or ($c | startswith($e + "/"))) end);
    def entry($legacy):
      if type != "object" then bad else . end
      | if ($legacy | not) and ((keys - ["until","mode","path","no_ask","except"]) | length) > 0 then bad else . end
      | (if $legacy and (has("until") | not) then
           (if (.for|type) == "number" and (.for|tojson|test("^-?[0-9]+$")) and .for >= 60 and .for <= 604800 then $mt + .for else bad end)
         elif (.until|type) == "number" and (.until|tojson|test("^-?[0-9]+$")) then .until else bad end) as $u
      | if $u - $now > 608400 then bad else . end
      | if (.mode == "park" or .mode == "allow") | not then bad else . end
      | if has("no_ask") and ((.no_ask|type) != "boolean") then bad else . end
      | (if has("except") then .except else [] end) as $x
      | if .path == null then (if has("except") then bad else {u: $u, m: .mode, r: null, x: []} end)
        elif (.path|type) == "string" and (.path|startswith("/")) and ((.path|root) as $r | $r != "" and $r != $home and (($home|startswith($r + "/")) | not)
             and ($r | test("//|(^|/)\\.\\.?(/|$)") | not))
        then ((.path|root) as $r
              | if has("except") and (($x|type) != "array" or ($x|length) == 0
                    or any($x[]; (type != "string") or ((startswith($r + "/") and (test("//|/\\.\\.?(/|$)|/$") | not)) | not)))
                then bad else {u: $u, m: .mode, r: $r, x: $x} end)
        else bad end;
    if length != 1 then "INVALID" else
      try (
        .[0] as $d
        | (if ($d|type) != "object" then bad
           elif ($d|has("windows")) then
             (if ($d|keys) != ["windows"] or ($d.windows|type) != "array" or ($d.windows|length) > 32 then bad else [$d.windows[] | entry(false)] end)
           else [$d | entry(true)] end) as $ws
        | ($cwd|root) as $c
        | [$ws[] | select(.u > $now) | select(.r as $r | $r == null or $c == $r or ($c|startswith($r + "/")))] as $hit0
        | (any($hit0[]; . as $w | ($w | exh($c)) and (any($hit0[]; (depth > ($w | depth)) and (exh($c) | not)) | not))) as $holed
        | (if $holed then [] else [$hit0[] | select(exh($c) | not)] end) as $hit
        | if ($hit|length) == 0 then "" else
            ($hit | map(depth) | max) as $dm
            | [$hit[] | select(depth == $dm)] as $tied
            | (if any($tied[]; .m == "park") then "park" else "allow" end) as $m
            | "\($m) \(([$tied[] | select(.m == $m) | .u] | max) - $now)" end
      ) catch "INVALID" end' "$_mp" 2>/dev/null) || _wrow="INVALID"
  if [[ "$_wrow" == INVALID ]]; then
    line2_parts+=("⚠ UNATTENDED(INVALID)")
  elif [[ "$_wrow" =~ ^(park|allow)\ ([0-9]+)$ ]]; then
    _wm="${BASH_REMATCH[1]}"; _wl="${BASH_REMATCH[2]}"
    _fmt_left _wt "$_wl"
    if [[ "$_wm" == allow ]]; then line2_parts+=("⚠⚠ UNATTENDED(allow,${_wt})"); else line2_parts+=("⚠ UNATTENDED(park,${_wt})"); fi
  fi
fi

# MODELS: the model-policy override table (state/model-overrides.json, plan model-policy-bypass). Shown whenever it overrides anything; an INVALID table is loud because
# ONE bad field voids every override (bin/model-override.sh validates the same rules). A symlink is treated as absent, like the CLI.
_mo="$HOME/.claude/state/model-overrides.json"
if [[ -f "$_mo" && ! -L "$_mo" ]]; then
  _mv=$(jq -r '
    def kok($s): (. == "*" or test("^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$"));
    if type != "object" or ((keys - ["version","skills","agents","agent-types","hooks"]) | length) > 0 or .version != 1 then "INVALID"
    elif ([ ["skills","agents","agent-types","hooks"][] as $s | if has($s) then (if (.[$s]|type) != "object" then 1 else (.[$s] | to_entries[]
           | (if (.key | kok($s)) then empty else 1 end),
             (if $s == "skills" then (if .value == "as-is" then empty else 1 end)
              elif ((.value|type) == "string" and (.value | test("^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$"))) then empty else 1 end)) end) else empty end ] | length) > 0 then "INVALID"
    else ((.skills // {}) as $k | (.agents // {}) as $a | (.["agent-types"] // {}) as $t | (.hooks // {}) as $h
          | ([ (if ($k|has("*")) then "skills:*" elif ($k|length) > 0 then "skills:\($k|length)" else empty end),
               (if ($a|has("*")) then "agents:*=\($a["*"])" elif ($a|length) > 0 then "agents:\($a|length)" else empty end),
               (if ($t|has("*")) then "agent-types:*=\($t["*"])" elif ($t|length) > 0 then "agent-types:\($t|length)" else empty end),
               (if ($h|has("*")) then "hooks:*=\($h["*"])" elif ($h|length) > 0 then "hooks:\($h|length)" else empty end) ] | join(","))) end' "$_mo" 2>/dev/null || echo INVALID)
  if [[ "$_mv" == INVALID ]]; then line2_parts+=("⚠⚠ MODELS-INVALID")
  elif [[ -n "$_mv" ]]; then line2_parts+=("⚠ MODELS($_mv)"); fi
fi

# The ⏳ expiry: the soonest TIMESTAMP expiry within 48 h, from the resolver's own feed (hooks/bypass-resolve.sh bypass_expiring). A bypass that ends
# silently is a surprise either way; this is the warning plan permission-unification step 5 promised. Never breaks the render: every failure leaves _exp empty.
# Scoped to THIS session's cwd (row 26zk, user 2026-10-16 00:37): only a grant in force here that really ends, for the gates + eg - never kg/cf (enables;
# keep-going shows its own expiry). Rules elsewhere stay in the gates-status WARN lines, which name the path.
_et=""
_gc_call "expiring" sid bypass_expiring 172800 "${cwd:-}" ah qg ac pw auto3c fw perm eg || true
_exp="${_GC_OUT%%$'\t'*}"
if [[ "$_exp" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9:]{8}Z$ ]]; then
  _es=$(( $(date -u -d "$_exp" +%s 2>/dev/null || echo 0) - $(date -u +%s 2>/dev/null || echo 0) )) || _es=0
  if (( _es > 0 )); then
    _fmt_left _et "$_es"
  fi
fi
# The gates group (plan statusline-redesign): `⚠ bypassed ah fw! qg (rule) eg (sess) ⏳46h` - the granted families in resolver order, one
# (source) after the families each source granted (sources in first-appearance order), `!` = level total, and the soonest expiry within 48 h
# (`⏳<t>`, _fmt_left) at its end. Rank 40 in _l2rank. An expiry with no group shows on its own as `⏳ bypass expires <t>` (rank 60).
if (( ${#_gates[@]} )); then
  _gsrc=(); declare -A _gfam=()
  for _ge in "${_gates[@]}"; do
    _gf="${_ge%%|*}"; _gr="${_ge#*|}"; _gl="${_gr%%|*}"; _gs="${_gr#*|}"
    if [[ -z "${_gfam[$_gs]+x}" ]]; then _gsrc+=("$_gs"); _gfam[$_gs]=""; fi
    _gfam[$_gs]+=" $_gf$_gl"
  done
  _gt="⚠ bypassed"
  for _gs in "${_gsrc[@]}"; do _gt+="${_gfam[$_gs]} ($_gs)"; done
  if [[ -n "$_et" ]]; then _gt+=" ⏳$_et"; fi
  line2_parts+=("$_gt")
elif [[ -n "$_et" ]]; then
  line2_parts+=("⏳ bypass expires $_et")
fi

# PERM-DOWN / perm-shadow: the permission engine's canary status (run/perm-engine-status, written at every SessionStart by
# hooks/perm-engine-canary.sh via bin/perm-engine-doctor.sh). DOWN = registered but broken (fails OPEN in the harness);
# SLOW = the self-test ran out of time on a busy host (amber: protected asks can be skipped while it lasts, no repair applies);
# SHADOW = registered in log-only mode. OFF/LIVE/absent render nothing.
if [[ -f "$HOME/.claude/run/perm-engine-status" ]]; then
  _pes=$(head -c 300 "$HOME/.claude/run/perm-engine-status" 2>/dev/null || true)
  case "$_pes" in
    DOWN*)   line2_parts+=("⚠⚠⚠ PERM-DOWN") ;;
    SLOW*)   line2_parts+=("⚠⚠ PERM-SLOW") ;;   # self-test out of time: host load, not a fault (framework-health 2026-10-08)
    SHADOW*) line2_parts+=("perm-shadow") ;;
  esac
fi

# BYPASS: the session runs in bypassPermissions — every permission prompt suppressed and the
# auto-mode classifier retired; only deny rules, explicit ask rules and exit-2 hooks still
# interrupt. The statusline payload carries NO permission-mode field (verified 2026-08-29 against
# the docs and the 2.1.251 binary), so the Stop and PostToolUse hooks persist the mode they DO
# receive to run/permission-mode-<sid>; this reads it back. Ranked near the front of line 2 (see _l2rank) for the
# same reason AUTO-3C is: a relaxed gate that is easy to miss gets missed. Known windows: no
# warning until the first tool call / turn end after arming; a stale BYPASS lingers until the
# next tool call / turn end after disarming (fail-loud by design).
if [[ -n "$_sess_key" && -f "${ctx_dir}/permission-mode-${_sess_key}" ]]; then
  _pmode=$(tr -d '[:space:]' < "${ctx_dir}/permission-mode-${_sess_key}" 2>/dev/null || true)
  [[ "$_pmode" == "bypassPermissions" ]] && line2_parts+=("⚠⚠⚠ BYPASS")
fi

# Line 2 is printed MOST SEVERE FIRST: the terminal cuts at the right edge, so what must survive goes left. The push sites above stay where they are;
# this ranks each rendered badge (stable inside a rank). An unlisted badge gets rank 50 (the "scoped or lower impact" tier), so a new badge is never dropped.
_l2rank() {
  case "$1" in
    "⚠⚠⚠ BYPASS"*)                _rk=10 ;;
    "⚠⚠⚠ PERM-DOWN"*)             _rk=11 ;;
    "⚠⚠⚠ PERM-OPEN"*)             _rk=12 ;;
    "⚠⚠ PERM-SLOW"*)              _rk=20 ;;   # a rank must be one the print loop below walks (10 11 12 20 ...), or the badge is dropped
    "⚠⚠ RULES-INVALID"*|"⚠⚠ MODELS-INVALID"*) _rk=20 ;;
    "⚠⚠ UNATTENDED("*)            _rk=30 ;;
    *"AUTO-3C"*)                  _rk=31 ;;
    "⚠ bypassed"*)                _rk=40 ;;
    "⏳ bypass expires"*)         _rk=60 ;;
    "perm-shadow"*)               _rk=70 ;;
    *)                            _rk=50 ;;
  esac
}
L2_F=(); L2_S=(); L2_K=()
for _rkv in 10 11 12 20 30 31 40 50 60 70; do
  for p in "${line2_parts[@]}"; do
    _l2rank "$p"
    if [[ "$_rk" == "$_rkv" ]]; then L2_F+=("$p"); L2_S+=("$p"); L2_K+=(""); fi
  done
done
L2_F+=("${L2S_F[@]}"); L2_S+=("${L2S_S[@]}"); L2_K+=("${L2S_K[@]}")
# Line 2: warnings most severe first, then the working state - never self-hiding (it always carries the mode).
_fit_print L2
_gc_save
