#!/usr/bin/env bash
# UserPromptSubmit: write a turn token on every new user message (not on a background-task notification; see below).
# The block hook (ask-human-gate-block.sh) uses this to enforce the gate
# once per request rather than once per 20-min session.
# State lives in ~/.claude/run/ask-human-gate/ (was /tmp until the P1 sentinel hole, 2026-10-11): the firewall SELFMOD list and
# protected engine rules make a model write or delete there prompt; /tmp let one unprompted Bash call forge a clearance.
# Emergency bypass: touch ~/.claude/state/ask-human-gate-bypass to disable gate globally.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

SESSION_ID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)
[[ -n "$SESSION_ID" ]] || exit 0

# A background task's completion notification fires UserPromptSubmit too (2026-10-10: one re-arm at 21:09:05, a "new user message"
# block 3 s later, nothing typed). Its prompt is NOTHING BUT <task-notification> blocks (125 of 125 in 40 real transcripts), so only
# that whole-prompt shape skips both stamps; any text outside a block, a non-string prompt or a jq failure re-arms (fail safe).
# The block body may not cross a closing tag: a lazy [\s\S]*? backtracks over one, so block-text-block matched (6C, N9).
# No stdout on that path: it would be injected into the model's context.
IS_NOTE=$(printf '%s' "$INPUT" | jq -r '(.prompt | type) == "string" and (.prompt | test("^\\s*(<task-notification>((?!</task-notification>)[\\s\\S])*</task-notification>\\s*)+$"))' 2>/dev/null || true)
if [[ "$IS_NOTE" == true ]]; then
  log_obs INFO ask-human-gate-arm "notification: turn not re-armed for session ${SESSION_ID}" || true
  exit 0
fi

CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
GATE_DIR="${GATE_DIR_OVERRIDE:-$HOME/.claude/run/ask-human-gate}"  # GATE_DIR_OVERRIDE: test-only injection point

# Prompt stamp, written in EVERY mode (framework-health step 7): while ah is bypassed no turn token exists, and the advisory
# guards (advisor-prework-guard.sh) key "once per turn" on this stamp instead. It is not a gate token: block.sh never reads
# prompts/. Guarded because this hook runs `set -e`: a failed stamp write (unwritable /tmp, ENOSPC) must not kill it before the
# turn token below, which would leave the ARMED gate with no token, i.e. open. Nothing reads a missing stamp as anything but
# "no interactive turn" (the advisory guard then stays silent).
# run/ survives a reboot, unlike /tmp: prune OTHER sessions' files older than 7 days (find -P never follows a symlink; a file another
# session prunes between the scan and the unlink is the one expected error, so stderr is dropped and the status ignored).
find "$GATE_DIR" -mindepth 1 -type f -mtime +7 ! -path "*${SESSION_ID}*" -delete 2>/dev/null || true
{ mkdir -p "$GATE_DIR/prompts" && printf '%s' "$(date +%s)" > "$GATE_DIR/prompts/${SESSION_ID}"; } 2>/dev/null || true

# Must use the SAME resolver as ask-human-gate-block.sh. If arm and block ever disagree about
# whether this cwd is bypassed, arm writes a turn token that block then ignores — leaving stale
# tokens behind and making the gate's state unreadable. One resolver, one answer.
# No target path at UserPromptSubmit, so except-lists are skipped by construction.
AH_BYP=0
if ( BYPASS_SESSION_ID="$SESSION_ID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
     bypass_applies ah "$CWD" ) 2>/dev/null; then
  AH_BYP=1
fi

# Confident picks (family cf, row 26zg; ASSUMED: injected on EVERY real prompt). This hook's stdout IS added to the model's context, so
# while cf is on the full tiered rule (the resolver's bypass_cf_text, worded for the mode) goes out on each prompt; when cf went off after
# this session saw it on (here, or in the SessionStart banner, which writes the same record), ONE "OFF now" line. The record is
# cf/<sid> under the gate dir (protected like the turn tokens; the 7-day prune above covers it). Every step is guarded: under set -e a
# failure here must never skip the turn token below.
CF_REC="$GATE_DIR/cf/${SESSION_ID}"
if ( BYPASS_SESSION_ID="$SESSION_ID"; source "$SCRIPT_DIR/bypass-resolve.sh" && bypass_applies cf "$CWD" ) 2>/dev/null; then
  ( source "$SCRIPT_DIR/bypass-resolve.sh" && bypass_cf_text "$( (( AH_BYP )) && echo autonomous || echo spec)" ) 2>/dev/null || true
  { mkdir -p "$GATE_DIR/cf" && printf '1' > "$CF_REC"; } 2>/dev/null || true
elif [[ "$(cat "$CF_REC" 2>/dev/null || true)" == 1 ]]; then
  printf '%s\n' "▸ CONFIDENT PICKS (cf): OFF now - it was on earlier in this session; this mode's own mid-task question policy applies again."
  { printf '0' > "$CF_REC"; } 2>/dev/null || true
fi

# An explicit "ask me" lifts an unattended window's no_ask for this turn (row 26zj, user ruling 2026-10-16 00:25 option a: "I told you to ask me !
# or does the ask not work while we are on those bypasses ?"). A REAL prompt (notifications exit above and keep it) that asks - `ask me` or `let me
# decide` as words, not negated (don't, can't, won't, not, never, no need to, without ... - the two tiers below; phrases from this machine's transcripts) -
# writes the marker; any other real prompt removes it. bin/lib/unattended.py ask_lifted reads it for the engine and keep-going alike. The name carries
# `unattended`, so a model write naming it stays parked even in an allow window (core rule); it sits in run/ask-human-gate/ (firewall SELFMOD,
# protected Edit rule). Guarded: under set -e a failure here must never skip the turn token below.
AK_F="$GATE_DIR/unattended-ask-${SESSION_ID}"
AK_T=$(printf '%s' "$INPUT" | jq -r 'if (.prompt | type) == "string" then .prompt else "" end' 2>/dev/null | tr '[:upper:]' '[:lower:]' | sed -E "s/’/'/g" 2>/dev/null) || AK_T=""
# Two tiers (milestone panel A-P2-1): the original five (don't, do not, never, no need to, without) negate with up to two words between;
# the words keep-going's _stop_intent list adds, plus needn't (final delivery panel A-P2-2: "you can't ask me" lifted no_ask) negate only DIRECTLY
# before, or across a closed set of modal gap words (re-round A3-P2-1: "you won't need to ask me", "it is not necessary to ask me";
# an adverb alone only after a modal word, AK_NEG3; the predicates required/supposed/allowed/going/try/want... to, C4-P3-1),
# so "if you are not sure ask me" and "not now, ask me later" still ask. A bare `no` only when a space follows it ("no, ask me
# first" still asks). A question about not being asked ("why did you not ask me", "why don't you ask me", "why do you not ask me",
# "why not ask me", a why/how-come question at a clause start - optional auxiliary and subject, then the negation - C4-P3-2 /
# round 4; an inverted "are you not ... ask me" question, round 4; the double negatives "no reason/need not to", "whether or not to", round 3 A4-P3-1) is a request to be asked, and so is a negated "forget/hesitate/fail/be afraid to" or "never mind" (A3-P3-1/C3-P3-5): those
# negations are dropped first. Known residuals: the declarative complaint "you didn't ask me" reads as a negation; a modal outside the
# closed list, or past tier 1's two-word window ("you don't really need to ask me", "no need for you to ask me"), lifts. The phrase
# list is a CLOSED heuristic (user ruling 2026-10-17 00:30): the tests pin it; an untested phrasing may read either way.
AK_T=$(printf '%s' "$AK_T" | sed -E "s/(^|[.!?;,][[:space:]]*)(why|how[[:space:]]+come)([[:space:]]+(do|does|did|would|will|can|could|should|are|is|were|was))?([[:space:]]+(you|it|we|they))?[[:space:]]+(not|never|don'?t|didn'?t|doesn'?t|wouldn'?t|won'?t|can'?t|couldn'?t|shouldn'?t)(([[:space:]]+[a-z']+){0,1}[[:space:]]+ask[[:space:]]+me)/\1\2\3\5\8/g; s/(^|[.!?;,][[:space:]]*)(are|is|were|was|do|does|did|would|will|should|could|can)[[:space:]]+(you|it|we|they)[[:space:]]+not([[:space:]])/\1\2 \3\4/g; s/(^|[^a-z])why[[:space:]]+(don'?t|didn'?t)[[:space:]]+you([[:space:]])/\1why you\3/g; s/(^|[^a-z])(did|do)[[:space:]]+you[[:space:]]+not([[:space:]])/\1\2 you\3/g; s/(^|[^a-z])(don'?t|do[[:space:]]+not|never)[[:space:]]+(forget|hesitate|fail|be[[:space:]]+afraid)[[:space:]]+to([[:space:]])/\1\4/g; s/(^|[^a-z])never[[:space:]]+mind([^a-z]|$)/\1\2/g; s/(^|[^a-z])why[[:space:]]+not([[:space:]])/\1why\2/g; s/(^|[^a-z])no[[:space:]]+(reason|need)[[:space:]]+not[[:space:]]+to([[:space:]])/\1\3/g; s/(^|[^a-z])whether[[:space:]]+or[[:space:]]+not([[:space:]])/\1whether\2/g" 2>/dev/null) || AK_T=""
AK_ME="(ask[[:space:]]+me|let[[:space:]]+me[[:space:]]+decide)([^a-z]|$)"
AK_NEG="(^|[^a-z])(don'?t|do[[:space:]]+not|never|no[[:space:]]+need[[:space:]]+to|without)[[:space:]]+([a-z']+[[:space:]]+){0,2}$AK_ME"
AK_GAP="(((ever|even|just|really|necessarily)[[:space:]]+)?((need|have|got|necessary|point|reason)[[:space:]]+(to[[:space:]]+)?|(required|supposed|allowed|permitted|meant|expected|obliged|going|try|trying|want)[[:space:]]+to[[:space:]]+)|to[[:space:]]+)?"
AK_NEG2="(^|[^a-z])(doesn'?t|didn'?t|needn'?t|can'?t|cannot|won'?t|shouldn'?t|mustn'?t|does[[:space:]]+not|not|no)[[:space:]]+$AK_GAP$AK_ME"
# An adverb alone (no modal after it) negates only after a modal tier word: "you can't just ask me" is a negation, "no just ask
# me" / "if not just ask me" ask (round 3 B4-P2-1); "should not just", "not ever (to)", "not even to" stay ones (round 4).
AK_NEG3="(^|[^a-z])((doesn'?t|didn'?t|can'?t|cannot|won'?t|shouldn'?t|mustn'?t|(does|do|did|should|must|will|would|can|could|need)[[:space:]]+not)[[:space:]]+(ever|even|just|really|necessarily)|not[[:space:]]+(ever([[:space:]]+to)?|even[[:space:]]+to))[[:space:]]+$AK_ME"
while [[ "$AK_T" =~ $AK_NEG || "$AK_T" =~ $AK_NEG2 || "$AK_T" =~ $AK_NEG3 ]]; do AK_T="${AK_T/"${BASH_REMATCH[0]}"/ NEGA }"; done
AK_RE="(^|[^a-z])(ask[[:space:]]+me|let[[:space:]]+me[[:space:]]+decide)([^a-z]|$)"
if [[ "$AK_T" =~ $AK_RE ]]; then
  { mkdir -p "$GATE_DIR" && printf '1' > "$AK_F"; } 2>/dev/null || true
else
  rm -f "$AK_F" 2>/dev/null || true
fi

if (( AH_BYP )); then
  exit 0
fi

mkdir -p "$GATE_DIR/turns" 2>/dev/null || true
printf '%s' "$(date +%s)" > "$GATE_DIR/turns/${SESSION_ID}"
AHG_KEYS=$(printf '%s' "$INPUT" | jq -r 'keys | join(",")' 2>/dev/null || true)   # key NAMES only, never prompt text
log_obs INFO ask-human-gate-arm "turn token written for session ${SESSION_ID} (payload keys: ${AHG_KEYS})" || true

exit 0
