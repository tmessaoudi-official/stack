#!/usr/bin/env bash
# PreToolUse: Bash — BOUNDARY GATE (v3, 2026-08-29; literal-var folding added 2026-08-30). Permission tier = blast radius; boundary = the
# project root. Every Bash command is tokenised (python3/shlex — quotes, redirects, `cd`/pushd/popd tracking,
# two-level `bash -c`/`sh -c`/`eval` unwrap, `xargs`/`find -exec` words (a shell run by either asks), heredoc
# bodies stripped as DATA (but `$( )`/backticks in an UNQUOTED-tag body run, so they are analysed — R2),
# `$( )`/backtick/`<( )`/`>( )` BODIES analysed in their segment's cwd up to 3 levels,
# ANSI-C `$'…'` decoded, globs enumerated up to 64 matches (above: the directory is judged as a tree),
# option-value writers modelled — curl -o/-O/-J/-w %output{}, wget -O/-P/-r/-e, tar -C/-c/-T/--one-top-level,
# unzip -d, 7z, zip, scp, cpio, unrar, patch, rsync option dirs, git -C/--work-tree/--git-dir/GIT_DIR/config/
# clone/init/worktree/--output/forced forms, find -fprint, cp/ln -t, sort -o, uniq, yq -i, awk inplace, the
# compressors, chattr/setfacl, GNU long-option prefixes, links made earlier in the command) and every MUTATE /
# READ / NET target is resolved to an absolute path, then tiered — highest tier wins (deny > ask > silent):
#   deny   host-critical targets (/, any top-level dir, $HOME itself, /etc /usr /bin /sbin /lib* /boot /var
#          /opt /root /proc /sys /dev≠/dev/null) and credential stores (~/.ssh ~/.gnupg ~/.aws ~/.kube ~/.netrc
#          ~/.config/gcloud ~/.azure ~/.docker/config.json ~/.config/gh/hosts.yml ~/.pgpass ~/.pypirc
#          ~/.git-credentials ~/.claude/.credentials.json ~/.claude/mcp/**/.env*, id_rsa|id_ed25519 anywhere,
#          *.pem|*.key OUTSIDE the root) — reads AND writes. A settings `allow` never lifts a deny.
#          Also `git push --force`/`-f`/`--mirror`/`+refspec` at every level, TOTAL included (2026-09-27);
#          `--force-with-lease` stays allowed.
#   ask    Claude self-mod paths (settings*.json, guard hooks, this hook, what they source — bypass-resolve.sh,
#          log-helpers.sh —, bin/permission-swap*.sh, state/ sentinels, autonomous-3c markers, session-remember
#          toggles, ~/.claude.json, shell rc files, ~/.gitconfig) EVEN inside ~/.claude — including a tree verb
#          (rm/mv/chmod -R/find -delete…) on a directory CONTAINING one, a cp/mv/install INTO a directory by
#          basename, and the words of every `find -exec` (a nested shell there asks); the .env matrix (write bare .env; read/write .env*prod*|*staging*); ROOT/.claude/
#          boundary.json `protected[]`; any mutate OUTSIDE the root and outside the SAFE zones; NET writes
#          (POST/PUT/PATCH/DELETE, -d/--data*/-F/-T) to non-local hosts; anything not statically resolvable
#          ($VAR, $(…), `…`, unknown cwd after `cd "$X"`, unbalanced quotes, missing python3) — fail closed.
#          A bypass RULE's grant is judged per target (2026-09-23): a target with no finding never withdraws it,
#          a target with a finding needs it, a DENIED target always withdraws it.
#          (F-1.2, 2026-08-30: a same-command literal `VAR=value` assignment IS folded before this
#          check — e.g. `S=/tmp/x && rm "$S/y"`; a `bash -c`/`sh -c` child does NOT inherit a bare
#          parent VAR. STRICT since 2026-09-23: VAR folds only if that is its ONE write in the command,
#          unconditional and outside every if/for/while/case/{ }/( ) body — see fold_poison().)
#          A `for V in WORDS` loop is resolved per word (step 7): $V is tiered once per value — see LOOPS.
#   silent everything else: mutates inside ROOT or in SAFE zones (/tmp, $TMPDIR, ~/.claude/{projects,run,logs},
#          /dev/null, boundary.json `trusted_outside[]`), all other reads, local-host / GET network, git in its
#          own work tree — EXCEPT a moved work tree, pathspecs, `config` scopes and FORCED whole-tree rewrites
#          (reset --hard, checkout -f, stash pop, clean …: the repo top is judged as a tree; in a repo whose top
#          is $HOME that is ~/.claude, so they ask there from any cwd).
# Time budget: the classifier answers ASK itself 10 s after the hook started (the hook timeout, 15 s, fails OPEN).
# ACCEPTED LIMIT: interpreter program text is not analysed — awk system()/print >, python -c, perl -e (without
# -i), sed e/w commands, node -e … run silently when their target verb is the interpreter (user ruling 2026-09-24).
# Same limit (R2): what an EXECUTED program does (git -c core.hooksPath, tar --to-command, a script) and the
# option values of an UNMODELLED verb (shuf -o, pandoc -o, openssl -out …) are not modelled — the tiers
# above hold for the modelled writers listed at the top.
# TOTAL LEVEL (2026-09-24): an fw grant at level total (rule "level":"total", sentinel content `total`) makes
# this hook never ask — the classifier's DENY still denies; anything else, unclassifiable included, is silent.
# ROOT = `git rev-parse --show-toplevel` of the tool's cwd, else cwd. CLAMP (advisor F-A): when that toplevel
# is $HOME (this machine's home directory is itself a git repo) ROOT = cwd; when cwd == $HOME the session is
# boundaryless (only SAFE zones + reads are silent).
# Evaluation order is load-bearing (F3): host-critical/credential → self-mod → .env/protected → SAFE → outside.
# Per mode: interactive sessions (default/acceptEdits/bypassPermissions) see `ask` as a prompt; auto-mode,
# headless (-p) and subagent sessions hard-deny an `ask` (Claude Code fails closed) — the reason text names
# the path, the tier and the escape (Edit tool for in-repo files; `!` for the user).
# `allow` rules in settings.json downgrade ask → silent only (F4), never deny. Decisions are appended to
# logs/firewall-suggestions.log. Off-switches (the user's escape, never set by Claude):
#   CLAUDE_BASH_FIREWALL_OFF=1 — the ONLY full off-switch. The bypass sentinels (~/.claude/state/,
#   projects/<slug>/state/, run/<family>-bypass-<sid>) and `fw` rules in state/gates-bypass-rules.json lift
#   FRICTION only since 2026-09-23 (step 6): boundary asks and literal NET writes. Deny, self-mod, .env,
#   protected[], unresolvable, nested-shell and brace findings are never lifted.
# HONEST: Bash is arbitrary code execution; this is best-effort supervision, NOT a sandbox.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

SETTINGS="${CLAUDE_BASH_FIREWALL_SETTINGS:-$HOME/.claude/settings.json}"   # test injection
SUG_LOG="${CLAUDE_BASH_FIREWALL_LOG:-$HOME/.claude/logs/firewall-suggestions.log}"

[[ "${CLAUDE_BASH_FIREWALL_OFF:-}" == "1" ]] && exit 0
FW_T0="${CLAUDE_BASH_FIREWALL_T0:-$EPOCHREALTIME}"   # hook start: the classifier budget counts from here (B1 review)

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0

CWD=$(printf '%s' "$INPUT" | jq -r '.cwd // empty' 2>/dev/null || true)
FW_SID=$(printf '%s' "$INPUT" | jq -r '.session_id // empty' 2>/dev/null || true)

# Shared resolver: legacy sentinels (global/project/session) + recursive path rules.
# SUBSHELL-invoked — this hook runs `set -u` and Claude Code blocks only on exit 2, so a resolver
# crash evaluated in our own shell would exit 1 and fail OPEN. See bypass-resolve.sh.
#
# Except-lists DO apply here, but they cannot be judged yet: a Bash command has MANY targets and
# they only exist once the python/shlex tokeniser below has resolved them. So the tokeniser exports
# its target list to a side file and this same bash resolver re-decides afterwards — path matching
# is never reimplemented in python, so the two can never drift apart.
FW_BYPASS_PENDING=0
FW_EXCEPT_IN_PLAY=0
FW_EXCEPT_HIT=""
FW_RESOLVER_FAILED=""
# LEVEL (permission-total-bypass plan, 2026-09-24). ONE resolver call answers both "is there an fw grant at
# this cwd" and "at which level": bypass_level is parity-pinned to bypass_applies (test-bypass-resolve.sh).
# At TOTAL the firewall never asks: a classifier DENY still denies (the floor — credentials, host-critical),
# everything else is silent, except-lists are ignored, and a command that cannot be classified at all
# (python3 missing, classifier crash) is ALLOWED (D3, user ruling 2026-09-24 — see the permission-total-bypass plan).
FW_LEVEL=$( ( BYPASS_SESSION_ID="$FW_SID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
              bypass_level fw "$CWD" ) 2>/dev/null ) || FW_LEVEL=none
case "$FW_LEVEL" in normal|total) ;; *) FW_LEVEL=none ;; esac
FW_TOTAL=0; [[ "$FW_LEVEL" == total ]] && FW_TOTAL=1
# CROSS-FAMILY: does ANY family's rule covering this cwd carry an except? Computed ONCE, before the
# grant check, because it is needed in two independent situations and each jq call costs real time:
#   (a) with an fw grant — to decide whether the target list must be exported for the per-target check;
#   (b) WITHOUT one — because an except must arm the Bash layer even when no rule grants `fw`.
# (b) is why this is not nested inside the grant branch: a rule naming only `perm` grants fw
# nothing, so the target list was never produced and its blacklist never reached Bash at all.
# At TOTAL too (row 26zu, user ruling 2026-10-17 01:02, superseding 2026-09-24 for excepted subtrees): an except is a hole in its rule
# at every level, so a target inside one asks (FW_EXCEPT_HIT, emitted before the TOTAL exit) and a cwd inside one has no total grant at all.
if ( BYPASS_SESSION_ID="$FW_SID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
     bypass_any_except "$CWD" ) 2>/dev/null; then
  FW_EXCEPT_IN_PLAY=1
fi
# At TOTAL there is nothing to adjudicate per target: the classifier's own deny is the only outcome kept.
if [[ "$FW_LEVEL" == normal ]]; then
  # NO FAST PATH (removed 2026-09-23, firewall-hardening step 6). It exited here, before the tokeniser, so
  # a grant — and every legacy sentinel — lifted EVERYTHING in the tree: credential reads, self-mod writes,
  # `curl -d @~/.ssh/id_rsa`. A grant now lifts friction only (boundary asks, literal NET writes); the
  # decision waits for the classifier: FW_BYPASS_PENDING is re-checked right after it returns.
  # Cost: one python pass (~0.1–0.2 s) on every bypassed command — why the hook timeout is 15 s, because a
  # PreToolUse hook that outruns its timeout FAILS OPEN (hooks.md).
  FW_BYPASS_PENDING=1
fi
CMD=$(printf '%s' "$INPUT" | jq -r '.tool_input.command // empty' 2>/dev/null || true)
[[ -z "$CMD" ]] && exit 0

log_flag() {  # $1=action  $2=reason  $3=suggestion
  local ts; ts=$(date -Is 2>/dev/null || date 2>/dev/null || echo '?')
  printf '%s | %s | %s | suggest: %s | cmd: %s\n' \
    "$ts" "$1" "$2" "$3" "${CMD:0:200}" >> "$SUG_LOG" 2>/dev/null || true
  log_obs INFO ask-bash-firewall "$1 ($2)" 2>/dev/null || true
}

emit() {  # $1=decision (ask|deny)  $2=reason (shown to USER / read by Claude as the block reason)  $3=suggestion (logged)
  jq -nc --arg d "$1" --arg r "$2" \
    '{hookSpecificOutput:{hookEventName:"PreToolUse",permissionDecision:$d,permissionDecisionReason:$r}}' \
    2>/dev/null || printf '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"%s","permissionDecisionReason":"bash firewall: review this command"}}' "$1"
  log_flag "${1^^}" "$2" "$3"
  exit 0
}

# RAW FLOOR, bash side (R3 S-F1/F2): the classifier's CRED_RAW/HOST_RAW mirror, for when it cannot run at all
# (python3 missing, crash). Only reached at TOTAL — at normal those paths already ask.
fw_raw_floor() {  # $1=why ; emits deny (and exits) when the raw text names a credential store / host write
  # Mirror of the classifier's raw_floor (CRED_RAW/HOST_RAW/WRITE_RAW, same normalisation) — keep in step;
  # the TOTAL floor tests run both sides (R4 G6: the /dev rule was missing here).
  local t; t=$(printf '%s' "$CMD" | tr -d "'\"\\\\" | sed -E ':a; s#/\./#/#g; ta; s#/{2,}#/#g
    s#[0-9]*>+&?[[:space:]]*/dev/(null|stdout|stderr|tty|fd/[0-9]+)([^[:alnum:]_]|$)# \2#g
    s#[0-9]*>&[0-9-]+# #g
    s#/dev/(null|stdin|stdout|stderr|tty|zero|u?random|fd/[0-9]+)([^[:alnum:]_]|$)# \2#g')
  local cred='(^|[[:space:]/=@:<>(,])(\.ssh|\.gnupg|\.aws|\.kube|\.config/gcloud|\.azure|\.netrc|\.git-credentials|\.claude/\.credentials\.json|\.docker/config\.json|\.config/gh/hosts\.yml|\.pgpass|\.pypirc)([^[:alnum:]_.-]|$)|(^|[^[:alnum:]_])id_(rsa|ed25519|ecdsa|dsa)([^[:alnum:]_]|$)'
  local d
  for d in .ssh .gnupg .aws .kube .config/gcloud .azure; do
    [[ "$CWD" == "$HOME/$d" || "$CWD" == "$HOME/$d/"* ]] && t="$t .ssh"
  done
  if printf '%s' "$t" | grep -Eq -- "$cred"; then
    emit deny "Bash firewall: $1, and the raw text names a credential store — denied at TOTAL (the deny floor does not depend on classification)." "spell the path literally"
  fi
  if printf '%s' "$t" | grep -Eq -- '(^|[[:space:]=:>(,{@-])/(etc|usr|bin|sbin|boot|var|opt|root|proc|sys|dev)(/|[^[:alnum:]_]|$)' \
     && printf '%s' "$t" | grep -Eq -- '(^|[[:space:];&|(`])(rm|mv|cp|dd|tee|chmod|chown|ln|install|truncate|shred|rsync|tar|unzip|sed|perl)([^[:alnum:]_]|$)|>'; then
    emit deny "Bash firewall: $1, and the raw text names a host-critical path with a write verb — denied at TOTAL (the deny floor)." "spell the path literally"
  fi
}

# python3: prefer the system interpreter (a pyenv shim on PATH costs ~0.5 s per call and may be absent from
# the hook's PATH); fall back to whatever PATH offers; none → fail closed.
PY="${CLAUDE_BASH_FIREWALL_PYTHON:-}"                                        # test injection
[[ -z "$PY" && -x /usr/bin/python3 ]] && PY=/usr/bin/python3
[[ -z "$PY" ]] && PY=$(command -v python3 2>/dev/null || true)
if [[ -z "$PY" || ! -x "$PY" ]]; then
  # D3 holds only with no except in play (row 26zu): unclassified, an excepted target cannot be ruled out, so it asks below.
  if [[ $FW_TOTAL -eq 1 && "$FW_EXCEPT_IN_PLAY" != "1" ]]; then   # D3: cannot classify at TOTAL = allowed — but never past the floor (R3)
    fw_raw_floor "python3 is unavailable"
    log_obs ERROR ask-bash-firewall "python3 not found — TOTAL level: allowed unclassified (D3)" 2>/dev/null || true
    exit 0
  fi
  log_obs ERROR ask-bash-firewall "python3 not found — failing closed" 2>/dev/null || true
  emit ask "Bash firewall: python3 is unavailable, so the command's targets cannot be classified (fail closed). Approve, or run it yourself with \`!\`." "install python3 / set CLAUDE_BASH_FIREWALL_PYTHON"
fi

ERRF=$(mktemp 2>/dev/null || echo /dev/null)
# Only ask the classifier to export its target list when something downstream needs it: a pending
# bypass to adjudicate, or an except list to enforce (which can bite with no grant in sight).
TGTF=""
[[ "$FW_BYPASS_PENDING" == "1" || "$FW_EXCEPT_IN_PLAY" == "1" ]] && TGTF=$(mktemp 2>/dev/null || true)
RESULT=$(FW_T0="$FW_T0" FW_TOTAL="$FW_TOTAL" FW_TGT_FILE="$TGTF" "$PY" - "$CMD" "$CWD" "$SETTINGS" "$FW_SID" 2>"$ERRF" <<'PY'
import codecs, fnmatch, glob as globmod, itertools, json, math, os, pwd, re, shlex, signal, subprocess, sys, time
from urllib.parse import urlparse

CMD, CWD_IN, SETTINGS = sys.argv[1], sys.argv[2], sys.argv[3]
SESSION_ID = sys.argv[4] if len(sys.argv) > 4 else ''
R = lambda p: os.path.realpath(p)
HOME = R(os.environ.get('HOME') or os.path.expanduser('~'))
TMPDIR = os.environ.get('TMPDIR') or ''

# F-1.2 (2026-08-30): constant folding for same-command literal variable assignments.
# `S=/tmp/x && rm "$S/y"` is the mandated scratchpad idiom; only a value that is ITSELF already
# fully literal (no $, `, $(), MARK) at assignment time gets folded — never resolved any other way.
KNOWN_VARS = {}
if TMPDIR: KNOWN_VARS['TMPDIR'] = TMPDIR
if SESSION_ID: KNOWN_VARS['CLAUDE_CODE_SESSION_ID'] = SESSION_ID
ENV_SEEDED_VARS = dict(KNOWN_VARS)   # what a bash -c/sh -c CHILD actually inherits (real env only)

def under(p, d):
    d = d.rstrip('/') or '/'
    return p == d or p.startswith(d + '/')
def any_under(p, ds): return any(under(p, d) for d in ds if d)

# ── ROOT (with the home-repo clamp) ─────────────────────────────────────────────
def git_top(d):
    try:
        r = subprocess.run(['git', '-C', d, 'rev-parse', '--show-toplevel'], capture_output=True, text=True, timeout=3)
        return R(r.stdout.strip()) if r.returncode == 0 and r.stdout.strip() else None
    except Exception:
        return None
CWD = R(CWD_IN) if CWD_IN else None
ROOT = None
if CWD:
    top = git_top(CWD) or CWD
    if top == HOME or under(HOME, top):      # toplevel is $HOME or an ancestor of it → clamp to cwd
        top = CWD
    ROOT = None if top == HOME else top
BOUNDARYLESS = ROOT is None

PROTECTED, TRUSTED, BOUNDARY_BROKEN = [], [], False
if ROOT:
    bpath = os.path.join(ROOT, '.claude', 'boundary.json')
    if os.path.exists(bpath):
        try:
            with open(bpath) as fh:
                b = json.load(fh)
            for x in b.get('protected', []) or []:
                x = os.path.expanduser(x)
                PROTECTED.append(R(x) if os.path.isabs(x) else R(os.path.join(ROOT, x)))
            TRUSTED = [R(os.path.expanduser(x)) for x in (b.get('trusted_outside', []) or [])]
        except Exception:
            BOUNDARY_BROKEN = True          # present but unreadable → protected[] unknown → fail closed inside ROOT
SAFE = [x for x in (ROOT, '/tmp', R(TMPDIR) if TMPDIR else '', os.path.join(HOME, '.claude', 'projects'),
                    os.path.join(HOME, '.claude', 'run'), os.path.join(HOME, '.claude', 'logs')) if x] + TRUSTED

CRED_DIR_NAMES = ('.ssh', '.gnupg', '.aws', '.kube', '.config/gcloud', '.azure')
CRED_FILE_NAMES = ('.netrc', '.git-credentials', '.claude/.credentials.json',
                   '.docker/config.json', '.config/gh/hosts.yml', '.pgpass', '.pypirc')   # + panel B3
CRED_DIRS = [os.path.join(HOME, d) for d in CRED_DIR_NAMES]
CRED_FILES = [os.path.join(HOME, f) for f in CRED_FILE_NAMES]
# The same stores in EVERY other home (credential-ancestor-tiering Q3): `~root/.aws/credentials` resolved through
# pwd but only a key basename was caught there. Kept apart from CRED_DIRS/FILES on purpose — those feed
# _CRED_REL/CRED_RAW as paths relative to $HOME, where another home would read `../../root/.ssh`.
# getpwall(): 54 entries in ~4 ms here (measured 2026-09-24).
OTHER_HOMES = sorted({R(u.pw_dir) for u in pwd.getpwall() if u.pw_dir.startswith('/')} - {HOME})
OTHER_CRED_DIRS = [os.path.join(h, d) for h in OTHER_HOMES for d in CRED_DIR_NAMES]
OTHER_CRED_FILES = {os.path.join(h, f) for h in OTHER_HOMES for f in CRED_FILE_NAMES}
KEY_NAMES = ('id_rsa', 'id_ed25519', 'id_ecdsa', 'id_dsa')
HOST_DIRS = ['/etc', '/usr', '/bin', '/sbin', '/boot', '/var', '/opt', '/root', '/proc', '/sys', '/dev']
SELFMOD = ['.claude/settings*.json', '.claude/run/confident-pick-*', '.claude/run/expertise-gate-off-*', '.claude/hooks/expertise-gate.sh', '.claude/hooks/*guard*.sh', '.claude/hooks/ask-bash-firewall.sh',
           '.claude/hooks/ask-human-gate-*.sh', '.claude/state',
           '.claude/hooks/bypass-resolve.sh', '.claude/hooks/log-helpers.sh',   # SOURCED by the guards (2026-09-23)
           '.claude/hooks/skill-model-notice.sh',                              # blocks strong skills; no 'guard' in its name (sonnet-audit A-F5)
           '.claude/config/permission-rules.json', '.claude/config/permission-rules.pre-cutover.json', '.claude/hooks/permission-engine.sh', '.claude/hooks/permission_engine.py', '.claude/hooks/perm_level.py', '.claude/hooks/agent-model-override.sh', '.claude/state/unattended.json', '.claude/bin/unattended.sh', '.claude/bin/lib/unattended.py', '.claude/hooks/perm-engine-canary.sh', '.claude/hooks/perm_shadow.py', '.claude/hooks/perm-request-log.sh',   # permission engine + shadow logging (plan permission-unification)
           '.claude/bin/permission-swap*.sh', '.claude/state/*', '.claude/projects/*/state',
           '.claude/CLAUDE.md', '.claude/bin', '.claude/bin/*',               # ruling B (2026-09-24); skills/ stays out
           '.claude/projects/*/state/*', '.claude/run/*-bypass-*', '.claude/run/ask-human-gate', '.claude/run/ask-human-gate/*',
           '.claude/hooks/*guard*.py', '.claude/hooks/subagent-start-context.sh', '.claude/hooks/subagent-stop-status.sh',   # protected Edit targets
           '.claude/lean-blocklist',                                           # the list missed (G6, 2026-10-11)
           '.claude/hooks/stop-failure-notify.sh', '.claude/hooks/session-start-banner.sh',   # protected since 26zp / 26zc (G6, panel C-P1-1)
           '.claude/hooks/session-remember/DISABLED', '.claude/hooks/session-remember/DISABLED.lean',
           '.claude/hooks/session-remember/READONLY', '.claude/hooks/session-remember/blacklist',
           '.claude/hooks/session-remember/readonly-list',
           '.claude.json', '.bashrc', '.bash_profile', '.profile', '.zshrc', '.zprofile', '.gitconfig']
# SELFMOD_BROAD (user ruling 2026-10-11 11:14): the ask-tier hooks. A Bash write to them asks exactly like SELFMOD, but they are NOT
# critical: guard-edit-protection derives the protected tier from SELFMOD alone. An unattended window does not lift either list (it
# converts the engine verdict only). By name, never a hooks/ glob: fnmatch's * crosses / into hooks/tests/. G6b fails for a hook missing here.
SELFMOD_BROAD = [
               '.claude/hooks/backup-before-write.sh', '.claude/hooks/cert-schedule.sh', '.claude/hooks/edit-log.sh',
               '.claude/hooks/ensure-mcp-health.sh', '.claude/hooks/patch-playwright-mcp.sh', '.claude/hooks/plan-write-check.sh',
               '.claude/hooks/precompact-handoff.sh', '.claude/hooks/remote-bang.sh', '.claude/hooks/session-remember/common.sh', '.claude/hooks/session-remember/consolidate.sh',
               '.claude/hooks/session-remember/extract.py', '.claude/hooks/session-remember/prompts/compress.txt',
               '.claude/hooks/session-remember/prompts/consolidate.txt', '.claude/hooks/session-remember/prompts/summarize.txt',
               '.claude/hooks/session-remember/run-tests.sh', '.claude/hooks/session-remember/save.sh', '.claude/hooks/session-remember/start.sh',
               '.claude/hooks/session-remember/stop.sh', '.claude/hooks/session-remember/trigger.sh',
               '.claude/hooks/session-status.sh', '.claude/hooks/skill-invocation-log.sh', '.claude/hooks/statusline.sh',
               '.claude/hooks/stop-context-bar.sh', '.claude/hooks/stop-git-status.sh']
MUTATE_VERBS = {'rm', 'rmdir', 'unlink', 'shred', 'truncate', 'mv', 'cp', 'install', 'rsync', 'ln', 'touch',
                'tee', 'chmod', 'chown', 'chgrp', 'dd', 'mkdir'}
READ_VERBS = {'cat', 'head', 'tail', 'less', 'more', 'grep', 'egrep', 'fgrep', 'rg', 'awk', 'cut', 'sort', 'uniq',
              'diff', 'stat', 'file', 'jq', 'yq', 'source', '.', 'wc', 'strings', 'xxd', 'od', 'base64', 'tac', 'nl'}
NET_VERBS = {'curl', 'wget', 'http', 'https', 'xh'}
WRAPPERS = {'env', 'command', 'nohup', 'time', 'nice', 'builtin', 'exec', 'sudo', 'doas',
            'rtk', 'timeout', 'setsid', 'stdbuf', 'ionice', 'chrt', 'unbuffer'}
# Options that consume the NEXT token, PER wrapper — a shared table cannot encode that `-p` takes an argument
# for sudo but none for `time`/`command`, or `-i` none for env but one for stdbuf (6C F-H). Unlisted wrappers
# (command, nohup, time, builtin, exec, setsid, unbuffer) have no argument-taking options.
WRAPPER_ARG_OPTS = {
    'env':     {'-u', '-C', '-S', '--unset', '--chdir', '--split-string'},
    'timeout': {'-s', '-k', '--signal', '--kill-after'},
    'nice':    {'-n', '--adjustment'},
    'ionice':  {'-c', '-n', '-p', '--class', '--classdata', '--pid'},
    'stdbuf':  {'-i', '-o', '-e', '--input', '--output', '--error'},
    'chrt':    {'-p', '--pid'},
    'sudo':    {'-u', '-g', '-h', '-p', '-C', '-D', '-r', '-t', '-T', '-U', '--user', '--group', '--host', '--prompt', '--chdir'},
    'doas':    {'-u', '-C'},
    'exec':    {'-a'},                                                    # exec -a NAME cmd (B2 review F14)
}
WRAP_CHDIR = [None]   # a wrapper that runs its command in ANOTHER directory: env -C/--chdir, sudo -D/--chdir
DIRSTACK, STACK_BAD = [], [False]   # pushd/popd stack of this shell; BAD = it may not match bash's any more
CDPATH_SET = [bool(os.environ.get('CDPATH'))]   # a relative `cd` then searches CDPATH first (B2 review F6)
XARGS_ARG_OPTS = {'-I', '-n', '-P', '-a', '-L', '-d', '-s', '-E', '--max-args', '--max-procs', '--arg-file',
                  '--delimiter', '--max-chars', '--eof', '--max-lines', '--process-slot-var'}
NUMERIC_POSITIONAL = {'timeout', 'chrt'}                                  # timeout DURATION cmd, chrt PRIO cmd
# Shell reserved words that can open a segment in front of the real command (2026-09-23). Without this
# the reserved word WAS the verb, matched no tier, and `for …; do rm -rf /etc; done` was silent while
# the bare `rm -rf /etc` was denied. Only a LEADING word is popped: `[[ ! -f x ]]`, `find \( ! … \)`
# keep their `!`. `for`/`case`/`select` headers are left alone — they are not verbs and tier nothing.
RESERVED = {'do', 'then', 'else', 'elif', 'if', 'while', 'until', '{', '}', '!'}
def env_split(v, words):
    """`env -S STRING`: STRING becomes words of the command line. env's own escapes (`\\_`, `\\t`, `${VAR}`) are
    not modelled — a string using them asks (B2 review F8)."""
    if '\\' in v or '${' in v:
        F.append(('ask', "`env -S` string uses env's escape or ${VAR} syntax — not modelled (fail closed). " + esc(), 'spell the command out'))
    try: words[:0] = shlex.split(v)
    except ValueError: F.append(('ask', "`env -S` string could not be split (fail closed). " + esc(), 'fix quoting'))
def strip_wrappers(words):
    """Pop leading reserved words, VAR=x assignments and wrapper verbs WITH their options so the real verb
    is classified: `env -i HOME=x rm …`, `timeout 30 rm …`, `rtk proxy rm …`, `time -p rm …`,
    `sudo -u bob rm …`, `then rm …`, `{ rm …`, `! rm …`, `function f { rm …` all reach `rm`."""
    while words:
        w = words[0]
        if w in RESERVED:
            words.pop(0); continue
        if w == 'function':                                 # `function NAME { body` — NAME is not a verb
            words.pop(0)
            if words: words.pop(0)
            continue
        if w == 'coproc':                                   # `coproc cmd …` or `coproc NAME { cmd …`
            words.pop(0)
            if len(words) >= 2 and words[1] == '{': words.pop(0)
            continue
        if re.fullmatch(r'[A-Za-z_]\w*=.*', w):
            words.pop(0); continue
        b = os.path.basename(w)
        if b not in WRAPPERS:
            break
        words.pop(0)
        if b == 'rtk':
            if words and words[0] in ('proxy', 'hook'): words.pop(0)      # `rtk proxy <cmd>`; `rtk <cmd>` is transparent
            continue
        argopts = WRAPPER_ARG_OPTS.get(b, set())
        while words and words[0].startswith('-'):
            opt = words.pop(0)
            if b == 'env':
                # `env -S STRING` splits STRING into the command itself (panel B2): popping it as an option
                # value left no verb, and `env -S 'rm -rf /etc/passwd'` was silent. Options are parsed as a
                # CLUSTER (`-iS STR`, `-vS…`) and -C/--chdir moves the command's cwd (B2 review F6/F8).
                if opt.startswith('--'):
                    name, eq, v = opt.partition('=')
                    if name in ('--split-string', '--chdir', '--unset', '--argv0'):
                        if not eq: v = words.pop(0) if words else ''
                        if name == '--split-string': env_split(v, words)
                        elif name == '--chdir': WRAP_CHDIR[0] = v
                    continue
                for k in range(1, len(opt)):
                    if opt[k] in 'uCSa':
                        v = opt[k + 1:] or (words.pop(0) if words else '')
                        if opt[k] == 'S': env_split(v, words)
                        elif opt[k] == 'C': WRAP_CHDIR[0] = v
                        break
                continue
            if opt.split('=', 1)[0] in argopts and '=' not in opt and words:
                v = words.pop(0)
                if b == 'sudo' and opt in ('-D', '--chdir'): WRAP_CHDIR[0] = v
            elif b == 'sudo' and opt.startswith('--chdir='):
                WRAP_CHDIR[0] = opt.split('=', 1)[1]
        if b in NUMERIC_POSITIONAL and words and re.fullmatch(r'\d+(\.\d+)?[smhd]?', words[0]):
            words.pop(0)
    return words

def is_cred(p):
    b = os.path.basename(p)
    if b in KEY_NAMES: return True
    if any_under(p, CRED_DIRS) or p in CRED_FILES: return True
    if any_under(p, OTHER_CRED_DIRS) or p in OTHER_CRED_FILES: return True
    if under(p, os.path.join(HOME, '.claude', 'mcp')) and b.startswith('.env'): return True
    return False
def is_host_critical(p):
    if p == '/dev/null': return False
    if p == '/' or p == HOME: return True
    if p.count('/') == 1: return True                      # any top-level directory: /etc /home /tmp /path/to/your/project …
    return any_under(p, HOST_DIRS) or p.startswith('/lib')
def is_selfmod(p):
    if not under(p, HOME): return False
    rel = os.path.relpath(p, HOME)
    if any(fnmatch.fnmatchcase(rel, g) for g in SELFMOD_BROAD): return True   # own line: tests anchor on the SELFMOD line below
    return any(fnmatch.fnmatchcase(rel, g) for g in SELFMOD)
def is_selfmod_ancestor(p):
    """p is a strict ancestor of some SELFMOD path (component-wise fnmatch): `~/.claude`, `~/.claude/hooks`,
    `~/.claude/projects/X` (holds X/state) — but not `~/.claude/projects/X/memory` or `~/.claude/hooks/tests`.
    Deleting, moving or chmod-ing such a directory disables every guard inside it (2026-09-23, step 3)."""
    if not under(p, HOME) or p == HOME: return False
    parts = os.path.relpath(p, HOME).split('/')
    for g in SELFMOD + SELFMOD_BROAD:
        gp = g.split('/')
        if len(parts) < len(gp) and all(fnmatch.fnmatchcase(a, b) for a, b in zip(parts, gp)): return True
    return False
def env_kind(p):
    b = os.path.basename(p)
    if not b.startswith('.env'): return None
    if re.search(r'prod|staging', b): return 'prod'
    return 'bare' if b == '.env' else 'other'

MARK = 'SUBSTMARK' + os.urandom(6).hex()   # per run: a user-typed marker cannot shift bodies (F13)
def _word_at(text, k, w):
    n = len(w)
    return text.startswith(w, k) and (k == 0 or not (text[k - 1].isalnum() or text[k - 1] == '_')) \
        and (k + n >= len(text) or not (text[k + n].isalnum() or text[k + n] == '_'))
def _paren_end(text, j):
    """Index of the `)` closing the `(` at j. Quote-aware, and a `)` that ends a case PATTERN inside the body
    does not close it (panel B2: `$(case x in x) rm -rf /etc;; esac)` was cut after `case x in x`)."""
    depth, case, k, n = 0, 0, j, len(text)
    while k < n:
        c = text[k]
        if c == '\\':
            k += 2; continue
        if c == "'":
            e = text.find("'", k + 1); k = n if e < 0 else e + 1; continue
        if c == '"':
            e = k + 1
            while e < n and text[e] != '"':
                e += 2 if text[e] == '\\' else 1
            k = e + 1; continue
        if c == '(':
            depth += 1
        elif c == ')':
            if not (case and depth == 1):
                depth -= 1
                if depth == 0: return k
        elif _word_at(text, k, 'case'):
            case += 1
        elif _word_at(text, k, 'esac'):
            case = max(0, case - 1)
        k += 1
    return n
ANSI_SIMPLE = {'a': '\a', 'b': '\b', 'e': '\x1b', 'E': '\x1b', 'f': '\f', 'n': '\n', 'r': '\r', 't': '\t',
               'v': '\v', '\\': '\\', "'": "'", '"': '"', '?': '?'}
def _ansi_c(body):
    """Decode a bash $'…' body with BASH's grammar (B2 review F1: python's unicode_escape wants exactly 2/4/8 hex
    digits, bash takes 1-2 / 1-4 / 1-8, so `$'\\u2f'` fell back to an unresolvable, silently-dropped READ).
    None when bash would not yield a plain string (NUL truncates, surrogates, out-of-range)."""
    out, i, n = [], 0, len(body)
    while i < n:
        c = body[i]
        if c != '\\' or i + 1 >= n:
            out.append(c); i += 1; continue
        d = body[i + 1]
        if d in ANSI_SIMPLE:
            out.append(ANSI_SIMPLE[d]); i += 2; continue
        m, v = None, None
        if d in '01234567':
            m = re.match(r'[0-7]{1,3}', body[i + 1:]); v = int(m.group(), 8) & 0xFF; i += 1 + len(m.group())
        elif d in 'xuU':
            m = re.match(r'[0-9A-Fa-f]{1,%d}' % {'x': 2, 'u': 4, 'U': 8}[d], body[i + 2:])
            if not m:
                out.append('\\' + d); i += 2; continue
            v = int(m.group(), 16); i += 2 + len(m.group())
        elif d == 'c' and i + 2 < n:
            v = ord(body[i + 2]) & 0x1F; i += 3
        else:
            out.append('\\' + d); i += 2; continue
        if v == 0 or 0xD800 <= v <= 0xDFFF or v > 0x10FFFF: return None
        out.append(chr(v))
    return ''.join(out)
def mask_subst(text):
    """Replace every `…`, $(…), <(…) and >(…) span with MARK so only the TARGETS that contain a substitution become
    unresolvable — not every target in a command that happens to contain one (`T=$(date)` is ubiquitous).
    Returns (masked text, bodies in order of appearance): each body is ANALYSED too (step 10 / panel B2 — before,
    `true $(rm -rf /etc)` and `cat <(rm -rf /etc)` were silent). Single-quoted text is literal and left alone;
    ANSI-C $'…' is decoded into an ordinary quoted word (`cat $'~/.ssh/id_rsa'` spelled a literal path)."""
    out, bodies, i, n, sq, dq = [], [], 0, len(text), False, False
    while i < n:
        c = text[i]
        if sq:
            if c == "'": sq = False
            out.append(c); i += 1; continue
        if c == '\\' and i + 1 < n:
            out.append(text[i:i + 2]); i += 2; continue
        if c == '$' and not dq and i + 1 < n and text[i + 1] == "'":
            j = i + 2
            while j < n and text[j] != "'":
                j += 2 if text[j] == '\\' else 1
            dec = _ansi_c(text[i + 2:j])
            if dec is None:
                F.append(('ask', "an ANSI-C $'…' string could not be decoded like bash does — fail closed. " + esc(), 'spell the path out'))
            out.append("'" + (dec if dec is not None else '$__undecodable__').replace("'", "'\"'\"'") + "'")
            i = j + 1; continue
        if c == "'" and not dq:
            sq = True; out.append(c); i += 1; continue
        if c == '"':
            dq = not dq; out.append(c); i += 1; continue
        if c == '`':
            j = text.find('`', i + 1)
            bodies.append(text[i + 1:] if j < 0 else text[i + 1:j])
            out.append(MARK); i = n if j < 0 else j + 1; continue
        if (c == '$' or (c in '<>' and not dq)) and i + 1 < n and text[i + 1] == '(' and not text.startswith('((', i + 1):
            j = _paren_end(text, i + 1)
            bodies.append(text[i + 2:j])
            out.append(MARK); i = j + 1; continue
        out.append(c); i += 1
    return ''.join(out), bodies

SUBST_MAX_DEPTH = 3
def analyze_bodies(bodies, cwd, depth):
    """A substitution runs in a SUBSHELL of the segment it appears in: same cwd, same shell vars and loop vars,
    but nothing it sets (vars, cd) reaches the parent."""
    for body in bodies:
        if depth + 1 > SUBST_MAX_DEPTH:
            F.append(('ask', f"nested command substitution — cannot inspect beyond {SUBST_MAX_DEPTH} levels (fail closed). {esc()}", 'flatten')); return
        saved = (dict(KNOWN_VARS), list(LOOPS), list(DIRSTACK), STACK_BAD[0])
        try:
            analyze(body, cwd, depth + 1, inherit=True)
        finally:
            KNOWN_VARS.clear(); KNOWN_VARS.update(saved[0]); LOOPS[:] = saved[1]
            DIRSTACK[:] = saved[2]; STACK_BAD[0] = saved[3]

def subst_known(text):
    """Fold $VAR / ${VAR} refs whose value was captured as a same-command literal assignment."""
    for var, val in KNOWN_VARS.items():
        text = re.sub(r'\$\{' + re.escape(var) + r'\}', lambda m: val, text)
        text = re.sub(r'\$' + re.escape(var) + r'(?![A-Za-z0-9_])', lambda m: val, text)
    return text

class Unresolvable(Exception): pass
BRACE_RE = re.compile(r'\{[^{}]*(,|\.\.)[^{}]*\}')
PROGRAM_VERBS = {'grep', 'egrep', 'fgrep', 'rg', 'awk', 'jq', 'yq'}   # one positional is a program/pattern, not a path
def resolve(tok, cwd, subst, lexical=False):
    """The realpath of tok. lexical=True: the LINK path instead — every parent resolved, the last component kept
    (credential-ancestor-tiering Q4: a symlink is tiered at both; parents stay resolved so a symlinked cwd does
    not make every target ask)."""
    if subst or MARK in tok or '`' in tok or '$(' in tok or '{}' in tok: raise Unresolvable(tok)
    t = subst_known(tok)
    t = re.sub(r'^~(?=/|$)', HOME, t).replace('${HOME}', HOME).replace('$HOME', HOME)
    if re.match(r'^~(?:[+-]\d*|\d+)(?=/|$)', t): raise Unresolvable(tok)   # ~- ~+ ~N: OLDPWD/PWD/dir stack (F6)
    m = re.match(r'^~([A-Za-z_][\w.-]*)(?=/|$)', t)          # ~user/ (step 10): bash expands it, so must we
    if m:
        try: t = pwd.getpwnam(m.group(1)).pw_dir + t[m.end():]
        except KeyError: pass                                  # unknown user: bash leaves `~name` literal too
    if '$' in t: raise Unresolvable(tok)
    # Glob OR brace expansion → the directory before it. A brace is NOT unresolvable here: its directory
    # is often decisive (`~/.ssh/{a,id_rsa}` must still deny, `/etc/{passwd,x}` too). The fact that a
    # brace hides WHICH paths is reported separately, as an ask (add_target / verb_target).
    cuts = [x.start() for x in (re.search(r'[*?\[]', t), BRACE_RE.search(t)) if x]
    if cuts:
        t = t[:min(cuts)]
        if not t.endswith('/'): t = os.path.dirname(t) or '.'
    if '\t' in t or '\n' in t: raise Unresolvable(tok)   # the target file is one `path<TAB>class` per line
    if not os.path.isabs(t):
        if cwd is None: raise Unresolvable(tok)
        t = os.path.join(cwd, t)
    t = os.path.normpath(t)
    # /proc/self/cwd is the COMMAND's cwd, /proc/self/root is / — realpath() would read the HOOK's (B4)
    m = re.match(r'^/proc/(self|thread-self|\d+)/(cwd|root)(?=/|$)', t)
    if m:
        own = not m.group(1).isdigit()                 # another pid's cwd/root is unknowable
        if own and m.group(2) == 'root': t = os.path.normpath('/' + t[m.end():])
        elif own:
            if cwd is None: raise Unresolvable(tok)
            t = os.path.normpath(cwd + '/' + t[m.end():])
        else: raise Unresolvable(tok)
    if re.fullmatch(r'/dev/(?:std(?:in|out|err)|fd/\d+)|/proc/(?:self|thread-self)/fd/\d+', t): return '/dev/null'   # a stream
    # a link this command created EARLIER does not exist yet for realpath(): substitute it (panel B3 —
    # `ln -s /etc e && rm -rf e/passwd` tiered PROJ/e/passwd)
    for L, T in LINKS.items():
        if t == L or t.startswith(L + '/'):
            if T is None: raise Unresolvable(tok)
            t = T + t[len(L):]
            break
    if lexical and t != '/': return os.path.join(R(os.path.dirname(t)), os.path.basename(t))
    return R(t)
CREATED = set()   # directories this command creates (mkdir, git clone/init/worktree add): a later cd may enter them
LINKS = {}   # link path → what it points to (None = unknown), for links made by `ln` earlier in this command

TARGETS = []   # every statically resolved path this command touches; exported via FW_TGT_FILE
# Per-target class (2026-09-23, step 5): `free` = tier() recorded no finding for it (SAFE zone, /dev/null, a
# plain read, an in-root write) — the grant is irrelevant to it, so it must not WITHDRAW the grant either;
# `grant` = it has a finding, which only an in-tree grant may lift; `deny` = it has a deny, which NO grant
# lifts (it withdraws the grant — before this class a free `2>/dev/null` beside a credential read was the only
# thing keeping that deny, and the bare read was lifted outright). Step 5 treats EVERY finding as `grant`;
# step 6 narrows which findings a grant may lift at all (boundary asks yes, deny/self-mod no).
F = []   # findings: (tier, reason, suggestion[, boundary[, lift]])
# Raw text a guard ask hands to the TOTAL floor verbatim. Re-reading it out of the message's backtick quoting
# lost it whenever the text carried its own backticks — the pairs shifted (R8, regression from e62884f9).
GUARD_RAW = []
# boundary (4th) = a settings `allow` may downgrade this ask (F4) — never for a redirect.
# lift (5th, step 6)  = a bypass GRANT may lift this ask: boundary asks (redirects included) and NET writes
#                       whose data is a literal. Every other finding is a GUARD — deny, self-mod, .env,
#                       protected[], unresolvable, braces, nested shells, xargs — and no grant lifts it.
def is_lift(f): return len(f) > 4 and f[4]
def esc(): return "In-repo files: use the Edit tool. Otherwise run it yourself with `!`."
def tier(kind, verb, p, tree=False):
    if p == '/dev/null': return
    if is_cred(p):
        F.append(('deny', f"`{verb}` targets a credential store ({p}) — denied regardless of project root; a settings allow does not lift this.", 'keep credential stores out of Bash')); return
    if kind == 'MUTATE':
        if is_host_critical(p):
            F.append(('deny', f"`{verb}` targets a host-critical path ({p}) — denied.", 'never'))
        elif is_selfmod(p):
            F.append(('ask', f"`{verb}` modifies a Claude self-mod path ({p}) — asks even inside ~/.claude. {esc()}", 'user applies guard/settings/sentinel changes'))
        elif tree and is_selfmod_ancestor(p):
            F.append(('ask', f"`{verb}` acts on a directory that CONTAINS Claude self-mod paths ({p}) — deleting/moving/re-permissioning it disables guards. {esc()}", 'user applies guard/settings/sentinel changes'))
        elif env_kind(p) == 'prod':
            F.append(('ask', f"`{verb}` writes a production/staging env file ({p}). {esc()}", '.env matrix'))
        elif env_kind(p) == 'bare':
            F.append(('ask', f"`{verb}` writes the bare .env ({p}) — live secrets; .env.example/.env.local are silent. {esc()}", '.env matrix'))
        elif any_under(p, PROTECTED):
            F.append(('ask', f"`{verb}` targets a path listed in .claude/boundary.json protected[] ({p}). {esc()}", 'boundary.json'))
        elif BOUNDARY_BROKEN and ROOT and under(p, ROOT):
            F.append(('ask', f"`{verb}` targets {p} but {ROOT}/.claude/boundary.json is unreadable, so protected[] is unknown — fix the file. {esc()}", 'repair boundary.json'))
        elif any_under(p, SAFE):
            return
        elif BOUNDARYLESS:
            F.append(('ask', f"`{verb}` targets {p} and this session has no project root (cwd is $HOME) — only /tmp and ~/.claude/{{projects,run,logs}} are silent. {esc()}", 'launch claude inside a project', verb != 'redirect', True))
        else:
            # a settings allow blesses the VERB, not a `>` target: redirect writes are never downgraded
            F.append(('ask', f"`{verb}` targets {p} — OUTSIDE the project root ({ROOT}). {esc()}", 'add to boundary.json trusted_outside[] if this is routine', verb != 'redirect', True))
    else:
        if env_kind(p) == 'prod':
            F.append(('ask', f"`{verb}` reads a production/staging env file ({p}). {esc()}", '.env matrix'))
        elif (p.endswith('.pem') or p.endswith('.key')) and not (ROOT and under(p, ROOT)):
            F.append(('deny', f"`{verb}` reads a private key outside the project root ({p}) — denied.", 'keys stay outside Bash'))
# ── for-loop resolution (2026-09-23, firewall-hardening step 7) ─────────────────────────────────────────
# `for V in WORDS` pushes (V, values) on LOOPS; a target that uses $V is tiered once per value, so
# `for f in /etc/a /etc/b; do rm "$f"` denies and `for f in a b; do rm "$f"` in the root is silent.
# Globs expand against the tracked cwd (> 64 matches → the pattern itself). The positional form
# (`for V; do`) and `for ((…))` → values unknown → the target stays unresolvable (ask). Everything else is
# PER WORD: a non-literal word stays unresolvable on its own and the literal words beside it are still tiered. while/until push a
# marker so every `done` pops its own loop. After `done` V is gone, and step 0 already poisons it (never folded).
LOOPS = []                 # [var, values|None] per enclosing loop, innermost last
LOOP_CAP = 64              # glob matches kept per word (more → the pattern itself)
LOOP_PRODUCT_CAP = 256     # concrete tokens one target may expand to (more → guard ask; timeout = fail OPEN)
VAR_REF = re.compile(r'\$\{([A-Za-z_]\w*)\}|\$([A-Za-z_]\w*)')
def loop_values(ws, cwd):
    out = []
    split = []
    for w in ws:
        v = subst_known(w)
        # a folded value with whitespace is word-split in an unquoted list: every word AND the whole (B2 review F4)
        if '$' in w and re.search(r'\s', v) and not re.search(r'\$|`', v) and MARK not in v: split += [v] + v.split()
        else: split.append(w)
    for w in split:
        v = re.sub(r'^~(?=/|$)', HOME, subst_known(w)).replace('${HOME}', HOME).replace('$HOME', HOME)
        # A non-literal word is kept AS IS (resolve() fails it closed on its own) — never "unknown list": that
        # hid the literals beside it, and `for f in ~/.ssh/id_rsa "$X"; do cat "$f"` went silent.
        if '$' in v or '`' in v or MARK in v or '{}' in v or BRACE_RE.search(v):
            out.append(v)
        elif re.search(r'[*?\[]', v):
            m = []
            if not (cwd is None and not os.path.isabs(v)):
                # LAZY and capped (panel B1): `sorted(glob())` enumerated `/*/*/*/*/*/*` for > 120 s — past the hook
                # timeout, which fails OPEN.
                m = list(itertools.islice(globmod.iglob(v if os.path.isabs(v) else os.path.join(cwd, v)), LOOP_CAP + 1))
            # no match / unknown cwd / more than LOOP_CAP matches: keep the PATTERN — resolve() tiers the
            # directory before it (or fails it closed), never a silently dropped list.
            out += sorted(m) if 0 < len(m) <= LOOP_CAP else [v]
        else:
            out.append(v)
        if len(out) > LOOP_PRODUCT_CAP: return None
    return out
def loop_entry(var):
    return next((e for e in reversed(LOOPS) if e[0] == var), None)
def loop_write(var, value):
    """A write to an enclosing loop var inside its body (panel B1): the value set GROWS by the new value — a
    superset is always safe, the write may be conditional — and a non-literal write makes it unknown."""
    e = loop_entry(var)
    if e is None or e[1] is None: return
    if value is None: e[1] = None
    elif value not in e[1]: e[1] = e[1] + [value]
class LoopOverflow(Exception): pass
def loop_expand(tok):
    """Concrete tokens for tok when it references enclosing loop vars with KNOWN values; None when it uses none,
    or one whose values are unknown (tok is then left to resolve() → unresolvable). All refs are matched on the
    ORIGINAL token with bash's longest-name rule, so `$f$g` is two refs and `$fx` is one (panel F7)."""
    refs = {}
    for m in VAR_REF.finditer(tok):
        name = m.group(1) or m.group(2)
        e = loop_entry(name)
        if e is None: continue
        if e[1] is None: return None
        refs[name] = e[1]
    if not refs: return None
    total = 1
    for v in refs.values(): total *= max(1, len(v))
    if total > LOOP_PRODUCT_CAP: raise LoopOverflow(tok)
    names = list(refs)
    out = []
    for combo in itertools.product(*(refs[n] for n in names)):
        env = dict(zip(names, combo))
        out.append(VAR_REF.sub(lambda m: env.get(m.group(1) or m.group(2), m.group(0)), tok))
    return out

def add_target(kind, verb, tok, cwd, subst, tree=False, expanded=False, globbed=False):
    if not expanded:                                   # one expansion pass: a value may itself read `$f` (F11)
        try:
            exp = loop_expand(tok)
        except LoopOverflow:
            TARGETS.append('UNRESOLVABLE')
            F.append(('ask', f"`{verb}` target `{tok}` expands to more than {LOOP_PRODUCT_CAP} paths across nested loops — not checked one by one (fail closed). {esc()}", 'smaller loops'))
            return
        if exp is not None:
            for t in exp: add_target(kind, verb, t, cwd, subst, tree, expanded=True)
            return
    if not globbed and not subst and re.search(r'[*?\[]', tok) and MARK not in tok and not BRACE_RE.search(tok):
        # A glob target is its MATCHES (B4): cut back to its directory it was never a self-mod path for a non-tree
        # verb, and `sed -i … ~/.claude/hooks/*.sh` from ~/.claude was silent. Lazy and capped like loop lists;
        # over the cap the directory is judged as a TREE (asks when it holds a self-mod path).
        v = re.sub(r'^~(?=/|$)', HOME, subst_known(tok)).replace('${HOME}', HOME).replace('$HOME', HOME)
        if '$' not in v and '`' not in v and not (cwd is None and not os.path.isabs(v)):
            m = list(itertools.islice(globmod.iglob(v if os.path.isabs(v) else os.path.join(cwd, v)), LOOP_CAP + 1))
            if 0 < len(m) <= LOOP_CAP:
                for x in sorted(m): add_target(kind, verb, x, cwd, subst, tree, expanded=True, globbed=True)
                return
            if len(m) > LOOP_CAP: tree = True
    if '$' in tok and not subst:
        # An unquoted use of a value with whitespace is word-split by bash: tier every word AS WELL as the whole
        # string (quotes are gone after tokenising, so both readings are checked — B2 review F4).
        v = subst_known(tok)
        if re.search(r'\s', v) and not re.search(r'\$|`', v) and MARK not in v:
            for w in v.split(): add_target(kind, verb, w, cwd, subst, tree, expanded=True)
    try:
        p = resolve(tok, cwd, subst)
    except Unresolvable:
        # Opaque target: can never be proven outside an except list. Plain ASCII and NOT absolute on
        # purpose — a NUL marker was silently dropped by bash `read`, leaving a relative path that got
        # canonicalised against the hook's process cwd (bypassed whenever that cwd was in the tree).
        # The bash loop treats ANY non-absolute line as unresolvable, whatever its spelling.
        TARGETS.append('UNRESOLVABLE')
        if kind == 'MUTATE':
            F.append(('ask', f"`{verb}` target `{tok}` is not statically resolvable (variable, command substitution, `{{}}` or unknown cwd) — fail closed. {esc()}", 'use literal paths', True))
        return
    if kind == 'MUTATE' and BRACE_RE.search(tok):
        # The brace's directory is tiered below (a deny still wins); the write itself asks, and the
        # command is never bypassable. Covers targets that skip verb_target: redirects, find -delete.
        TARGETS.append('UNRESOLVABLE')
        F.append(('ask', f"`{verb}` target `{tok}` is a brace expansion — it hides which paths are written (fail closed). Write the paths out. {esc()}", 'expand the braces'))
    n0 = len(F)
    tier(kind, verb, p, tree)
    cls = 'deny' if any(f[0] == 'deny' for f in F[n0:]) else ('free' if len(F) == n0 else 'grant')
    TARGETS.append(p + '\t' + cls)
    # Q4: a SYMLINK is tiered at its link path too — the stricter finding wins (a deny sorts first). Only the
    # realpath was tiered, so `rm /etc/resolv.conf` (-> /run/…) asked and `cat ~/.ssh/config` (-> a dotfiles
    # file) was silent. The link entry carries the stricter class of the pair.
    lp = resolve(tok, cwd, subst, lexical=True)
    if lp != p and os.path.islink(lp):
        n1 = len(F)
        tier(kind, verb, lp, tree)
        rank_c = {'free': 0, 'grant': 1, 'deny': 2}
        c2 = 'deny' if any(f[0] == 'deny' for f in F[n1:]) else ('free' if len(F) == n1 else 'grant')
        TARGETS.append(lp + '\t' + max(cls, c2, key=rank_c.get))

# ── parsing ─────────────────────────────────────────────────────────────────────
HD_RE = re.compile(r"""(?<!<)<<(?!<)(-?)[ \t]*((?:'[^']*'|"[^"]*"|[^\s;&|<>()'"])+)""")   # the tag is a WORD; quote removal below (B2 review F3)
def _unescaped(line, j):
    """True when line[j] is not backslash-escaped (an even run of `\\` precedes it)."""
    n = 0
    while j - 1 - n >= 0 and line[j - 1 - n] == '\\': n += 1
    return n % 2 == 0
def _subst_end(line, i):
    """Index just past the `$( … )` or `` `…` `` starting at line[i] (quote-aware); len(line) if unclosed."""
    if line[i] == '`':
        j = i + 1
        while j < len(line):
            if line[j] == '\\': j += 2; continue
            if line[j] == '`': return j + 1
            j += 1
        return len(line)
    depth, j, q = 0, i + 1, None
    while j < len(line):
        c = line[j]
        if q == "'":
            if c == "'": q = None
        elif c == '\\': j += 2; continue
        elif q == '"':
            if c == '"': q = None
        elif c in '\'"': q = c
        elif c == '(': depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0: return j + 1
        j += 1
    return len(line)
def _heredoc_as_dq(line):
    """An UNQUOTED heredoc body line re-expressed as a double-quoted word with identical expansion (R2 C7):
    in both, `\\` escapes only $ ` \\ (and newline); a body `\\` before anything else, and every `"`, are literal."""
    if ('$(' in line or '`' in line) and re.search(r'(?<![\w-])case(?![\w-])', line):
        # A `case` beside a substitution: its pattern `)`s make the substitution's end undecidable, and every
        # heuristic leaked (R4 N1, R5-2, R6-4; taking the rest of the line let a prose `"` hide `$(rm …)`, R7-1 P0).
        # Not parsed: a GUARD ask quoting the line — ask at normal; at TOTAL the raw floor reads the quoted line.
        F.append(('ask', f"an unquoted heredoc line runs `{line}` — a `case` beside a substitution cannot be analysed (fail closed). {esc()}", 'quote the heredoc tag (<<\'EOF\')'))
        GUARD_RAW.append(line)
        return ': ""'
    out, i = [], 0
    while i < len(line):
        c = line[i]
        if c == '\\' and i + 1 < len(line) and line[i + 1] in '$`\\':
            out.append(line[i:i + 2]); i += 2; continue
        if (c == '`' or line.startswith('$(', i)) and _unescaped(line, i):
            # a command substitution is CODE inside double quotes too: its quotes are its own, never escaped
            # (R3 C-F5: `$(rm -rf "/etc")` became `$(rm -rf \"/etc\")` and was silent)
            j = _subst_end(line, i)
            out.append(line[i:j]); i = j; continue
        out.append('\\\\' if c == '\\' else '\\"' if c == '"' else c); i += 1
    return ': "' + ''.join(out) + '"'
def _code_positions(line):
    """Indexes of `line` that are shell CODE: outside quotes and outside $(( )) / (( )) arithmetic."""
    code, sq, dq, arith, brace, brack, i = set(), False, False, 0, 0, 0, 0
    while i < len(line):
        c = line[i]
        if sq:
            sq = c != "'"
        elif c == '\\':
            i += 2; continue
        elif c == "'" and not dq:
            sq = True
        elif c == '"':
            dq = not dq
        elif not dq and line.startswith('((', i):
            arith += 1; i += 2; continue
        elif not dq and arith and line.startswith('))', i):
            arith -= 1; i += 2; continue
        elif not dq and line.startswith('${', i):        # parameter expansion / $[ ] arithmetic (B2 review F2)
            brace += 1; i += 2; continue
        elif not dq and brace and c == '}':
            brace -= 1
        elif not dq and line.startswith('$[', i):
            brack += 1; i += 2; continue
        elif not dq and brack and c == ']':
            brack -= 1
        elif not dq and not arith and not brace and not brack:
            # A comment only at a WORD START (B3 review F10; R2 F1): the previous char must be UNESCAPED
            # whitespace or an operator that opens a word. `)` is excluded — it also closes $( )/$(( )), after
            # which bash is mid-word (`$(cmd)#x`), and a wrongly-ended code region hid a real heredoc.
            if c == '#' and (i == 0 or (line[i - 1] in ' \t;|&(' and _unescaped(line, i - 1))):
                break
            code.add(i)
        i += 1
    return code
def strip_heredocs(cmd):
    out, tags = [], []
    for line in cmd.split('\n'):
        if tags:
            tag, dash, quoted = tags[0]
            body = line.lstrip('\t') if dash else line
            if body == tag: tags.pop(0); continue
            # An UNQUOTED tag's body still expands $( ) and backticks — and they RUN (R2 C7: `cat <<EOF⏎$(rm -rf
            # /etc)⏎EOF` was silent). Such a line is handed to the analyser as a double-quoted word of `:`.
            if not quoted and ('$(' in body or '`' in body): out.append(_heredoc_as_dq(body))
            continue                                        # otherwise heredoc body = data, never a command
        # Only a `<<` in CODE opens a heredoc (panel B2): `echo "a << b"` / `$(( 1 << 2 ))` registered a tag
        # and every later line was dropped as data — `…\nrm -rf /etc` went silent.
        code = _code_positions(line)
        real = [m for m in HD_RE.finditer(line) if m.start() in code]
        for m in real:
            tags.append((re.sub(r'[\'"\\\\]', '', m.group(2)), m.group(1) == '-', bool(re.search(r'[\'"\\\\]', m.group(2)))))
        for m in reversed(real):
            line = line[:m.start()] + ' ' + line[m.end():]
        out.append(line)
    if tags:   # a body that never ends means we mis-read the tag, or everything after it is data: either way ask
        F.append(('ask', "a heredoc in this command never reaches its end tag — the rest cannot be told apart from data (fail closed). " + esc(), 'close the heredoc'))
    return '\n'.join(out)
def tokenize(text):
    s = shlex.shlex(text, posix=True, punctuation_chars='();<>|&\n')
    s.whitespace = ' \t\r'; s.whitespace_split = True; s.commenters = ''
    return list(s)
SEP_RE = re.compile(r'^[;|&\n()]+$')
def is_sep(t): return bool(SEP_RE.match(t)) and t not in ('>&', '&>')
def positional(args):
    """Operands: non-option words, and EVERY word after `--` (panel B3: `rm -f -- -x` dropped `-x`)."""
    out, dd = [], False
    for a in args:
        if dd or a == '-' or not a.startswith('-'): out.append(a)
        elif a == '--': dd = True
    return out

# Strict folding (2026-09-23, firewall-hardening step 0). The fold is sequential, so it is only sound when
# the variable has exactly ONE write in the whole command and that write certainly ran before any later use:
# a sole-word `VAR=literal` segment, outside every if/while/for/case/{ }/( ) body, not in a pipeline or
# background job, and not after &&/|| — unless everything after it is a pure && chain, so a later use runs
# only if the write did. Any other write form (export/declare/local/readonly, +=, ${V:=}, prefix `V=x cmd`,
# read/mapfile/printf -v/getopts/unset/for/select operands, `(( V = … ))`) POISONS the variable: it is never
# folded, so its targets are unresolvable → ask. The stale-fold shapes this closes were all SILENT, e.g.
# `S=<root>/b; if …; then S=/etc; fi; rm -rf "$S/y"`; `false && S=<root>/b; rm -rf "$S/y"` ran `rm -rf /y`.
# `source`/`.`/`eval` anywhere make every fold opaque (they can set anything).
POISON, NOFOLD = set(), False
NEXT_SEP = ['']   # the connector following the segment being analysed (cd into a missing dir, R2 C8)
ASSUMED_CD = [False]   # that segment's cd into a MISSING dir was assumed to succeed (R3 C-F2)
FOLD_OPEN = {'if', 'while', 'until', 'for', 'select', 'case', '{'}
FOLD_CLOSE = {'fi', 'done', 'esac', '}'}
FOLD_NEUTRAL = {'then', 'do', 'else', 'elif', '!'}
OPERAND_WRITERS = {'read', 'mapfile', 'readarray', 'getopts', 'unset', 'declare', 'typeset', 'local',
                   'readonly', 'printf', 'for', 'select'}
WRITE_RE = re.compile(r'(?<![\w$])([A-Za-z_]\w*)(?:\[[^\]]*\])?(?:\+?=|:=)')
def seg_words(seg):
    """The segment's words with redirects and their targets removed, parens stripped."""
    out, i = [], 0
    while i < len(seg):
        if re.fullmatch(r'[<>&|]+', seg[i]):
            if out and re.fullmatch(r'\d+', out[-1]): out.pop()     # fd number (2>…), as segment() does
            i += 2; continue
        w = seg[i].strip('()')
        if w: out.append(w)
        i += 1
    return out
FUNCS = set()   # functions defined anywhere in the command: calling one can write any variable
FUNC_RE = re.compile(r'(?:^|[;&|\n({]|\bfunction)\s*([A-Za-z_][\w-]*)\s*\(\s*\)|\bfunction\s+([A-Za-z_][\w-]*)')
def opaque_writer(rest):
    """A command that writes variables the classifier cannot see: source/., a function of this command, a
    nameref declaration (`declare -n r=f; r=/etc/passwd` writes f). B1 review."""
    if not rest: return False
    vb = os.path.basename(rest[0])
    return vb in ('source', '.', 'eval') or rest[0] in FUNCS or (vb in ('declare', 'typeset', 'local') and
           any(re.fullmatch(r'-[A-Za-z]*n[A-Za-z]*', a) for a in rest[1:]))
def fold_poison(segs, seps):
    """segs[k] sits between seps[k] and seps[k+1] ('' = start/end). Returns (poisoned names, opaque)."""
    writes, opaque, depth, paren, ctx = {}, False, 0, 0, []
    for k, seg in enumerate(segs):
        for c in seps[k]:
            if c == '(': paren += 1
            elif c == ')' and paren: paren -= 1       # a case-pattern `)` has no opener
        words = seg_words(seg)
        while words:
            w = words[0]
            if w == 'function':                       # `function NAME {` — NAME is not a verb
                del words[:2]; continue
            if w in FOLD_OPEN:
                depth += 1
                if w in ('for', 'select', 'case'): break          # keep the header: `for V in` writes V
            elif w in FOLD_CLOSE:
                depth = max(0, depth - 1)
            elif w not in FOLD_NEUTRAL:
                break
            words.pop(0)
        ctx.append(depth)                              # control depth of this segment's command (cd scoping)
        for t in seg:
            for m in WRITE_RE.finditer(t):
                writes.setdefault(m.group(1), []).append(False)
        for j in range(len(words) - 1):
            if re.fullmatch(r'[A-Za-z_]\w*', words[j]) and re.match(r'[-+*/%]?=', words[j + 1]):
                writes.setdefault(words[j], []).append(False)                 # (( V = … ))
        rest = strip_wrappers(list(words))
        if rest:
            vb = os.path.basename(rest[0])
            if opaque_writer(rest): opaque = True
            if vb in OPERAND_WRITERS:
                for a in rest[1:]:
                    m = re.fullmatch(r'([A-Za-z_]\w*)(?:\[.*\])?', a)
                    if m: writes.setdefault(m.group(1), []).append(False)
        m = re.fullmatch(r'([A-Za-z_]\w*)=.*', words[0], re.S) if len(words) == 1 else None
        if m and depth == 0 and paren == 0:
            before, after = seps[k], seps[k + 1]
            after_ok = not any(c in after for c in '|&') or after.strip(';\n') in ('&&', '||')
            if not any(c in before for c in '|&'):
                before_ok = True
            else:
                before_ok = before.strip(';\n') == '&&' and all(s.strip() in ('&&', '') for s in seps[k + 1:])
            if after_ok and before_ok and writes.get(m.group(1)):
                writes[m.group(1)][-1] = True     # the regex already counted this token — mark it plain
    if 'IFS' in writes: opaque = True   # word splitting changes for every later use: fold nothing (B2 review F5)
    return {v for v, ws in writes.items() if len(ws) != 1 or not ws[0]}, opaque, ctx

def analyze(cmd, cwd, depth, inherit=False):
    global POISON, NOFOLD
    cmd = cmd.replace('\\\n', '')                        # line continuation: bash joins before parsing (panel B2)
    masked, bodies = mask_subst(strip_heredocs(cmd))
    FUNCS.update(a or b for a, b in FUNC_RE.findall(masked))
    toks = tokenize(masked)
    segs, seps, cur, sep = [], [], [], ''
    for t in toks:
        if is_sep(t):
            if cur: segs.append(cur); seps.append(sep); cur, sep = [], ''
            sep += t
        else:
            cur.append(t)
    if cur: segs.append(cur); seps.append(sep); sep = ''
    seps.append(sep)
    saved = (POISON, NOFOLD)
    if re.search(r'\bCDPATH=', masked): CDPATH_SET[0] = True
    saved_stack = None if inherit else (list(DIRSTACK), STACK_BAD[0])
    if not inherit: DIRSTACK.clear(); STACK_BAD[0] = False   # a new shell (top level, bash -c) has its own stack
    poison, opaque, ctx = fold_poison(segs, seps)
    POISON = (POISON | poison) if inherit else poison
    NOFOLD = (NOFOLD and inherit) or opaque
    if NOFOLD: KNOWN_VARS.clear()
    for v in POISON: KNOWN_VARS.pop(v, None)
    # cd SCOPE (2026-09-23, step 6b). Tracking cd linearly let a cd that bash runs in a SUBSHELL, or maybe not
    # at all, move the classifier's cwd: from ~/.claude/hooks `(cd tests); cp x ask-bash-firewall.sh` was
    # tiered as hooks/tests/… (silent) while bash overwrote the firewall. Now: `( )` saves/restores cwd; a cd
    # in a pipeline or background job is discarded; a cd inside if/for/while/case/{ } (depth > 0) makes cwd
    # unknown; a cd after &&/|| holds only along a pure && chain, then becomes unknown.
    def piped(sep): return '|' in sep.replace('||', '') or '&' in sep.replace('&&', '')
    stack, maybe = [], False
    cases = []   # per open `case`: True while a PATTERN is expected — its `(`/`)` are not subshells (B4 / F12)
    try:
        for k, seg in enumerate(segs):
            if cases and any(x in seps[k] for x in (';;', ';&')): cases[-1] = True
            for c in seps[k]:
                if cases and cases[-1] and c in '()':
                    if c == ')': cases[-1] = False
                    continue
                if c == '(': stack.append((cwd, maybe))
                elif c == ')' and stack: cwd, maybe = stack.pop()   # an assumed cd inside ( ) ends there (R4 N4)
            w0 = next((w for w in seg if w not in ('do', 'then', 'else', 'elif', '{', '}', '!')), None)
            if w0 == 'case': cases.append(True)
            elif w0 == 'esac' and cases: cases.pop()
            if maybe and seps[k].strip() != '&&':
                cwd, maybe = None, False               # the conditional cd may not have run
            nb = sum(t.count(MARK) for t in seg)       # this segment's substitutions, in order
            analyze_bodies(bodies[:nb], cwd, depth); bodies = bodies[nb:]
            st0 = (len(DIRSTACK), DIRSTACK[-1] if DIRSTACK else None)
            NEXT_SEP[0] = seps[k + 1] if k + 1 < len(seps) else ''   # the connector AFTER this segment (R2 C8)
            ASSUMED_CD[0] = False
            new = segment(seg, cwd, False, depth)    # substitutions are per-token MARKs, never command-wide
            if (len(DIRSTACK), DIRSTACK[-1] if DIRSTACK else None) != st0 and (
                    stack or piped(seps[k]) or piped(seps[k + 1]) or ctx[k] > 0 or maybe
                    or any(x in seps[k] for x in ('&&', '||'))):
                STACK_BAD[0] = True                    # a push/pop that may not have run in THIS shell
            if new != cwd:
                if piped(seps[k]) or piped(seps[k + 1]):
                    pass                               # subshell: the parent never moves
                elif ctx[k] > 0:
                    cwd = None
                else:
                    cwd = new
                    # the assumed cd holds only along the && chain: after it (`;`, newline, `||`) bash is back
                    # in the old cwd if the cd failed — unknown (R3 C-F2)
                    if any(x in seps[k] for x in ('&&', '||')) or ASSUMED_CD[0]: maybe = True
    finally:
        POISON, NOFOLD = saved
        if saved_stack is not None: DIRSTACK[:] = saved_stack[0]; STACK_BAD[0] = saved_stack[1]
    return cwd

def segment(seg, cwd, subst, depth):
    words, i, n = [], 0, len(seg)
    while i < n:                                            # redirects first
        t = seg[i]
        if re.fullmatch(r'[<>&|]+', t):
            if words and re.fullmatch(r'\d+', words[-1]): words.pop()      # fd number (2>…)
            tgt = seg[i + 1] if i + 1 < n else None
            if tgt is None: i += 1; continue
            if tgt.startswith('&') or (t in ('>&', '&>') and re.fullmatch(r'\d+', tgt)): i += 2; continue
            add_target('MUTATE' if '>' in t else 'READ', 'redirect', tgt, cwd, subst)
            i += 2; continue
        words.append(t); i += 1
    words = [w.strip('()') for w in words]
    words = [w for w in words if w]
    lead = 0
    while lead < len(words) and words[lead] in ('do', 'then', 'else', 'elif', '{', '}', '!'): lead += 1
    if lead < len(words):
        w0 = words[lead]
        if w0 == 'done':
            if LOOPS:
                var, vals = LOOPS.pop()
                # bash keeps the var's value after `done`: the last one normally, but ANY one after a `break` or a
                # conditional body write — so the enclosing loop over the same var gets the whole set (B1 review)
                if var is not None and loop_entry(var) is not None:
                    for v in (vals if vals else [None]): loop_write(var, v)
            return cwd
        if w0 in ('while', 'until'):
            LOOPS.append([None, None])                 # the condition command is still tiered below
        elif w0 in ('for', 'select'):
            rest = words[lead + 1:]
            if len(rest) >= 2 and rest[1] == 'in' and re.fullmatch(r'[A-Za-z_]\w*', rest[0]):
                # re-looping an enclosing var is fine: pop() hands the last value back to the outer entry
                LOOPS.append([rest[0], loop_values(rest[2:], cwd)])
            elif rest and re.fullmatch(r'[A-Za-z_]\w*', rest[0]):
                LOOPS.append([rest[0], None])          # `for V; do` iterates "$@"
            else:
                LOOPS.append([None, None])             # `for ((…))`
            return cwd
    if LOOPS and opaque_writer(strip_wrappers(list(words[lead:]))):
        for e in LOOPS: e[1] = None                    # a write the body text does not show (B1 review)
    if LOOPS:                                          # writes to an enclosing loop var (panel B1)
        core = words[lead:]                            # `do f=x` / `then f=x` are sole assignments too
        sole = re.fullmatch(r'([A-Za-z_]\w*)=(.*)', core[0], re.S) if len(core) == 1 else None
        for tkn in seg:
            for m in WRITE_RE.finditer(tkn):
                if loop_entry(m.group(1)) is None: continue
                if sole and m.group(1) == sole.group(1) and m.start() == 0:
                    v = subst_known(sole.group(2))
                    loop_write(sole.group(1), None if ('$' in v or '`' in v or MARK in v) else v)
                else:
                    loop_write(m.group(1), None)
        rest = strip_wrappers(list(words))
        if rest and os.path.basename(rest[0]) in OPERAND_WRITERS - {'for', 'select'}:
            for a in rest[1:]:
                mm = re.fullmatch(r'([A-Za-z_]\w*)(?:\[.*\])?', a)
                if mm: loop_write(mm.group(1), None)
    if len(words) == 1:
        m = re.fullmatch(r'([A-Za-z_]\w*)=(.*)', words[0], re.S)
        if m:
            var, val = m.group(1), m.group(2)
            folded = subst_known(val)
            if NOFOLD or var in POISON:
                KNOWN_VARS.pop(var, None)   # strict folding: not this command's one plain unconditional write
            elif MARK not in folded and not re.search(r'\$|`|\{\}', folded):   # whitespace: split in add_target
                KNOWN_VARS[var] = folded
            else:
                KNOWN_VARS.pop(var, None)   # non-literal reassignment invalidates any prior fold
            return cwd
    # `\;` ends a find -exec AND is a separator here, so a SECOND `-exec VERB …` arrives as its own segment
    # starting with `-exec` — which used to be the verb, silently (2026-09-23). Its `{}` has lost the start
    # path, so it stays unresolvable (fail closed).
    popped = False
    while words and words[0] in ('-exec', '-execdir', '-ok', '-okdir'):
        words.pop(0); popped = True
    if popped and words and words[-1] == '+': words.pop()
    WRAP_CHDIR[0] = None
    words = strip_wrappers(words)
    if not words: return cwd
    if WRAP_CHDIR[0] is not None:                      # env -C DIR / sudo -D DIR: the command runs THERE (F6)
        d, WRAP_CHDIR[0] = WRAP_CHDIR[0], None
        try: ecwd = resolve(d, cwd, subst)
        except Unresolvable: ecwd = None
        segment(words, ecwd, subst, depth)
        return cwd
    verb, args = words[0], words[1:]
    # A command NAME that is not a literal (2026-09-23, step 6c) cannot be classified: `eval "$X"`,
    # `bash -c "$X"`, `eval "$(…)"`, `$RUNNER …` ran arbitrary code silently. Folded vars and $HOME count as
    # literal; anything else left is a guard ask.
    if not literal_verb(verb):
        GUARD_RAW.append(' '.join(args))   # S3: its arguments reach the TOTAL floor (the ask quotes only the verb)
        return cwd
    b = os.path.basename(verb)
    if b in ('cd', 'pushd', 'popd'):
        # options before the operand, and the directory STACK (panel B2): `cd -P /etc && rm -rf passwd`
        # resolved `-P` as the directory; `popd` was not modelled at all.
        # The stack is modelled (B2 review F10): popd returns to the directory its pushd left, as long as every
        # push/pop so far ran unconditionally in this shell — otherwise STACK_BAD and the cwd is unknown.
        if b == 'popd':
            if STACK_BAD[0] or not DIRSTACK or args:
                STACK_BAD[0] = True; return None
            return DIRSTACK.pop()
        a2 = list(args)
        while a2 and re.fullmatch(r'-[LPe@n]+', a2[0]): a2.pop(0)
        if a2 and a2[0] == '--': a2.pop(0)
        if b == 'pushd' and (not a2 or re.fullmatch(r'[+-]\d+', a2[0]) or '-n' in args):
            STACK_BAD[0] = True; return None
        if not a2 or a2[0] == '~': new = HOME
        elif a2[0] == '-': new = None
        elif CDPATH_SET[0] and not a2[0].startswith(('/', './', '../', '~')) and a2[0] not in ('.', '..'):
            new = None                                 # CDPATH may pick another directory first (F6)
        else:
            try: new = resolve(a2[0], cwd, subst)
            except Unresolvable: new = None
        if new is not None and not os.path.isdir(new) and new not in CREATED and NEXT_SEP[0].strip() == '&&':
            ASSUMED_CD[0] = True
        if new is not None and not os.path.isdir(new) and new not in CREATED and NEXT_SEP[0].strip() != '&&':
            # bash's cd FAILS and the cwd stays; a failed pushd leaves the stack untouched (B3 review F6). Along an
            # && chain nothing after runs unless the cd succeeded, so the new dir IS the cwd (R2 C8/F4: `cargo new
            # x && cd x && …` asked).
            if b == 'pushd': STACK_BAD[0] = True
            return None
        if b == 'pushd': DIRSTACK.append(cwd)
        return new
    if b == 'dirs' and '-c' in args: STACK_BAD[0] = True
    cl = shell_c(args) if b in ('bash', 'sh', 'zsh', 'dash', 'ksh') else None
    if cl is not None:
        # `-c` may sit in a cluster (-lc, -xc, -ec) and options may follow it (`bash -c -e 'x'`): the script is the first
        # operand after it (6C round 1: `bash -lc 'rm -rf /etc'` was silent at normal). An o/O in the cluster takes the
        # next word as its value — not modelled.
        if re.search(r'[oO]', args[cl]):
            F.append(('ask', f"`{b} {args[cl]}` — an option taking a value inside the -c cluster is not modelled (fail closed). {esc()}", 'write -c on its own'))
            GUARD_RAW.append(' '.join(args)); return cwd
        k = cl + 1
        while k < len(args) and args[k][:1] in ('-', '+') and args[k] not in ('-', '--'):
            k += 2 if args[k] in ('-o', '+o', '-O', '+O') else 1
        if k < len(args) and args[k] == '--': k += 1
        inner = args[k] if k < len(args) else ''
        # the words after the script are its $0 $1 … (6C round 2: `bash -c 'cat "$1"' _ ~/.ssh/id_rsa` was silent even
        # at normal): a credential path among them is a read of it, and the script's guarded targets are those words
        if args[k + 1:]:
            cred_args(b, args[k + 1:], cwd, subst)
            GUARD_RAW.extend(args[k + 1:])
        if depth >= 2:
            GUARD_RAW.append(inner)                    # never analysed: its text reaches the TOTAL floor (plan find-exec-tree-read)
            F.append(('ask', f"nested `{b} -c` wrapper — cannot inspect beyond one level (fail closed). {esc()}", 'flatten the command')); return cwd
        # F-1.2: a child shell only inherits EXPORTED env (TMPDIR, CLAUDE_CODE_SESSION_ID), never a
        # bare `VAR=x` set in the parent — folding those in here would turn a correct fail-closed ask
        # into a false-negative silent-allow on the worst shape (`S=/tmp/x && bash -c 'rm "$S/"*'`
        # runs with $S EMPTY in the child → `rm -rf /*`). `eval` needs no such snapshot (same shell).
        _saved_vars, _saved_loops = dict(KNOWN_VARS), list(LOOPS)
        LOOPS.clear()                   # a loop var is a plain shell var: the child never sees it
        KNOWN_VARS.clear()
        if not NOFOLD:                  # a seed the parent rewrote (`export TMPDIR=/etc; bash -c …`) is not the env value
            KNOWN_VARS.update({k: v for k, v in ENV_SEEDED_VARS.items() if k not in POISON})
        try:
            analyze(inner, cwd, depth + 1)
        finally:
            KNOWN_VARS.clear(); KNOWN_VARS.update(_saved_vars); LOOPS[:] = _saved_loops
        return cwd
    if b == 'alias':
        bodies_ = [a.split('=', 1)[1] for a in args if '=' in a]
        if bodies_:
            F.append(('ask', f"an alias definition runs its body wherever the alias is used later — not inspected there (fail closed). {esc()}", 'call the command directly'))
            if depth < 2:
                for body in bodies_: analyze(body, cwd, depth + 1, inherit=True)
            else: GUARD_RAW.extend(bodies_)
        return cwd
    if b == 'eval':
        if depth >= 2:
            GUARD_RAW.append(' '.join(args))
            F.append(('ask', "nested `eval` — cannot inspect beyond one level (fail closed).", 'flatten')); return cwd
        return analyze(' '.join(args), cwd, depth + 1, inherit=True)   # same shell: its cd is ours
    if b == 'xargs':
        # skip xargs' own options WITH their values (panel B2): `xargs -I {} rm -rf {}` made `{}` the verb.
        j = 0
        while j < len(args) and args[j].startswith('-') and args[j] != '-':
            a = args[j]; j += 1
            if a == '--': break
            if a in XARGS_ARG_OPTS: j += 1
        rest = args[j:]
        r2 = strip_wrappers(list(rest))
        if r2 and os.path.basename(r2[0]) in ('bash', 'sh', 'zsh', 'dash', 'ksh', 'eval'):
            # the script runs on words read from stdin: tier its text, and ask — its operands are unknown (F11)
            F.append(('ask', f"`xargs … {os.path.basename(r2[0])}` runs a shell on arguments read from stdin — cannot inspect them (fail closed). {esc()}", 'use a loop over literal paths'))
            segment(r2, cwd, subst, depth)
            return cwd
        if rest: verb_target(rest[0], rest[1:], cwd, subst, from_xargs=True)
        return cwd
    if b == 'find':
        paths, j = [], 0
        while j < len(args):                           # leading options: `find -L ~` walks ~, not the cwd
            if args[j] in ('-H', '-L', '-P') or re.fullmatch(r'-O\d+', args[j]): j += 1
            elif args[j] == '-D': j += 2
            elif args[j] == '--': j += 1; break
            else: break
        while j < len(args) and not args[j].startswith('-') and args[j] not in ('!', '('):
            paths.append(args[j]); j += 1
        paths = paths or ['.']
        opts = args[j:]
        if '-delete' in opts:
            for p in paths: add_target('MUTATE', 'find -delete', p, cwd, subst, tree=True)
        for k, a in enumerate(opts):                   # file-writing actions (panel B3)
            if a in ('-fprint', '-fprint0', '-fprintf', '-fls') and k + 1 < len(opts):
                add_target('MUTATE', f'find {a}', opts[k + 1], cwd, subst)
        pre, idx = [], 0                               # plan find-exec-tree-read: the tests an -exec is ANDed with
        while idx < len(opts):
            k = opts[idx]
            if k not in ('-exec', '-execdir', '-ok', '-okdir'):
                pre.append(k); idx += 1; continue
            ex = []
            for a in opts[idx + 1:]:
                if a in ('+', ';'): break
                ex.append(a)
            idx += len(ex) + 2
            ex = strip_wrappers(ex)
            if ex and find_exec_reads(k, ex):
                nonexec = pre + [t for t in opts[idx:] if t not in ('-exec', '-execdir', '-ok', '-okdir')]
                for p in paths: tree_read(f'find {k} {os.path.basename(ex[0])}', p, cwd, subst, names=(list(pre), nonexec))
        for idx, k in enumerate(opts):
            if k not in ('-exec', '-execdir', '-ok', '-okdir'): continue
            ex = []
            for a in opts[idx + 1:]:
                if a in ('+', ';'): break
                ex.append(a)
            ex = strip_wrappers(ex)
            if not ex: continue
            ev = os.path.basename(ex[0])
            if ev in ('bash', 'sh', 'zsh', 'dash', 'ksh', 'eval', 'xargs'):
                GUARD_RAW.append(' '.join(ex[1:]))     # the script is never analysed: its text reaches the TOTAL floor
                F.append(('ask', f"`find {k} {ev}` runs a nested shell on every match — cannot inspect (fail closed). {esc()}", 'use a plain -exec verb')); continue
            if ev in MUTATE_VERBS:
                for p in paths: add_target('MUTATE', f'find {k} {ev}', p, cwd, subst, tree=True)
            # The -exec words are a command of their own (2026-09-23): `-exec cp {} /etc/b` was never tiered.
            # `{}` stands for each match, i.e. something under a start path.
            for p in paths:
                verb_target(ex[0], [t.replace('{}', p.rstrip('/') + '/__found__') for t in ex[1:]], cwd, subst)
        return cwd
    verb_target(verb, args, cwd, subst)
    return cwd

# credential-ancestor-tiering S4 (Q1): a content reader walking a TREE that contains a credential store.
_ANC = [None]
def _anc_creds():
    """Own-home stores always; another home's only when present (or its home is unreadable) — a system account's
    never-created ~/.ssh under /var/lib/<svc> would otherwise make `grep -r x /var/lib` ask. Computed on first use."""
    if _ANC[0] is None:
        other = [os.path.join(h, n) for h in OTHER_HOMES for n in CRED_DIR_NAMES + CRED_FILE_NAMES]
        _ANC[0] = CRED_DIRS + CRED_FILES + [c for c in other if os.path.lexists(c)
                  or (os.path.isdir(os.path.dirname(c)) and not os.access(os.path.dirname(c), os.R_OK | os.X_OK))]
        # is_cred's 4th rule: ~/.claude/mcp/**/.env* (6C round 1 — `find ~ -name .env -exec cat {} +` and `grep -r x
        # ~/.claude/mcp` were silent). An unreadable subdir counts as holding one (the -name walk then fails closed).
        mcp = os.path.join(HOME, '.claude', 'mcp')
        for r, ds, fs in (os.walk(mcp, onerror=lambda e: _ANC[0].append(e.filename)) if os.path.isdir(mcp) else ()):
            _ANC[0].extend(os.path.join(r, n) for n in ds + fs if n.startswith('.env'))
    return _ANC[0]
def cred_under(p, hidden=True):
    """A credential path strictly INSIDE p; hidden=False: reachable through non-hidden components only (rg)."""
    for c in _anc_creds():
        if c != p and under(c, p) and (hidden or not any(x.startswith('.') for x in os.path.relpath(c, p).split('/'))):
            return c
    return None
def tree_read(label, tok, cwd, subst, hidden=True, names=None):
    """Ask at normal, deny at TOTAL (ruling 2026-09-24 20:39) — a guard, never lifted. The store ITSELF is already a
    credential path that tier() denies; this is its ancestor. names = (tests before, all non-exec tests) of a find."""
    if is_remote_spec(tok): return
    try: ps = {resolve(tok, cwd, subst), resolve(tok, cwd, subst, lexical=True)}
    except Unresolvable: return
    for p in sorted(ps):
        c = cred_under(p, hidden)
        if c and not (names and find_names_exclude(names[0], names[1], p)):
            total = os.environ.get('FW_TOTAL') == '1'
            hint = 'Add a -name filter, or name a narrower start path.' if label.startswith('find') else 'Name a narrower directory, or use the Grep tool.'
            F.append(('deny' if total else 'ask',
                      f"`{label}` reads the whole tree {p}, which contains a credential store ({c}){' — denied at TOTAL (the deny floor)' if total else ''}. {hint} {esc()}",
                      'name a subdirectory without credential stores'))
            return

# plan find-exec-tree-read: which -exec commands carry a match's content anywhere. Everything else — a non-literal
# verb, a shell, mv/ln/cp/scp (they relocate or copy it) — is a reader. ssh/ssh-add/git authenticate with a key.
FIND_NONREADERS = {'rm', 'rmdir', 'unlink', 'shred', 'truncate', 'chmod', 'chown', 'chgrp', 'touch', 'mkdir', 'tee',
                   'stat', 'file', 'ssh', 'ssh-add', 'git'}   # + NO_CONTENT (defined below)
def find_exec_reads(k, ex):
    """Only when a match reaches the command: `{}` in its words, or a shell run IN each match's directory."""
    ev = os.path.basename(ex[0])
    if ev in FIND_NONREADERS or ev in NO_CONTENT: return False
    return any('{}' in t for t in ex[1:]) or (k in ('-execdir', '-okdir') and ev in ('bash', 'sh', 'zsh', 'dash', 'ksh'))
FIND_UNMODELLED = {'-o', '-or', '!', '-not', ',', '-regex', '-iregex', '-path', '-ipath', '-wholename', '-iwholename'}
FIND_WALK_CAP = 5000
def find_names_exclude(pre, nonexec, start):
    """True only when the positive -name/-iname tests (ANDed, ruling 22:54) provably fail on every credential entry
    under start: the start itself, each directory down to a store, everything inside it, and any key basename.
    Anything this cannot model (an operator, a path/regex test, a pattern python's fnmatch reads differently from
    find's, an unreadable or oversized store) means the tree is read."""
    if any(t in FIND_UNMODELLED for t in nonexec): return False
    pats = [(pre[i] == '-iname', pre[i + 1]) for i in range(len(pre) - 1) if pre[i] in ('-name', '-iname')]
    if not pats or any(re.search(r'[/\\$`]|\[\^', p) or MARK in p for _, p in pats): return False
    def hit(n): return all(fnmatch.fnmatchcase(n.casefold() if ci else n, p.casefold() if ci else p) for ci, p in pats)
    if any(hit(k) for k in KEY_NAMES): return False
    names, count = {os.path.basename(start.rstrip('/'))}, 0
    for c in _anc_creds():
        if not under(c, start): continue
        names.update(os.path.relpath(c, start).split('/'))
        if not os.path.lexists(c):
            par = os.path.dirname(c)            # absent only when its parent can be listed (else: unknowable)
            while not os.path.lexists(par) and par != '/': par = os.path.dirname(par)
            if not os.access(par, os.R_OK | os.X_OK): return False
            continue
        if os.path.isdir(c):
            err = []
            for _, ds, fs in os.walk(c, onerror=err.append, followlinks=True):
                count += len(ds) + len(fs)
                if count > FIND_WALK_CAP: return False
                names.update(ds); names.update(fs)
            if err: return False
    return not any(hit(n) for n in names)
GREP_RECURSE = re.compile(r'-[A-Za-z]*[rR][A-Za-z]*')
def grep_tree(b, args, pos, cwd, subst):
    """grep -r/-R and rg (always recursive): the PATH operands (never the pattern), or the cwd when none."""
    if b == 'rg':
        if '--files' in args or '--type-list' in args: return          # names only, no content
        us = sum(a.count('u') for a in args if re.fullmatch(r'-[A-Za-z.]+', a))
        hidden = '--hidden' in args or us >= 2 or any(re.fullmatch(r'-[A-Za-z]*\.[A-Za-z.]*', a) for a in args)
    else:
        if not any(a in ('--recursive', '--dereference-recursive') or (not a.startswith('--') and GREP_RECURSE.fullmatch(a))
                   for a in args): return
        hidden = True
    explicit = any(a in ('-e', '-f', '--regexp', '--file') or a.startswith(('--regexp=', '--file='))
                   or (re.fullmatch(r'-[A-Za-z]*[ef].*', a) and not a.startswith('--')) for a in args)
    evals = {args[k + 1] for k in range(len(args) - 1) if args[k] in ('-e', '--regexp') or re.fullmatch(r'-[A-Za-z]*e', args[k])}
    paths = ([a for a in pos if a not in evals] if explicit else pos[1:]) or ['.']
    for t in paths: tree_read(f'{b} (recursive)', t, cwd, subst, hidden)

# credential-ancestor-tiering S3 (Q2): a verb the classifier does not model still READS what it is given.
# Key consumers authenticate with a key (routine); no-content verbs print names or metadata, never content.
KEY_CONSUMERS = {'ssh', 'scp', 'sftp', 'ssh-add', 'git'}
NO_CONTENT = {'ls', 'echo', 'printf', 'test', '[', '[[', 'realpath', 'readlink', 'basename', 'dirname', 'du'}
def cred_args(b, args, cwd, subst):
    """Every argument (and the VAL of --opt=VAL) that resolves to a credential path: ask at normal, deny at TOTAL
    (ruling 2026-09-24 20:50). Resolved here directly — never add_target/TARGETS, which would export every argument
    of every unknown command to the except-list check."""
    if b in KEY_CONSUMERS or b in NO_CONTENT: return
    total = os.environ.get('FW_TOTAL') == '1'
    for a in args:
        for c in ([a] + ([a.split('=', 1)[1]] if a.startswith('-') and '=' in a else [])):
            try: ps = {resolve(c, cwd, subst), resolve(c, cwd, subst, lexical=True)}
            except Unresolvable: continue
            hit = next((p for p in ps if is_cred(p)), None)
            if hit:
                F.append(('deny' if total else 'ask',
                          f"`{b}` is given a credential path ({hit}) — the classifier does not model `{b}`, so it is treated as a read of it{' — denied at TOTAL (the deny floor)' if total else ''}. {esc()}",
                          'keep credential stores out of Bash'))
                return

def shell_c(args):
    """Index of the word carrying -c (alone or in a cluster: -lc, -xc) — searched in the LEADING option run only: past
    the first operand (the script) every word is the script's argument (6C round 2: `bash tool.sh -encrypt ~/.gnupg`
    lost its S3 ask when -encrypt was read as a cluster). An o/O in a cluster, -o/-O and --rcfile/--init-file take
    the next word as a value."""
    k = 0
    while k < len(args):
        a = args[k]
        if a in ('-', '--', '+') or a[:1] not in ('-', '+'): return None
        if a.startswith('--'):
            k += 2 if a in ('--rcfile', '--init-file') else 1; continue
        if a[0] == '-' and 'c' in a[1:]: return k
        k += 2 if re.search(r'[oO]', a[1:]) else 1
    return None

def literal_verb(verb):
    """False (and a guard ask recorded) when the command NAME is not a literal. Called from segment() and
    from verb_target(), because xargs and find -exec reach verb_target without passing through segment()."""
    vt = subst_known(verb).replace('${HOME}', HOME).replace('$HOME', HOME)
    if '$' in vt or '`' in vt or MARK in vt:
        F.append(('ask', f"the command name `{verb}` is not a literal (variable or substitution) — cannot inspect what runs (fail closed). {esc()}", 'spell the command out'))
        return False
    return True

def perl_inplace(args):
    """perl's switch grammar: `i` anywhere in a cluster is in-place, unless a switch before it takes the rest of
    the word (-C -d -D -I -m -M -x -F -e -E) — `-CSDi` is -C with value SDi."""
    for a in args:
        if not a.startswith('-') or a.startswith('--') or a == '-': continue
        k = 1
        while k < len(a):
            c = a[k]
            if c == 'i': return True
            if c in 'CdDIMmxFeE': break
            k += 1
            if c in 'l0':
                while k < len(a) and (a[k].isdigit() or (c == '0' and a[k] in 'xXabcdefABCDEF')): k += 1
    return False

def verb_target(verb, args, cwd, subst, from_xargs=False):
    if not literal_verb(verb):
        GUARD_RAW.append(' '.join(args))   # S3: as in segment()
        return
    b = os.path.basename(verb)
    pos = positional(args)
    tg, kind, tree = [], 'MUTATE', False
    if b in ('rm', 'rmdir', 'unlink', 'shred', 'touch', 'tee'):
        tg, tree = pos, b not in ('touch', 'tee')
    elif b == 'mkdir':                                 # panel B3
        opts, tg = parse_opts(args, 'mZ', {'--mode', '--context'})
        note_created(tg, cwd, subst)
    elif b == 'truncate':
        skip = False
        for a in args:
            if skip: skip = False; continue
            if a in ('-s', '--size', '-r', '--reference'): skip = True; continue
            if a.startswith('-'): continue
            tg.append(a)
    elif b in ('chmod', 'chown', 'chgrp'):
        # a chmod MODE may look like an option (`-w`, `-x`), and --reference replaces the mode/owner operand
        # (panel B3: both made the FILE disappear from the targets)
        flags = re.compile(r'-[RfvchHLP]+|--[a-z-]+(=.*)?')
        ops, dd = [], False
        for a in args:
            if dd or not a.startswith('-') or a == '-' or not flags.fullmatch(a): ops.append(a)
            elif a == '--': dd = True
        ref = any(a.startswith('--reference') for a in args)
        tg, tree = (ops if ref else ops[1:]), True
    elif b in ('cp', 'install', 'rsync', 'ln', 'mv'):
        tg, tree, reads = copy_targets(b, args, pos, cwd, subst)
        if b == 'rsync':                               # option-value writers (B3 review F9)
            rdest = pos[-1] if len(pos) >= 2 else None
            for o, v in parse_opts(args, '', {'--backup-dir', '--log-file', '--partial-dir', '--temp-dir'})[0]:
                if not v or o not in ('--backup-dir', '--log-file', '--partial-dir', '--temp-dir'): continue
                if o == '--log-file':                  # the log is written locally, relative to the cwd
                    add_target('MUTATE', f'rsync {o}', v, cwd, subst); continue
                # the others live on the DESTINATION side: a remote path for a remote destination, and relative to
                # the destination dir for a local one (R2 F9)
                if rdest is None or is_remote_spec(rdest): continue
                vv = v if v.startswith(('/', '~')) else rdest.rstrip('/') + '/' + v
                add_target('MUTATE', f'rsync {o}', vv, cwd, subst, tree=True)
        # Sources are READS (2026-09-23, step 4): tiering only the destination let `cp ~/.ssh/id_rsa ./x`
        # through silently. mv's sources are already MUTATE targets. ln's operand is not read, but a link
        # to a credential is the same exfiltration setup — READ tiering only fires on creds/keys/prod env.
        for r in reads: add_target('READ', b, r, cwd, subst)
        if tree and b in ('cp', 'rsync'):              # S4: a recursive copy reads the whole source tree
            for r in reads: tree_read(f'{b} (recursive)', r, cwd, subst)
        if b == 'mv':                                  # …and mv relocates it (plan find-exec-tree-read)
            tdir_, vals_ = target_dir_opt(b, args)
            ms = [a for a in pos if a not in vals_]
            for r in (ms if tdir_ is not None else ms[:-1]): tree_read('mv', r, cwd, subst)
    elif b == 'dd':
        tg = [a[3:] for a in args if a.startswith('of=')]
        for a in args:
            if a.startswith('if='): add_target('READ', b, a[3:], cwd, subst)
    elif b == 'sed':
        # an `i` anywhere in a short-option cluster is in-place: `sed -Ei`, `-si` (panel B2)
        inplace = any(a.startswith('--in-place') or (re.match(r'-[A-Za-z]*i', a) and not a.startswith('--')) for a in args)
        explicit = any(a in ('-e', '-f', '--expression', '--file') or a.startswith(('-e', '--expression=', '--file=')) for a in args)
        tg = pos if explicit else pos[1:]
        kind = 'MUTATE' if inplace else 'READ'
    elif b == 'perl':
        if perl_inplace(args): tg = pos[1:]            # -i, -pi, -0pi, -Wpi … (panel B2, B2 review F7)
        else: cred_args(b, args, cwd, subst); return   # S3: `perl -ne print ~/.aws/credentials` reads it
    elif b in OUTPUT_WRITERS:                          # sort -o, uniq OUT, yq -i, awk -i inplace, gzip… (F9)
        tg, reads = OUTPUT_WRITERS[b](args, pos)
        rl = RECURSE_LETTER.get(b)
        tree = bool(rl) and any(a == '--recursive' or re.fullmatch(rf'-[A-Za-z]*{rl}[A-Za-z]*', a) for a in args)
        for r in reads: add_target('READ', b, r, cwd, subst)
        if not tg: kind = 'READ'                       # nothing written: still brace-checked below, and never an xargs ask
    elif b in READ_VERBS:
        tg, kind = pos, 'READ'
        if b in ('grep', 'egrep', 'fgrep', 'rg'): grep_tree(b, args, pos, cwd, subst)   # S4
        # every positional is a read, a grep/rg PATTERN included: `grep id_rsa notes.md` denies (accepted false
        # deny, user ruling 2026-09-24 13:45 — the R5 narrowing leaked `rg --files ~/.aws`, `jq . -e <cred>`)
    elif b in NET_VERBS:
        # files the download WRITES (panel B3: `curl -o /etc/x URL` was silent)
        if b in NET_WRITE_OPTS:
            letters, longs, fileopts, diropts = NET_WRITE_OPTS[b]
            for o, v in parse_opts(args, letters, longs, canon=(WGET_LONGS if b == 'wget' else None))[0]:
                if v and v != '-' and (o in fileopts or o in diropts):
                    add_target('MUTATE', f'{b} {o}', v, cwd, subst, tree=o in diropts)
            download_targets(b, args, cwd, subst)
        CWD_TRACK[0] = cwd; net(b, args); return
    elif b in ARCHIVE_WRITERS:
        ARCHIVE_WRITERS[b](args, cwd, subst); return
    else:
        cred_args(b, args, cwd, subst)                 # S3: an unmodelled verb still reads what it is given
        return
    # A brace token hides paths from the target COUNT as well as from resolve(): `cp {/tmp/evil,/etc/x}`
    # has one positional, so cp picked no target and the check in resolve() never ran. Look at every
    # positional (minus a program/pattern argument), READ verbs included — `cat {a,~/.ssh/id_rsa}` was
    # silent because unresolvable READ targets record no finding. 6C review, 2026-09-23.
    # Program verbs: an option VALUE (`grep -A 2`, `awk -v a=1`, `jq --arg k v`) shifts the program
    # argument out of pos[0], so there only a PATH-LIKE argument counts (a / or ~ anywhere in it):
    # `{a,~/.ssh/id_rsa}` and `~/.ssh/{a,id_rsa}` ask, `x{1,3}` / `{print a,b}` / `{a:1,b:2}` stay text.
    # sed has an exact answer instead: its file operands are `tg` minus any `-e`/`-f` value.
    if b == 'sed':
        vals = {args[k + 1] for k in range(len(args) - 1) if args[k] in ('-e', '-f', '--expression', '--file')}
        bad = next((a for a in tg if a not in vals and BRACE_RE.search(a)), None)
    elif b in PROGRAM_VERBS:
        # pos[0] is the program/pattern (or an option value before it) — never a path, even with a /
        # in it (`grep -E 'https?://[a-z]{2,5}'`); later args count only when path-like.
        # …unless the pattern came in through -e/-f/--regexp/--file (attached or not): then pos[0] is a FILE
        # (panel B2: `grep -e. {a,~/.ssh/id_rsa}` skipped the brace as "the pattern").
        explicit = any(a in ('-e', '-f', '--regexp', '--file') or a.startswith(('--regexp=', '--file='))
                       or (re.fullmatch(r'-[A-Za-z]*[ef].*', a) and not a.startswith('--')) for a in args)
        # …and the separate-word VALUE of -e (or a cluster ending in e) is the pattern, not a file (F9)
        evals = {args[k + 1] for k in range(len(args) - 1)                  # -f FILE stays a file: checked
                 if args[k] in ('-e', '--regexp') or re.fullmatch(r'-[A-Za-z]*e', args[k])}
        cand = [a for a in pos if a not in evals] if explicit else pos[1:]
        bad = next((a for a in cand if BRACE_RE.search(a) and re.search(r'[/~]', a)), None)
    else:
        bad = next((a for a in pos if BRACE_RE.search(a)), None)
    if bad is not None:
        # Record, never `return`: the command's OTHER targets are still tiered below, so a deny beside a
        # brace token (`rm -rf /etc/x {a,b}`) stays a deny — the sort puts deny above this ask.
        TARGETS.append('UNRESOLVABLE')
        F.append(('ask', f"`{b}` argument `{bad}` is a brace expansion — it hides which paths are touched (fail closed). Write the paths out. {esc()}", 'expand the braces'))
    if kind == 'MUTATE' and from_xargs and not tg:
        F.append(('ask', f"`xargs {b}` takes its targets from stdin — not statically resolvable (fail closed). {esc()}", 'use find -exec or literal paths')); return
    for t in tg: add_target(kind, b, t, cwd, subst, tree)
    # AFTER the verb's own targets: the link path is what `ln` WRITES, never resolved through the link it is
    # creating (B3 review F13 — `ln -sf /tmp/evil ~/.claude/hooks/x-guard.sh` was silent, `ln -s /usr/bin/x y` denied)
    if b == 'ln' or (b == 'cp' and any(a in ('-s', '--symbolic-link') or re.fullmatch(r'-[A-Za-z]*s[A-Za-z]*', a) for a in args)):
        record_links(b, args, pos, cwd, subst)

def parse_opts(args, letters, longs, oldstyle=False, canon=None):
    """(options as (name, value|None), operands). `letters` = short options that TAKE a value (attached, clustered
    `-sSo FILE`, or the next word); `longs` = long options whose value may be the next word. oldstyle: tar's
    `tar czf ARCHIVE …` first-word cluster, whose value letters consume the following words in order."""
    out, pos, i, dd = [], [], 0, False
    if oldstyle and args and re.fullmatch(r'[A-Za-z]+', args[0]):
        j = 1
        for c in args[0]:
            if c in letters and j < len(args): out.append(('-' + c, args[j])); j += 1
            else: out.append(('-' + c, None))
        i = j
    while i < len(args):
        a = args[i]
        if dd or a == '-' or not a.startswith('-'):
            pos.append(a)
        elif a == '--':
            dd = True
        elif a.startswith('--'):
            name, eq, v = a.partition('=')
            if canon and name not in canon and name not in longs and len(name) >= 4:
                # GNU getopt_long accepts any unambiguous PREFIX (`--dir`, `--output-doc`) — B3 review F5/F8
                c = [x for x in canon | longs if x.startswith(name)]
                if len(c) == 1: name = c[0]
            if eq: out.append((name, v))
            elif name in longs and i + 1 < len(args): out.append((name, args[i + 1])); i += 1
            else: out.append((name, None))
        else:
            for k in range(1, len(a)):
                c = a[k]
                if c in letters:
                    if k + 1 < len(a): out.append(('-' + c, a[k + 1:]))
                    else:
                        out.append(('-' + c, args[i + 1] if i + 1 < len(args) else None)); i += 1
                    break
                out.append(('-' + c, None))
        i += 1
    return out, pos

# per download verb: (value letters, value longs, FILE options, DIRECTORY options) — panel B3
NET_WRITE_OPTS = {
    'curl': ('oDcKHdFTuAebxXrmwECYyzUQtP', {'--output', '--dump-header', '--cookie-jar', '--trace', '--trace-ascii',
             '--stderr', '--libcurl', '--etag-save', '--output-dir', '--header', '--data', '--form', '--user',
             '--url', '--request', '--config', '--cookie', '--upload-file', '--user-agent', '--referer', '--hsts',
             '--alt-svc', '--write-out'},
             {'-o', '--output', '-D', '--dump-header', '-c', '--cookie-jar', '--trace', '--trace-ascii', '--stderr',
              '--libcurl', '--etag-save', '--hsts', '--alt-svc'}, {'--output-dir'}),
    'wget': ('oaOPeiBtTwQUlARDIX', {'--output-document', '--output-file', '--append-output', '--directory-prefix',
             '--save-cookies', '--input-file', '--execute', '--user-agent', '--header'},
             {'-O', '--output-document', '-o', '--output-file', '-a', '--append-output', '--save-cookies'},
             {'-P', '--directory-prefix'}),
}

TAR_LONGS = {'--directory', '--file', '--one-top-level', '--absolute-names', '--extract', '--create', '--append',
             '--update', '--concatenate', '--get', '--files-from', '--exclude-from', '--transform', '--to-command'}
def download_targets(b, args, cwd, subst):
    """Files a download writes WITHOUT naming them (B3 review F4/F5): curl -O/-J into the cwd, wget's default
    cwd/basename(URL) or a recursive tree, wget -e wgetrc commands, curl -w %output{FILE}, curl -K config."""
    letters, longs, _f, _d = NET_WRITE_OPTS[b]
    opts, pos = parse_opts(args, letters, longs, canon=(WGET_LONGS if b == 'wget' else None))
    names = {o for o, _ in opts}
    urls = [u for u in pos if '://' in u or re.match(r'[\w.-]+\.[a-z]{2,}(/|$)', u)]
    def urlname(u):
        path = re.sub(r'[?#].*$', '', u.split('://', 1)[-1]).split('/', 1)
        return (path[1].rstrip('/').split('/')[-1] if len(path) > 1 else '') or 'index.html'
    if b == 'curl':
        for o, v in opts:
            if o in ('-w', '--write-out') and v and v.startswith('@'):
                # the format itself comes from a file (or stdin) — its %output{} is not visible (R2 C2)
                TARGETS.append('UNRESOLVABLE')
                F.append(('ask', f"`curl -w @FILE` reads the write-out format (which may name an output file) from a file — not inspected (fail closed). {esc()}", 'pass the format inline'))
            elif o in ('-w', '--write-out') and v:
                # %output{FILE} writes, %output{>>FILE} APPENDS (R2 C2: the append form was silent)
                for m in re.finditer(r'%output\{(?:>>)?([^}]*)\}', v): add_target('MUTATE', 'curl -w %output', m.group(1), cwd, subst)
            elif o in ('-K', '--config'):
                TARGETS.append('UNRESOLVABLE')
                F.append(('ask', f"`curl -K` reads options (an output file among them) from a file — not inspected (fail closed). {esc()}", 'pass the options on the command line'))
        if names & {'-O', '--remote-name', '--remote-name-all', '-J', '--remote-header-name'} and '--output-dir' not in names:
            if names & {'-J', '--remote-header-name'}: add_target('MUTATE', 'curl -OJ', '.', cwd, subst, tree=True)
            else:
                for u in urls: add_target('MUTATE', 'curl -O', urlname(u), cwd, subst)
    elif b == 'wget':
        out_doc, pref = None, None
        for o, v in opts:
            if o in ('-O', '--output-document'): out_doc = v
            elif o in ('-P', '--directory-prefix'): pref = v
            elif o in ('-e', '--execute') and v:
                m = re.match(r'\s*(output_document|dir_prefix|logfile|save_cookies)\s*=\s*(.*)$', v)
                if m:
                    add_target('MUTATE', f'wget -e {m.group(1)}', m.group(2).strip(), cwd, subst, tree=m.group(1) == 'dir_prefix')
                    if m.group(1) == 'output_document': out_doc = m.group(2)
                    elif m.group(1) == 'dir_prefix': pref = m.group(2)
        if out_doc is None:
            d = pref if pref is not None else '.'
            if names & {'-r', '--recursive', '-m', '--mirror', '-x', '--force-directories', '-p', '--page-requisites'}:
                add_target('MUTATE', 'wget -r', d, cwd, subst, tree=True)
            else:
                for u in urls: add_target('MUTATE', 'wget', d.rstrip('/') + '/' + urlname(u), cwd, subst)
WGET_LONGS = {'--output-document', '--directory-prefix', '--output-file', '--append-output', '--execute', '--recursive',
              '--mirror', '--force-directories', '--page-requisites', '--save-cookies', '--input-file'}

def tar_targets(args, cwd, subst):
    """-x writes under -C (or the cwd); -c/-r/-u/-A write the -f archive and READ the sources (panel B3)."""
    opts, pos = parse_opts(args, 'fCbKNTXgHVLI', {'--file', '--directory', '--exclude', '--transform', '--owner',
                           '--group', '--mode', '--files-from', '--exclude-from', '--label', '--newer',
                           '--use-compress-program', '--blocking-factor'}, oldstyle=True,   # --one-top-level: =DIR only (R2 F10)
                           canon=TAR_LONGS)
    names = {o for o, _ in opts}
    if ('-P' in names or '--absolute-names' in names) and ('-x' in names or '--extract' in names or '--get' in names):
        TARGETS.append('UNRESOLVABLE')
        F.append(('ask', f"`tar -P` extracts absolute member names — where they land is not visible here (fail closed). {esc()}", 'extract without -P'))
    for o, v in opts:
        if o == '--one-top-level' and v: add_target('MUTATE', 'tar --one-top-level', v, cwd, subst, tree=True)
    extract = '-x' in names or '--extract' in names or '--get' in names
    create = bool(names & {'-c', '-r', '-u', '-A', '--create', '--append', '--update', '--concatenate'})
    arch = next((v for o, v in opts if o in ('-f', '--file')), None)
    cdir = next((v for o, v in reversed(opts) if o in ('-C', '--directory')), None)
    if extract:
        if cdir is not None: add_target('MUTATE', 'tar -x -C', cdir, cwd, subst, tree=True)
        else: add_target('MUTATE', 'tar -x', '.', cwd, subst)
        if arch and arch != '-': add_target('READ', 'tar', arch, cwd, subst)
    elif create:
        if arch and arch != '-': add_target('MUTATE', 'tar -c', arch, cwd, subst)
        if names & {'-T', '--files-from'}:            # the sources come from a list file: not visible (R2 C15)
            TARGETS.append('UNRESOLVABLE')
            F.append(('ask', f"`tar -c -T LIST` archives files named in a list — their READ tier is not visible here (fail closed). {esc()}", 'name the sources on the command line'))
        base = cwd
        if cdir is not None:
            try: base = resolve(cdir, cwd, subst)
            except Unresolvable: base = None
        for src in pos: add_target('READ', 'tar -c', src, base, subst)
        if '--no-recursion' not in names:              # S4: tar -c walks every directory it is given
            for src in pos: tree_read('tar -c', src, base, subst)

def unzip_targets(args, cwd, subst):
    opts, pos = parse_opts(args, 'dP', set())
    if {'-l', '-t', '-p', '-v', '-z', '-Z'} & {o for o, _ in opts}: return   # list / test / pipe (B3 review F12)
    ddir = next((v for o, v in opts if o == '-d'), None)
    add_target('MUTATE', 'unzip -d' if ddir else 'unzip', ddir if ddir is not None else '.', cwd, subst, tree=ddir is not None)
    if pos: add_target('READ', 'unzip', pos[0], cwd, subst)

def patch_targets(args, cwd, subst):
    opts, pos = parse_opts(args, 'odpirDBFVzYg', {'--output', '--directory', '--input', '--reject-file', '--strip'})
    for o, v in opts:
        if v and v != '-' and o in ('-o', '--output', '-r', '--reject-file'): add_target('MUTATE', f'patch {o}', v, cwd, subst)
        elif v and o in ('-d', '--directory'): add_target('MUTATE', 'patch -d', v, cwd, subst, tree=True)
        elif v and v != '-' and o in ('-i', '--input'): add_target('READ', 'patch', v, cwd, subst)
    if pos: add_target('MUTATE', 'patch', pos[0], cwd, subst)
    if len(pos) > 1: add_target('READ', 'patch', pos[1], cwd, subst)

GIT_WT_WRITERS = {'checkout', 'restore', 'reset', 'switch', 'stash', 'clean', 'rm', 'mv', 'apply', 'am', 'merge',
                  'pull', 'rebase', 'cherry-pick', 'revert', 'read-tree', 'checkout-index'}
GIT_PATH_CMDS = {'restore', 'rm', 'mv', 'clean', 'checkout-index'}   # every operand is a pathspec
# FORCE-PUSH DENY FLOOR (ruling 2026-09-27, review-remediation WS1.3): a push that can DISCARD commits on the
# remote is denied at every level, TOTAL included — a classifier deny outranks every bypass and the TOTAL exit.
# `--force-with-lease` / `--force-if-includes` (they refuse when the remote moved) stay allowed. Spellings as git
# ACCEPTS them (probed 2026-09-27): `--force` only in full (`--for`/`--forc` are ambiguous with the lease
# options, and `--force-w…` IS the lease, so a prefix test would deny the safe form); `--mirror` from `--m` up;
# `-f` inside a short cluster; a `+` refspec anywhere, `--` included. Not modelled (SPEC §2.4): git aliases,
# `-c remote.<r>.push=+…` config refspecs, `--delete`/`:ref`/`--prune`, and text the classifier cannot parse.
PUSH_VOPT = {'-o', '--push-option', '--repo', '--receive-pack', '--exec'}   # take the next token as their value
def push_force(rest):
    k, dd = 0, False
    while k < len(rest):
        a = rest[k]
        if dd or not a.startswith('-'):
            if a.startswith('+'): return f'a `+` refspec ({a})'
        elif a == '--': dd = True
        elif a in PUSH_VOPT: k += 1
        elif a == '--force': return '`--force`'
        elif len(a) >= 3 and '--mirror'.startswith(a.split('=')[0]): return '`--mirror`'
        elif re.fullmatch(r'-[A-Za-z]*f[A-Za-z]*', a): return f'`-f` ({a})'
        k += 1
    return None
def git_targets(args, cwd, subst):
    """git writes files through -C / --work-tree, worktree commands and `config` scopes (panel B3). Plain
    `git checkout main` / `git -C sub status` stay unmodelled — only a MOVED worktree or a real path counts."""
    gdir, wt, gitdir, i = cwd, None, None, 0
    while i < len(args) and args[i].startswith('-'):
        a = args[i]
        if a in ('-C', '--work-tree', '-c', '--git-dir', '--namespace', '--super-prefix', '--config-env'):
            v = args[i + 1] if i + 1 < len(args) else None
            if a == '-C' and v is not None:
                try: gdir = resolve(v, gdir, subst)
                except Unresolvable: gdir = None
            elif a == '--work-tree': wt = v
            elif a == '--git-dir': gitdir = v
            i += 2; continue
        if a.startswith('--work-tree='): wt = a.split('=', 1)[1]
        elif a.startswith('--git-dir='): gitdir = a.split('=', 1)[1]
        elif a.startswith('-C') and len(a) > 2:
            try: gdir = resolve(a[2:], gdir, subst)
            except Unresolvable: gdir = None
        i += 1
    if i >= len(args): return
    sub, rest = args[i], args[i + 1:]
    if sub == 'push':
        why = push_force(rest)
        if why:
            F.append(('deny', f"`git push` with {why} can discard commits on the remote — denied at every level (ruling 2026-09-27). Use `--force-with-lease`, which refuses when the remote moved.", 'git push --force-with-lease'))
    base = gdir
    if wt is not None:
        try: base = resolve(wt, gdir, subst)
        except Unresolvable: base = None
    # env-var work tree / git dir (B3 review F1): only an ASSIGNMENT (`GIT_DIR=x git …`, `env GIT_DIR=x`), an
    # export/declare of it, or one INHERITED by this hook moves the tree — a mere mention (a commit message,
    # `echo $GIT_DIR`) does not (R2 F5/C14).
    env_moved = bool(re.search(r'(?<![\w$])GIT_(?:WORK_TREE|DIR)=', CMD)) \
        or bool(re.search(r'\b(?:export|declare|typeset|local|readonly)\b[^;&|\n]*\bGIT_(?:WORK_TREE|DIR)\b', CMD)) \
        or bool(os.environ.get('GIT_WORK_TREE') or os.environ.get('GIT_DIR'))
    if env_moved: base = None
    # --output=FILE on any subcommand (diff/log/show/format-patch …) writes FILE (B3 review F2)
    # message values are TEXT, never options (R2 F8: `git commit -m '--output=/etc/x'` denied)
    # … but only where -m/-F TAKE a message: on log/show/diff they are plain flags (R3 C-F1: `git log -m
    # --output=/etc/x` was silent)
    msg_sub = sub in ('commit', 'tag', 'merge', 'notes', 'stash')
    msgv = {k + 1 for k, a in enumerate(rest) if msg_sub and a in ('-m', '--message', '-F', '--file')}
    for k, a in enumerate(rest):
        if k in msgv or (msg_sub and re.fullmatch(r'-m.+', a)): continue
        if a.startswith('--output='): add_target('MUTATE', f'git {sub} --output', a.split('=', 1)[1], gdir, subst)
        elif a == '--output' and k + 1 < len(rest): add_target('MUTATE', f'git {sub} --output', rest[k + 1], gdir, subst)
    gpos = [a for a in rest if not a.startswith('-')]
    if sub == 'clone':
        vopt = {'-b', '--branch', '-o', '--origin', '--depth', '--reference', '-c', '--config', '--separate-git-dir',
                '--template', '-j', '--jobs', '-u', '--upload-pack', '--filter', '--shallow-since', '--shallow-exclude'}
        cp_, k = [], 0
        while k < len(rest):
            if rest[k] == '--separate-git-dir' and k + 1 < len(rest):   # writes the repository there (R2 F6)
                add_target('MUTATE', 'git clone --separate-git-dir', rest[k + 1], gdir, subst, tree=True)
            elif rest[k].startswith('--separate-git-dir='):
                add_target('MUTATE', 'git clone --separate-git-dir', rest[k].split('=', 1)[1], gdir, subst, tree=True)
            if rest[k] in vopt: k += 2; continue
            if not rest[k].startswith('-'): cp_.append(rest[k])
            k += 1
        if cp_:
            dest = cp_[1] if len(cp_) > 1 else re.sub(r'\.git$', '', cp_[0].rstrip('/').split('/')[-1].split(':')[-1]) or '.'
            add_target('MUTATE', 'git clone', dest, gdir, subst, tree=True); note_created([dest], gdir, subst)
        return
    if sub == 'init':
        # option VALUES are not the directory (R2 F7: `init --template DIR` denied, `-b main` targeted ./main);
        # --separate-git-dir writes the repository there (R2 F6)
        ivopt = {'-b', '--initial-branch', '--template', '--separate-git-dir', '--object-format', '--ref-format'}
        ip, k = [], 0
        while k < len(rest):
            a = rest[k]
            if a in ivopt:
                if a == '--separate-git-dir' and k + 1 < len(rest):
                    add_target('MUTATE', 'git init --separate-git-dir', rest[k + 1], gdir, subst, tree=True)
                k += 2; continue
            if a.startswith('--separate-git-dir='):
                add_target('MUTATE', 'git init --separate-git-dir', a.split('=', 1)[1], gdir, subst, tree=True)
            elif not a.startswith('-'): ip.append(a)
            k += 1
        gpos = ip
        dest = gpos[0] if gpos else '.'
        add_target('MUTATE', 'git init', dest, gdir, subst, tree=True); note_created([dest], gdir, subst)
        return
    if sub == 'worktree' and rest[:1] == ['add']:
        wp, k = [], 1
        while k < len(rest):
            if rest[k] in ('-b', '-B', '--reason'): k += 2; continue
            if not rest[k].startswith('-'): wp.append(rest[k])
            k += 1
        if wp: add_target('MUTATE', 'git worktree add', wp[0], gdir, subst, tree=True); note_created(wp[:1], gdir, subst)
        return
    if sub in ('archive', 'format-patch'):
        for k, a in enumerate(rest):
            if a in ('-o', '--output-directory') and k + 1 < len(rest):
                add_target('MUTATE', f'git {sub} -o', rest[k + 1], gdir, subst, tree=sub == 'format-patch')
            elif a.startswith('--output-directory='):
                add_target('MUTATE', f'git {sub} -o', a.split('=', 1)[1], gdir, subst, tree=True)
        return
    if sub == 'bundle' and rest[:1] == ['create'] and len(gpos) > 1:
        add_target('MUTATE', 'git bundle create', gpos[1], gdir, subst); return
    if sub == 'config':
        target, cpos, k = None, [], 0
        while k < len(rest):
            a = rest[k]
            if a == '--global': target = os.path.join(HOME, '.gitconfig')
            elif a == '--system': target = '/etc/gitconfig'
            elif a in ('--file', '-f') and k + 1 < len(rest): target = rest[k + 1]; k += 1
            elif a.startswith('--file='): target = a.split('=', 1)[1]
            elif a in ('--blob', '--type', '--default', '--comment', '--value') and k + 1 < len(rest): k += 1
            elif not a.startswith('-'): cpos.append(a)
            k += 1
        names = set(rest)
        reads = {'--get', '--get-all', '--get-regexp', '--get-urlmatch', '--list', '-l', '--get-color', '--get-colorbool'}
        writes = {'--unset', '--unset-all', '--add', '--replace-all', '--rename-section', '--remove-section', '--edit', '-e'}
        write = bool(names & writes) or (cpos[:1] and cpos[0] in ('set', 'unset', 'rename-section', 'remove-section', 'edit')) \
            or (not (names & reads) and not (cpos[:1] and cpos[0] in ('get', 'list')) and len(cpos) >= 2)
        if write and target is None and (env_moved or gdir is None):
            TARGETS.append('UNRESOLVABLE')
            F.append(('ask', f"`git config` writes the config of a repository that cannot be resolved statically (fail closed). {esc()}", 'use a literal -C path'))
        elif write and target is None and (gitdir is not None or gdir != cwd):
            # the LOCAL config of ANOTHER repository (-C / --git-dir): core.hooksPath there runs code on its next
            # commit — tier that repository's config file (B3 review F3)
            if gitdir is not None: target = os.path.join(gitdir, 'config')
            else: target = os.path.join(git_top(gdir) or gdir, '.git', 'config')
        if write and target is not None: add_target('MUTATE', 'git config', target, gdir, subst)
        return
    if sub not in GIT_WT_WRITERS: return
    # index-only forms never touch the work tree: `git restore --staged`, `git rm --cached`
    if sub == 'restore' and ({'--staged', '-S'} & set(rest)) and not ({'--worktree', '-W'} & set(rest)): return
    if sub == 'rm' and '--cached' in rest: return
    if base is None:
        TARGETS.append('UNRESOLVABLE')
        F.append(('ask', f"`git {sub}` runs in a work tree that cannot be resolved statically (fail closed). {esc()}", 'use a literal -C path')); return
    skip = {'-b', '-B', '-c', '-C', '--create', '--force-create', '--orphan', '-s', '--source', '--conflict',
            '--pathspec-from-file'} | ({'-m', '--message'} if sub in ('merge', 'stash') else set())   # checkout -m: a flag
    ops, dd, k = [], False, 0
    while k < len(rest):
        a = rest[k]
        if dd: ops.append((a, True))
        elif a == '--': dd = True
        elif a in skip: k += 1
        elif not a.startswith('-'): ops.append((a, False))
        k += 1
    moved = base != cwd
    # Forced whole-tree rewrites, as git ACCEPTS them: GNU long-option prefixes (`--har`, `--forc`, `--discard`),
    # short clusters (`-qf`), options before the stash verb (`stash -q pop`), and the plumbing that does the same
    # (`read-tree -u`, `checkout-index -a`). R2 C4 — each of these was silent.
    def _long(names): return any(a.startswith('--') and len(a.split('=')[0]) >= 4
                                 and any(n.startswith(a.split('=')[0]) for n in names) for a in rest)
    def _short(ch): return any(re.fullmatch(rf'-[A-Za-z]*{ch}[A-Za-z]*', a) for a in rest)
    words = [a for a in rest if not a.startswith('-')]
    forced = (sub == 'reset' and _long(('--hard', '--merge', '--keep'))) \
        or (sub in ('checkout', 'switch') and (_short('f') or _long(('--force', '--discard-changes')))) \
        or (sub == 'stash' and words[:1] in (['pop'], ['apply'])) or sub == 'clean' \
        or (sub == 'read-tree' and ('-u' in rest or _short('u'))) \
        or (sub == 'checkout-index' and ('-a' in rest or '--all' in rest or _short('a')))
    # Ruling A (2026-09-24): forms that INSTALL other history into the work tree — a checkout/switch to a ref
    # (not a path), revert, rebase, cherry-pick, `git am`, `git apply` (not a dry run) — are judged like forced
    # rewrites: the repo top as a tree, so they ask where the repo holds self-mod paths (~/.claude) and stay
    # silent in an ordinary project. pull/merge stay silent (ruling 11: newer upstream content).
    def _is_path(o):
        try: return os.path.lexists(resolve(o, base, subst))
        except Unresolvable: return False
    _pre_dd = rest[:rest.index('--')] if '--' in rest else rest
    _restore = sub == 'checkout' and any(dd_ or _is_path(o) for o, dd_ in ops)   # `checkout REF -- P` (R3 C-F6)
    installs = (sub in ('checkout', 'switch') and not _restore and ('-' in _pre_dd   # `-` = the previous branch
                                                   or any(not dd_ and not _is_path(o) for o, dd_ in ops))) \
        or sub in ('revert', 'rebase', 'cherry-pick', 'am') \
        or (sub == 'apply' and not ({'--check', '--stat', '--numstat', '--summary'} & set(rest)))
    forced = forced or installs
    def repo_top():
        # The tree a whole-repo rewrite touches. When the repository is $HOME itself (this machine's layout),
        # every tracked file under ~/.claude is rewritten too, whatever the cwd — judge ~/.claude as the tree
        # (it asks; $HOME itself would be an unapprovable deny). R2 C3/F2: from ~/.claude/docs this was silent.
        gt = git_top(base)
        if gt and gt == HOME: return os.path.join(HOME, '.claude')
        if gt: return gt
        return ROOT if ROOT and (base == ROOT or base.startswith(ROOT + '/')) else base
    if moved:
        # a MOVED work tree is rewritten by any of these, whatever the operands name (B3 review F1)
        add_target('MUTATE', f'git {sub}', base, base, subst, tree=True)
    elif forced:
        # forced whole-tree rewrites judge the repository TOP as a tree: inside ~/.claude that holds self-mod
        # paths and asks; an ordinary project stays silent (B3 review F11)
        add_target('MUTATE', f'git {sub}', repo_top(), base, subst, tree=True)
    for o, after_dd in ops:
        if o.startswith((':/', ':(top)')) and not moved:   # top-of-repo pathspec magic (R2 C4)
            add_target('MUTATE', f'git {sub}', repo_top(), base, subst, tree=True); continue
        if sub in GIT_PATH_CMDS or after_dd:
            add_target('MUTATE', f'git {sub}', o, base, subst, tree=True)   # a directory pathspec (F11)
        elif sub == 'checkout':                        # a ref or a path: only an EXISTING path counts
            try: rp = resolve(o, base, subst)
            except Unresolvable: continue
            if os.path.lexists(rp): add_target('MUTATE', f'git {sub}', o, base, subst)

def sevenz_targets(args, cwd, subst):
    opts, pos = parse_opts(args, 'o', set())
    if pos[:1] and pos[0] in ('x', 'e'):
        d = next((v for o, v in opts if o == '-o' and v), None)
        add_target('MUTATE', '7z x', d if d is not None else '.', cwd, subst, tree=d is not None)
    elif pos[:1] and pos[0] in ('a', 'u', 'd', 'rn') and len(pos) > 1:
        add_target('MUTATE', f'7z {pos[0]}', pos[1], cwd, subst)
        if pos[0] in ('a', 'u'):
            for src in pos[2:]: add_target('READ', f'7z {pos[0]}', src, cwd, subst)   # sources are READ (R2 C9)
def zip_targets(args, cwd, subst):
    """zip ARCHIVE FILES…: writes the archive (plus `.zip` when it has no extension) and -O OUT; READS the files
    (R2 C9: `zip -r x.zip ~/.aws` was silent). -x/-i pattern lists are skipped, never read."""
    a2, k = [], 0
    while k < len(args):
        if args[k] in ('-x', '-i', '--exclude', '--include'):
            k += 1
            while k < len(args) and not args[k].startswith('-'): k += 1
            continue
        a2.append(args[k]); k += 1
    opts, pos = parse_opts(a2, 'bnPtZOs', {'--temp-path', '--suffixes', '--password', '--output-file', '--split-size'})
    for o, v in opts:
        if o in ('-O', '--output-file') and v: add_target('MUTATE', 'zip -O', v, cwd, subst)
    if not pos or pos[0] == '-': return
    add_target('MUTATE', 'zip', pos[0], cwd, subst)
    if '.' not in os.path.basename(pos[0]): add_target('MUTATE', 'zip', pos[0] + '.zip', cwd, subst)
    for src in pos[1:]: add_target('READ', 'zip', src, cwd, subst)
    if any(a in ('--recurse-paths', '--recurse-patterns') or (not a.startswith('--') and re.fullmatch(r'-[A-Za-z]*[rR][A-Za-z]*', a)) for a in a2):
        for src in pos[1:]: tree_read('zip -r', src, cwd, subst)   # S4
def is_remote_spec(x):
    """`[user@]host:path` / `scp://…` / rsync `host::module` — a path on ANOTHER machine."""
    return x.startswith(('scp://', 'rsync://')) or bool(re.match(r'(?:[\w.%+-]+@)?(?:[\w.-]+|\[[^\]]+\]):', x)) \
        and not x.startswith(('/', './', '../', '~'))
def scp_targets(args, cwd, subst):
    """scp SRC… DEST: local sources are READ (a credential store is refused — R2 C9), a local DEST is written.
    Option values (-i identity, -F config, -o …) are never read-tiered: authenticating with a key is routine."""
    opts, pos = parse_opts(args, 'cFiJloPSD', set())
    remote = is_remote_spec
    if len(pos) < 2: return
    *srcs, dest = pos
    for src in srcs:
        if not remote(src): add_target('READ', 'scp', src, cwd, subst)
        if not remote(src) and '-r' in {o for o, _ in opts}: tree_read('scp -r', src, cwd, subst)   # S4
    if not remote(dest):
        add_target('MUTATE', 'scp', dest, cwd, subst, tree='-r' in {o for o, _ in opts} or len(srcs) > 1)
def unrar_targets(args, cwd, subst):
    pos = positional(args)
    if pos[:1] and pos[0] in ('x', 'e'):
        dest = next((a for a in pos[2:] if a.endswith('/')), None)
        add_target('MUTATE', 'unrar x', dest if dest is not None else '.', cwd, subst, tree=dest is not None)
def cpio_targets(args, cwd, subst):
    opts, pos = parse_opts(args, 'DEFHIMORs', {'--directory', '--file', '--pattern-file', '--format', '--message', '--owner'})
    names = {o for o, _ in opts}
    d = next((v for o, v in opts if o in ('-D', '--directory')), None)
    if names & {'-i', '--extract', '-p', '--pass-through'}:
        dest = pos[0] if (names & {'-p', '--pass-through'}) and pos else (d if d is not None else '.')
        add_target('MUTATE', 'cpio', dest, cwd, subst, tree=dest != '.')
    for o, v in opts:
        if o in ('-F', '--file', '-O') and v and (names & {'-o', '--create'}): add_target('MUTATE', 'cpio -o', v, cwd, subst)

ARCHIVE_WRITERS = {'tar': tar_targets, 'bsdtar': tar_targets, 'unzip': unzip_targets, 'patch': patch_targets,
                   'git': git_targets, '7z': sevenz_targets, '7za': sevenz_targets, '7zz': sevenz_targets,
                   'unrar': unrar_targets, 'cpio': cpio_targets, 'zip': zip_targets, 'scp': scp_targets}

def _sort_out(args, pos):
    opts, p = parse_opts(args, 'oTSkt', {'--output', '--temporary-directory', '--buffer-size', '--key', '--field-separator'})
    return [v for o, v in opts if o in ('-o', '--output') and v], [x for x in p]
def _uniq_out(args, pos):
    opts, p = parse_opts(args, 'fsw', {'--skip-fields', '--skip-chars', '--check-chars'})
    return p[1:2], p[:1]
def _yq_out(args, pos):
    inplace = any(a in ('-i', '--inplace') or re.fullmatch(r'-[A-Za-z]*i[A-Za-z]*', a) for a in args)
    return (pos[1:] if inplace else []), (pos[1:] if not inplace else [])
def _awk_out(args, pos):
    inplace = any(a == 'inplace' and k and args[k - 1] in ('-i', '--include') for k, a in enumerate(args)) \
        or '--include=inplace' in args or '-iinplace' in args
    progfile = any(a in ('-f', '--file') or a.startswith('--file=') for a in args)
    p = [a for a in pos if a != 'inplace']
    files = p if progfile else p[1:]
    return (files if inplace else []), (files if not inplace else [])
# Per tool: the short options that TAKE a value, and the letters that mean "write nothing" (to stdout / test /
# list). R2 F3: `gzip -Sl F` is suffix "l" (F compressed to Fl, F deleted), not list; `lz4 -l` is its LEGACY
# compress. A value letter ends the cluster, so its value is never mistaken for a flag.
ZIP_VALS = {'gzip': 'S', 'gunzip': 'S', 'xz': 'SFCMT', 'unxz': 'SFCMT', 'lzma': 'SFCMT', 'unlzma': 'SFCMT',
            'zstd': 'oDTLM', 'unzstd': 'oDTLM', 'lz4': 'B', 'bzip2': '', 'bunzip2': '', 'compress': 'b'}
ZIP_NOWRITE = {'lz4': 'ct', 'bzip2': 'ct', 'bunzip2': 'ct', 'compress': 'c'}   # default: c t l
def _zip_out_for(b):
    def f(args, pos):
        opts, p = parse_opts(args, ZIP_VALS.get(b, ''), {'--suffix', '--output', '--format', '--check', '--threads'})
        nw = ZIP_NOWRITE.get(b, 'ctl')
        names = {o for o, _ in opts}
        outs = [v for o, v in opts if o in ('-o', '--output') and v]
        if any(len(o) == 2 and o[1] in nw for o in names) or names & {'--stdout', '--to-stdout', '--test', '--list'}:
            return outs, p                              # to stdout / test / list: the files are only READ
        return p + outs, []                             # the file is REPLACED by its (de)compressed twin
    return f
def _attr_out(args, pos):
    ops = [a for a in args if not re.fullmatch(r'-[RVf]+', a)]
    return ops[1:], []                                  # chattr MODE FILES… (the mode may look like an option)
def _facl_out(args, pos):
    opts, p = parse_opts(args, 'mxMX', {'--modify', '--remove', '--modify-file', '--remove-file', '--set', '--set-file'})
    return p, []
OUTPUT_WRITERS = {'sort': _sort_out, 'uniq': _uniq_out, 'yq': _yq_out, 'awk': _awk_out, 'gawk': _awk_out,
                  'chattr': _attr_out, 'setfacl': _facl_out}
for _z in ('gzip', 'gunzip', 'bzip2', 'bunzip2', 'xz', 'unxz', 'zstd', 'unzstd', 'lz4', 'lzma', 'unlzma', 'compress'):
    OUTPUT_WRITERS[_z] = _zip_out_for(_z)
# The recursion letter per OUTPUT_WRITER: with it the operands are TREES (R2 C6: `gzip -r hooks` was silent).
RECURSE_LETTER = dict({z: 'r' for z in ZIP_VALS}, chattr='R', setfacl='R')

TDIR_LETTERS = {'cp': 'St', 'mv': 'St', 'ln': 'St', 'install': 'Smogt'}   # short options TAKING a value
def target_dir_opt(b, args):
    """(-t DIR / -tDIR / a cluster with t (`-at DIR`) / --target-directory[=]DIR or a GNU prefix of it (`--target=`),
    the option VALUES consumed — never mistaken for operands). rsync has no -t DIR (its -t = times). B3 review F7."""
    letters = TDIR_LETTERS.get(b)
    if letters is None: return None, set()
    tdir, vals, i = None, set(), 0
    while i < len(args):
        a = args[i]
        if a == '--': break
        if a.startswith('--'):
            name, eq, v = a.partition('=')
            if len(name) >= 3 and '--target-directory'.startswith(name):
                if not eq and i + 1 < len(args): v = args[i + 1]; vals.add(v); i += 1
                tdir = v
            elif name in ('--suffix', '--mode', '--owner', '--group') and not eq and i + 1 < len(args):
                vals.add(args[i + 1]); i += 1
        elif a.startswith('-') and a != '-':
            for k in range(1, len(a)):
                if a[k] in letters:
                    v = a[k + 1:]
                    if not v and i + 1 < len(args): v = args[i + 1]; vals.add(v); i += 1
                    if a[k] == 't': tdir = v
                    break
        i += 1
    return tdir, vals

def note_created(paths, cwd, subst):
    for t in paths:
        try: p = resolve(t, cwd, subst)
        except Unresolvable: continue
        while p and p != '/' and p not in CREATED:
            CREATED.add(p); p = os.path.dirname(p)

def record_links(b, args, pos, cwd, subst):
    """Remember each link `ln` (or `cp -s`) creates, so a LATER use in this command resolves through it (panel B3)."""
    sym = b == 'cp' or any(a in ('-s', '--symbolic') or (re.match(r'-[A-Za-z]*s', a) and not a.startswith('--')) for a in args)
    tdir, tvals = target_dir_opt(b, args)
    srcs = [a for a in pos if a not in tvals and a != tdir]
    if tdir is not None: pairs = [(x, tdir.rstrip('/') + '/' + os.path.basename(x.rstrip('/'))) for x in srcs]
    elif len(srcs) == 1: pairs = [(srcs[0], os.path.basename(srcs[0].rstrip('/')))]
    elif len(srcs) >= 2:
        dest = srcs[-1]
        try: isdir = dest.endswith('/') or (len(srcs) > 2) or os.path.isdir(resolve(dest, cwd, subst))
        except Unresolvable: isdir = False
        pairs = [(x, dest.rstrip('/') + '/' + os.path.basename(x.rstrip('/'))) for x in srcs[:-1]] if isdir else [(srcs[0], dest)]
    else: pairs = []
    for src, link in pairs:
        try: L = resolve(link, cwd, subst)
        except Unresolvable: continue
        try: T = resolve(src, os.path.dirname(L) if sym else cwd, subst)
        except Unresolvable: T = None
        LINKS[L] = T

def copy_targets(b, args, pos, cwd, subst):
    """cp/mv/install/rsync/ln: the destination, plus `dest/basename(src)` for every source when the destination
    is a directory — `cp x-guard.sh ~/.claude/hooks/` writes hooks/x-guard.sh, and only that name can match a
    self-mod glob (2026-09-23, step 3). mv also removes its sources. `tree` = the verb may act on whole trees.
    Returns (mutate targets, tree, read sources) — mv's sources are mutate targets, never reads."""
    tdir, vals = target_dir_opt(b, args)
    srcs = [a for a in pos if a not in vals]
    recursive = b in ('rsync', 'mv') or any(a in ('--recursive', '--archive') or
                    (a.startswith('-') and not a.startswith('--') and any(c in a[1:] for c in 'rRa')) for a in args)
    if b == 'install' and ('-d' in args or '--directory' in args):
        return srcs, False, []
    if tdir is None:
        if len(srcs) < 2: return [], recursive, []
        tdir, srcs = srcs[-1], srcs[:-1]
        isdir = tdir.endswith('/')
        if not isdir:
            # a loop-var destination is judged by its VALUES (B1 review: `for d in ~/.claude/hooks; do cp x "$d"`)
            try: cands = loop_expand(tdir) or [tdir]
            except LoopOverflow: cands = [tdir]
            for c in cands:
                try: isdir = isdir or os.path.isdir(resolve(c, cwd, subst))
                except Unresolvable: pass
        if not isdir: return [tdir] + (srcs if b == 'mv' else []), recursive, ([] if b == 'mv' else srcs)
    tg = [tdir] + [tdir.rstrip('/') + '/' + os.path.basename(s.rstrip('/')) for s in srcs]
    return tg + (srcs if b == 'mv' else []), recursive, ([] if b == 'mv' else srcs)

CWD_TRACK = [None]   # cwd of the NET segment being tiered (net() predates the cwd parameter)
def local_host(h):
    return (not h) or h in ('localhost', '0.0.0.0', '::1') or h.startswith('127.') or h.endswith('.local') or '.' not in h
def net(b, args):
    W = ('POST', 'PUT', 'PATCH', 'DELETE')
    mutating = False
    for i, a in enumerate(args):
        if a in ('-X', '--request') and i + 1 < len(args) and args[i + 1].upper() in W: mutating = True
        elif a.startswith('-X') and len(a) > 2 and a[2:].upper() in W: mutating = True
        elif a.startswith('--request=') and a.split('=', 1)[1].upper() in W: mutating = True
        elif a in ('-d', '-F', '-T', '--json', '--form', '--upload-file', '--post-data', '--post-file', '--body-data', '--body-file') or a.startswith('--data'): mutating = True
        elif a.startswith('--method=') and a.split('=', 1)[1].upper() in W: mutating = True
    if b in ('http', 'https', 'xh') and any(a.upper() in W for a in args[:2]): mutating = True
    # Data operands (step 6): an uploaded FILE is a READ of that file (`-d @~/.ssh/id_rsa` → deny), and data
    # that is not a literal ($VAR, $(…), `…`, @file, <file) makes the write a GUARD — a bypass never lifts it.
    DATA = ('-d', '--data', '--data-binary', '--data-raw', '--data-ascii', '--data-urlencode', '--json',
            '-F', '--form', '--form-string', '--post-data', '--body-data')
    FILEOPT = ('-T', '--upload-file', '--post-file', '--body-file')
    dirty = False
    for i, a in enumerate(args):
        v = None
        if a in DATA or a in FILEOPT:
            v = args[i + 1] if i + 1 < len(args) else ''
        elif a.startswith('--') and '=' in a and a.split('=', 1)[0] in DATA + FILEOPT:
            a, v = a.split('=', 1)
        elif re.fullmatch(r'-[dFT].+', a):
            a, v = a[:2], a[2:]
        if v is None: continue
        f = None
        if a in FILEOPT: f = v
        elif a != '--data-raw' and a != '--form-string':
            m = re.search(r'(?:^|=)[@<](.+)$', v) if a in ('-F', '--form') else re.match(r'@(.+)$', v)
            if m: f = m.group(1)
        if f and f != '-':
            add_target('READ', b, f, CWD_TRACK[0], False); dirty = True
        if MARK in v or '$' in v or '`' in v: dirty = True
    if not mutating: return
    urls = [a for a in args if re.match(r'^[a-z][a-z0-9+.-]*://', a, re.I)]
    if not urls:
        F.append(('ask', f"`{b}` write request with no literal URL — fail closed. {esc()}", 'literal URL')); return
    for u in urls:
        h = urlparse(u).hostname or ''
        if not local_host(h):
            F.append(('ask', f"`{b}` sends a write request to external host {h} ({u}){' with non-literal data (a file, $VAR or $(…))' if dirty else ''}. {esc()}", 'external writes ask', False, not dirty))

def allowed_by_settings():
    try:
        with open(SETTINGS) as fh: rules = json.load(fh).get('permissions', {}).get('allow', []) or []
    except Exception:
        return False
    for r in rules:
        if not (isinstance(r, str) and r.startswith('Bash(') and r.endswith(')')): continue
        pat = r[5:-1].replace(':*', '*')
        if fnmatch.fnmatchcase(CMD, pat) or CMD.startswith(pat + ' '): return True
    return False

# TIME BUDGET (panel B1): a PreToolUse hook that reaches its timeout FAILS OPEN ("doesn't block the tool call",
# hooks.md). Whatever input makes classification slow, python answers ASK itself well before that.
# RAW FLOOR (R3 S-F1/F2): when the command cannot be classified (python's shlex rejects a bash-valid line —
# `# don't` in a comment — or the budget runs out), the deny floor must not depend on classification: at
# TOTAL every ask is silent, so `# don't⏎cat ~/.ssh/id_rsa` read the key. A credential path anywhere in the
# RAW text denies; at TOTAL a host-critical path with a write verb does too. The bash side mirrors this for
# a crash / missing python3 (fw_raw_floor). Over-matching is accepted: it fires only on unclassifiable text.
_CRED_REL = [os.path.relpath(p, HOME) for p in CRED_DIRS + CRED_FILES]
# a credential name as a PATH COMPONENT — after a quote/backslash/`/./` normalisation — so `"$HOME"/.ssh`,
# `$HOME/./.ssh`, a relative `.ssh/x` and `tar -C ~ .ssh` all match (R4 G3); plus the private-key file names.
CRED_RAW = re.compile(r'(?:^|[\s/=@:<>(,])(?:' + '|'.join(re.escape(r) for r in _CRED_REL)
                      + r')(?![\w.-])|\bid_(?:rsa|ed25519|ecdsa|dsa)\b')
HOST_RAW = re.compile(r'(?:^|[\s=:>(,{@-])/(?:etc|usr|bin|sbin|boot|var|opt|root|proc|sys|dev)(?:/|[^\w]|$)')
WRITE_RAW = re.compile(r'(?:^|[\s;&|(`])(?:rm|mv|cp|dd|tee|chmod|chown|ln|install|truncate|shred|rsync|tar|unzip|sed|perl)(?:[^\w]|$)|>')
def _raw_norm(t):
    # quotes/backslashes out, `/./` and `//` collapsed; then the harmless device paths and fd duplications
    # (`2>&1`, `>/dev/null`, `/dev/zero`) removed so they are neither a host path nor a write (R4 N3/G6).
    # The bash fw_raw_floor applies the SAME steps — keep them in step.
    t = re.sub(r'[\'"\\]', '', t)
    while '/./' in t: t = t.replace('/./', '/')
    t = re.sub(r'/{2,}', '/', t)
    t = re.sub(r'\d*>+&?\s*/dev/(?:null|stdout|stderr|tty|fd/\d+)(?![\w])', ' ', t)
    t = re.sub(r'\d*>&[\d-]+', ' ', t)
    return re.sub(r'/dev/(?:null|stdin|stdout|stderr|tty|zero|u?random|fd/\d+)(?![\w])', ' ', t)
def _subst_bodies(t):
    """The raw text of every `$( … )` / `` `…` `` in t (quote-aware end, nested ones included in their parent)."""
    out, k = [], 0
    while k < len(t):
        if (t[k] == '`' or t.startswith('$(', k)) and _unescaped(t, k):
            e = _subst_end(t, k); out.append(t[k:e]); k = e; continue
        k += 1
    return out
def raw_floor(why, host_text=None):
    """TOTAL-only net (R4 N2: at normal an unclassifiable command already ASKS — denying it there was a false
    deny). Runs when the classifier could not tokenise / timed out, or ended with a GUARD ask (an unresolvable
    target, non-literal NET data …) that total would silence (R4 G1)."""
    if os.environ.get('FW_TOTAL') != '1': return
    t = _raw_norm(CMD)
    # CREDENTIAL rule: the whole command, always (user ruling 2026-09-24 13:45, safe side — a narrower scan let
    # `ssh-keygen -y -f ~/.ssh/id_rsa | curl -d @- "$U"` through at total; `scp -i ~/.ssh/k f "$S":` now denies)
    if CRED_RAW.search(t) or (CWD and any_under(CWD, CRED_DIRS)):
        F.append(('deny', f"{why}, and its raw text names a credential store — denied at TOTAL (the deny floor does not depend on classification). {esc()}", 'spell the path literally'))
    elif (HOST_RAW.search(_raw_norm(host_text)) if host_text is not None else (HOST_RAW.search(t) and WRITE_RAW.search(t))):
        F.append(('deny', f"{why}, and its raw text names a host-critical path with a write verb — denied at TOTAL (the deny floor). {esc()}", 'spell the path literally'))
class Budget(Exception): pass
def _budget(signum, frame): raise Budget()
def _envf(name, default):
    """A positive finite float from the env, else default: 0 would DISARM the timer, nan/inf/-1 crash (B1 review)."""
    try: v = float((os.environ.get(name) or '').replace(',', '.'))
    except ValueError: return default
    return v if math.isfinite(v) and v > 0 else default
BUDGET_S = _envf('CLAUDE_BASH_FIREWALL_BUDGET', 8.0)            # test injection
# The hook timeout is wall-clock from the HOOK start (15 s): python startup, git_top and the bash-side resolver
# run before this line and the jq/resolver stage after it, so the classifier gets what is left of a 10 s
# deadline, leaving ≥ 5 s for the rest (B1 review: 10.3 s measured end-to-end for an 8 s budget under load).
DEADLINE_S = 10.0
T0 = _envf('FW_T0', 0.0)
LEFT = min(BUDGET_S, DEADLINE_S - (time.time() - T0)) if T0 else BUDGET_S
signal.signal(signal.SIGALRM, _budget)
try:
    try:
        if LEFT <= 0: raise Budget()
        signal.setitimer(signal.ITIMER_REAL, LEFT)       # armed INSIDE the try: it may fire at once
        analyze(CMD, CWD, 0)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)          # disarmed before ANY handler runs (B1 review)
except Budget:
    raw_floor('the classifier ran out of time')
    F.append(('ask', f"classifying this command took too long (budget {BUDGET_S:g} s, {DEADLINE_S:g} s from the hook start) — fail closed rather than let the hook time out, which would let it run unchecked. {esc()}", 'split the command'))
except ValueError as e:                                     # unbalanced quotes etc.
    raw_floor('the command could not be tokenised')
    F.append(('ask', f"command could not be parsed ({e}) — fail closed. {esc()}", 'fix quoting'))
signal.setitimer(signal.ITIMER_REAL, 0)                     # never fire during the output stage
if not any(f[0] == 'deny' for f in F) and any(f[0] == 'ask' and not is_lift(f) for f in F):
    # R4 G1: `curl -d @$(echo ~/.ssh/x)` / `rm -rf ${X:-/etc}` at TOTAL. The host rule looks only at the tokens
    # the guard findings quote (a whole-command scan denied any long script that merely MENTIONS /dev or /etc).
    # Both rules read only the tokens the guard findings quote PLUS the raw text of every $( )/backtick body — a
    # whole-command scan hard-denied `scp -i ~/.ssh/key f "$S":/tmp/` (R5-1), while substituted targets reach the
    # findings as a placeholder, so `rm -rf $(echo /etc)/x` needs the bodies (R5 S1).
    _gt = ' '.join([q for f in F if f[0] == 'ask' and not is_lift(f) for q in re.findall(r'`([^`]*)`', f[1])] + GUARD_RAW)
    # the $( ) bodies count for the HOST rule only when a guarded target carries a substitution (R6-3: a body that
    # merely READS /etc beside an unrelated guard ask denied); one MARK for all bodies, so all of them then
    raw_floor('a target could not be classified', _gt + (' ' + ' '.join(_subst_bodies(CMD)) if MARK in _gt else ''))

rank = {'deny': 2, 'ask': 1}
F.sort(key=lambda f: -rank[f[0]])
if F:
    d, reason, sug = F[0][:3]
    # the decision line is TAB-separated and read as one line: a NL/TAB in a target must not cut the reason (F16)
    reason, sug = (x.replace('\\', '\\\\').replace('\t', '\\t').replace('\n', '\\n') for x in (reason, sug))
    boundary_only = all(len(f) > 3 and f[3] for f in F)   # every finding is a boundary ask (none is a policy ask / deny)
    if d == 'ask' and boundary_only and allowed_by_settings():
        print('\t'.join(('defer', reason, sug)))            # F4: allow downgrades boundary asks → silent, never deny/policy
    else:
        print('\t'.join((d, reason, sug)))

# Targets go to a SIDE FILE, never stdout: the single decision line is a contract with 180 tests.
_tf = os.environ.get('FW_TGT_FILE', '')
if _tf:
    try:
        with open(_tf, 'w') as _fh:
            # Trailing newline is load-bearing: bash `read` returns non-zero on a final
            # unterminated line, which silently skipped the ONLY target in a one-target command.
            # `#guard` first: some finding no grant may lift (step 6) — the bypass is off for this command.
            _fh.write(('#guard\n' if any(not is_lift(f) for f in F) else '') + ''.join(t + '\n' for t in TARGETS))
    except Exception:
        sys.exit(3)   # the grant decision READS this file: a lost write must not look like "no targets" (F14)
PY
)
RC=$?

# Deferred bypass decision (except-list in play). The rule bypasses this command only if EVERY
# target it touches is inside the rule and outside every except entry — one excepted target is
# enough to keep the gate armed for the whole command, because a single Bash line can touch both
# your code and a vendored tree, and the safe reading of that is "ask".
# An unresolvable target (any non-absolute line; python writes `UNRESOLVABLE`) can never be proven
# safe, so it also keeps the gate armed.
if [[ ( "$FW_BYPASS_PENDING" == "1" || "$FW_EXCEPT_IN_PLAY" == "1" ) && $RC -eq 0 && -n "$TGTF" && -f "$TGTF" ]]; then
  _fw_all_ok=1
  _fw_guard=0
  _fw_paths=(); _fw_cls=()
  while IFS=$'\t' read -r _t _c || [[ -n "$_t" ]]; do
    [[ -z "$_t" ]] && continue
    # python writes `#guard` first when some finding is not liftable (step 6): no grant bypasses this command.
    # Keep looping anyway — the except check below must still see every target.
    if [[ "$_t" == '#guard' ]]; then _fw_guard=1; _fw_all_ok=0; continue; fi
    # Unresolvable (python writes a non-absolute marker): never canonicalised — a relative path would
    # resolve against THIS process's cwd — never an except hit, never granted.
    if [[ "$_t" != /* ]]; then _fw_all_ok=0; continue; fi
    # A target python DENIED (credential, host-critical) is never bypassed, in or out of the rule tree.
    [[ "$_c" == deny ]] && _fw_all_ok=0
    _fw_paths+=("$_t"); _fw_cls+=("$_c")
  done < "$TGTF"
  # ONE batched resolver call for every target (step 6b): the per-target calls cost ~2 jq each and a hook
  # that outruns its timeout FAILS OPEN (hooks.md). The answers are the same functions' answers (parity
  # is pinned in test-bypass-resolve.sh): <G|A> = bypass_applies fw, <X|-> = bypass_except_hit.
  if (( ${#_fw_paths[@]} )); then
    printf '%s\n' "${_fw_paths[@]}" > "$TGTF"
    _fw_ans=()
    if _fw_res=$( ( BYPASS_SESSION_ID="$FW_SID"; source "$SCRIPT_DIR/bypass-resolve.sh" && \
                    bypass_batch fw "$CWD" "$TGTF" ) 2>/dev/null ) && mapfile -t _fw_ans <<< "$_fw_res" \
       && (( ${#_fw_ans[@]} == ${#_fw_paths[@]} )); then
      for _i in "${!_fw_paths[@]}"; do
        # Protection first, grant second. A blacklisted target ASKS — it does not merely lose the grant:
        # withdrawing the grant only restored the firewall's own tiering, and an in-root mutate has none
        # (measured 82cbe622: `sed -i` into a blacklisted api/vendor was silent while Edit prompted). The
        # ask is emitted after the `deny` branch below so a deny is never downgraded to it.
        if [[ "${_fw_ans[_i]:1:1}" == X ]]; then FW_EXCEPT_HIT="${_fw_paths[_i]}"; _fw_all_ok=0; break; fi
        # A `free` target (no finding of its own: /dev/null, /tmp, a plain read) needs no grant, so it cannot
        # withdraw one. A `grant` target's findings are all liftable here (else `#guard` was set), so it
        # needs the rule to cover IT, not just the cwd.
        if [[ "${_fw_ans[_i]:0:1}" != G && "${_fw_cls[_i]}" != free ]]; then _fw_all_ok=0; fi
      done
    else
      # FAIL CLOSED: no answer means no bypass, and with an except list in play a blacklisted target may
      # have been missed — so ask rather than fall through to a possibly silent tiering.
      _fw_all_ok=0
      [[ "$FW_EXCEPT_IN_PLAY" == "1" ]] && FW_RESOLVER_FAILED=1
    fi
  fi
  rm -f "$TGTF" 2>/dev/null || true
  # FAIL-OPEN GUARD: this silent exit is a BYPASS, so it requires a grant. The block is now entered
  # on an except alone (no grant), and without this check that path would silently bypass every
  # command whose targets merely happen to miss the except list — authorised by nothing.
  if [[ "$FW_BYPASS_PENDING" == "1" && $_fw_all_ok -eq 1 ]]; then
    rm -f "$ERRF" 2>/dev/null || true
    exit 0
  fi
fi
[[ -n "$TGTF" ]] && rm -f "$TGTF" 2>/dev/null || true

if [[ $RC -ne 0 ]]; then
  log_obs ERROR ask-bash-firewall "classifier exited $RC: $(head -c 300 "$ERRF" 2>/dev/null | tr '\n' ' ')" 2>/dev/null || true
  rm -f "$ERRF"
  if [[ $FW_TOTAL -eq 1 && "$FW_EXCEPT_IN_PLAY" != "1" ]]; then   # D3 (no except in play, row 26zu): cannot classify at TOTAL = allowed — never past the floor (R3)
    fw_raw_floor "the command classifier failed (exit $RC)"
    log_flag "TOTAL(allowed)" "classifier failed (exit $RC) — allowed unclassified at TOTAL (D3)" "see logs/hooks-errors.log"
    exit 0
  fi
  emit ask "Bash firewall: the command classifier failed (exit $RC) — fail closed. Approve, or run it yourself with \`!\`." "see logs/hooks-errors.log"
fi
rm -f "$ERRF"

IFS=$'\t' read -r DECISION REASON SUGGEST <<< "${RESULT:-}"
# A deny outranks the blacklist ask: both interrupt, but a deny must never be softened to a prompt.
case "${DECISION:-}" in
  deny)  emit deny "Bash firewall: DENIED — $REASON" "$SUGGEST" ;;
esac
# The blacklist ask sits between `deny` and `defer` on purpose. Below `deny` so it cannot downgrade
# one; ABOVE `defer` so a settings.json allow cannot downgrade IT — an allow blesses a verb, and a
# blacklist is a statement about a path, which no verb-level allow was ever meant to overrule.
# ABOVE the TOTAL exit too (row 26zu): an except is a hole at every level.
if [[ -n "$FW_RESOLVER_FAILED" ]]; then
  emit ask "Bash firewall: the bypass resolver failed, so this command's targets could not be checked against the except lists (fail closed). Approve?" \
           "check jq / gates-bypass-rules.json; see logs/hooks-errors.log"
fi
if [[ -n "$FW_EXCEPT_HIT" ]]; then
  emit ask "Bash firewall: \`$FW_EXCEPT_HIT\` is inside a bypass-rule except list (blacklisted), so the rule does not apply here. Approve?" \
           "remove it from except[] in state/gates-bypass-rules.json if this is routine"
fi
# TOTAL: the deny floor and the except asks above are the only decisions kept — nothing below may ask.
if [[ $FW_TOTAL -eq 1 ]]; then
  [[ "${DECISION:-}" == ask ]] && log_flag "TOTAL(allowed)" "$REASON" "would have asked at normal"
  exit 0
fi
case "${DECISION:-}" in
  ask)   emit ask  "Bash firewall: $REASON Approve?" "$SUGGEST" ;;
  defer) log_flag "DEFER(allowed)" "$REASON — settings.json ALLOWS this exact command" "review the allow rule; tighten it if unintended" ;;
esac

# Obfuscation present without a decision → log only (advisory), do not interrupt.
case "$CMD" in
  *'$('*|*'`'*) log_flag "NOTE" "command substitution present (can hide effects)" "informational — no action" ;;
esac

exit 0   # silent: no opinion → settings/auto + the rtk hook decide
