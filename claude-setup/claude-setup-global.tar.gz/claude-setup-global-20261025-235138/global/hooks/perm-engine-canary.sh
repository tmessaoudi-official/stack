#!/usr/bin/env bash
# SessionStart — HOOK-DOWN canary for the permission engine (plan: permission-unification step 4).
# Runs bin/perm-engine-doctor.sh --write-status. Silent unless the state is DOWN (Rule 13: no output on no-ops); when DOWN it
# tells the model and the user at the top of the session, logs an ERROR, and the statusline shows the red PERM-DOWN badge from
# run/perm-engine-status. A registered-but-broken engine FAILS OPEN in the harness (missing file, non-exec, disabled hooks — all
# probed), so without this nothing would say so. Never fatal.
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
H="$(cd "$D/.." && pwd)"
cat >/dev/null 2>&1 || true                          # drain the SessionStart payload
OUT=$(CLAUDE_HOME="$H" bash "$H/bin/perm-engine-doctor.sh" --write-status 2>/dev/null); RC=$?
if [[ $RC -eq 2 ]]; then
  # SLOW (framework-health 2026-10-08): the self-test ran out of time on a busy host. Not a fault, so no repair advice — it used
  # to say "registered but broken" here and the suggested repair changed nothing. Still worth one line: a hook that times out at
  # total fails open, so protected asks can be skipped until the load drops.
  # shellcheck source=/dev/null
  { . "$D/log-helpers.sh" && log_obs WARN perm-engine-canary "$OUT"; } 2>/dev/null || true
  MSG="⚠ PERM-SLOW — the host is too busy for the permission engine's self-test: ${OUT}. No repair needed; the settings.json denies still hold, but protected asks can be skipped while this lasts. It clears when the load drops."
  python3 -c 'import json,sys; m=sys.argv[1]; print(json.dumps({"systemMessage":m,"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":m}}))' "$MSG" 2>/dev/null || true
elif [[ $RC -ne 0 ]]; then
  # shellcheck source=/dev/null
  { . "$D/log-helpers.sh" && log_obs ERROR perm-engine-canary "$OUT"; } 2>/dev/null || true
  MSG="⚠⚠⚠ PERM-DOWN — the permission engine is registered but broken, so permission rules may NOT be enforced. ${OUT}. Fix: ! bash ~/.claude/bin/perm-engine-apply.sh repair  (or rollback: ! bash ~/.claude/bin/perm-engine-apply.sh rollback)"
  python3 -c 'import json,sys; m=sys.argv[1]; print(json.dumps({"systemMessage":m,"hookSpecificOutput":{"hookEventName":"SessionStart","additionalContext":m}}))' "$MSG" 2>/dev/null || true
fi
exit 0
