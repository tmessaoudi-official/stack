#!/usr/bin/env bash
# skill-model-notice.sh — UserPromptSubmit + PreToolUse (matcher Skill). Model policy v2 (decisions D12, D16, D19).
#
# An inline skill cannot choose its own model (its `model:` pin is inert — probes 2026-09-29), so the lever left is to
# STOP and hand the user the command. A skill whose frontmatter says `wants-session-model: strong`, on a session weaker
# than opus, is stopped — there is no carve-out, ask-human, certify and next included (D16):
#   typed /name    UserPromptSubmit -> {"decision":"block","reason":...}. Nothing reaches the model (verified 2026-09-29:
#                  num_turns 0, cost 0, the reason and the original prompt are shown). The first block per skill per
#                  session is a notice; the user sending the SAME command again is the override (D19) and it runs.
#   model-invoked  PreToolUse Skill -> {"hookSpecificOutput":{"permissionDecision":"deny",...}}. The skill does not run;
#                  the model reads the reason and ends its turn with the command (verified 2026-09-29). It is denied
#                  until the USER overrode that skill by typing it: the model retrying the call never overrides, and a
#                  deny counts as the notice, so the user typing the command afterwards runs it at once.
# D23 (ruled 2026-09-29): an ORCHESTRATOR (mega-analysis, loop) is itself `wants-session-model: strong` and lists the stages it
# launches in `covers-skills:`; the user's override at the orchestrator also writes "override STAGE" for each, so the pipeline
# is decided once — otherwise its first strong stage would be denied and the run would stop. The first BLOCK does not cover them.
# A FORKED skill with a `model:` pin (recent, memory-status, sr-health — decision D14) runs on that model whatever this
# session is on: it gets ONE informational systemMessage per skill per session (typed or model-invoked share the marker
# line "forknote NAME"), never a block, on any session model. systemMessage display was probed 2026-09-29: surfaced as an
# informational notice for both UserPromptSubmit and PreToolUse.
# The STOP is silent on opus/fable, on an unknown session model (no false alarm), for a skill without the key, for headless side
# calls, for a session id that is not a plain id, and — on the TYPED path — whenever the per-session state cannot be kept
# safely (a block that could never be overridden would wedge the user, so it fails OPEN). A MODEL-INVOKED call of a strong
# skill is denied instead when the state cannot be kept (the user can still type it; panel B-P2-2). Always exit 0.
#
# The session model comes from bin/session-model.sh: the NEWER of the statusline's live file run/session-model-<sid> (from the payload's
# .model.id) and the transcript's later of the last real assistant message.model / last /model switch, by session id. A brand-new session (no evidence yet) is judged
# by the saved default in settings.json (D27).
# State: one file per session, ~/.claude/state/model-notice/<session id>, lines "notified NAME" / "override NAME". Only the
# typed path writes "override". It lives under state/ ON PURPOSE (D19, "override by the user only"): probed 2026-09-29 by
# piping `printf ... >> <path>` into hooks/ask-bash-firewall.sh — a write under ~/.claude/state/ ASKS, while the same write
# under /tmp or ~/.claude/run/ was silent, so a model-side write by a MODELLED shell writer (redirect, cp, sed -i, tee, touch) now
# prompts the user. An interpreter writing from inside its own code (`python3 - <<EOF`, `python3 -c`) is not modelled and stays silent
# (probed 2026-09-29: the same silence let this session edit two guard hooks) — no marker location can stop it. The Write/Edit tools are NOT
# covered by a single ask rule, Edit(~/.claude/state/model-notice/**): Edit covers every built-in editing tool, Write included (a
# Write(path) rule is rejected at startup — "only Edit(path) rules are" consulted — and was removed 2026-09-30).
# Measured condition of the Bash ask (2026-09-29): asks at firewall level normal with no fw grant — no fw rule, sentinel or env
# switch existed — from cwd ~/.claude, /path/to/your/project/projects/phorj and /path/to/your/project. NOT probed: an fw grant at level `total`, which
# CLAUDE.md says ignores the self-mod tier; such a grant would lift the ask. Files older than 7 days are pruned here (claude-cleanup never touches state/).
# THE USER'S OVERRIDES (bin/model-override.sh, state/model-overrides.json): the stop only tells you the session is weaker than the skill wants;
# it can never change which model an inline skill runs on. Two ways to run the skill anyway, both the USER's decision:
#   * a flag in a TYPED prompt — `/name --as-is` or `/name --model-override <model>` — for that one call. Honoured ONLY on the typed path: on a
#     model-invoked call the flag is ignored, or the model could add it and lift the stop itself. Whole tokens only.
#   * a standing table entry, skills.<name> = "as-is" (or skills."*" for all) — logged, noted once per session per skill ("tabled NAME").
# A malformed table is invalid AS A WHOLE and applies nothing (the stop holds). The flag reaches the skill as plain text, so the message says so.
# Registration (settings.json, user-run): PreToolUse matcher "Skill" and UserPromptSubmit →
#   "$HOME"/.claude/hooks/skill-model-notice.sh
# NOT covered: a subagent invoking a strong skill — its payload's session id is the parent's, and no probe showed an
# agent-id field, so a subagent on opus under a sonnet parent would be judged by the parent's model.
set -uo pipefail
[[ -n "${GS_NO_AUTO_HANDOFF:-}" ]] && exit 0
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SM="${SKILL_NOTICE_SESSION_MODEL:-$HERE/../bin/session-model.sh}"
# Rule 13: log_obs writes to ~/.claude/logs/hooks-errors.log (never fatal). INFO on block / deny / override / prune, WARN when failing
# open; silent on no-ops. MN_LOGH lets a test or a scratch copy of this file point at the real helper.
# shellcheck disable=SC1090
. "${MN_LOGH:-$HERE/log-helpers.sh}" 2>/dev/null || log_obs() { :; }

INPUT=$(cat 2>/dev/null || true)
# EVENT<TAB>NAME<TAB>SID from a typed "/name ..." prompt or a Skill tool call; empty for everything else.
TRIPLE=$(printf '%s' "$INPUT" | jq -r '
  if .hook_event_name == "PreToolUse" and .tool_name == "Skill" then ["pre", (.tool_input.skill // ""), (.session_id // ""), ((.tool_input.args // "") | tostring)]
  elif .hook_event_name == "UserPromptSubmit" then
    ((.prompt // "") | capture("^/(?<n>[A-Za-z0-9][A-Za-z0-9:._-]*)(\\s|$)")?) as $m
    | if $m then ["typed", $m.n, (.session_id // ""), (.prompt // "")] else empty end
  else empty end | @tsv' 2>/dev/null) || exit 0
[[ -n "$TRIPLE" ]] || exit 0
EV="${TRIPLE%%$'\t'*}"; REST="${TRIPLE#*$'\t'}"; NAME="${REST%%$'\t'*}"; REST="${REST#*$'\t'}"; SID="${REST%%$'\t'*}"; ARGS="${REST#*$'\t'}"
ARGS="${ARGS//\\t/ }"; ARGS="${ARGS//\\n/ }"   # @tsv escapes a tab or newline inside the args as \t / \n — they are separators here
# a plain skill directory name only: no ':' (plugin), no '/', no '..', so nothing outside skills/ can be read. A single '.' is allowed:
# Claude Code loads ANY skills/ dir as a skill (milestone panel B-P2-3), so skills/forge.claude-bak.<epoch> must meet the stop too.
[[ "$NAME" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ && "$NAME" != *..* ]] || exit 0
# a plain session id (a UUID in practice): no '.', no '/', so neither the transcript glob nor the marker path can leave its directory
[[ "$SID" =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$ ]] || exit 0

F="$HOME/.claude/skills/$NAME/SKILL.md"
[[ -f "$F" ]] || exit 0
# ONE frontmatter reader for every key this hook cares about: "key=value" lines, top-level keys only, first match wins
FMV=$(awk 'NR==1 && $0=="---"{f=1;next} f && $0=="---"{exit} f && /^[A-Za-z-]+:/ {k=$0; sub(/:.*/,"",k); v=$0; sub(/^[^:]*:[ ]*/,"",v); gsub(/^["\047]|["\047]$/,"",v); if ((k=="wants-session-model"||k=="context"||k=="model"||k=="covers-skills"||k=="strong-when-args") && !(k in seen)) {seen[k]=1; print k "=" v}}' "$F")
fmv() { printf '%s\n' "$FMV" | sed -n "s/^$1=//p" | head -n 1; }
WANT=$(fmv wants-session-model); CTX=$(fmv context); PIN=$(fmv model); COVERS=$(fmv covers-skills); SWA=$(fmv strong-when-args)
FORKNOTE=0; [[ "$CTX" == fork && "$PIN" =~ ^[A-Za-z0-9._-]+$ ]] && FORKNOTE=1
STRONG=0
# D24: `strong-when-args: --flag` narrows the stop to invocations carrying that whole-token flag (a plain /loop is not stopped)
ARGS_OK=1
if [[ -n "$SWA" ]]; then
  ARGS_OK=0
  [[ "$SWA" =~ ^--[A-Za-z0-9-]+$ && " $ARGS " == *" $SWA "* ]] && ARGS_OK=1
fi
if [[ "$WANT" == strong && $ARGS_OK == 1 ]]; then
  CUR=$(CLAUDE_CODE_SESSION_ID="$SID" bash "$SM" 2>/dev/null)
  RANK=$(bash "$SM" --rank "$CUR" 2>/dev/null)
  NEED=$(bash "$SM" --rank opus 2>/dev/null)
  # rank 0 = unknown -> stay silent; at or above opus -> nothing to say
  [[ "$RANK" =~ ^[0-9]+$ && "$NEED" =~ ^[0-9]+$ ]] && (( RANK != 0 && RANK < NEED )) && STRONG=1
fi
(( STRONG || FORKNOTE )) || exit 0

CMD="/$NAME"; [[ -n "$SWA" ]] && CMD="/$NAME $SWA"   # the command that OVERRIDES: a flag-scoped skill is only stopped (and so only overridden) with its flag
# per-session state; refuse a symlinked directory or file, and fail open when it cannot be written
MARK_DIR="$HOME/.claude/state/model-notice"
# a marker that cannot be kept means a block that could never be overridden, so the TYPED branch fails OPEN — and says so. The
# MODEL-INVOKED branch of a strong skill DENIES instead (final delivery panel B-P2-2): failing open there let one filesystem tweak
# (a symlinked marker dir) lift the stop for every session, and a deny wedges nothing — the user can still type the command, which
# fails open. The user's standing table (as-is) is honoured either way.
fo() {
  if (( STRONG )) && [[ "$EV" == pre ]] && [[ "$(bash "${MN_OVERRIDE:-$HERE/../bin/model-override.sh}" get skill "$NAME" 2>/dev/null)" != as-is ]]; then
    log_obs WARN skill-model-notice "cannot keep state for /$NAME (session ${SID:0:8}): $1 — denying the model-invoked call"
    jq -nc --arg r "/$NAME was not run: its model-policy state cannot be kept ($1, under ~/.claude/state/model-notice). End your turn and tell the user to type $CMD themselves (that path still runs it), and that the state needs a look." \
      '{hookSpecificOutput: {hookEventName: "PreToolUse", permissionDecision: "deny", permissionDecisionReason: $r}}' 2>/dev/null
    exit 0
  fi
  log_obs WARN skill-model-notice "cannot keep state for /$NAME (session ${SID:0:8}): $1 — failing open"; exit 0
}
[[ -L "$MARK_DIR" ]] && fo "marker dir is a symlink"
mkdir -p -m 700 "$MARK_DIR" 2>/dev/null || fo "cannot create the marker dir"
[[ -d "$MARK_DIR" && -O "$MARK_DIR" ]] || fo "marker dir is not ours"
# claude-cleanup never touches state/, so trim our own per-session files (older than 7 days) — never fatal
# — except THIS session's own file: after an override the hook stops writing, so its mtime freezes and a week-long pipeline would lose its override
PRUNED=$(find "$MARK_DIR" -maxdepth 1 -type f ! -name "$SID" -mtime +7 -print -delete 2>/dev/null | wc -l)
(( PRUNED > 0 )) && log_obs INFO skill-model-notice "pruned $PRUNED marker file(s) older than 7 days"
MARK="$MARK_DIR/$SID"
[[ -L "$MARK" ]] && fo "marker file is a symlink"
: >> "$MARK" 2>/dev/null || fo "cannot write the marker file"
has()  { if [[ "$1" == *" "* ]]; then grep -qxF -- "$1" "$MARK" 2>/dev/null; else grep -qxF -- "$1 $NAME" "$MARK" 2>/dev/null; fi; }   # "KIND" -> this skill; "KIND NAME" -> that exact line
note() { printf '%s %s\n' "$1" "$NAME" >> "$MARK" 2>/dev/null; }


if (( STRONG )); then
has override && exit 0    # the user already overrode this skill for this session

# D23/D25: an orchestrator's override covers its stages. A one-off flag or a table entry on an ORCHESTRATOR must cover them too, or
# `/loop --pipeline --as-is` would run the orchestrator and then have every stage it invokes as a model call denied. Only the stages are
# written — the orchestrator itself stays un-overridden, so its next plain call is stopped again. Plain skill names only.
cover_stages() {
  local c
  for c in $COVERS; do
    [[ "$c" =~ ^[A-Za-z0-9][A-Za-z0-9_-]*$ ]] && { has "override $c" || printf 'override %s\n' "$c" >> "$MARK" 2>/dev/null; }
  done
  return 0
}
# --- the USER's overrides: a typed flag (this call only), then the standing table --------------------------------------------------------
asis=0; REQ=""
if [[ "$EV" == typed ]]; then
  read -ra TOK <<< "$ARGS"
  for ((i = 0; i < ${#TOK[@]}; i++)); do
    if [[ "${TOK[i]}" == --as-is ]]; then asis=1
    elif [[ "${TOK[i]}" == --model-override && "${TOK[i+1]:-}" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$ ]]; then asis=1; REQ="${TOK[i+1]}"
    fi
  done
fi
if (( asis )); then
  CUR=${CUR:-unknown}
  RQ=""; [[ -n "$REQ" ]] && RQ=$(bash "$SM" --alias "$REQ" 2>/dev/null)
  if [[ -z "$REQ" ]]; then MSG="$CMD is running on $CUR as requested (--as-is)."
  elif [[ "$RQ" == "$CUR" ]]; then MSG="$CMD is running on $CUR as requested (--model-override $REQ)."
  else MSG="$CMD is running on $CUR (--model-override $REQ was noted, but this session is on $CUR — not switching models; an inline skill runs on the session's model)."; fi
  MSG="$MSG The flag is a model-policy switch, not part of the task: ignore it."
  cover_stages
  log_obs INFO skill-model-notice "as-is $NAME on $CUR (flag${REQ:+, requested $REQ}, session ${SID:0:8})"
  # systemMessage is shown to the USER only (hooks docs); the skill still receives the flag as plain text in its arguments, so the MODEL is
  # told via additionalContext — UserPromptSubmit's additionalContext is added to the conversation as a system reminder.
  CTX="The user put a model-policy flag (--as-is or --model-override) in their /$NAME command. A hook already handled it. It is NOT part of the task: ignore it and do the task as if the flag were absent."
  jq -nc --arg m "$MSG" --arg c "$CTX" '{systemMessage: $m, hookSpecificOutput: {hookEventName: "UserPromptSubmit", additionalContext: $c}}' 2>/dev/null
  exit 0
fi
MO="${MN_OVERRIDE:-$HERE/../bin/model-override.sh}"
if [[ "$(bash "$MO" get skill "$NAME" 2>/dev/null)" == as-is ]]; then
  cover_stages
  if ! has tabled; then
    note tabled || fo "cannot record the table use"
    log_obs INFO skill-model-notice "tabled $NAME on $CUR (state/model-overrides.json, session ${SID:0:8})"
    jq -nc --arg m "$CMD is running on $CUR: state/model-overrides.json lets it run without the stop." '{systemMessage: $m}' 2>/dev/null
  fi
  exit 0
fi
# ---------------------------------------------------------------------------------------------------------------------------------------

if [[ "$EV" == typed ]]; then
  if has notified; then     # the user was told (by an earlier block or a model deny) and sent it anyway: run it
    note override || fo "cannot record the override"
    # D23: an orchestrator's override is the one decision for the whole pipeline — cover the stages it launches (plain skill names only)
    for c in $COVERS; do
      [[ "$c" =~ ^[A-Za-z0-9][A-Za-z0-9_-]*$ ]] && printf 'override %s\n' "$c" >> "$MARK" 2>/dev/null
    done
    log_obs INFO skill-model-notice "override $NAME on $CUR (session ${SID:0:8})"
    jq -nc --arg m "$CMD is running on $CUR as you confirmed (it works best on opus or stronger)." '{systemMessage: $m}' 2>/dev/null
    exit 0
  fi
  note notified || fo "cannot record the notice"
  log_obs INFO skill-model-notice "block $NAME on $CUR (session ${SID:0:8})"
  REASON="$CMD works best on opus or stronger and this session is on $CUR. Switch with /model opus, then send $CMD again. To run it on $CUR anyway, send the same command again, or type $CMD --as-is."
  jq -nc --arg r "$REASON" '{decision: "block", reason: $r}' 2>/dev/null
  exit 0
fi

# model-invoked: deny until the user overrode it. A deny counts as the notice, so the user typing the command next runs it.
has notified || note notified || fo "cannot record the notice"
log_obs INFO skill-model-notice "deny $NAME on $CUR (session ${SID:0:8})"
REASON="$CMD works best on opus or stronger and this session is on $CUR, so it was not run. End your turn now with a short message telling the user to run /model opus and then $CMD again, or to type $CMD once themselves, or type $CMD --as-is, to run it on $CUR. Do not ask a question, and do not replace the denied skill with a direct AskUserQuestion or advisor() call."
jq -nc --arg r "$REASON" '{hookSpecificOutput: {hookEventName: "PreToolUse", permissionDecision: "deny", permissionDecisionReason: $r}}' 2>/dev/null
exit 0
fi

# D14: a forked skill runs on its own pinned model whatever this session is on — say so ONCE per session per skill.
# Informational (a systemMessage; verified surfaced on UserPromptSubmit and PreToolUse 2026-09-29), never a block.
has forknote && exit 0
note forknote || fo "cannot record the fork notice"
[[ -n "${CUR:-}" ]] || CUR=$(CLAUDE_CODE_SESSION_ID="$SID" bash "$SM" 2>/dev/null)
SESS=""; [[ -n "$CUR" && "$CUR" != unknown ]] && SESS=" (this session is on $CUR)"
log_obs INFO skill-model-notice "forknote $NAME on $PIN (session ${SID:0:8})"
jq -nc --arg m "/$NAME runs in a forked session on $PIN$SESS." '{systemMessage: $m}' 2>/dev/null
exit 0
