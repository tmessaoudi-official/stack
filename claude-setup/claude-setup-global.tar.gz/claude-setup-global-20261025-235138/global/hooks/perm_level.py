"""Engine fast path for `bypass_level perm <cwd>` (plan: perm-engine-inprocess-level).

WHY: the engine learned the bypass level by spawning `bash -c '. bypass-resolve.sh; bypass_level perm ...'` (bash + jq + realpath + grep). Under load
that spawn was ~half of a slow engine run (2026-10-01: avg 0.93 s of 1.93 s over 181 runs) and its 3 s timeout was a route back to unanswerable prompts.

CONTRACT: level(cwd, home) -> 'none' | 'normal' | 'total', or None = "defer to the authoritative bash resolver".
The port answers ONLY when the rules file is well-formed in every respect the bash predicate checks; anything unusual returns None, so the bash
path keeps its side effects (RULES-INVALID log + marker) and its exact semantics. Whenever this answers it must equal bash:
hooks/tests/test-perm-level.sh is the differential guard. Semantics list: docs/research/perm-level-port-20261001/SEMANTICS.md.
Statusline, firewall and gates-bypass keep using the bash resolver; this is a second implementation (SPEC register)."""
import datetime
import json
import os
import re
import shutil

_EXPIRES = re.compile(r'^[0-9]{4}-[0-9]{2}-[0-9]{2}(T[0-9]{2}:[0-9]{2}:[0-9]{2}Z)?$')
_PATH_KEYS = ('path', 'recursive', 'except')


def _no_const(_name):
    raise ValueError('NaN/Infinity constant')


def _valid(r):
    """jq `vrule`, strictly: True only for a rule the bash predicate certainly accepts (a rule we are unsure of is invalid => defer)."""
    if type(r) is not dict:
        return False
    g = r.get('guards')
    if type(g) is not list or not all(type(x) is str for x in g):
        return False
    if 'expires' in r:
        e = r['expires']
        if type(e) is not str or not _EXPIRES.match(e):
            return False
        try:                                              # a real calendar instant: jq's fromdateiso8601 accepts everything Python accepts here (it also accepts
            datetime.datetime.strptime(e if len(e) > 10 else e + 'T00:00:00Z', '%Y-%m-%dT%H:%M:%SZ')   # a few Python rejects, e.g. Feb 30: those defer)
        except ValueError:
            return False
    if 'level' in r and r['level'] not in ('normal', 'total'):
        return False
    if 'global' in r:
        return r['global'] is True and not any(k in r for k in _PATH_KEYS)
    p = r.get('path')
    if type(p) is not str or not p.startswith('/') or p == '/' or '*' in p:
        return False
    if 'recursive' in r and type(r['recursive']) is not bool:
        return False
    if 'except' in r and not (type(r['except']) is list and all(type(x) is str for x in r['except'])):
        return False
    return True


def level(cwd, home=None):
    try:
        home = home or os.path.expanduser('~')
        if type(cwd) is not str or not cwd or not cwd.startswith('/') or any(ord(ch) < 32 for ch in cwd):
            return None                                   # control chars (a trailing newline: bash `$(realpath)` strips it and resolves a DIFFERENT dir) => defer                                   # empty / relative / odd cwd: let bash decide (realpath -m semantics)
        if shutil.which('jq') is None:
            return None                                   # bash cannot lint without jq and answers none: let it
        path = os.path.join(home, '.claude', 'state', 'gates-bypass-rules.json')
        if not os.path.isfile(path):
            return 'none'
        with open(path, 'rb') as f:
            raw = f.read()
        if raw.startswith(b'\xef\xbb\xbf'):
            return None
        if re.search(rb'\\u[dD][89a-fA-F]', raw) or raw.count(b'[') + raw.count(b'{') > 5000:
            return None                                   # surrogate escapes (jq 1.8 rejects lone high ones) and absurd nesting (jq depth limit 10000): bash invalidates, Python would not
        data = json.loads(raw.decode('utf-8'), parse_constant=_no_const)
        if type(data) is not dict or type(data.get('rules')) is not list:
            return None
        rules = data['rules']
        if not all(_valid(r) for r in rules):
            return None                                   # one bad rule invalidates the WHOLE file in bash (+ a log side effect): defer
        groups = {}
        for r in rules:
            groups.setdefault(None if r.get('global') is True else r['path'], []).append(r)
        for rs in groups.values():
            if len(rs) > 1:
                allg = [x for r in rs for x in r['guards']]
                if len(allg) != len(set(allg)):
                    return None                           # same path declared twice for one guard: lint conflict => invalid file
        c = os.path.realpath(cwd, strict=True)               # a nonexistent / looping / unreadable cwd raises OSError => defer (bash `realpath -m` answers none or resolves lexically)
        today = datetime.date.today().isoformat()
        now = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        for r in rules:                                   # row 26zu: an except is a hole matched on the cwd and filled only by a deeper rule of ANY family -
            if r.get('except') and r.get('global') is not True and (c == r['path'] or (r.get('recursive') is True and c.startswith(r['path'] + '/'))):
                return None                               # that (and its globs) stays in ONE place: bash decides whenever a covering rule carries an except
        best = None
        for r in rules:
            if 'perm' not in r['guards']:
                continue
            if 'expires' in r:
                e = r['expires']
                if not (e >= today if len(e) == 10 else e > now):
                    continue
            if r.get('global') is True:
                plen = 0
            else:
                p = r['path']
                if not (c == p or (r.get('recursive') is True and c.startswith(p + '/'))):
                    continue
                plen = len(p)
            if best is None or plen >= best[0]:
                best = (plen, r)
        if best is None:
            return 'none'
        return 'total' if best[1].get('level') == 'total' else 'normal'
    except Exception:
        return None
