#!/usr/bin/env bash
# Stop hook: "don't stop" loop, opt-in. When keep-going is armed here (resolver family kg: /keep-going on, any of the six scopes) and nothing
# is running in the background, block the stop (exit 2) so Claude does the next thing instead of idling.
#   autonomous mode (ah bypassed): the reason tells Claude to apply /next's reconcile logic inline and act.
#   spec mode: the reason tells Claude to ask via AskUserQuestion (header KEEPGOING-Q): Do NEXT / Stop.
# Allows the stop when: toggle absent; a running shell, subagent or MCP task in background_tasks (never a monitor, row 26zl) / non-empty session_crons
# (their completion re-invokes the session); the last user message asks to stop (typed at the prompt OR queued while Claude works:
# stop/pause/halt anywhere, wait/enough as the first word, unless the same message says don't stop / non-stop / keep going); a stop
# stands keep-going down for that prompt only, nothing is disarmed, and the next user message resumes the loop (plan keep-going-stop);
# the last assistant message ENDS with KEEPGOING-DONE (the plan's verdict is done) or KEEPGOING-NEEDS-USER (the rest waits on the user; row 26s) as its
# final word - a mention mid-message does not count (panel 26s B-P3-1); the user answered Stop to the hook's own question;
# the cap of consecutive unattended blocks is reached AND the user was asked about it twice without answering (the count restarts on a new user message and on each
# answered KEEPGOING-Q). stop_hook_active is IGNORED on purpose (it is true on every forced continuation, so honouring it would cap the loop at one); the counter is the cap.
# The cap is a parameter (user ruling 2026-10-04): env KEEPGOING_CAP, else the session sentinel's content "cap=N", else the nearest
# ~/.claude/projects/<slug>/state/keep-going-cap up from cwd, else ~/.claude/state/keep-going-cap, else 25. N is 1-999999, or "unlimited" / 0 for no cap (no cap
# question; a stop word, a closing marker, the no-progress breaker, Esc or KEEPGOING_OFF=1 end it, each but the last two after the KG-STOP question). At the cap, in BOTH modes, the hook blocks and tells Claude to ask via AskUserQuestion (KEEPGOING-Q): continue N
# more / continue unlimited for this prompt / stop. An answer restarts the count; "unlimited" in the ANSWER lifts the cap for the prompt. Asked twice without an
# answer (a stuck session) the hook asks the KG-STOP question, then lets the stop through. The stop word is checked before any of this, so it wins under every cap.
# KEEPGOING_NOPROGRESS forced segments in a row (default 3; 0 = off) with no tool call let the stop through: a loop that stopped doing
# work (no-progress breaker, framework-health 8.3; real runs of 8 and 9 idle forced turns). Autonomous-only by construction.
# Every allowed stop above except the toggle-absent one ASKS FIRST (row 26u, user 2026-10-14: "if keep going is active in any mode i need to know when it stops"), except
# busy (the job's notification wakes the session), a FRESH Stop answer (KEEPGOING-Q or KG-STOP: the user just answered) and headless: _let_stop
# blocks once with a KEEP-GOING STOP-ASK reason (PushNotification, then an AskUserQuestion with header KG-STOP as the only question in its call).
# It lets the stop through without asking when KEEPGOING_STOP_ASK=0, when there is no readable transcript, when the FILTER fails on a readable one
# (filter-error), or after 2 stop-ask blocks with no well-formed KG-STOP question / task notification since (run/keep-going-stopask-<sid>); each of
# those sends a "stopped (<reason>)" notification. Under an unattended window with no_ask at the session cwd (bin/lib/unattended.py no_ask_at, the
# engine's reader; row 26zi) the question would be denied, so _let_stop blocks once with a KEEP-GOING STOP-NOTIFY reason instead (phone push, no
# question), remembers the stop key (run/keep-going-noask-<sid>), and the next stop under that key goes through (stop-noask); the cap ends the run there
# (cap-final) rather than asking KEEPGOING-Q; a turn whose prompt explicitly asked ("ask me", row 26zj: ask_lifted) asks as usual. A headless session (entrypoint sdk*: claude -p, the SDK; nobody can answer; read from the
# transcript tail, else the CLAUDE_CODE_ENTRYPOINT env) skips the WHOLE hook.
# The KG-STOP answer (row 26v) is toolUseResult.answers[<question text>] (the "Q"="A" text only for a one-question call with no quote in it;
# otherwise unreadable -> ask again). It is a STOP unless it is clearly a chase (row 26za, user 2026-10-15: a stop read as a chase forces work against the
# user's words, a chase read as a stop costs one retype): an offered label is a chase only when it is not the first option (the instructed Stop option)
# and its first word is not stop/pause/halt; typed text is a chase only when it holds a continue phrase that is not negated or deferred until the user
# acts ("let me run it, then you continue"), and never when it picks option 1 (_chase_typed, row 26zi). A stop lets
# every later stop through - until a task notification arrives after it.
# Fails open (any internal error -> exit 0). KEEPGOING_OFF=1 disables. Payload fields probed 2026-10-03.
# Every stop past the payload parse leaves ONE line in logs/keep-going-trace.log: the exit reason (not-armed / busy / done-marker / needs-user-marker /
# stop-word / kg-stop-answer / stop-answer-stale / stop-answer-unreadable / no-progress / cap-ask / cap-final / filter-error / blocked-auto / blocked-spec / headless /
# stop-ask / stop-ask-final / stop-answer / stop-notify / stop-noask; an allow reason that asks is traced stop-ask from=<it>), the background-task digest (kind:status) and the counter key (user ruling 2026-10-04: a stop
# let through at 08:38 in twes-in could not be explained, the payload is not saved anywhere). A block in autonomous mode also tells Claude to open
# its next message with "▸ KEEP-GOING continuing (block n/CAP): <action>"; the statusline shows ↻n/CAP while the counter is fresh.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=log-helpers.sh
source "$SCRIPT_DIR/log-helpers.sh" 2>/dev/null || true

DEFAULT_CAP=25
[[ "${KEEPGOING_OFF:-}" == "1" ]] && exit 0

INPUT=$(cat 2>/dev/null || true)
[[ -z "$INPUT" ]] && exit 0
jq -e . >/dev/null 2>&1 <<<"$INPUT" || exit 0

field(){ jq -r "$1" <<<"$INPUT" 2>/dev/null || true; }
SID=$(field '.session_id // empty'); PID=$(field '.prompt_id // empty'); CWD=$(field '.cwd // empty')
[[ -n "$SID" ]] || exit 0

TRACE="$HOME/.claude/logs/keep-going-trace.log"
_trace() {  # $1=reason $2=detail. A log write: never fatal, never changes the decision (kept to ~1000 lines).
  local d; d=$(jq -r '"tasks=[\([(.background_tasks // [])[] | "\(.type // "?"):\(.status // "-")"] | join(","))] crons=\((.session_crons // []) | length)"' <<<"$INPUT" 2>/dev/null)
  if [[ "$(stat -c %s "$TRACE" 2>/dev/null || echo 0)" -gt 400000 ]]; then
    tail -n 1000 "$TRACE" >"$TRACE.tmp" 2>/dev/null && mv -f "$TRACE.tmp" "$TRACE" 2>/dev/null
  fi
  printf '%s | %s | %s | %s | %s\n' "$(date -Iseconds)" "$SID" "$1" "${d:-tasks=[?] crons=?}" "${2:-}" >>"$TRACE" 2>/dev/null || true
}

# Does the user's message ask to stop? (user ruling 2026-10-06, plan keep-going-stop.) stop/pause/halt ANYWHERE, wait/enough as the first
# word; but a message that also says "don't stop" / "non-stop" / "keep going|working" anywhere is a keep-going message, whatever else it
# says: run over 293 real twes-in messages, the plain anywhere rule fired on "Keep going ! don't stop ! unless i stop you !"; with this veto
# 25 fire, all real stops, and none of the 16 vetoed ones was a stop. [[ =~ ]], not printf|grep -q: under pipefail a long message can
# SIGPIPE the printf and the && never fires. Sets STOPW to the deciding word (for the trace).
_answer_value() {  # the last chosen/typed answer in an AskUserQuestion result ("Q"="A"), lowercased; never the question text
  local t re v=""; t=$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]'); re='="([^"]*)"'
  while [[ "$t" =~ $re ]]; do v="${BASH_REMATCH[1]}"; t="${t#*"${BASH_REMATCH[0]}"}"; done
  printf '%s' "$v"
}
_stop_intent() {
  local t re
  STOPW=""
  # Negated phrases become NEG first, up to two words between negation and verb ("don't ever stop"). An explicit list, not [a-z]+n't:
  # "want"/"current" end in -nt and "i want you to stop" must stop.
  t=$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed -E "s/’/'/g; s/(^|[^a-z0-9_])non[- ]?(stop|pause|halt)/\1 NEG /g; s/(^|[^a-z0-9_])(don'?t|doesn'?t|didn'?t|can'?t|cannot|won'?t|shouldn'?t|mustn'?t|do not|does not|not|no|never|without)[[:space:]]+([a-z']+[[:space:]]+){0,2}(stop|pause|halt)([^a-z0-9_]|$)/\1 NEG \5/g")
  [[ "$t" == *' NEG '* ]] && return 1
  re='(^|[^a-z0-9_])keep[[:space:]]+(going|working|implementing|at it)([^a-z0-9_]|$)'; [[ "$t" =~ $re ]] && return 1
  re='(^|[^a-z0-9_])(stop|pause|halt)([^a-z0-9_]|$)'; [[ "$t" =~ $re ]] && { STOPW="${BASH_REMATCH[2]}"; return 0; }
  re='^[^a-z]*((please|ok|okay)[^a-z]+)?(wait|enough)([^a-z]|$)'; [[ "$t" =~ $re ]] && { STOPW="${BASH_REMATCH[3]}"; return 0; }
  return 1
}

RUN="$HOME/.claude/run"
# Armed? The shared resolver, family kg (same six scopes as every gate: global / project / session sentinels, tree / exact /
# global rules; the session file run/keep-going-<sid> is scope 3, unchanged). Subshell: a resolver crash must read as "not armed".
( BYPASS_SESSION_ID="$SID"; source "$SCRIPT_DIR/bypass-resolve.sh" && bypass_applies kg "$CWD" ) 2>/dev/null || { _trace not-armed "cwd=$CWD"; exit 0; }

# The cap: first VALID source wins; an invalid one is skipped (never an accidental unlimited). "unlimited" or 0 = no cap.
_cap_norm() {  # $1 = raw text -> prints a decimal 1-999999, "unlimited", or nothing when invalid
  local v; v=$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//')   # trim the ends only: "5 5" must not become 55
  if [[ "$v" == unlimited ]] || [[ "$v" =~ ^0+$ ]]; then printf 'unlimited'
  elif [[ "$v" =~ ^[0123456789]{1,6}$ ]]; then printf '%s' "$((10#$v))"; fi
}
_cap_first_line() { local l=""; [[ -f "$1" ]] && { read -r l <"$1" 2>/dev/null || true; }; printf '%s' "$l"; }
resolve_cap() {
  local c d l
  c=$(_cap_norm "${KEEPGOING_CAP:-}"); [[ -n "$c" ]] && { printf '%s' "$c"; return; }
  l=$(_cap_first_line "$RUN/keep-going-$SID"); [[ "$l" == cap=* ]] && { c=$(_cap_norm "${l#cap=}"); [[ -n "$c" ]] && { printf '%s' "$c"; return; }; }
  d="${CWD%/}"                                    # nearest ancestor first, like the rules walk: the shell cwd drifts into subdirectories
  while [[ -n "$d" ]]; do
    c=$(_cap_norm "$(_cap_first_line "$HOME/.claude/projects/$(printf '%s' "$d" | tr '/' '-')/state/keep-going-cap")"); [[ -n "$c" ]] && { printf '%s' "$c"; return; }
    d="${d%/*}"
  done
  c=$(_cap_norm "$(_cap_first_line "$HOME/.claude/state/keep-going-cap")"); [[ -n "$c" ]] && { printf '%s' "$c"; return; }
  printf '%s' "$DEFAULT_CAP"
}
CAP=$(resolve_cap 2>/dev/null) || CAP=""; [[ -n "$CAP" ]] || CAP=$DEFAULT_CAP
KGU=0   # set when the last answered KEEPGOING-Q was answered "unlimited"

# Row 26u: the transcript is read BEFORE the first allow exit (busy), so every allowed stop can ask first (_let_stop below).
RES=""; FERR=0; FRC=0
TRANSCRIPT=$(field '.transcript_path // empty')
if [[ -n "$TRANSCRIPT" && -f "$TRANSCRIPT" ]]; then
  # Real user text = a user entry that is a string or holds a text block and no tool_result AND was typed by the human. Many
  # type:user entries are not: background-task notifications (origin.kind "task-notification", a NEW promptId), skill bodies
  # (isMeta + sourceToolUseID, no origin), the compact summary (isCompactSummary), local-command echoes (real transcript 2026-10-03).
  # So the rule is positive: origin.kind or turnOrigin == "human". An old CLI whose entries carry neither falls back to excluding
  # notifications. isMeta and isCompactSummary are excluded in BOTH branches: compact summaries carry turnOrigin "human" (45 real
  # ones, 2026-10-06), so they reset the count after every compaction. Each of those would otherwise reset the cap (a new uuid each).
  # Nor are the plain-string entries the user's `!` runner writes (<bash-input>, <bash-stdout>/<bash-stderr>, turnOrigin "human") or
  # a built-in command's (<command-name>, <local-command-stdout>): they restarted the cap and a "stop" in a command's OUTPUT stood the
  # hook down. The clause is the pw/ac/qg guards' (993bd452); a typed skill (<command-message>) IS a prompt (panel 2026-10-13 A-P3-4).
  # A message typed WHILE Claude works is not a type:user entry at all: it is {type:"attachment", attachment:{type:"queued_command",
  # commandMode:"prompt", origin:{kind:"human"}, humanTurn:true, prompt:"<text>"}}, appended when delivered. Notifications use the same
  # attachment with commandMode "task-notification", most with no origin (1,276 real entries probed 2026-10-06): all fields are checked.
  FILTER='
    # Type-safe throughout (row 26v, panel 26t B2-P2-3): one entry whose field has an unexpected type (a malformed tool call, an error
    # result whose toolUseResult is a STRING) aborted the whole filter, RES came back empty and the stop was forced into work. g() turns
    # an access error into null, s() keeps strings only, blocks yields only the object blocks of an array content.
    def g(f): try f catch null;
    def s(f): (g(f) | strings) // "";
    def ctext: if type=="string" then . else ([(arrays // [])[] | objects | .text? | strings] | join(" ")) end;
    def blocks: (g(.message.content) | arrays // [])[] | objects;
    def queued(m): .type=="attachment" and s(.attachment.type)=="queued_command" and s(.attachment.commandMode)==m;
    def queued_human: queued("prompt") and (s(.attachment.origin.kind)=="human" or g(.attachment.humanTurn)==true);
    . as $a
    | ([$a[] | select(.type=="user" and ((g(.origin.kind) // g(.turnOrigin) // null) != null))] | length > 0) as $hasorigin
    | ([range(0; ($a|length)) as $i | $a[$i] as $e | select(($e | queued_human) or ($e.type=="user"
         and g($e.isMeta) != true and g($e.isCompactSummary) != true
         and (g($e.message.content) as $c | ($c|type)!="string" or ($c|test("^\\s*<(bash-(input|stdout|stderr)|local-command-[a-z]+|command-name)>")|not))
         and (if $hasorigin then (s($e.origin.kind) == "human" or s($e.turnOrigin) == "human")
              else (s($e.origin.kind) != "task-notification") end)
         and ((g($e.message.content)|type)=="string"
              or (([$e | blocks | select(.type=="tool_result")]|length)==0
                  and ([$e | blocks | select(.type=="text")]|length)>0)))) | $i] | last) as $u0
    | (($u0 // -1)) as $start
    | ($a[$start+1:]) as $turn
    | ([ $turn[] | select(.type=="assistant") | blocks
         | select(.type=="tool_use" and .name=="AskUserQuestion" and ((g(.input)|tostring)|contains("KEEPGOING-Q"))) | .id ]) as $kgids
    # Row 26u. The last task notification of the turn: an answer given BEFORE it does not cover the stops after it.
    | ([range(0; ($turn|length)) as $i | $turn[$i] | select((.type=="user" and s(.origin.kind)=="task-notification") or queued("task-notification")) | $i] | last) as $ni
    # The last KG-STOP question (exact header, so a question that merely NAMES it does not count), its offered labels, and its result.
    | ([range(0; ($turn|length)) as $i | $turn[$i] | select(.type=="assistant") | blocks | select(.type=="tool_use" and .name=="AskUserQuestion")
         | . as $tu | [(g($tu.input.questions) | arrays // [])[] | objects] as $qs
         | ([$qs[] | select(s(.header)=="KG-STOP")] | first) as $q | select($q != null)
         | {id: $tu.id, q: s($q.question), qok: (g($q.question)|type=="string"), n: ($qs|length),
            labels: [(g($q.options) | arrays // [])[] | objects | s(.label)], i: $i}] | last) as $sq
    | (if $sq == null then null else ([range(0; ($turn|length)) as $i | $turn[$i] | select(.type=="user") | . as $e | blocks
         | select(.type=="tool_result" and .tool_use_id == $sq.id)
         | {i: $i, err: (g(.is_error) == true), text: (g(.content) | ctext), tur: (g($e.toolUseResult) | objects // null)}] | last) end) as $sa
    # The answer (row 26v, panel 26t A2-P2-1): the CLI writes toolUseResult.answers keyed by the exact question text - read that. The
    # "Q"="A" text split is the fallback only for a one-question call whose question holds no double quote; anything else is unreadable.
    | (if $sa == null then {k: "", v: ""}
       else (if ($sa.tur != null and $sq.qok) then (g($sa.tur.answers[$sq.q]) | strings) else null end) as $sv
         | if $sv != null then {k: "s", v: $sv}
           elif (($sa.err | not) and $sq.n == 1 and $sq.qok and $sq.q != "" and ($sq.q | contains("\"") | not)) then
             (($sa.text | split("\"" + $sq.q + "\"=\"")) as $p | if ($p|length) > 1 then {k: "t", v: ($p[1] | split("\"")[0])} else {k: "u", v: ""} end)
           else {k: "u", v: ""} end end) as $ans
    # An offered label chosen as offered: a stop when it is the FIRST option (the instructed Stop option) or its first word is stop/pause/halt, else a
    # chase (row 26za: "Finish here (Recommended)" chosen read as a chase, panel 26t A3-P3-1). Anything else was typed via Other.
    | (if $ans.k == "" then "" elif $ans.k == "u" then "unreadable"
       elif any($sq.labels[]; . == $ans.v) then (if (($ans.v | ascii_downcase | test("^[^a-z]*(stop|pause|halt)([^a-z]|$)")) or $ans.v == $sq.labels[0]) then "stop" else "chase" end)
       else "typed" end) as $sk
    | ([range(0; ($turn|length)) as $i | $turn[$i] | select(.type=="user") | blocks | select(.type=="tool_result") | .tool_use_id as $t
         | select(any($kgids[]; . == $t)) | $i] | last) as $kai
    | {
        user_uuid: (if $u0==null then "" else s($a[$u0].uuid) end),
        via: (if $u0==null then "" elif $a[$u0].type=="attachment" then "queued" else "user" end),
        user_text: (if $u0==null then "" elif $a[$u0].type=="attachment" then (g($a[$u0].attachment.prompt) // "" | if type=="string" then . else tostring end) else
                      (g($a[$u0].message.content) | if type=="string" then . else ([(arrays // [])[] | objects | select(.type=="text") | .text? | strings] | join("\n")) end) end),
        kg_id: ($kgids | last),
        entry: ([$a[] | g(.entrypoint) | strings] | last // ""),
        ni: ($ni // -1),
        kg_ans_i: ($kai // -1),
        sa_i: (if $sa == null then -1 else $sa.i end),
        sa_id: (if $sa == null then "" else ($sq.id | tostring) end),
        sa_val: $ans.v,
        sa_kind: $sk,
        # The stuck guard key moves to a KG-STOP question only once it has a well-formed result: a malformed call (an error result, no
        # object toolUseResult) repeated by a stuck session must still reach the 2-block bound.
        sq_bound: (if $sq != null and ($sq.i > ($ni // -1)) and $sa != null and ($sa.err | not) and $sa.tur != null then ($sq.id | tostring)
                   elif $ni != null then (s($turn[$ni].uuid) | if . == "" then ("n" + ($ni|tostring)) else . end) else "" end),
        idle: (
          # No-progress breaker (framework-health 8.3): the trailing run of forced segments with NO tool call. A segment starts at the
          # feedback text this guard writes itself (an isMeta user entry; matched on that text, not on the registered command path); a spec-mode
          # or cap-ask segment always carries the KEEPGOING-Q AskUserQuestion, so the breaker is autonomous-only by construction.
          ([range(0; ($turn|length)) | select($turn[.].type=="user" and (g($turn[.].isMeta) == true)
             and ((g($turn[.].message.content) | ctext) | contains("KEEP-GOING (autonomous, block")))]) as $marks
          | [range(0; ($marks|length)) as $k
              | ($turn[($marks[$k]+1):(if $k+1 < ($marks|length) then $marks[$k+1] else ($turn|length) end)]
                 | [.[] | select(.type=="assistant") | blocks | select(.type=="tool_use" or .type=="server_tool_use")] | length)]
          | reverse | reduce .[] as $x ({n: 0, open: true}; if .open and $x == 0 then .n += 1 else .open = false end) | .n),
        kg_last: ([ $turn[] | select(.type=="user") | blocks | select(.type=="tool_result") | .tool_use_id
                    | select(. as $t | any($kgids[]; . == $t)) ] | last),
        results: ([ $turn[] | select(.type=="user") | blocks | select(.type=="tool_result") | {id: .tool_use_id, text: (g(.content) | ctext)} ])
      }'
  # A filter failure on a readable transcript is NOT "no transcript": it is flagged and lets the stop through after the headless check
  # (filter-error below), as the header promises. Non-object lines (a bare number, a string) are dropped before the filter.
  RES=$(tail -n 800 "$TRANSCRIPT" 2>/dev/null | jq -Rc 'fromjson? | objects' 2>/dev/null | jq -s "$FILTER" 2>/dev/null); FRC=$?
  if (( FRC != 0 )) || ! jq -e 'type=="object"' >/dev/null 2>&1 <<<"$RES"; then FERR=1; RES=""; fi
fi
_jr(){ jq -r "$1" <<<"$RES" 2>/dev/null; }
_num(){ local v; v=$(_jr "$1"); [[ "$v" =~ ^-?[0123456789]{1,6}$ ]] && printf '%s' "$v" || printf '%s' -1; }
UUID=""; KGLAST=""; kg=""; ENTRY=""; SQB=""; SA_VAL=""; SA_KIND=""; SAID=""; NI=-1; SAI=-1; KGAI=-1; STALE_STOP=0
if [[ -n "$RES" ]]; then
  UUID=$(_jr '.user_uuid // empty'); KGLAST=$(_jr '.kg_last // empty'); kg=$(_jr '.kg_id // empty')
  ENTRY=$(_jr '.entry // empty'); SQB=$(_jr '.sq_bound // empty'); SA_VAL=$(_jr '.sa_val // empty'); SAID=$(_jr '.sa_id // empty')
  SA_KIND=$(_jr '.sa_kind // empty'); NI=$(_num '.ni'); SAI=$(_num '.sa_i'); KGAI=$(_num '.kg_ans_i')
elif [[ "$FERR" == 1 ]]; then   # the filter failed: read the entrypoint alone (no slurp), so a headless session is still never asked
  ENTRY=$(tail -n 800 "$TRANSCRIPT" 2>/dev/null | jq -Rr 'fromjson? | objects | .entrypoint? | strings' 2>/dev/null | tail -n 1)
fi
[[ -z "$ENTRY" ]] && ENTRY="${CLAUDE_CODE_ENTRYPOINT:-}"   # no entrypoint in the transcript tail: the CLI's own env says (C2-P3-5)
SQK="${UUID:-$PID}/${SQB:-0}"   # the stop key: the last genuine user entry / the last answered KG-STOP question or task notification (stuck guard, row 26zi)
# A headless session (claude -p, the SDK) has nobody to answer and nobody watching: keep-going never forces it (user 2026-10-14; the
# llm-sandbox runs got one blocked-auto each from the recursive ~/.claude rule).
if [[ "$ENTRY" == sdk* ]]; then _trace headless "entry=$ENTRY"; exit 0; fi
_chase_typed() {  # a KG-STOP answer typed via Other is a CHASE only when it holds a continue phrase that is not negated (row 26za)
  local t neg phr later
  phr="(keep[[:space:]]+(going|working|implementing|at[[:space:]]+it)|continue|carry[[:space:]]+on|go[[:space:]]+(on|ahead)|proceed|chase|do[[:space:]]+(it|that|this|both|all|next))"
  # A negation with at most two words between it and the phrase, spaces only ("don't keep going", "no need to continue"); "no, keep going" is not one.
  # The negation words are _stop_intent's (panel round 3 A-P2-1: "you shouldn't continue", "cannot proceed" read as a chase).
  neg="(^|[^a-z0-9_'])(don'?t|doesn'?t|didn'?t|can'?t|cannot|won'?t|shouldn'?t|mustn'?t|do[[:space:]]+not|does[[:space:]]+not|not|never|no|without|no[[:space:]]+longer)[[:space:]]+([a-z']+[[:space:]]+){0,2}${phr}([^a-z0-9_]|$)"
  t=$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed -E "s/’/'/g")
  # Row 26zi (real answer 2026-10-15 16:23Z: "Yes option 1 let me run the commands than you continue !" read as a chase). (A) Picking option 1 is the
  # instructed Stop option, whatever follows. (B) A continue phrase AFTER the user acts first ("let me <verb>" but not "let me know", "wait for/on me",
  # "once/after/when I ...") is a deferral, neutralised like "keep going tomorrow"; "keep going until I say stop" keeps its chase.
  [[ "$t" =~ (^|[^a-z0-9_])((option|choice)[[:space:]]*#?[[:space:]]*(1|one)|(1st|first)[[:space:]]+(option|choice|one))([^a-z0-9_]|$) ]] && return 1
  t=$(printf '%s' "$t" | sed -E 's/(^|[^a-z0-9_])let[[:space:]]+me[[:space:]]+know([^a-z0-9_]|$)/\1 LMK \2/g')
  local defer="(^|[^a-z0-9_])(let[[:space:]]+me|wait[[:space:]]+(for|on)[[:space:]]+me|(once|after|when)[[:space:]]+i([[:space:]]|'[a-z]+))[^.!?]*${phr}([^a-z0-9_]|$)"
  while [[ "$t" =~ $defer ]]; do t="${t/"${BASH_REMATCH[0]}"/ NEGC }"; done
  while [[ "$t" =~ $neg ]]; do t="${t/"${BASH_REMATCH[0]}"/ NEGC }"; done
  later="${phr}[[:space:]]+(tomorrow|later|next[[:space:]]+time|another[[:space:]]+time)([^a-z0-9_]|$)"   # a deferral ("keep going tomorrow") is no chase now
  while [[ "$t" =~ $later ]]; do t="${t/"${BASH_REMATCH[0]}"/ NEGC }"; done
  [[ "$t" =~ (^|[^a-z0-9_])${phr}([^a-z0-9_]|$) ]] && return 0
  [[ "$t" =~ (^|[^a-z0-9_])((don\'?t|do[[:space:]]+not|never)[[:space:]]+stop|non[-[:space:]]?stop)([^a-z0-9_]|$) ]]   # a negated stop asks to continue
}
_push() { command -v notify-send >/dev/null 2>&1 && notify-send "Claude keep-going" "$1" >/dev/null 2>&1 || true; }
_NA=""
_noask() {  # row 26zi: does the unattended window at the session cwd deny AskUserQuestion? bin/lib/unattended.py no_ask_at - the engine's own reader
  # (read_marker + select), so the hook and the engine cannot disagree. Asked once per run, only when the marker exists. Not 0 (no marker, an
  # empty cwd, a crash, a timeout under the hook's 5 s budget) = no window: the question is asked as before, bounded by the stuck guard.
  if [[ -z "$_NA" ]]; then
    _NA=1
    if [[ -n "$CWD" ]] && [[ -e "$HOME/.claude/state/unattended.json" || -L "$HOME/.claude/state/unattended.json" ]]; then
      timeout 2 python3 -I "$SCRIPT_DIR/../bin/lib/unattended.py" no-ask "$CWD" "$SID" >/dev/null 2>&1 && _NA=0   # SID: a turn the user lifted asks (26zj)
    fi
  fi
  [[ "$_NA" == 0 ]]
}
_let_stop() {  # $1 = the allow reason, $2 = trace detail. Row 26u: ask the user before an allowed stop ends the turn (see the header).
  local r="$1" d="${2:-}" f="$RUN/keep-going-stopask-$SID" k ck="" cn="" n=0
  # Every pass that asks nothing still tells the user it stopped (C2-P3-4): one push, never "asking you".
  if [[ "${KEEPGOING_STOP_ASK:-1}" == 0 ]]; then _push "stopped ($r)"; _trace "$r" "$d"; exit 0; fi
  if [[ -z "$RES" ]]; then _push "stopped ($r)"; _trace "$r" "$d no-transcript"; exit 0; fi   # nothing to key on: fail open, never a loop
  # The stuck guard is a run file keyed on structured ids (the last KG-STOP question or task notification), never on feedback text.
  k="$SQK"
  # Row 26zi (user 2026-10-16 00:25, ratified: "skip its stop question when a no_ask window denies it - only the push is sent"): block ONCE so Claude
  # sends the phone push, asking nothing; the key is remembered and the next stop under it goes through (stop-noask, checked before every block).
  if _noask; then
    printf '%s\n' "$k" >"$RUN/keep-going-noask-$SID" 2>/dev/null || true
    _push "stopped ($r): no_ask window, not asking"
    {
      echo "KEEP-GOING STOP-NOTIFY ($r): keep-going is letting this stop through. An unattended window with no_ask covers this directory, so it denies AskUserQuestion: do NOT ask anything."
      echo "1. Send a phone push: load PushNotification with ToolSearch (select:PushNotification) and call it with one line, e.g. 'Claude stopped ($r): <why, and what waits on the user>'. Skip this step if the tool is unavailable."
      echo "2. Then end the turn with one short line and no further tool call. The next stop goes through; a background task reporting back, or the user's next message, starts the loop again."
    } >&2
    log_obs INFO keep-going-guard "stop-notify ($r), no_ask window, sid=$SID" 2>/dev/null || true
    _trace stop-notify "from=$r $d"
    exit 2
  fi
  [[ -f "$f" ]] && { read -r ck cn _ <"$f" 2>/dev/null || true; }
  [[ "$ck" == "$k" && "${cn:-}" =~ ^[0123456789]{1,6}$ ]] && n=$((10#$cn))
  if (( n >= 2 )); then _push "stopped ($r)"; _trace stop-ask-final "from=$r n=$n $d"; exit 0; fi
  printf '%s %s\n' "$k" "$((n + 1))" >"$f" 2>/dev/null || true
  _push "stopping ($r): asking you first"
  {
    echo "KEEP-GOING STOP-ASK ($r): keep-going is letting this stop through, and the user wants to be told every time it stops (row 26u). Before the turn ends:"
    echo "1. Send a phone push: load PushNotification with ToolSearch (select:PushNotification) and call it with one line, e.g. 'Claude stopped ($r): <why>'. Skip this step if the tool is unavailable."
    echo "2. Then ask ONE AskUserQuestion with header KG-STOP as the ONLY question in that call (no double quotes in its question text), saying why it stopped:"
    echo "   options 'Stop here (Recommended)' FIRST and the one next thing worth chasing second (from the plan or bash ~/.claude/bin/project-state.sh | jq .plans.verdict), plus the auto Other."
    echo "   The first option, and any offered label whose first word is stop, pause or halt, reads as a stop: never start the chase option's label with stop, pause or halt."
    echo "3. The hook reads any answer as a stop unless it is the chase option or typed text that asks to continue (keep going, continue, carry on, go ahead, proceed, chase, do it)."
    echo "   A stop answer: end the turn with one short line and no further tool call. A chase answer: do that. Other typed text: do what it says, then end the turn."
  } >&2
  log_obs INFO keep-going-guard "stop-ask ($r), sid=$SID n=$((n + 1))" 2>/dev/null || true
  _trace stop-ask "from=$r n=$((n + 1)) $d"
  exit 2
}
if [[ "$FERR" == 1 ]]; then _let_stop filter-error "rc=$FRC"; fi   # RES is empty there: a "stopped" push and exit 0 (fail open)
# The user answered the stop question with a stop: this stop and every later one goes through - until a task notification arrives after it.
SA_STOP=0
case "$SA_KIND" in
  stop) SA_STOP=1 ;;
  typed) _chase_typed "$SA_VAL" || SA_STOP=1 ;;
esac
if (( SA_STOP )); then
  if (( SAI > NI )); then _trace stop-answer "kind=$SA_KIND answer=${SA_VAL:0:40}"; exit 0; fi
  STALE_STOP=1
fi
# Row 26zi: a STOP-NOTIFY block under this same key already told Claude to send the push and end the turn: this stop goes through, whatever it carries.
if [[ -n "$RES" && -f "$RUN/keep-going-noask-$SID" ]]; then
  nk=""; read -r nk _ <"$RUN/keep-going-noask-$SID" 2>/dev/null || true
  if [[ -n "$nk" && "$nk" == "$SQK" ]]; then _trace stop-noask "key=$SQK"; exit 0; fi
fi

# Something will re-invoke the session by itself: let the stop through. background_tasks holds shells and subagents
# ({id,type:"shell"|"subagent",status:"running",...}); there is no background_subagents key (probed 2026-10-03). It ALSO holds monitors
# ({type:"monitor",status:"running"}): an expired Monitor stayed "running" for hours and its source was gone (row 26zl, user 2026-10-16:
# twes-in 453d8e8a, 66 of 66 armed stops traced busy, keep-going never fired). So an ALLOWLIST: only a running shell, subagent or
# "MCP task" (a background MCP call; type string seen in the trace 2026-10-11), or a cron, will wake the session; a monitor, an unknown
# or a missing type does not (the digest still lists it in the trace).
busy=$(jq -r '([(.background_tasks // [])[] | select(.type == "shell" or .type == "subagent" or .type == "MCP task") | select((.status // "running") == "running")] | length) + ((.session_crons // []) | length)' <<<"$INPUT" 2>/dev/null || echo 0)
[[ "$busy" =~ ^[0123456789]{1,6}$ ]] && busy=$((10#$busy)) || busy=0
if [[ "$busy" -gt 0 ]]; then _trace busy "busy=$busy"; exit 0; fi   # exempt from the stop question (row 26u): the job wakes the session
# The KG-STOP answer could not be read (several questions without structured answers, a quote in the question, an error result): ask again.
[[ "$SA_KIND" == unreadable ]] && _let_stop stop-answer-unreadable "id=$SAID"

# Claude says the work is finished, or that what is left waits on the user (the collector's plans.verdict, row 26s). The marker must be the
# message's LAST word (backticks, ** and a trailing . or ! allowed): a message that only MENTIONS it ("so I will not write KEEPGOING-NEEDS-USER;
# continuing") stood the loop down with work left (panel 26s B-P3-1).
LAST_MSG=$(field '.last_assistant_message // empty')
# The marker may sit in a fence, parentheses, __bold__ or before a ; or an emoji (panel 26t A2-P3-2); a longer word (MARKER2, MARKER-ish, MARKER_) or a
# question after it (MARKER?) does not count (A3-P3-7). Accepted residue: a negated parenthetical "(Not MARKER.)" still reads as the marker (errs toward stopping).
_ends_with() {   # a trailing _ counts only when an italic opened it (panel round 3 A-P3-1: `_MARKER_`); a lone one is another word (A3-P3-7)
  local re='(^|[[:space:](])[`*_]*'"$1"'(__)?[^[:alnum:]?_]*$' it='(^|[[:space:](])[`*]*_'"$1"'_[^[:alnum:]?_]*$'
  [[ "$LAST_MSG" =~ $re || "$LAST_MSG" =~ $it ]]
}
if _ends_with KEEPGOING-DONE; then _let_stop done-marker; fi
if _ends_with KEEPGOING-NEEDS-USER; then
  log_obs INFO keep-going-guard "needs-user marker, sid=$SID" 2>/dev/null || true
  _let_stop needs-user-marker
fi

if [[ -n "$RES" ]]; then
    UTXT=$(jq -r '.user_text // ""' <<<"$RES" 2>/dev/null)
    VIA=$(jq -r '.via // ""' <<<"$RES" 2>/dev/null)
    # A stop stands the hook down for this prompt; nothing is disarmed ("keep going and don't stop" must NOT stand it down).
    if _stop_intent "$UTXT"; then _let_stop stop-word "word=$STOPW via=$VIA"; fi
    if [[ -n "${KGLAST:-}" ]]; then   # the ANSWER (the part after ="), never the question text
      ansl=$(jq -r --arg id "$KGLAST" '[.results[]|select(.id==$id)|.text]|last // empty' <<<"$RES" 2>/dev/null)
      av=$(_answer_value "$ansl"); re='^(continue[[:space:]]+)?unlimited([^a-z]|$)'; [[ "$av" =~ $re ]] && KGU=1   # CHOSE unlimited, not merely named it (A-F8)
    fi
    if [[ -n "$kg" ]]; then
      ansr=$(jq -r --arg id "$kg" '[.results[]|select(.id==$id)|.text]|last // empty' <<<"$RES" 2>/dev/null)
      if _stop_intent "$(_answer_value "$ansr")"; then   # "Stop here", or any stop typed via Other (A-F8)
        (( KGAI > NI )) && { _trace kg-stop-answer "word=$STOPW"; exit 0; }   # the user just answered: nothing more to ask
        _let_stop kg-stop-answer "word=$STOPW stale: a notification came after it"
      fi
    fi
    # No-progress breaker: KEEPGOING_NOPROGRESS forced segments in a row (default 3; 0 = off) with no tool call = a loop that stopped
    # doing work (real runs 2026-10-05/06: 11 and 9 tool-less forced turns ~7 s apart). The stop goes through; nothing is disarmed.
    NOPROG=${KEEPGOING_NOPROGRESS:-3}; [[ "$NOPROG" =~ ^[0123456789]{1,6}$ ]] && NOPROG=$((10#$NOPROG)) || NOPROG=3
    IDLE=$(jq -r '.idle // 0' <<<"$RES" 2>/dev/null); [[ "$IDLE" =~ ^[0123456789]{1,6}$ ]] && IDLE=$((10#$IDLE)) || IDLE=0
    if (( NOPROG > 0 && IDLE >= NOPROG )); then
      log_obs INFO keep-going-guard "no progress in $IDLE forced turns, sid=$SID" 2>/dev/null || true
      _let_stop no-progress "idle=$IDLE limit=$NOPROG"
    fi
fi
[[ "${STALE_STOP:-0}" == 1 ]] && _let_stop stop-answer-stale "a notification came after the Stop answer"

# Counter: "<key> <n>", key = <last genuine user entry uuid, else prompt_id>/<tool_use id of the last answered KEEPGOING-Q, else 0>. A new user message is a new entry; in spec mode
# each approved "Do NEXT" is user input too, but it is a tool_result inside the SAME prompt (same prompt_id), so the id of the last
# answered question is part of the key: an approved cycle starts the count again, only unattended cycles accumulate toward the cap.
# An id, not a count: a count over the sliding tail window is not monotonic.
CF="$RUN/keep-going-count-$SID"
KANS="$KGLAST"; (( SAI > KGAI )) && [[ -n "$SAID" ]] && KANS="$SAID"   # a chase answer to KG-STOP is user input too (row 26u)
KEY="${UUID:-$PID}/${KANS:-0}"   # the last genuine user entry, not prompt_id (a notification starts a new prompt_id)
n=0
cpid=""; cn=""
[[ -f "$CF" ]] && { read -r cpid cn _ <"$CF" 2>/dev/null || true; }
# The user's message can fall out of the tail window in a long run: with no genuine entry to key on, keep counting under the
# stored key instead of starting over (errs toward stopping; widening the tail would cost the hook its ~0.13 s).
[[ -z "${UUID:-}" && -n "$cpid" ]] && KEY="${cpid%/*}/${KANS:-0}"
# Every numeric field here is checked against an explicit digit list, never [0-9]: under a UTF-8 locale that range matches U+0665,
# and a counter holding one broke the cap and the breaker for the rest of the prompt (panel 2026-10-13 B-P3-2; the class acf3ca00 fixed).
[[ "$cpid" == "$KEY" && "${cn:-}" =~ ^[0123456789]{1,6}$ ]] && n=$((10#$cn))
SHOWCAP="$CAP"; [[ "$CAP" == unlimited || "$KGU" == 1 ]] && SHOWCAP='∞'
if [[ "$CAP" != unlimited && "$KGU" != 1 && "$n" -ge "$CAP" ]]; then
  # asked twice, nobody answered: a stuck session must not be forced forever. Under a no_ask window the cap question would be denied, so
  # the cap ends the run at once (cap-final, the notify path; row 26zi, ASSUMED 2026-10-16: a denied KEEPGOING-Q read as answered restarted the count).
  if [[ "$n" -ge $((CAP + 2)) ]] || _noask; then
    log_obs INFO keep-going-guard "cap $CAP reached, unanswered, sid=$SID" 2>/dev/null || true
    _let_stop cap-final "key=$KEY n=$n cap=$CAP"   # asks too (user 2026-10-14), bounded by the stuck guard
  fi
  printf '%s %s %s\n' "$KEY" "$((n + 1))" "$CAP" >"$CF" 2>/dev/null || true
  command -v notify-send >/dev/null 2>&1 && notify-send "Claude keep-going" "cap of $CAP reached, waiting for your answer" >/dev/null 2>&1 || true
  {
    echo "KEEP-GOING cap reached ($CAP consecutive blocks for this prompt): do not stop silently and do not keep going on your own. Ask the user via AskUserQuestion with header KEEPGOING-Q:"
    echo "options 'Continue $CAP more (Recommended)', 'Continue unlimited for this prompt', 'Stop here', plus the auto Other. Put the cap number in the question."
    echo "Then act on the answer. If the collector verdict (bash ~/.claude/bin/project-state.sh | jq .plans.verdict) is done, end your message with KEEPGOING-DONE as its last word; if needs-user, end it with KEEPGOING-NEEDS-USER as its last word."
  } >&2
  log_obs INFO keep-going-guard "cap $CAP reached, asking, sid=$SID n=$((n + 1))" 2>/dev/null || true
  _trace cap-ask "key=$KEY n=$((n + 1)) cap=$CAP"
  exit 2
fi
printf '%s %s %s\n' "$KEY" "$((n + 1))" "$([[ "$KGU" == 1 ]] && echo unlimited || echo "$CAP")" >"$CF" 2>/dev/null || true

_auto=0; ( BYPASS_SESSION_ID="$SID"; source "$SCRIPT_DIR/bypass-resolve.sh" && bypass_applies ah "$CWD" ) 2>/dev/null && _auto=1
if [[ "$_auto" == 1 ]]; then
  {
    echo "KEEP-GOING (autonomous, block $((n + 1))/$SHOWCAP): the keep-going toggle is armed, so the user has said non-stop: do not stop and do not end a step with a closing question (except the KG-STOP question this hook asks when it lets a stop through)."
    echo "Apply /next's reconcile logic inline (do not invoke the /next skill): read the active plan's Status block and the handoff, check git log, pick ONE next action, and do it without asking."
    echo "Steps that are destructive or irreversible still ask first. Decide whether anything remains with the collector, not by eye: bash ~/.claude/bin/project-state.sh | jq .plans.verdict"
    echo "(verdict actionable = do step .next; needs-user = say in one line what waits on the user, then end the message with KEEPGOING-NEEDS-USER as its last word; done = end it with KEEPGOING-DONE as its last word)."
    echo "Start your next message with exactly: ▸ KEEP-GOING continuing (block $((n + 1))/$SHOWCAP): <the one action you picked> — so the user can see that the loop continued."
    echo "If the user asks you to stop or pause (also in a message typed while you work), finish the current step so nothing is left half-applied, say in one line where you stopped, and end the turn: the hook asks the KG-STOP question once, then lets that stop through, and keep-going stays armed for their next message."
  } >&2
else
  {
    echo "KEEP-GOING (spec, block $((n + 1))/$SHOWCAP): do not end the turn silently. Ask via AskUserQuestion with header KEEPGOING-Q:"
    echo "options 'Do NEXT (Recommended)' (name the one next action), 'Stop here', plus the auto Other. Decide whether anything remains with bash ~/.claude/bin/project-state.sh | jq .plans.verdict:"
    echo "done = end the message with KEEPGOING-DONE as its last word; needs-user = say what waits on the user and end with KEEPGOING-NEEDS-USER as its last word."
    echo "If the user asks you to stop or pause (also in a message typed while you work), finish the current step so nothing is left half-applied, say in one line where you stopped, and end the turn: the hook asks the KG-STOP question once, then lets that stop through, and keep-going stays armed for their next message."
  } >&2
fi
log_obs INFO keep-going-guard "blocked stop sid=$SID n=$((n + 1))" 2>/dev/null || true
_trace "blocked-$([[ "$_auto" == 1 ]] && echo auto || echo spec)" "key=$KEY n=$((n + 1)) cwd=$CWD"
exit 2
