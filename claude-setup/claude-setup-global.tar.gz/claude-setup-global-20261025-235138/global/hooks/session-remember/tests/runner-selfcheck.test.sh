#!/usr/bin/env bash
# runner-selfcheck.test.sh - run-tests.sh's unlisted-suite self-check (milestone panel 2026-10-13 C-P2-3, re-round C2-P3-8): every suite
# file in tests/ must have a LIVE run_suite line; a suite named only in a comment is unrun. Runs a COPY of the runner over stub suites.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; RUNNER="$HERE/../run-tests.sh"
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); }
bad() { FAIL=$((FAIL+1)); printf 'FAIL: %s\n' "$*" >&2; }
mkcopy() {  # mkcopy <dir>: the real runner + an exit-0 stub for every suite it lists
  mkdir -p "$1/tests"; cp "$RUNNER" "$1/run-tests.sh"
  grep -oE '^[[:space:]]*run_suite "[^"]+"' "$RUNNER" | sed -E 's/.*"([^"]+)"/\1/' | while read -r n; do
    case "$n" in *.py) printf 'import sys\nsys.exit(0)\n' ;; *) printf 'exit 0\n' ;; esac > "$1/tests/$n"; done
}
C="$T/c0"; mkcopy "$C"
out=$(NO_COLOR=1 bash "$C/run-tests.sh" 2>&1); rc=$?
[[ $rc -eq 0 && "$out" != *"unrun suite"* ]] && ok || bad "S1 every listed suite present -> exit 0, nothing unrun: rc=$rc out=$(tail -3 <<<"$out")"
C="$T/c1"; mkcopy "$C"; printf 'exit 0\n' > "$C/tests/ghost.test.sh"
out=$(NO_COLOR=1 bash "$C/run-tests.sh" 2>&1); rc=$?
[[ $rc -ne 0 && "$out" == *"unrun suite file(s): ghost.test.sh"* ]] && ok || bad "S2 a suite with no run_suite line is reported: rc=$rc out=$(tail -3 <<<"$out")"
C="$T/c2"; mkcopy "$C"; printf 'exit 0\n' > "$C/tests/ghost.test.sh"
python3 - "$C/run-tests.sh" <<'PY'
import sys
p = sys.argv[1]; s = open(p).read(); a = '\n# Every suite file must be run above'
assert s.count(a) == 1; open(p, 'w').write(s.replace(a, '\n# run_suite "ghost.test.sh"     bash    "$TESTS_DIR/ghost.test.sh"' + a))
PY
out=$(NO_COLOR=1 bash "$C/run-tests.sh" 2>&1); rc=$?
[[ $rc -ne 0 && "$out" == *"unrun suite file(s): ghost.test.sh"* ]] && ok || bad "S3 a suite listed only in a COMMENTED-OUT run_suite line is unrun: rc=$rc out=$(tail -3 <<<"$out")"
printf 'runner-selfcheck.test: %d passed, %d failed\n' "$PASS" "$FAIL"
[[ $FAIL -eq 0 ]]
