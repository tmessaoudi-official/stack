#!/usr/bin/env bash
# transcript-path.test.sh — SESSION_STORE must come from the hook payload, not a slug
#
# Run with: bash transcript-path.test.sh
#
# Regression cover for SPEC.md §6-20 (P0): session-remember rebuilt Claude Code's
# transcript directory with `tr '/' '-'`, but Claude Code also collapses '.' to '-'.
# For any project path containing a dot the pipeline read an empty directory and
# captured nothing, silently, for months.
#
# The fix is not a better transform — every hook payload carries `transcript_path`.
# These tests pin that contract:
#   1. payload present  → SESSION_STORE is the payload's directory (dotted path works)
#   2. payload absent   → falls back to the slug derivation AND warns (never silent)
#   3. extract.py honours --transcript-dir
#
# Hermetic: HOME is a temp dir. Nothing touches the live memory store.

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

_PASS=0; _FAIL=0

assert_equals() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n' "$desc"
    printf '    expected: %q\n' "$expected"
    printf '    actual:   %q\n' "$actual"
    (( _FAIL++ )) || true
  fi
}

assert_matches() {
  local desc="$1" pattern="$2" actual="$3"
  if [[ "$actual" =~ $pattern ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n' "$desc"
    printf '    pattern: %s\n' "$pattern"
    printf '    actual:   %q\n' "$actual"
    (( _FAIL++ )) || true
  fi
}

# ─── Isolation ────────────────────────────────────────────────────────────────
# _PROJ_DOT deliberately contains a dot, reproducing the ~/.claude shape that
# triggered the P0. _TR_SLUG is what the pipeline used to compute; _NATIVE_SLUG
# is where Claude Code actually stores the transcript.
_HOME="" _PROJ_BASE="" _PROJ_DOT="" _TR_SLUG="" _NATIVE_SLUG=""
_NATIVE_DIR="" _TR_DIR="" _SID="" _TRANSCRIPT=""

_setup() {
  _HOME=$(mktemp -d /tmp/sr-tp-home-XXXXXX)
  _PROJ_BASE=$(mktemp -d /tmp/sr-tp-proj-XXXXXX)
  _PROJ_DOT="$_PROJ_BASE/.claude"
  mkdir -p "$_PROJ_DOT"

  _TR_SLUG=$(printf '%s' "$_PROJ_DOT" | tr '/' '-')
  _NATIVE_SLUG=$(printf '%s' "$_PROJ_DOT" | tr './' '--')

  _NATIVE_DIR="$_HOME/.claude/projects/$_NATIVE_SLUG"
  _TR_DIR="$_HOME/.claude/projects/$_TR_SLUG"
  mkdir -p "$_NATIVE_DIR" "$_TR_DIR"

  # One real-shaped transcript, in the NATIVE directory only — mirroring the
  # live situation where the tr-form directory exists but holds zero JSONLs.
  _SID="11111111-2222-3333-4444-555555555555"
  _TRANSCRIPT="$_NATIVE_DIR/$_SID.jsonl"
  {
    printf '%s\n' '{"type":"user","cwd":"'"$_PROJ_DOT"'","message":{"role":"user","content":"hello from the native dir"}}'
    printf '%s\n' '{"type":"assistant","message":{"role":"assistant","content":[{"type":"text","text":"ack"}]}}'
  } > "$_TRANSCRIPT"
}

_teardown() { rm -rf "$_HOME" "$_PROJ_BASE" 2>/dev/null || true; }

# Source common.sh in the isolated env and echo one expression. Stderr captured
# separately so the fallback warning can be asserted.
_store_with_payload() {
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ_DOT" SR_TZ=UTC SR_TRANSCRIPT_PATH="$1" \
    bash --norc --noprofile -c "
source '$PIPELINE_DIR/common.sh' >/dev/null 2>&1 || exit 1
printf '%s' \"\$SESSION_STORE\"
" 2>/dev/null
}

_store_no_payload() {
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ_DOT" SR_TZ=UTC \
    bash --norc --noprofile -c "
source '$PIPELINE_DIR/common.sh' >/dev/null 2>&1 || exit 1
printf '%s' \"\$SESSION_STORE\"
" 2>/dev/null
}

_stderr_no_payload() {
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ_DOT" SR_TZ=UTC \
    bash --norc --noprofile -c "
source '$PIPELINE_DIR/common.sh' || exit 1
" 2>&1 >/dev/null
}

# ─── Section 1: payload present → native directory ────────────────────────────
echo "Section 1: SESSION_STORE from payload transcript_path"
_setup

assert_equals "dotted project: SESSION_STORE is the payload's directory" \
  "$_NATIVE_DIR" "$(_store_with_payload "$_TRANSCRIPT")"

# The whole point: the tr-form directory exists but is empty. Resolving to it is
# the bug. This assertion is what went red before the fix.
assert_equals "dotted project: SESSION_STORE is NOT the tr-form directory" \
  "false" "$([[ "$(_store_with_payload "$_TRANSCRIPT")" == "$_TR_DIR" ]] && echo true || echo false)"

assert_equals "resolved directory actually contains the transcript" \
  "1" "$(find "$(_store_with_payload "$_TRANSCRIPT")" -maxdepth 1 -name '*.jsonl' 2>/dev/null | wc -l)"

# ─── Section 2: payload absent → slug fallback, and it must be LOUD ───────────
echo "Section 2: fallback when the payload carries no transcript_path"

assert_equals "no payload: falls back to the slug derivation" \
  "$_TR_DIR" "$(_store_no_payload)"

assert_matches "no payload: fallback is announced, never silent" \
  "transcript_path" "$(_stderr_no_payload)"

# ─── Section 3: extract.py --transcript-dir ──────────────────────────────────
echo "Section 3: extract.py honours --transcript-dir"

_extract_out=$(python3 "$PIPELINE_DIR/extract.py" \
  --transcript-dir "$_NATIVE_DIR" --session "$_SID" --state-dir /dev/null 2>&1)
_extract_rc=$?

assert_equals "extract.py --transcript-dir exits 0" "0" "$_extract_rc"
assert_matches "extract.py reads the transcript in the native dir" \
  "hello from the native dir" "$_extract_out"

# --project-dir must keep working: existing fixtures and the fallback rely on it.
_legacy_out=$(python3 "$PIPELINE_DIR/extract.py" \
  --project-dir "$_PROJ_DOT" --session "$_SID" --state-dir /dev/null 2>&1 || true)
assert_matches "extract.py --project-dir still resolves via the slug (back-compat)" \
  "no session JSONL files" "$_legacy_out"

# ─── Section 4: start.sh wires the payload through before sourcing common.sh ──
# start.sh reads stdin and exports SR_TRANSCRIPT_PATH *before* `source common.sh`.
# If that ordering ever regresses, common.sh takes the fallback branch — which is
# observable on stderr. Without this the new branch is never exercised: no other
# suite feeds start.sh a payload.
echo "Section 4: start.sh payload wiring"

_start_stderr_with_payload=$(printf '{"hook_event_name":"SessionStart","session_id":"%s","transcript_path":"%s","cwd":"%s"}' \
    "$_SID" "$_TRANSCRIPT" "$_PROJ_DOT" \
  | HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ_DOT" SR_TZ=UTC \
    timeout 30 bash "$PIPELINE_DIR/start.sh" 2>&1 >/dev/null)

assert_equals "start.sh with payload: no fallback warning (ordering intact)" \
  "false" \
  "$([[ "$_start_stderr_with_payload" == *"no transcript_path in payload"* ]] && echo true || echo false)"

# And the converse: with no payload it MUST warn. A silent fallback is the failure
# shape that hid §6-20 — this asserts the loudness, not just the resolution.
_start_stderr_no_payload=$(HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ_DOT" SR_TZ=UTC \
  timeout 30 bash "$PIPELINE_DIR/start.sh" 2>&1 >/dev/null </dev/null)

assert_matches "start.sh without payload: warns loudly" \
  "no transcript_path in payload" "$_start_stderr_no_payload"

# start.sh must never hang: the stdin read is bounded. An unbounded `cat` blocks
# forever when a caller holds stdin open, which would stall session startup.
( sleep 6 | timeout 5 bash "$PIPELINE_DIR/start.sh" >/dev/null 2>&1 )
assert_equals "start.sh returns even when stdin is held open (bounded read)" \
  "0" "$?"

_teardown

# ─── Summary ──────────────────────────────────────────────────────────────────
printf '\n  %d passed, %d failed\n' "$_PASS" "$_FAIL"
[[ "$_FAIL" -eq 0 ]]
