#!/usr/bin/env bash
# model-knobs.test.sh — model-assignment audit, decision D6: session-remember's headless `claude -p` calls use a
# model PER CLASS instead of one model for everything.
#   bulk         save.sh summaries + NDC compress (~300 calls/day)  default claude-haiku-5-5
#   consolidate  daily rollup + weekly archive (rewrite history.md / archive.md)  default claude-haiku-5-5 (D12.3 reverted D6's sonnet)
#   handoff      precompact-handoff.sh (the file the next session resumes from)   default claude-haiku-5-5 (D12.3 reverted D6's sonnet; 5.5 since 2026-10-09, after the prompt fix - held on 4.5 2026-10-08)
# Precedence (assumed 2026-09-29, so the documented SR_MODEL keeps its meaning): class knob > SR_MODEL > class default.
# Hermetic: temp HOME, a stub `claude` that records its --model argument, no real LLM call.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SR="$(cd "$HERE/.." && pwd)"; HOOKS="$(cd "$SR/.." && pwd)"
PASS=0; FAIL=0
ok()  { PASS=$((PASS+1)); printf '\033[0;32m✓\033[0m %s\n' "$1"; }
bad() { FAIL=$((FAIL+1)); printf '\033[0;31m✗\033[0m %s\n  → %s\n' "$1" "$2"; }
T=$(mktemp -d)
SAVE_MO="$HOOKS/../bin/model-override.sh"   # K21 renames the REAL helper for a moment — the exit trap puts it back even if the run dies in between
trap '[[ -f "$SAVE_MO.k21" ]] && mv -f "$SAVE_MO.k21" "$SAVE_MO"; rm -rf "$T"' EXIT
mkdir -p "$T/home/.claude/llm-sandbox" "$T/home/.claude/logs" "$T/home/.claude/run" "$T/bin" "$T/proj"
printf '%s\n' '#!/usr/bin/env bash' 'while [ $# -gt 0 ]; do [ "$1" = "--model" ] && echo "$2" >> "$REC"; shift; done' 'printf "%s\n" "{\"result\": \"OK\"}"' > "$T/bin/claude"
printf '%s\n' '#!/usr/bin/env bash' 'exit 0' > "$T/bin/sleep"; chmod +x "$T/bin/claude" "$T/bin/sleep"
printf 'p\n' > "$T/prompt.txt"

# call CLASS [ENV=VAL ...] -> the model the stub received from sr_call_haiku
call() {
  local class="$1"; shift; rm -f "$T/rec"
  env -u SR_MODEL -u SR_MODEL_BULK -u SR_MODEL_CONSOLIDATE -u SR_MODEL_HANDOFF HOME="$T/home" CLAUDE_PROJECT_DIR="$T/proj" REC="$T/rec" PATH="$T/bin:$PATH" "$@" \
    bash -c 'source "'"${SR_UT:-$SR}"'/common.sh" >/dev/null 2>&1; sr_call_haiku "'"$T"'/prompt.txt" RES '"$class" >/dev/null 2>&1
  cat "$T/rec" 2>/dev/null | tail -1
}
# handoff [ENV=VAL ...] -> the model the stub received from precompact-handoff.sh
handoff() {
  rm -f "$T/rec"; local tr="$T/tr.jsonl"
  printf '{"type":"user","message":{"content":"hello world"}}\n{"type":"assistant","message":{"content":"hi there"}}\n' > "$tr"
  printf '{"transcript_path":"%s","cwd":"%s"}' "$tr" "$T/proj" \
    | env -u SR_MODEL -u SR_MODEL_BULK -u SR_MODEL_CONSOLIDATE -u SR_MODEL_HANDOFF HOME="$T/home" REC="$T/rec" PATH="$T/bin:$PATH" "$@" bash "${HOOKS_UT:-$HOOKS}/precompact-handoff.sh" >/dev/null 2>&1
  cat "$T/rec" 2>/dev/null | tail -1
}
eq() { [[ "$3" == "$2" ]] && ok "$1" || bad "$1" "want '$2' got '$3'"; }

echo "=== model-knobs.test.sh ==="
eq "K1: bulk default is haiku"                      claude-haiku-5-5  "$(call bulk)"
eq "K2: no class argument means bulk"               claude-haiku-5-5  "$(call '')"
eq "K3: consolidate default is haiku (policy v2, D12.3)" claude-haiku-5-5 "$(call consolidate)"
eq "K4: SR_MODEL alone still overrides bulk"        my-model          "$(call bulk SR_MODEL=my-model)"
eq "K5: SR_MODEL alone still overrides consolidate" my-model          "$(call consolidate SR_MODEL=my-model)"
eq "K6: class knob beats SR_MODEL (consolidate)"    cons-model        "$(call consolidate SR_MODEL=my-model SR_MODEL_CONSOLIDATE=cons-model)"
eq "K7: a consolidate knob does not touch bulk"     my-model          "$(call bulk SR_MODEL=my-model SR_MODEL_CONSOLIDATE=cons-model)"
eq "K8: bulk knob beats the default"                bulk-model        "$(call bulk SR_MODEL_BULK=bulk-model)"
eq "K9: handoff default is haiku (policy v2, D12.3)"     claude-haiku-5-5  "$(handoff)"
eq "K10: SR_MODEL alone overrides the handoff"      my-model          "$(handoff SR_MODEL=my-model)"
eq "K11: handoff knob beats SR_MODEL"               hand-model        "$(handoff SR_MODEL=my-model SR_MODEL_HANDOFF=hand-model)"

# which class each caller passes (text assertions: the callers run only against real transcripts/state)
n=$(grep -c 'sr_call_haiku "\$CONS_PROMPT" CONS_RESULT consolidate' "$SR/consolidate.sh"); eq "K12: the daily rollup call passes the consolidate class" 1 "$n"
n=$(grep -c 'sr_call_haiku "\$ARCH_PROMPT" ARCH_RESULT consolidate' "$SR/consolidate.sh"); eq "K13: the weekly archive call passes the consolidate class" 1 "$n"
n=$(grep -hE 'sr_call_haiku "\$(NDC_PROMPT|PROMPT_FILE)"' "$SR/consolidate.sh" "$SR/save.sh" | grep -c 'consolidate'); eq "K14: NDC and the save summary stay on the bulk class" 0 "$n"
n=$(grep -c 'sr_call_haiku' "$SR/consolidate.sh" "$SR/save.sh" | awk -F: '{s+=$2} END{print s}'); eq "K15: exactly 5 sr_call_haiku call sites exist (a new one must be classified)" 5 "$n"

# K16-K18: the failure text names the knob that is actually read, and the volume claim is a measurement, not a guess
n=$(grep -c 'check SR_MODEL_BULK: ${SR_MODEL_BULK:-claude-haiku-5-5}' "$SR/save.sh"); eq "K16: the save.sh failure text names SR_MODEL_BULK (the knob it really reads)" 1 "$n"
n=$(grep -cE 'check SR_MODEL: ' "$SR/save.sh"); eq "K16b: no failure text still names the bare SR_MODEL as the thing to check" 0 "$n"
n=$(grep -c '~300' "$SR/common.sh" "$SR/../../refs/SESSION-REMEMBER.md" | awk -F: '{s+=$2} END{print s}'); eq "K17: the unmeasured '~300/day' volume claim is gone from common.sh and refs/SESSION-REMEMBER.md" 0 "$n"
n=$(grep -c 'measured 2026-09-25..29' "$SR/common.sh" "$SR/../../refs/SESSION-REMEMBER.md" | awk -F: '{s+=$2} END{print s}'); eq "K18: both places state the measured range and its dates" 2 "$n"

# K12-K19: the user's override TABLE (state/model-overrides.json, hooks section) sits between the class knob and SR_MODEL:
#   env class knob > table > SR_MODEL > default. An invalid table applies nothing (strict, whole file).
TBL="$T/home/.claude/state/model-overrides.json"; mkdir -p "$(dirname "$TBL")"
tbl() { printf '%s\n' "$1" > "$TBL"; }
tbl '{"version":1,"hooks":{"session-remember.bulk":"tbl-bulk","session-remember.consolidate":"tbl-cons","precompact-handoff":"tbl-hand"}}'
eq "K12: table beats the default (bulk)"               tbl-bulk   "$(call bulk)"
eq "K13: table beats SR_MODEL (bulk)"                  tbl-bulk   "$(call bulk SR_MODEL=my-model)"
eq "K14: the env class knob beats the table (bulk)"    bulk-model "$(call bulk SR_MODEL_BULK=bulk-model)"
eq "K15: consolidate reads its OWN table entry"        tbl-cons   "$(call consolidate SR_MODEL=my-model)"
eq "K16: the handoff reads its table entry"            tbl-hand   "$(handoff SR_MODEL=my-model)"
eq "K17: the env handoff knob beats the table"         hand-model "$(handoff SR_MODEL_HANDOFF=hand-model)"
tbl '{"version":1,"hooks":{"session-remember.bulk":"tbl bulk"}}'
eq "K18: an INVALID table applies nothing (bulk -> default)"   claude-haiku-5-5 "$(call bulk)"
eq "K18b: ... nor for the handoff"                     claude-haiku-5-5 "$(handoff)"
tbl '{"version":1,"hooks":{"session-remember.bulk":"tbl-bulk"}}'
eq "K19: a bulk entry does not touch consolidate"      claude-haiku-5-5 "$(call consolidate)"
rm -f "$TBL"
# K21: a bundle WITHOUT bin/model-override.sh must still work (under set -e the handoff hook died silently when the helper was missing)
mv "$SAVE_MO" "$SAVE_MO.k21" 2>/dev/null
eq "K21: helper missing -> the handoff still runs on the default" claude-haiku-5-5 "$(handoff)"
eq "K21b: helper missing -> bulk still runs on the default"       claude-haiku-5-5 "$(call bulk)"
mv "$SAVE_MO.k21" "$SAVE_MO" 2>/dev/null
# K22: a hooks/ tree with NO sibling bin/ at all (a partial bundle). The path to the helper must be plain string work: a `cd … && pwd`
# on a missing directory fails inside the assignment and, under set -e, killed the hook (reproduced 2026-09-30).
mkdir -p "$T/tree"; cp -a "$HOOKS" "$T/tree/hooks"; rm -rf "$T/tree/bin"
eq "K22: no bin/ dir -> the handoff still runs on the default" claude-haiku-5-5 "$(HOOKS_UT="$T/tree/hooks" handoff)"
eq "K22b: no bin/ dir -> bulk still runs on the default"       claude-haiku-5-5 "$(SR_UT="$T/tree/hooks/session-remember" call bulk)"
eq "K20: no table -> unchanged default"                claude-haiku-5-5 "$(call bulk)"

echo ""; echo "$PASS passed, $FAIL failed"
[[ $FAIL -eq 0 ]]
