#!/usr/bin/env bash
# consolidate.test.sh — Tests for consolidate.sh
# Run with: bash tests/consolidate.test.sh

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

_PASS=0; _FAIL=0

assert_equals() {
  local desc="$1" expected="$2" actual="$3"
  if [[ "$expected" == "$actual" ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s\n    expected: %q\n    actual:   %q\n' "$desc" "$expected" "$actual"
    (( _FAIL++ )) || true
  fi
}
assert_file_exists() {
  local desc="$1" path="$2"
  if [[ -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — not found: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}
assert_file_not_exists() {
  local desc="$1" path="$2"
  if [[ ! -f "$path" ]]; then printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else printf '  FAIL: %s — unexpected: %s\n' "$desc" "$path"; (( _FAIL++ )) || true; fi
}
assert_file_contains() {
  local desc="$1" path="$2" pattern="$3"
  if [[ -f "$path" ]] && grep -q "$pattern" "$path" 2>/dev/null; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s — pattern %q not in %s\n' "$desc" "$pattern" "$path"
    (( _FAIL++ )) || true
  fi
}
assert_file_empty() {
  local desc="$1" path="$2"
  if [[ -f "$path" && ! -s "$path" ]]; then
    printf '  PASS: %s\n' "$desc"; (( _PASS++ )) || true
  else
    printf '  FAIL: %s — non-empty or missing: %s\n' "$desc" "$path"
    (( _FAIL++ )) || true
  fi
}

_HOME="" _PROJ="" _SLUG="" _SESSION_DIR="" _STATE_DIR="" _FAKE_BIN=""
_SR_TODAY="" _SR_BUFFER="" _SR_HISTORY="" _SR_ARCHIVE=""

_setup() {
  _HOME=$(mktemp -d /tmp/sr-test-home-XXXXXX)
  _PROJ=$(mktemp -d /tmp/sr-test-proj-XXXXXX)
  _SLUG=$(echo "$_PROJ" | tr '/' '-')
  _SESSION_DIR="$_HOME/.claude/projects/$_SLUG/memory/sessions"
  _STATE_DIR="$_SESSION_DIR/.state"
  mkdir -p "$_SESSION_DIR" "$_STATE_DIR"
  # sr_call_haiku does "cd $HOME/.claude/llm-sandbox" — create it in the test HOME
  mkdir -p "$_HOME/.claude/llm-sandbox"
  _SR_TODAY="$_SESSION_DIR/today.md"
  _SR_BUFFER="$_SESSION_DIR/buffer.md"
  _SR_HISTORY="$_SESSION_DIR/history.md"
  _SR_ARCHIVE="$_SESSION_DIR/archive.md"
  _FAKE_BIN=$(mktemp -d /tmp/sr-test-bin-XXXXXX)
}

_teardown() { rm -rf "$_HOME" "$_PROJ" "$_FAKE_BIN" 2>/dev/null || true; }

_make_claude_succeed() {
  cat > "$_FAKE_BIN/claude" << 'CLAUDEEOF'
#!/usr/bin/env bash
printf '%s\n' '{"result": "## Summary\n\nTest content."}'
CLAUDEEOF
  chmod +x "$_FAKE_BIN/claude"
}

_make_claude_fail() {
  printf '#!/usr/bin/env bash\nexit 1\n' > "$_FAKE_BIN/claude"
  chmod +x "$_FAKE_BIN/claude"
}

_run() {
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" SR_TZ=UTC \
    PATH="$_FAKE_BIN:$PATH" \
    bash "$PIPELINE_DIR/consolidate.sh" 2>/dev/null
}

# ── c1: DISABLED sentinel ────────────────────────────────────────────────────
echo "Section 1: DISABLED sentinel"
_setup
_make_claude_succeed
printf 'stale content\n' > "$_SR_BUFFER"
mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/DISABLED"
rc=0; _run || rc=$?
assert_equals "c1: DISABLED → exits 0" "0" "$rc"
assert_file_contains "c1: buffer untouched when DISABLED" "$_SR_BUFFER" "stale content"
_teardown

# ── c2: READONLY sentinel ────────────────────────────────────────────────────
echo "Section 2: READONLY sentinel"
_setup
_make_claude_succeed
printf 'stale content\n' > "$_SR_BUFFER"
mkdir -p "$_HOME/.claude/hooks/session-remember"
touch "$_HOME/.claude/hooks/session-remember/READONLY"
rc=0; _run || rc=$?
assert_equals "c2: READONLY → exits 0" "0" "$rc"
assert_file_contains "c2: buffer preserved when READONLY" "$_SR_BUFFER" "stale content"
_teardown

# ── c3: Empty state ──────────────────────────────────────────────────────────
echo "Section 3: Empty state (no buffer, no today.md)"
_setup
_make_claude_fail
rc=0; _run || rc=$?
assert_equals "c3: empty state → exits 0" "0" "$rc"
assert_file_not_exists "c3: no today.md created" "$_SR_TODAY"
assert_file_not_exists "c3: no history.md created" "$_SR_HISTORY"
_teardown

# ── c4: Buffer flush — success ───────────────────────────────────────────────
echo "Section 4: Buffer flush (Haiku succeeds)"
_setup
printf '## 2020-01-01\n\nOld buffer content.\n' > "$_SR_BUFFER"
_make_claude_succeed
rc=0; _run || rc=$?
assert_equals "c4: buffer flush → exits 0" "0" "$rc"
assert_file_empty "c4: buffer cleared after flush" "$_SR_BUFFER"
assert_file_exists "c4: today.md written" "$_SR_TODAY"
_teardown

# ── c5: Buffer flush — Haiku fails ──────────────────────────────────────────
echo "Section 5: Buffer flush (Haiku fails)"
_setup
printf '## 2020-01-01\n\nBuffer content.\n' > "$_SR_BUFFER"
_make_claude_fail
rc=0; _run || rc=$?
assert_equals "c5: Haiku failure → exits 0" "0" "$rc"
assert_file_contains "c5: buffer preserved on Haiku failure" "$_SR_BUFFER" "Buffer content"
_teardown

# ── c6: Today.md stale → rolled into history.md ─────────────────────────────
echo "Section 6: Today.md rollup (stale date)"
_setup
printf '## 2020-01-01\n\nYesterday work.\n' > "$_SR_TODAY"
_make_claude_succeed
rc=0; _run || rc=$?
assert_equals "c6: stale rollup → exits 0" "0" "$rc"
assert_file_empty "c6: today.md cleared after rollup" "$_SR_TODAY"
assert_file_exists "c6: history.md written" "$_SR_HISTORY"
_teardown

# ── c7: Today.md current → no rollup ────────────────────────────────────────
echo "Section 7: Today.md current (no rollup needed)"
_setup
TODAY=$(TZ=UTC date '+%Y-%m-%d')
printf '## %s\n\nToday work.\n' "$TODAY" > "$_SR_TODAY"
_make_claude_fail
rc=0; _run || rc=$?
assert_equals "c7: current today.md → exits 0" "0" "$rc"
assert_file_contains "c7: today.md untouched" "$_SR_TODAY" "Today work"
assert_file_not_exists "c7: history.md NOT written" "$_SR_HISTORY"
_teardown

# ── c8-c9: History rotation — COMPLETE Mon-Sun weeks only (model policy v2, D15/D17/D18) ──────────────────────────
# The model gets only the rotated days plus the exact heading line per week, and returns only those weekly
# sections; the code appends them and rewrites history from the code-cut keep set. The stub returns FIXED text
# (no prompt parsing), records what it was sent and counts its calls, so these tests judge the code, not the wording.
# Fixture (max=2): 2026-01-05 (Mon) and 01-06 sit in a week that ended before the oldest kept entry (01-13) -> rotated;
# 01-13 and 01-14 are the newest two -> kept.
_entry()     { printf '## %s\n\n%s\n\n' "$1" "$2"; }
_hist_asc()  { { _entry 2026-01-05 ROTATED-A.; _entry 2026-01-06 ROTATED-B.; _entry 2026-01-13 KEPT-C.; _entry 2026-01-14 KEPT-D.; } > "$_SR_HISTORY"; }
_hist_desc() { { _entry 2026-01-14 KEPT-D.; _entry 2026-01-13 KEPT-C.; _entry 2026-01-06 ROTATED-B.; _entry 2026-01-05 ROTATED-A.; } > "$_SR_HISTORY"; }
_arch_dup()  { printf '## Week of 2025-12-22\n\nARCHBODY-UNIQUE.\n\n## Week of 2025-12-22\n\nARCHBODY-UNIQUE.\n' > "$_SR_ARCHIVE"; }  # duplicated on purpose (legacy data)
_stub() {  # $1 = the model's reply text
  printf '%s' "$1" > "$_FAKE_BIN/answer.txt"; rm -f "$_FAKE_BIN/rec.txt" "$_FAKE_BIN/cnt.txt"
  cat > "$_FAKE_BIN/claude" << 'CLAUDEEOF'
#!/usr/bin/env bash
cat > "$STUB_REC"; echo x >> "$STUB_CNT"
jq -Rs '{result: .}' < "$STUB_ANS"
CLAUDEEOF
  chmod +x "$_FAKE_BIN/claude"
}
_rot() {
  HOME="$_HOME" CLAUDE_PROJECT_DIR="$_PROJ" SR_TZ=UTC SR_HISTORY_MAX_ENTRIES=2 \
    STUB_REC="$_FAKE_BIN/rec.txt" STUB_CNT="$_FAKE_BIN/cnt.txt" STUB_ANS="$_FAKE_BIN/answer.txt" \
    PATH="$_FAKE_BIN:$PATH" bash "$PIPELINE_DIR/consolidate.sh" 2>/dev/null
}
_calls() { if [[ -f "$_FAKE_BIN/cnt.txt" ]]; then wc -l < "$_FAKE_BIN/cnt.txt" | tr -d ' '; else echo 0; fi; }
_lines() { grep -cxF -- "$2" "$1" 2>/dev/null || true; }                    # exact-line count (grep -c prints 0 itself)
_has()   { grep -qF -- "$2" "$1" 2>/dev/null && echo yes || echo no; }
_prefix_ok() { [[ "$(head -c "$(wc -c < "$1")" "$2" | md5sum)" == "$(md5sum < "$1")" ]] && echo yes || echo no; }   # $2 starts with all of $1's bytes
GOOD='## Week of 2026-01-05

The week moved the pipeline forward.
'

echo "Section 8: rotation of a complete week (c8)"
_setup; _hist_asc; _arch_dup; cp "$_SR_ARCHIVE" "$_FAKE_BIN/arch.orig"; _stub "$GOOD"
rc=0; _rot || rc=$?
assert_equals "c8: rotation → exits 0" "0" "$rc"
assert_equals "c8: the model was called once" "1" "$(_calls)"
assert_equals "c8: existing archive bytes are an untouched prefix (D15, even the duplicated legacy heading)" "yes" "$(_prefix_ok "$_FAKE_BIN/arch.orig" "$_SR_ARCHIVE")"
assert_equals "c8: the new week heading appears exactly once" "1" "$(_lines "$_SR_ARCHIVE" '## Week of 2026-01-05')"
assert_equals "c8: the new week body was appended" "yes" "$(_has "$_SR_ARCHIVE" 'moved the pipeline forward')"
assert_equals "c8: history keeps the newest two (KEPT-C)" "yes" "$(_has "$_SR_HISTORY" 'KEPT-C.')"
assert_equals "c8: history keeps the newest two (KEPT-D)" "yes" "$(_has "$_SR_HISTORY" 'KEPT-D.')"
assert_equals "c8: rotated day A left history" "no" "$(_has "$_SR_HISTORY" 'ROTATED-A.')"
assert_equals "c8: rotated day B left history" "no" "$(_has "$_SR_HISTORY" 'ROTATED-B.')"
assert_equals "c8: the prompt carries the rotated days" "yes" "$(_has "$_FAKE_BIN/rec.txt" 'ROTATED-A.')"
assert_equals "c8: the prompt states the exact heading to use" "1" "$(_lines "$_FAKE_BIN/rec.txt" '## Week of 2026-01-05')"
assert_equals "c8: the prompt does NOT carry the kept entries" "no" "$(_has "$_FAKE_BIN/rec.txt" 'KEPT-C.')"
assert_equals "c8: the prompt does NOT carry the archive body (no echo, no 130 KB input)" "no" "$(_has "$_FAKE_BIN/rec.txt" 'ARCHBODY-UNIQUE')"
rc=0; _rot || rc=$?
assert_equals "c8: a second run has nothing to rotate and does not call the model" "1" "$(_calls)"
_teardown

echo "Section 9a: a model that echoes the archive (the old contract) is rejected, nothing is duplicated"
_setup; _hist_asc; _arch_dup; cp "$_SR_ARCHIVE" "$_FAKE_BIN/arch.orig"; cp "$_SR_HISTORY" "$_FAKE_BIN/hist.orig"
_stub "=== HISTORY ===
## 2026-01-13

KEPT-C.

## 2026-01-14

KEPT-D.

=== ARCHIVE ===
$(cat "$_SR_ARCHIVE")
$GOOD"
rc=0; _rot || rc=$?
assert_equals "c9a: exits 0" "0" "$rc"
assert_equals "c9a: archive is byte-identical (the echo was not appended)" "yes" "$(cmp -s "$_FAKE_BIN/arch.orig" "$_SR_ARCHIVE" && echo yes || echo no)"
assert_equals "c9a: history is byte-identical (fail closed)" "yes" "$(cmp -s "$_FAKE_BIN/hist.orig" "$_SR_HISTORY" && echo yes || echo no)"
_teardown

echo "Section 9b: the week straddles the kept entries — nothing to rotate, no model call"
_setup
{ _entry 2026-01-12 STRADDLE-A.; _entry 2026-01-13 KEPT-C.; _entry 2026-01-14 KEPT-D.; } > "$_SR_HISTORY"
_arch_dup; cp "$_SR_ARCHIVE" "$_FAKE_BIN/arch.orig"; cp "$_SR_HISTORY" "$_FAKE_BIN/hist.orig"; _stub "$GOOD"
rc=0; _rot || rc=$?
assert_equals "c9b: exits 0" "0" "$rc"
assert_equals "c9b: the model is not called" "0" "$(_calls)"
assert_equals "c9b: history is byte-identical (3 entries stay while the week is incomplete)" "yes" "$(cmp -s "$_FAKE_BIN/hist.orig" "$_SR_HISTORY" && echo yes || echo no)"
assert_equals "c9b: archive is byte-identical" "yes" "$(cmp -s "$_FAKE_BIN/arch.orig" "$_SR_ARCHIVE" && echo yes || echo no)"
_teardown

echo "Section 9c: an answer with no weekly section leaves history and archive untouched (the data-loss path)"
_setup; _hist_asc; _arch_dup; cp "$_SR_ARCHIVE" "$_FAKE_BIN/arch.orig"; cp "$_SR_HISTORY" "$_FAKE_BIN/hist.orig"; _stub "Sorry, I cannot summarise that."
rc=0; _rot || rc=$?
assert_equals "c9c: exits 0" "0" "$rc"
assert_equals "c9c: the model was called" "1" "$(_calls)"
assert_equals "c9c: history is byte-identical (the rotated days are not lost)" "yes" "$(cmp -s "$_FAKE_BIN/hist.orig" "$_SR_HISTORY" && echo yes || echo no)"
assert_equals "c9c: archive is byte-identical" "yes" "$(cmp -s "$_FAKE_BIN/arch.orig" "$_SR_ARCHIVE" && echo yes || echo no)"
_teardown

echo "Section 9d: the week already has a heading in the archive → '(continued)' (D18)"
_setup; _hist_asc; printf '## Week of 2026-01-05\n\nLEGACY-PARTIAL-BODY.\n' > "$_SR_ARCHIVE"; cp "$_SR_ARCHIVE" "$_FAKE_BIN/arch.orig"
_stub '## Week of 2026-01-05 (continued)

The rest of that week.
'
rc=0; _rot || rc=$?
assert_equals "c9d: the prompt asks for the (continued) heading" "1" "$(_lines "$_FAKE_BIN/rec.txt" '## Week of 2026-01-05 (continued)')"
assert_equals "c9d: legacy archive bytes untouched" "yes" "$(_prefix_ok "$_FAKE_BIN/arch.orig" "$_SR_ARCHIVE")"
assert_equals "c9d: the original heading still appears once" "1" "$(_lines "$_SR_ARCHIVE" '## Week of 2026-01-05')"
assert_equals "c9d: the continued heading appears once" "1" "$(_lines "$_SR_ARCHIVE" '## Week of 2026-01-05 (continued)')"
assert_equals "c9d: history was cut" "no" "$(_has "$_SR_HISTORY" 'ROTATED-A.')"
_teardown

echo "Section 9e: an answer whose heading is not the one requested is rejected (fail closed)"
_setup; _hist_asc; printf '## Week of 2026-01-05\n\nLEGACY-PARTIAL-BODY.\n' > "$_SR_ARCHIVE"; cp "$_SR_ARCHIVE" "$_FAKE_BIN/arch.orig"; cp "$_SR_HISTORY" "$_FAKE_BIN/hist.orig"
_stub "$GOOD"   # asks for (continued); the model repeats the plain heading
rc=0; _rot || rc=$?
assert_equals "c9e: archive is byte-identical (no second plain heading)" "yes" "$(cmp -s "$_FAKE_BIN/arch.orig" "$_SR_ARCHIVE" && echo yes || echo no)"
assert_equals "c9e: history is byte-identical" "yes" "$(cmp -s "$_FAKE_BIN/hist.orig" "$_SR_HISTORY" && echo yes || echo no)"
_teardown

echo "Section 9f: history written newest-first (the order some models leave it in) rotates the same way"
_setup; _hist_desc; _arch_dup; cp "$_SR_ARCHIVE" "$_FAKE_BIN/arch.orig"; _stub "$GOOD"
rc=0; _rot || rc=$?
assert_equals "c9f: the new week was appended once" "1" "$(_lines "$_SR_ARCHIVE" '## Week of 2026-01-05')"
assert_equals "c9f: history keeps the two newest" "yes" "$(_has "$_SR_HISTORY" 'KEPT-D.')"
assert_equals "c9f: rotated days left history" "no" "$(_has "$_SR_HISTORY" 'ROTATED-B.')"
_teardown

# ── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo "Results: ${_PASS} passed, ${_FAIL} failed"
(( _FAIL == 0 )) && exit 0 || exit 1
