#!/usr/bin/env bash
# Smoke tests for the session-remember pipeline.
# Tests infrastructure behaviours only — LLM calls are stubbed.
# Run: bash ~/.claude/hooks/session-remember/test-smoke.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PIPELINE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# ── §6-22 residue guard ───────────────────────────────────────────────────────
# The pipeline derives MEMORY_DIR/SESSION_STORE from $HOME (common.sh:66,84). Keep a
# handle on the operator's real store so t16 can prove this suite never writes into it.
SR_REAL_HOME="$HOME"
SR_RESIDUE_GLOB="$SR_REAL_HOME/.claude/projects/-tmp-tmp.*"
# Count via an unquoted glob expansion, not `compgen -G`: compgen exits 1 on no-match, and
# with `set -o pipefail` that makes the whole assignment fail under `set -e` — so the guard
# crashed the suite on exactly the clean system it is meant to certify. Same idiom as
# start.sh:76-77.
_sr_residue_count() {
  local -a _m
  # shellcheck disable=SC2206  # deliberate word-split glob expansion
  _m=( $SR_RESIDUE_GLOB )
  if [[ -e "${_m[0]:-}" ]]; then printf '%s\n' "${#_m[@]}"; else printf '0\n'; fi
}
SR_RESIDUE_BEFORE=$(_sr_residue_count)

# Shadow $HOME into $TMP so every store the pipeline derives lands inside the tree the
# EXIT trap already reclaims. `hooks` and `llm-sandbox` are symlinked back to the real
# tree on purpose: they are READ-ONLY config for these tests (DISABLED/READONLY/blacklist/
# readonly-list at common.sh:32,34,92,108 and the sandbox cwd at :191), and t6 toggles
# DISABLED through $PIPELINE_DIR — an absolute real path — so both views must stay the
# same file or t6 would silently stop testing anything.
mkdir -p "$TMP/home/.claude"
ln -s "$SR_REAL_HOME/.claude/hooks"       "$TMP/home/.claude/hooks"
ln -s "$SR_REAL_HOME/.claude/llm-sandbox" "$TMP/home/.claude/llm-sandbox"
export HOME="$TMP/home"

# ── colours ───────────────────────────────────────────────────────────────────
if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
  G='\033[0;32m' R='\033[0;31m' B='\033[1m' D='\033[0m'
else
  G='' R='' B='' D=''
fi

PASS=0; FAIL=0
declare -a FAILURES=()

ok()   { (( ++PASS )); printf "  ${G}✓${D}  %s\n" "$1"; }
fail() { (( ++FAIL )); printf "  ${R}✗${D}  %s\n" "$1"; FAILURES+=("$1");
         [[ -n "${2:-}" ]] && printf "       ${D}%s${D}\n" "$2"; }

# ── helpers ───────────────────────────────────────────────────────────────────
# Make a minimal JSONL session file with N human + N assistant turns
make_jsonl() {
  local path="$1" turns="${2:-2}"
  mkdir -p "$(dirname "$path")"
  for (( i=1; i<=turns; i++ )); do
    printf '{"type":"user","isMeta":false,"message":{"content":"Human message %d"}}\n' "$i"
    printf '{"type":"assistant","isMeta":false,"message":{"content":"Agent reply %d"}}\n'   "$i"
  done > "$path"
}

# Fake Claude project dir (JSONL lives in <slug>/*.jsonl)
setup_project() {
  local base="$1"
  export CLAUDE_PROJECT_DIR="$base/project"
  local slug
  slug="$(echo "$CLAUDE_PROJECT_DIR" | tr '/' '-')"
  export SESSION_STORE="$HOME/.claude/projects/${slug}"
  mkdir -p "$SESSION_STORE" "$base/project"
}

echo ""
printf "${B}  session-remember — smoke test suite${D}\n"
echo ""

# ═══════════════════════════════════════════════════════════════════════════
printf "${B}  ── extract.py ──${D}\n"
# ═══════════════════════════════════════════════════════════════════════════

# t1: extract messages from a minimal JSONL
T="$TMP/t1"; mkdir -p "$T"
setup_project "$T"
SESSION_ID="test-session-t1"
make_jsonl "$SESSION_STORE/${SESSION_ID}.jsonl" 2
out=$(python3 "$PIPELINE_DIR/extract.py" \
  --project-dir "$CLAUDE_PROJECT_DIR" \
  --state-dir /dev/null \
  --session "$SESSION_ID" 2>/tmp/sr-test-stderr.txt) && rc=0 || rc=$?
if [[ $rc -eq 0 ]] && echo "$out" | grep -q "Human message 1"; then
  ok "t1: extract.py — extracts human messages from JSONL"
else
  fail "t1: extract.py — extracts human messages from JSONL" "output: $out"
fi

# t2: --since-last-save skips lines already processed
T="$TMP/t2"; mkdir -p "$T"
setup_project "$T"
SESSION_ID="test-session-t2"
make_jsonl "$SESSION_STORE/${SESSION_ID}.jsonl" 4
STATE_DIR="$T/state"; mkdir -p "$STATE_DIR"
# Record that lines 1-4 were already saved (2 turns = 4 lines)
printf '{"session":"%s","line":4}\n' "$SESSION_ID" > "$STATE_DIR/last-save.json"
out=$(python3 "$PIPELINE_DIR/extract.py" \
  --project-dir "$CLAUDE_PROJECT_DIR" \
  --state-dir "$STATE_DIR" \
  --session "$SESSION_ID" \
  --since-last-save 2>/tmp/sr-test-stderr.txt)
# Human messages 1+2 should NOT appear (already saved)
if ! echo "$out" | grep -q "Human message 1" && ! echo "$out" | grep -q "Human message 2"; then
  ok "t2: extract.py --since-last-save skips already-saved lines"
else
  fail "t2: extract.py --since-last-save skips already-saved lines" "output: $out"
fi

# t3: invalid session_id → clean error, exit 1, no traceback
err=$(python3 "$PIPELINE_DIR/extract.py" \
  --project-dir /nonexistent \
  --session "../../etc/passwd" 2>&1) && rc=0 || rc=$?
if [[ $rc -eq 1 ]] && echo "$err" | grep -q "invalid session_id" && ! echo "$err" | grep -q "Traceback"; then
  ok "t3: extract.py — invalid session_id → clean error, no traceback"
else
  fail "t3: extract.py — invalid session_id → clean error, no traceback" "exit=$rc output=$err"
fi

# t4: missing JSONL → exit 1, no traceback
err=$(python3 "$PIPELINE_DIR/extract.py" \
  --project-dir "$TMP/nonexistent" 2>&1) && rc=0 || rc=$?
if [[ $rc -eq 1 ]] && ! echo "$err" | grep -q "Traceback"; then
  ok "t4: extract.py — missing session JSONL → exit 1, no traceback"
else
  fail "t4: extract.py — missing session JSONL → exit 1, no traceback" "exit=$rc output=$err"
fi

# t5: stderr carries __POSITION__, __HUMAN__, __EXCHANGES__
T="$TMP/t5"; mkdir -p "$T"
setup_project "$T"
SESSION_ID="test-session-t5"
make_jsonl "$SESSION_STORE/${SESSION_ID}.jsonl" 3
python3 "$PIPELINE_DIR/extract.py" \
  --project-dir "$CLAUDE_PROJECT_DIR" \
  --state-dir /dev/null \
  --session "$SESSION_ID" \
  >/dev/null 2>"$T/stderr.txt" && rc=0 || rc=$?
if grep -q "__POSITION__:" "$T/stderr.txt" && \
   grep -q "__HUMAN__:3"   "$T/stderr.txt" && \
   grep -q "__EXCHANGES__:6" "$T/stderr.txt"; then
  ok "t5: extract.py — stderr carries __POSITION__, __HUMAN__:3, __EXCHANGES__:6"
else
  fail "t5: extract.py — stderr carries __POSITION__, __HUMAN__, __EXCHANGES__" "$(cat "$T/stderr.txt")"
fi

# ═══════════════════════════════════════════════════════════════════════════
printf "\n${B}  ── common.sh ──${D}\n"
# ═══════════════════════════════════════════════════════════════════════════

# t6: DISABLED sentinel → source returns 1
T="$TMP/t6"; mkdir -p "$T"
DISABLED_FILE="$PIPELINE_DIR/DISABLED"
touch "$DISABLED_FILE"
result=$(bash -c "
  export CLAUDE_PROJECT_DIR='$T/project'
  source '$PIPELINE_DIR/common.sh' && echo LOADED || echo SKIPPED
" 2>/dev/null)
rm -f "$DISABLED_FILE"
if [[ "$result" == "SKIPPED" ]]; then
  ok "t6: common.sh — DISABLED sentinel causes source to return 1"
else
  fail "t6: common.sh — DISABLED sentinel causes source to return 1" "got: $result"
fi

# t7: sr_write_last_save + sr_last_save_field round-trip
T="$TMP/t7"; mkdir -p "$T"
export CLAUDE_PROJECT_DIR="$T/project"; mkdir -p "$CLAUDE_PROJECT_DIR"
result=$(bash -c "
  export CLAUDE_PROJECT_DIR='$T/project'
  source '$PIPELINE_DIR/common.sh' 2>/dev/null
  sr_ensure_dirs
  sr_write_last_save 'abc-123' 42
  echo \"\$(sr_last_save_field session ''):\$(sr_last_save_field line 0)\"
")
if [[ "$result" == "abc-123:42" ]]; then
  ok "t7: common.sh — sr_write_last_save / sr_last_save_field round-trip"
else
  fail "t7: common.sh — sr_write_last_save / sr_last_save_field round-trip" "got: $result"
fi

# t8: model wiring (model-assignment audit D6) — model literals live only in the three knob defaults, and
# sr_call_haiku passes the per-class variable, not a literal. (model-knobs.test.sh covers the precedence.)
# A knob default is a knob line that carries a model literal; the state/model-overrides.json lookup lines (c65c7c1e) carry none.
knob_defaults=$(grep -cE '^SR_MODEL(_BULK|_CONSOLIDATE)?=.*claude-(haiku|sonnet|opus)-[0-9]' "$PIPELINE_DIR/common.sh" || true)
literals_outside=$(grep -nE 'claude-(haiku|sonnet|opus)-[0-9]' "$PIPELINE_DIR/common.sh" | grep -vcE '^[0-9]+:(SR_MODEL(_BULK|_CONSOLIDATE)?=|[[:space:]]*#)' || true)
call_uses_var=$(grep -c -- '--model "\$model"' "$PIPELINE_DIR/common.sh" || true)
if [[ "$knob_defaults" -eq 3 && "$literals_outside" -eq 0 && "$call_uses_var" -eq 1 ]]; then
  ok "t8: common.sh — 3 model knob defaults, no model literal elsewhere; sr_call_haiku passes the per-class \$model"
else
  fail "t8: common.sh — model wiring" \
    "knob_defaults=$knob_defaults literals_outside=$literals_outside call_uses_var=$call_uses_var"
fi

# ═══════════════════════════════════════════════════════════════════════════
printf "\n${B}  ── save.sh ──${D}\n"
# ═══════════════════════════════════════════════════════════════════════════

# t9: --dry-run exits 0, does NOT write buffer.md, prints extraction
T="$TMP/t9"; mkdir -p "$T"
setup_project "$T"
SESSION_ID="test-session-t9"
make_jsonl "$SESSION_STORE/${SESSION_ID}.jsonl" 2
MEMORY_DIR="$T/memory"; mkdir -p "$MEMORY_DIR/sessions/.state"
# Redirect SR paths into our temp dir
out=$(SR_SAVE_COOLDOWN=0 SR_MIN_HUMAN=1 \
  bash -c "
    export CLAUDE_PROJECT_DIR='$CLAUDE_PROJECT_DIR'
    # Override memory paths
    source '$PIPELINE_DIR/common.sh' 2>/dev/null
    SR_BUFFER='$MEMORY_DIR/sessions/buffer.md'
    SR_LOCK='$MEMORY_DIR/sessions/.state/save.lock'
    SR_LAST_SAVE='$MEMORY_DIR/sessions/.state/last-save.json'
    SESSION_DIR='$MEMORY_DIR/sessions'
    STATE_DIR='$MEMORY_DIR/sessions/.state'
    bash '$PIPELINE_DIR/save.sh' '$SESSION_ID' --dry-run 2>/dev/null
  ") && rc=0 || rc=$?
buffer_exists=false
[[ -f "$MEMORY_DIR/sessions/buffer.md" ]] && buffer_exists=true
if [[ $rc -eq 0 ]] && echo "$out" | grep -q "DRY RUN" && [[ "$buffer_exists" == false ]]; then
  ok "t9: save.sh --dry-run — exits 0, prints extraction, does not write buffer.md"
else
  fail "t9: save.sh --dry-run — exits 0, prints extraction, does not write buffer.md" \
    "exit=$rc buffer_exists=$buffer_exists"
fi

# t10: cooldown — second run within cooldown window skips
T="$TMP/t10"; mkdir -p "$T"
setup_project "$T"
SESSION_ID="test-session-t10"
make_jsonl "$SESSION_STORE/${SESSION_ID}.jsonl" 2
# Plant last-save-ts in the path save.sh will actually derive from CLAUDE_PROJECT_DIR
_T10_SLUG="$(echo "$CLAUDE_PROJECT_DIR" | tr '/' '-')"
_T10_STATE="$HOME/.claude/projects/${_T10_SLUG}/memory/sessions/.state"
mkdir -p "$_T10_STATE"
date +%s > "$_T10_STATE/last-save-ts"
out=$(SR_SAVE_COOLDOWN=9999 CLAUDE_PROJECT_DIR="$CLAUDE_PROJECT_DIR" \
  bash "$PIPELINE_DIR/save.sh" "$SESSION_ID" 2>&1) && rc=0 || rc=$?
if echo "$out" | grep -q "skipping"; then
  ok "t10: save.sh — cooldown gate skips run within cooldown window"
else
  fail "t10: save.sh — cooldown gate skips run within cooldown window" "exit=$rc output=$out"
fi

# ═══════════════════════════════════════════════════════════════════════════
printf "\n${B}  ── trigger.sh ──${D}\n"
# ═══════════════════════════════════════════════════════════════════════════

# t11: no JSONL files → exits 0
T="$TMP/t11"; mkdir -p "$T"
export CLAUDE_PROJECT_DIR="$T/project"; mkdir -p "$CLAUDE_PROJECT_DIR"
slug="$(echo "$CLAUDE_PROJECT_DIR" | tr '/' '-')"
mkdir -p "$HOME/.claude/projects/${slug}"
rc=$(echo '{}' | bash "$PIPELINE_DIR/trigger.sh" 2>/dev/null; echo $?)
if [[ "$rc" -eq 0 ]]; then
  ok "t11: trigger.sh — no JSONL files → exits 0"
else
  fail "t11: trigger.sh — no JSONL files → exits 0" "exit: $rc"
fi

# t12: delta below threshold → no save.sh invoked
T="$TMP/t12"; mkdir -p "$T"
setup_project "$T"
SESSION_ID="test-session-t12"
make_jsonl "$SESSION_STORE/${SESSION_ID}.jsonl" 1   # 2 lines — well below default 50
out=$(SR_DELTA_THRESHOLD=50 \
  CLAUDE_PROJECT_DIR="$CLAUDE_PROJECT_DIR" \
  echo '{}' | bash "$PIPELINE_DIR/trigger.sh" 2>&1) && rc=0 || rc=$?
if [[ $rc -eq 0 ]] && ! echo "$out" | grep -q "triggered"; then
  ok "t12: trigger.sh — delta below threshold → no save triggered"
else
  fail "t12: trigger.sh — delta below threshold → no save triggered" "exit=$rc output=$out"
fi

# ═══════════════════════════════════════════════════════════════════════════
printf "\n${B}  ── start.sh ──${D}\n"
# ═══════════════════════════════════════════════════════════════════════════

# t13: handoff content injected into stdout, handoff file cleared after injection
T="$TMP/t13"; mkdir -p "$T"
setup_project "$T"
slug="$(echo "$CLAUDE_PROJECT_DIR" | tr '/' '-')"
SESSION_DIR_T13="$HOME/.claude/projects/${slug}/memory/sessions"
mkdir -p "$SESSION_DIR_T13"
printf 'This is the handoff note\n' > "$SESSION_DIR_T13/handoff.md"
out=$(CLAUDE_PROJECT_DIR="$CLAUDE_PROJECT_DIR" bash "$PIPELINE_DIR/start.sh" 2>/dev/null)
handoff_cleared=false
[[ ! -s "$SESSION_DIR_T13/handoff.md" ]] && handoff_cleared=true
if echo "$out" | grep -q "handoff note" && [[ "$handoff_cleared" == true ]]; then
  ok "t13: start.sh — handoff injected into output, file cleared after injection"
else
  fail "t13: start.sh — handoff injected into output, file cleared after injection" \
    "cleared=$handoff_cleared output=$(echo "$out" | head -3)"
fi

# t14: no context files → no SESSION CONTINUITY block in output
T="$TMP/t14"; mkdir -p "$T"
setup_project "$T"
slug="$(echo "$CLAUDE_PROJECT_DIR" | tr '/' '-')"
mkdir -p "$HOME/.claude/projects/${slug}/memory/sessions"
out=$(CLAUDE_PROJECT_DIR="$CLAUDE_PROJECT_DIR" bash "$PIPELINE_DIR/start.sh" 2>/dev/null)
if ! echo "$out" | grep -q "SESSION CONTINUITY"; then
  ok "t14: start.sh — no context files → no SESSION CONTINUITY block"
else
  fail "t14: start.sh — no context files → no SESSION CONTINUITY block" \
    "output: $(echo "$out" | head -3)"
fi

# t15: Haiku failure advances position AND updates cooldown timestamp
T="$TMP/t15"; mkdir -p "$T"
setup_project "$T"
SESSION_ID="test-session-t15"
make_jsonl "$SESSION_STORE/${SESSION_ID}.jsonl" 3
_T15_SLUG="$(echo "$CLAUDE_PROJECT_DIR" | tr '/' '-')"
_T15_STATE="$HOME/.claude/projects/${_T15_SLUG}/memory/sessions/.state"
mkdir -p "$_T15_STATE"
rm -f "$_T15_STATE/last-save.json" "$_T15_STATE/last-save-ts"
# Put a fake `claude` binary first in PATH that always exits 1 (simulates API failure)
_T15_BIN="$T/fake-bin"; mkdir -p "$_T15_BIN"
printf '#!/bin/bash\nexit 1\n' > "$_T15_BIN/claude"; chmod +x "$_T15_BIN/claude"
out=$(SR_MIN_HUMAN=1 SR_SAVE_COOLDOWN=0 CLAUDE_PROJECT_DIR="$CLAUDE_PROJECT_DIR" \
  PATH="$_T15_BIN:$PATH" bash "$PIPELINE_DIR/save.sh" "$SESSION_ID" --force 2>&1) && rc=0 || rc=$?
ts_updated=false; position_advanced=false
[[ -f "$_T15_STATE/last-save-ts" ]]   && ts_updated=true
[[ -f "$_T15_STATE/last-save.json" ]] && position_advanced=true
if [[ $rc -eq 1 && "$ts_updated" == true && "$position_advanced" == true ]]; then
  ok "t15: save.sh — Haiku failure advances position AND updates cooldown timestamp"
else
  fail "t15: save.sh — Haiku failure advances position AND updates cooldown timestamp" \
    "exit=$rc ts_updated=$ts_updated position_advanced=$position_advanced"
fi

# ═══════════════════════════════════════════════════════════════════════════
printf "${B}  ── harness hygiene ──${D}\n"
# ═══════════════════════════════════════════════════════════════════════════

# t16: this suite must not write into the operator's real memory store (SPEC §6-22).
# Every setup_project() call derives SESSION_STORE from $HOME; if $HOME is not shadowed
# the store lands in the live ~/.claude/projects/ and the EXIT trap (which only removes
# $TMP) never reclaims it. 154 such directories had accumulated by 2026-09-03.
SR_RESIDUE_AFTER=$(_sr_residue_count)
if [[ "$SR_RESIDUE_AFTER" -eq "$SR_RESIDUE_BEFORE" ]]; then
  ok "t16: harness — no new -tmp-tmp.* stores in the real memory root ($SR_RESIDUE_AFTER)"
else
  fail "t16: harness — leaked into the real memory store" \
    "before=$SR_RESIDUE_BEFORE after=$SR_RESIDUE_AFTER root=$SR_REAL_HOME/.claude/projects"
fi

# ═══════════════════════════════════════════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════════════════════════════════════════
TOTAL=$(( PASS + FAIL ))
BAR="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
printf "${B}%s${D}\n" "$BAR"
echo ""
if [[ $FAIL -eq 0 ]]; then
  printf "  ${B}${G}ALL PASSED${D}   ${G}✓ %d / %d${D}\n" "$PASS" "$TOTAL"
else
  printf "  ${B}${R}FAILURES${D}      ${G}✓ %d passed${D}   ${R}✗ %d failed${D}   (%d total)\n" \
    "$PASS" "$FAIL" "$TOTAL"
  echo ""
  printf "${B}  Failed tests:${D}\n"
  for f in "${FAILURES[@]}"; do printf "    ${R}•${D} %s\n" "$f"; done
fi
echo ""
printf "${B}%s${D}\n" "$BAR"
echo ""
[[ $FAIL -eq 0 ]] || exit 1
