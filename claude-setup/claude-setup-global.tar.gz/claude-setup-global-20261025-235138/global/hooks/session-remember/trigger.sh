#!/usr/bin/env bash
# trigger.sh — PostToolUse hook: check JSONL delta, fire save.sh when needed
#
# Fires on ALL tool calls (no matcher). Always exits 0 — never blocks the agent.
# Reads tool call JSON from stdin (provided by Claude Code) but doesn't need it.

set -euo pipefail

# Consume stdin (required by Claude Code hook protocol)
# shellcheck disable=SC2034
_input=$(cat 2>/dev/null || true)

# Persist the permission mode for the statusline on EVERY tool call, ahead of the memory
# kill-switches and the delta check below — this write is a statusline concern that must keep
# working when session-remember itself is disabled. The statusline payload has no permission-mode
# field (verified 2026-08-29); PostToolUse stdin does. Never clobber on input without the field.
_pm_sid=$(printf '%s' "$_input" | jq -r '.session_id // empty' 2>/dev/null || true)
_pm_mode=$(printf '%s' "$_input" | jq -r '.permission_mode // empty' 2>/dev/null || true)
if [[ -n "$_pm_sid" && -n "$_pm_mode" ]]; then
  mkdir -p "$HOME/.claude/run" 2>/dev/null || true
  printf '%s\n' "$_pm_mode" > "$HOME/.claude/run/permission-mode-${_pm_sid}" 2>/dev/null || true
fi
unset _pm_sid _pm_mode

# Claude Code hands us the transcript path outright; common.sh uses it to locate
# SESSION_STORE instead of guessing the directory name from the project path.
# Must be exported BEFORE common.sh is sourced. See SPEC.md §6-20.
SR_TRANSCRIPT_PATH=$(printf '%s' "$_input" | jq -r '.transcript_path // empty' 2>/dev/null || true)
export SR_TRANSCRIPT_PATH

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh" || exit 0
[[ "${SR_READONLY:-}" == "1" ]] && exit 0

sr_ensure_dirs || { sr_warn "sr_ensure_dirs failed — skipping trigger"; exit 0; }

# ── Find this session's JSONL ─────────────────────────────────────────────────
# Prefer the exact path from the payload. Picking by mtime (the old behaviour)
# selects the wrong session whenever two sessions are live at once — and there
# routinely are (SPEC.md §6-30). The glob remains only for the no-payload case.
if [[ -n "${SR_TRANSCRIPT_PATH:-}" && -f "$SR_TRANSCRIPT_PATH" ]]; then
  LATEST_JSONL="$SR_TRANSCRIPT_PATH"
else
  LATEST_JSONL=$(ls -t "$SESSION_STORE"/*.jsonl 2>/dev/null | head -1 || true)
fi
[[ -n "$LATEST_JSONL" ]] || exit 0

# ── Count current lines ───────────────────────────────────────────────────────
CURRENT_LINES=$(wc -l < "$LATEST_JSONL" 2>/dev/null | tr -d ' ' || echo 0)
SESSION_ID=$(basename "$LATEST_JSONL" .jsonl)

# ── Get last saved position ───────────────────────────────────────────────────
LAST_LINE=0
SAVED_SESSION=$(sr_last_save_field "session" "")
if [[ "$SAVED_SESSION" == "$SESSION_ID" ]]; then
  LAST_LINE=$(sr_last_save_field "line" "0")
fi

# ── Check delta ───────────────────────────────────────────────────────────────
DELTA=$(( CURRENT_LINES - LAST_LINE ))
if (( DELTA <= SR_DELTA_THRESHOLD )); then
  exit 0
fi

# ── Skip back-off ─────────────────────────────────────────────────────────────
# save.sh skips a session with too few human msgs or 0 exchanges WITHOUT advancing the position,
# so DELTA stays above the threshold and every tool call used to dispatch another save.sh that
# skipped again (7,309 dispatches for one keep-going session, 2026-10-07). save.sh records the
# skip in skip-ts.<sid>; hold back while it is younger than SR_SKIP_BACKOFF. A garbage marker
# reads as none (dispatch, as before), never as an arithmetic error under set -e; so does a stamp in
# the future (clock stepped back), which would otherwise hold the session back forever.
_skip_ts=$(cat "$STATE_DIR/skip-ts.${SESSION_ID}" 2>/dev/null || true)
if [[ "$_skip_ts" =~ ^[0-9]{1,10}$ ]]; then
  _skip_age=$(( $(date +%s) - 10#$_skip_ts ))
  if (( _skip_age >= 0 && _skip_age < SR_SKIP_BACKOFF )); then
    exit 0
  fi
fi

# ── Check if save already running ────────────────────────────────────────────
if [[ -f "$SR_PID" ]]; then
  OLD_PID=$(cat "$SR_PID" 2>/dev/null || echo "")
  if [[ -n "$OLD_PID" ]] && kill -0 "$OLD_PID" 2>/dev/null; then
    sr_info "save already running (PID $OLD_PID), skipping trigger"
    exit 0
  fi
fi

# ── Launch save.sh in background ─────────────────────────────────────────────
mkdir -p "$SESSION_DIR/logs"
LOG_FILE="$SESSION_DIR/logs/save-$(TZ="$SR_TZ" date +%H%M%S).log"
nohup "$SCRIPT_DIR/save.sh" "$SESSION_ID" \
  > "$LOG_FILE" 2>&1 &
echo $! > "$SR_PID"
sr_info "triggered save (delta=${DELTA}, PID=$!, session=${SESSION_ID})"
log_obs INFO trigger.sh "save.sh dispatched (delta=${DELTA}, session=${SESSION_ID}, PID=$!)" 2>/dev/null || true

# Rotate: keep only 20 newest save-*.log files
{ ls -t "$SESSION_DIR/logs"/save-*.log 2>/dev/null | tail -n +21 | xargs rm -f --; } 2>/dev/null || true

exit 0
