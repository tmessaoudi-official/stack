#!/usr/bin/env bash
# start.sh — SessionStart hook: inject session context into Claude Code
#
# Outputs context to stdout (Claude Code injects this into the session).
# Triggers consolidation + missed-session recovery in background.
# Never fails — all errors logged to stderr, exit always 0.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# SessionStart stdin carries {session_id, transcript_path, cwd, ...}. common.sh needs
# transcript_path to locate SESSION_STORE, so it must be read and exported BEFORE the
# source below. Guarded on a tty: this script is also run by hand to inspect the
# injected context, and an unguarded `cat` would block waiting on the terminal.
# See SPEC.md §6-20.
#
# The read is BOUNDED. A bare `cat` blocks until EOF, and a caller that holds stdin
# open without writing (a test harness, a shell pipeline) hangs this hook forever —
# which would stall session startup, since SessionStart runs before the session is
# usable. Measured 2026-09-02: `sleep 5 | bash start.sh` never returns; with `timeout`
# it exits 0. Claude Code sends the payload then closes, so the bound is never reached
# in normal operation. The `-t 0` test additionally avoids consuming a real terminal.
SR_TRANSCRIPT_PATH=""
if [[ ! -t 0 ]]; then
  _start_payload=$(timeout 2 cat 2>/dev/null || true)
  if command -v jq &>/dev/null; then
    SR_TRANSCRIPT_PATH=$(printf '%s' "$_start_payload" | jq -r '.transcript_path // empty' 2>/dev/null || true)
  fi
  unset _start_payload
fi
export SR_TRANSCRIPT_PATH

# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh" || exit 0

sr_ensure_dirs || true

if [[ "${SR_READONLY:-}" != "1" ]]; then
  # ── Background: recover missed session ──────────────────────────────────────
  # If the second-most-recent JSONL wasn't saved, save it now.
  {
    mapfile -t JSONL_FILES < <(ls -t "$SESSION_STORE"/*.jsonl 2>/dev/null || true)
    if (( ${#JSONL_FILES[@]} >= 2 )); then
      MISSED_ID=$(basename "${JSONL_FILES[1]}" .jsonl)
      SAVED_ID=$(sr_last_save_field "session" "")
      # sr_has_saved_session, not just != SAVED_ID: SAVED_ID is the single top-level slot,
      # which this session's own saves overwrite, so the same missed session looked unsaved
      # again on every SessionStart — and SessionStart also fires on /compact and resume.
      # SPEC §6-23.
      if [[ -n "$MISSED_ID" && "$MISSED_ID" != "$SAVED_ID" ]] \
         && ! sr_has_saved_session "$MISSED_ID"; then
        mkdir -p "$SESSION_DIR/logs"
        nohup "$SCRIPT_DIR/save.sh" "$MISSED_ID" --force \
          > "$SESSION_DIR/logs/recovery-$(date +%Y%m%d-%H%M%S).log" 2>&1 &
        sr_info "background recovery: $MISSED_ID (PID: $!)"
      fi
    fi
  } 2>/dev/null || true

  # ── Background: consolidate stale today.md if needed ────────────────────────
  {
    TODAY_DATE=$(sr_today)
    if [[ -f "$SR_TODAY" && -s "$SR_TODAY" ]]; then
      FIRST_DATE=$(grep -m1 '^## [0-9]' "$SR_TODAY" 2>/dev/null | sed 's/^## //' | head -c 10 || echo "")
      if [[ -n "$FIRST_DATE" && "$FIRST_DATE" != "$TODAY_DATE" ]]; then
        mkdir -p "$SESSION_DIR/logs"
        sr_info "stale today.md ($FIRST_DATE), running consolidation in background"
        nohup "$SCRIPT_DIR/consolidate.sh" \
          > "$SESSION_DIR/logs/consolidate-$(date +%Y%m%d-%H%M%S).log" 2>&1 &
        sr_info "background consolidation started (PID: $!)"
      fi
    fi
  } 2>/dev/null || true
fi

# ── WAL recovery: process orphaned WAL files into buffer.md ──────────────────
# WAL files are written by stop.sh --mark-only when Phase 2 hasn't completed.
# Recovery is synchronous so content is visible in this session's context injection.
if [[ "${SR_READONLY:-}" != "1" ]]; then
  _wal_files=( "$STATE_DIR"/wal-*.md )
  if [[ -e "${_wal_files[0]:-}" ]]; then
    for _wal_f in "${_wal_files[@]}"; do
      [[ -f "$_wal_f" ]] || continue
      if cat "$_wal_f" >> "$SR_BUFFER" 2>/dev/null; then
        rm -f "$_wal_f" 2>/dev/null || true
      else
        sr_warn "WAL recovery: failed to append ${_wal_f##*/} — keeping WAL file"
      fi
    done
    sr_info "WAL recovery: orphaned WAL content appended to buffer.md"
  fi
fi

# ── Inject context into session ───────────────────────────────────────────────
HAS_CONTEXT=false
for f in "$SR_HANDOFF" "$SR_TODAY" "$SR_BUFFER"; do
  [[ -f "$f" && -s "$f" ]] && HAS_CONTEXT=true && break
done

if [[ "$HAS_CONTEXT" == true ]]; then
  log_obs INFO start.sh "context injected (handoff=$([ -s "$SR_HANDOFF" ] && echo yes || echo no), today=$([ -s "$SR_TODAY" ] && echo yes || echo no), buffer=$([ -s "$SR_BUFFER" ] && echo yes || echo no))" 2>/dev/null || true
  echo "=== SESSION CONTINUITY ==="
  echo ""

  if [[ -f "$SR_HANDOFF" && -s "$SR_HANDOFF" ]]; then
    echo "--- Handoff ---"
    cat "$SR_HANDOFF"
    echo ""
    # Consume: one-shot briefing — clear after injection
    : > "$SR_HANDOFF"
  fi

  if [[ -f "$SR_TODAY" && -s "$SR_TODAY" ]]; then
    echo "--- Today ---"
    cat "$SR_TODAY"
    echo ""
  fi

  if [[ -f "$SR_BUFFER" && -s "$SR_BUFFER" ]]; then
    echo "--- Recent Activity ---"
    cat "$SR_BUFFER"
    echo ""
  fi

  echo "Tip: run /handoff before ending a session to save a handoff note."
  echo "==========================="
  echo ""
fi

exit 0
