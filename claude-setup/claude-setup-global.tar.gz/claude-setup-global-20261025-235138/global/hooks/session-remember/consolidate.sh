#!/usr/bin/env bash
# consolidate.sh — Temporal compression: buffer→today, today→history, history→archive
#
# Called by start.sh when stale data is detected (yesterday's today.md exists).
# Can be run standalone for debugging: CLAUDE_PROJECT_DIR=/path/to/your/project bash consolidate.sh
# Always exits 0.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "$SCRIPT_DIR/common.sh" || exit 0
[[ "${SR_READONLY:-}" == "1" ]] && exit 0

sr_ensure_dirs || { sr_error "consolidate: failed to create session directories"; exit 0; }

# Acquire the same lock as save.sh — prevents concurrent buffer/today.md writes
exec 9>"$SR_LOCK"
flock --wait 30 9 || { sr_warn "consolidate: could not acquire lock after 30s, skipping"; exit 0; }

TODAY_DATE=$(sr_today)

# ── Step 1: Final NDC — flush stale buffer into today.md ─────────────────────
if [[ -f "$SR_BUFFER" && -s "$SR_BUFFER" ]]; then
  sr_info "consolidate: flushing stale buffer via NDC"
  NDC_PROMPT=$(mktemp /tmp/sr-ndc-XXXXXX.txt)
  BUFFER_CONTENT=$(cat "$SR_BUFFER")
  cat "$SCRIPT_DIR/prompts/compress.txt" > "$NDC_PROMPT"
  printf '\n\nText:\n%s\n' "$BUFFER_CONTENT" >> "$NDC_PROMPT"

  NDC_RESULT=""
  if sr_call_haiku "$NDC_PROMPT" NDC_RESULT; then
    STALE_DATE=$(grep -m1 '^## [0-9]' "$SR_TODAY" 2>/dev/null | sed 's/^## //' | head -c 10) || true
    [[ -z "$STALE_DATE" ]] && STALE_DATE=$(grep -m1 '^## [0-9]' "$SR_BUFFER" 2>/dev/null | sed 's/^## //' | head -c 10) || true
    [[ -z "$STALE_DATE" ]] && STALE_DATE="$TODAY_DATE"
    printf '## %s\n\n%s\n\n' "$STALE_DATE" "$NDC_RESULT" >> "$SR_TODAY"
    : > "$SR_BUFFER"
    sr_info "consolidate: buffer flushed into today.md"
  else
    sr_warn "consolidate: NDC Haiku failed — keeping buffer"
  fi
  rm -f "$NDC_PROMPT" 2>/dev/null || true
fi

# ── Step 2: Roll stale today.md → history.md ─────────────────────────────────
if [[ ! -f "$SR_TODAY" || ! -s "$SR_TODAY" ]]; then
  sr_info "consolidate: no today.md content to roll up"
else
  FIRST_DATE=$(grep -m1 '^## [0-9]' "$SR_TODAY" 2>/dev/null | sed 's/^## //' | head -c 10 || echo "")
  if [[ "$FIRST_DATE" == "$TODAY_DATE" ]]; then
    sr_info "consolidate: today.md is current ($TODAY_DATE), no rollup needed"
  else
    sr_info "consolidate: today.md is stale (${FIRST_DATE:-unknown}), rolling into history.md"

    CONS_PROMPT=$(mktemp /tmp/sr-cons-XXXXXX.txt)
    TODAY_CONTENT=$(cat "$SR_TODAY")
    HISTORY_CONTENT=""
    [[ -f "$SR_HISTORY" ]] && HISTORY_CONTENT=$(cat "$SR_HISTORY")

    cat "$SCRIPT_DIR/prompts/consolidate.txt" > "$CONS_PROMPT"
    printf '\n\n### Daily entries to compress:\n%s\n\n### Current history.md:\n%s\n\nWrite the updated history.md now (oldest first, newest last):\n' \
      "$TODAY_CONTENT" \
      "$HISTORY_CONTENT" \
      >> "$CONS_PROMPT"

    CONS_RESULT=""
    if sr_call_haiku "$CONS_PROMPT" CONS_RESULT consolidate; then
      echo "$CONS_RESULT" > "$SR_HISTORY"
      : > "$SR_TODAY"
      sr_info "consolidate: today.md rolled into history.md"
    else
      sr_warn "consolidate: rollup Haiku failed — keeping today.md"
    fi
    rm -f "$CONS_PROMPT" 2>/dev/null || true
  fi
fi

# ── Step 3: Rotate COMPLETE Mon-Sun weeks of history → archive.md ────────────
# Model policy v2 (decisions D15, D17, D18). The CODE splits history.md: it keeps the newest SR_HISTORY_MAX_ENTRIES
# entries plus every entry whose week still touches them, and rotates the weeks that ended before the oldest kept
# entry. The model only summarises the rotated days, one section per week, under the exact heading line the code
# hands it. The code checks that answer, appends the sections (existing archive bytes are never rewritten) and only
# then rewrites history from the code-cut keep set. Any other outcome leaves history and archive untouched.
# (The old contract had the model echo the whole archive and the code append that echo to the file that already
# held it — every rotation duplicated the archive, and rewrote history even when the model returned no archive.)
if [[ -f "$SR_HISTORY" && -s "$SR_HISTORY" ]]; then
  ROT_DIR=$(mktemp -d /tmp/sr-rot-XXXXXX)
  # keep.md = history minus the rotated days; weeks.txt = the Mondays (ISO) of the weeks to rotate;
  # rot-<monday>.md = that week's daily entries. Entries are read by their "## YYYY-MM-DD" heading, in any file order.
  awk -v max="$SR_HISTORY_MAX_ENTRIES" -v dir="$ROT_DIR" '
    function dfc(y, m, d,   era, yoe, doy) {
      if (m <= 2) y--
      era = int(y / 400); yoe = y - era * 400
      doy = int((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1
      return era * 146097 + yoe * 365 + int(yoe / 4) - int(yoe / 100) + doy - 719468
    }
    function cfd(z,   era, doe, yoe, y, doy, mp, d, m) {
      z += 719468; era = int(z / 146097); doe = z - era * 146097
      yoe = int((doe - int(doe / 1460) + int(doe / 36524) - int(doe / 146096)) / 365)
      y = yoe + era * 400; doy = doe - (365 * yoe + int(yoe / 4) - int(yoe / 100))
      mp = int((5 * doy + 2) / 153); d = doy - int((153 * mp + 2) / 5) + 1
      m = mp + (mp < 10 ? 3 : -9)
      return sprintf("%04d-%02d-%02d", y + (m <= 2), m, d)
    }
    BEGIN { n = 0; pre = "" }
    /^## [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]/ {
      y = substr($0, 4, 4) + 0; m = substr($0, 9, 2) + 0; d = substr($0, 12, 2) + 0
      if (m >= 1 && m <= 12 && d >= 1 && d <= 31) { n++; z[n] = dfc(y, m, d); txt[n] = $0 "\n"; next }
    }
    { if (n == 0) pre = pre $0 "\n"; else txt[n] = txt[n] $0 "\n" }
    END {
      keepf = dir "/keep.md"; weeksf = dir "/weeks.txt"
      printf "" > keepf; printf "" > weeksf
      printf "%s", pre > keepf
      max += 0
      for (i = 1; i <= n; i++) {
        r = 1
        for (j = 1; j <= n; j++) if (z[j] > z[i] || (z[j] == z[i] && j > i)) r++
        keep[i] = (r <= max) ? 1 : 0
      }
      oldest = -1
      for (i = 1; i <= n; i++) if (keep[i] && (oldest < 0 || z[i] < oldest)) oldest = z[i]
      nw = 0
      for (i = 1; i <= n; i++) {
        mon = z[i] - ((z[i] + 3) % 7)
        if (!keep[i] && oldest >= 0 && mon + 6 < oldest) {
          wk[i] = mon
          if (!(mon in seen)) { seen[mon] = 1; wl[++nw] = mon }
        } else printf "%s", txt[i] > keepf
      }
      for (a = 2; a <= nw; a++) { v = wl[a]; b = a - 1; while (b >= 1 && wl[b] > v) { wl[b + 1] = wl[b]; b-- } wl[b + 1] = v }
      for (a = 1; a <= nw; a++) {
        mon = wl[a]; iso = cfd(mon); f = dir "/rot-" iso ".md"; cnt = 0; delete idx
        for (i = 1; i <= n; i++) if ((i in wk) && wk[i] == mon) idx[++cnt] = i
        for (p = 2; p <= cnt; p++) {
          v = idx[p]; q = p - 1
          while (q >= 1 && (z[idx[q]] > z[v] || (z[idx[q]] == z[v] && idx[q] > v))) { idx[q + 1] = idx[q]; q-- }
          idx[q + 1] = v
        }
        printf "" > f
        for (p = 1; p <= cnt; p++) printf "%s", txt[idx[p]] > f
        close(f)
        print iso > weeksf
      }
    }' "$SR_HISTORY"

  if [[ -s "$ROT_DIR/weeks.txt" ]]; then
    NW=$(wc -l < "$ROT_DIR/weeks.txt" | tr -d ' ')
    sr_info "consolidate: rotating ${NW} complete week(s) of history to archive"
    ARCH_PROMPT=$(mktemp /tmp/sr-arch-XXXXXX.txt)
    : > "$ROT_DIR/expected.txt"
    # The prompt is built with printf/cat (not heredoc expansion) so $(cmd) or backticks in session files stay inert.
    {
      printf '%s\n\n' 'You are a memory archivist. Summarise each week below into ONE weekly summary for archive.md.'
      printf '%s\n' 'Rules:' \
        '- Output ONLY the weekly sections, nothing else: no preamble, no history, no existing archive text.' \
        '- One section per week, in the order given. The first line of each section is the heading line shown for that week, copied EXACTLY.' \
        '- Each section: 2-3 sentences covering conventions, infrastructure changes and major deliverables. Drop daily details, keep patterns and decisions.' ''
    } > "$ARCH_PROMPT"
    while IFS= read -r MON; do
      HDG="## Week of $MON"
      # a week that already has a heading (legacy partial-week summaries) gets "(continued)", then "(continued 2)" ...
      if grep -q "^## Week of $MON" "$SR_ARCHIVE" 2>/dev/null; then
        HN=2; HDG="## Week of $MON (continued)"
        while grep -qxF -- "$HDG" "$SR_ARCHIVE" 2>/dev/null; do HN=$((HN + 1)); HDG="## Week of $MON (continued $((HN - 1)))"; done
      fi
      printf '%s\n' "$HDG" >> "$ROT_DIR/expected.txt"
      { printf '=== WEEK: use exactly this heading line ===\n%s\n--- daily entries of that week ---\n' "$HDG"
        cat "$ROT_DIR/rot-$MON.md"; printf '\n'; } >> "$ARCH_PROMPT"
    done < "$ROT_DIR/weeks.txt"

    ARCH_RESULT=""
    if sr_call_haiku "$ARCH_PROMPT" ARCH_RESULT consolidate; then
      # accept only an answer whose "## " headings are EXACTLY the requested ones (each once): anything else fails closed
      GOT_HEADS=$(printf '%s\n' "$ARCH_RESULT" | awk '/^## /')
      if [[ -n "$GOT_HEADS" && "$(printf '%s\n' "$GOT_HEADS" | LC_ALL=C sort)" == "$(LC_ALL=C sort "$ROT_DIR/expected.txt")" ]]; then
        ARCH_BODY=$(printf '%s\n' "$ARCH_RESULT" | awk '/^## /{ f=1 } f')
        if [[ -s "$SR_ARCHIVE" ]]; then
          [[ -z "$(tail -c1 "$SR_ARCHIVE")" ]] || printf '\n' >> "$SR_ARCHIVE"   # a last line without a newline
          printf '\n' >> "$SR_ARCHIVE"                                             # blank line between weeks
        fi
        printf '%s\n' "$ARCH_BODY" >> "$SR_ARCHIVE"
        # history is rewritten only now that the archive holds the rotated weeks
        cat "$ROT_DIR/keep.md" > "$SR_HISTORY.rot.$$" && mv "$SR_HISTORY.rot.$$" "$SR_HISTORY"
        sr_info "consolidate: archived ${NW} week(s); history keeps the newest ${SR_HISTORY_MAX_ENTRIES} entries and any week still in progress"
        log_obs INFO consolidate.sh "archive rotation complete (${NW} week(s) archived)" 2>/dev/null || true
      else
        sr_warn "consolidate: archive answer did not match the requested week headings — history and archive unchanged"
        log_obs WARN consolidate.sh "archive rotation: answer did not match the requested headings — history and archive unchanged" 2>/dev/null || true
      fi
    else
      sr_warn "consolidate: archive rotation Haiku failed"
      log_obs ERROR consolidate.sh "archive rotation: Haiku call failed" 2>/dev/null || true
    fi
    rm -f "$ARCH_PROMPT" 2>/dev/null || true
  fi
  rm -rf "$ROT_DIR" 2>/dev/null || true
fi

sr_info "consolidate: done"
