#!/usr/bin/env bash
# common.sh — Shared config and utilities for session-remember hooks (GLOBAL)
# Sourced by start.sh, trigger.sh, save.sh, consolidate.sh
# Works for any project — derives all paths from $CLAUDE_PROJECT_DIR
# shellcheck disable=SC2034  # Variables are intentionally defined for use by sourcing scripts

[[ -n "${_SR_COMMON_LOADED:-}" ]] && return 0
readonly _SR_COMMON_LOADED=1

set -euo pipefail
umask 077  # session files contain conversation content — restrict to owner only

# ── Centralized observability (log_obs → ~/.claude/logs/hooks-errors.log) ────
_SR_HOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck disable=SC1091
source "$_SR_HOOKS_DIR/log-helpers.sh" 2>/dev/null || true

# ── Logging (defined first so other sections can use it) ──────────────────────
_sr_log() {
  local level="$1"; shift
  printf '%s [session-remember] [%s] %s\n' "$(date -Iseconds)" "$level" "$*" >&2
}

sr_info()  { _sr_log "info"  "$@"; }
sr_warn()  { _sr_log "warn"  "$@"; }
sr_error() { _sr_log "error" "$@"; }

# ── Global toggles ────────────────────────────────────────────────────────────
# File-presence kill switches — independent of project and blacklist.
# DISABLED: touch this file → no load, no capture (full silence)
# READONLY: touch this file → load prior context but skip capture
_SR_DISABLED_FILE="$HOME/.claude/hooks/session-remember/DISABLED"
_SR_LEAN_DISABLED_FILE="${_SR_DISABLED_FILE}.lean"
_SR_READONLY_FILE="$HOME/.claude/hooks/session-remember/READONLY"

sr_is_disabled() { [[ -f "$_SR_DISABLED_FILE" ]] || [[ -f "$_SR_LEAN_DISABLED_FILE" ]]; }
sr_is_readonly()  { [[ -f "$_SR_READONLY_FILE" ]]; }

if sr_is_disabled; then
  sr_info "DISABLED toggle active — session-remember fully off"
  return 1 2>/dev/null || exit 0
fi

if sr_is_readonly; then
  sr_info "READONLY toggle active — context will load, no capture"
  SR_READONLY=1
fi

# ── Path derivation ───────────────────────────────────────────────────────────
# Graceful handling: if CLAUDE_PROJECT_DIR is not set, return 1 so the sourcing
# script can exit cleanly (e.g., `source common.sh || exit 0`)
PROJECT_DIR="${CLAUDE_PROJECT_DIR:-}"
if [[ -z "$PROJECT_DIR" ]]; then
  sr_warn "CLAUDE_PROJECT_DIR not set — session-remember disabled for this session"
  return 1 2>/dev/null || exit 0
fi

# _SR_PROJECT_SLUG is the pipeline's IDENTITY slug. It names this project's own
# memory store and is the key both `blacklist` and `readonly-list` are matched
# against — the same `tr '/' '-'` form the six gate-bypass families use. It must
# NEVER be used to locate Claude Code's transcripts: Claude Code collapses '.' to
# '-' as well, so for a dotted path (~/.claude) the two disagree and this one is
# wrong. Changing this line orphans every memory dir and every blacklist entry.
# Transcripts come from SESSION_STORE below. See SPEC.md §6-20.
_SR_PROJECT_SLUG="$(echo "$PROJECT_DIR" | tr '/' '-')"
MEMORY_DIR="$HOME/.claude/projects/${_SR_PROJECT_SLUG}/memory"
SESSION_DIR="$MEMORY_DIR/sessions"
STATE_DIR="$SESSION_DIR/.state"

# SESSION_STORE is where Claude Code keeps this session's transcripts — foreign
# territory, so we do not compute it. Every hook payload carries `transcript_path`
# (verified 2026-09-02 on PostToolUse, incl. from inside subagents, where it still
# points at the top-level parent transcript); each entry script exports it as
# SR_TRANSCRIPT_PATH before sourcing this file.
#
# Fallback: a caller with no hook-payload ancestor — i.e. a human running
# `bash save.sh <sid>` by hand. For projects whose path has no dot (all of /path/to/your/project)
# the slug derivation IS correct, which is why the pipeline worked there for
# years. For dotted paths it is the §6-20 bug, so the fallback is announced. It is
# deliberately loud: silence is what hid this failure for months.
if [[ -n "${SR_TRANSCRIPT_PATH:-}" ]]; then
  SESSION_STORE="$(dirname "$SR_TRANSCRIPT_PATH")"
else
  SESSION_STORE="$HOME/.claude/projects/${_SR_PROJECT_SLUG}"
  sr_warn "no transcript_path in payload — falling back to slug derivation (${SESSION_STORE}); wrong for dotted project paths, see SPEC.md §6-20"
  log_obs WARN common.sh "transcript_path absent; SESSION_STORE fell back to slug derivation for ${PROJECT_DIR}" 2>/dev/null || true
fi

# ── Blacklist check ───────────────────────────────────────────────────────────
# If ~/.claude/hooks/session-remember/blacklist exists, skip projects listed there.
# Format: one project slug per line (e.g., "-tmp" or "-home-user-scratch")
_SR_BLACKLIST_FILE="$HOME/.claude/hooks/session-remember/blacklist"
if [[ -f "$_SR_BLACKLIST_FILE" ]]; then
  while IFS= read -r _bl_slug || [[ -n "$_bl_slug" ]]; do
    # Skip comments and blank lines
    [[ "$_bl_slug" =~ ^[[:space:]]*#.*$ || -z "${_bl_slug// }" ]] && continue
    if [[ "$_SR_PROJECT_SLUG" == "$_bl_slug" ]]; then
      sr_info "project ${_SR_PROJECT_SLUG} is blacklisted — session-remember disabled"
      return 1 2>/dev/null || exit 0
    fi
  done < "$_SR_BLACKLIST_FILE"
fi

# ── Per-project readonly-list check ──────────────────────────────────────────
# If a project slug appears in readonly-list, set SR_READONLY=1 (load, no capture).
# Complements the global READONLY toggle; does not abort the pipeline.
# Format: one project slug per line — same as blacklist.
_SR_READONLY_LIST_FILE="$HOME/.claude/hooks/session-remember/readonly-list"
sr_is_readonly_project() {
  [[ -f "$_SR_READONLY_LIST_FILE" ]] || return 1
  while IFS= read -r _rl_slug || [[ -n "$_rl_slug" ]]; do
    [[ "$_rl_slug" =~ ^[[:space:]]*#.*$ || -z "${_rl_slug// }" ]] && continue
    [[ "$_SR_PROJECT_SLUG" == "$_rl_slug" ]] && return 0
  done < "$_SR_READONLY_LIST_FILE"
  return 1
}
if sr_is_readonly_project; then
  sr_info "project ${_SR_PROJECT_SLUG} in readonly-list — context loads, no capture"
  SR_READONLY=1
fi

# ── Session data files ────────────────────────────────────────────────────────
SR_HANDOFF="$SESSION_DIR/handoff.md"
SR_BUFFER="$SESSION_DIR/buffer.md"
SR_TODAY="$SESSION_DIR/today.md"
SR_HISTORY="$SESSION_DIR/history.md"
SR_ARCHIVE="$SESSION_DIR/archive.md"

# ── State files ───────────────────────────────────────────────────────────────
SR_LAST_SAVE="$STATE_DIR/last-save.json"
SR_LAST_NDC="$STATE_DIR/last-ndc-ts"
SR_LOCK="$STATE_DIR/save.lock"
SR_PID="$STATE_DIR/save.pid"

# ── Tunable config (override via env vars) ────────────────────────────────────
SR_SAVE_COOLDOWN="${SR_SAVE_COOLDOWN:-120}"       # seconds between saves
SR_NDC_COOLDOWN="${SR_NDC_COOLDOWN:-3600}"        # seconds between NDC compressions
SR_MIN_HUMAN="${SR_MIN_HUMAN:-3}"                 # min human messages before saving
SR_DELTA_THRESHOLD="${SR_DELTA_THRESHOLD:-50}"    # JSONL lines delta to trigger save
SR_SKIP_BACKOFF="${SR_SKIP_BACKOFF:-300}"         # seconds trigger.sh waits after save.sh skipped a session (too few human msgs / 0 exchanges)
[[ "$SR_SKIP_BACKOFF" =~ ^[0-9]{1,9}$ ]] || SR_SKIP_BACKOFF=300   # it reaches (( )) in trigger.sh: a non-number must not run as an expression
SR_TZ="${SR_TZ:-${TZ:-{{TZ}}}}"  # machine-specific: set SR_TZ in env to override (bundle default: {{TZ}})
SR_HISTORY_MAX_ENTRIES="${SR_HISTORY_MAX_ENTRIES:-10}"
# Model per call class (model-assignment audit D6, 2026-09-29; defaults reverted to haiku by D12.3, same day). Precedence: class knob > the user's override table > SR_MODEL (when set) > class default.
# SR_MODEL stays the documented global override, so setting it still changes every class it does not have its own knob for.
# These calls run headless, so nothing can ask which model to use: the default IS the decision, and a class knob is how to raise one class.
# The user's override table (state/model-overrides.json, hooks section — bin/model-override.sh) sits BETWEEN the class knob and SR_MODEL:
# env class knob > table > SR_MODEL > default. Nothing when the table is absent or invalid (strict, whole file), so the default holds.
_SR_MO="$(dirname "${BASH_SOURCE[0]}")/../../bin/model-override.sh"   # plain string work: a `cd … && pwd` on a missing bin/ fails inside the assignment and kills a set -e caller
_sr_table_model() { [[ -f "$_SR_MO" ]] || return 0; bash "$_SR_MO" get hook "$1" 2>/dev/null; }
SR_MODEL_BULK="${SR_MODEL_BULK:-$(_sr_table_model session-remember.bulk)}"
SR_MODEL_BULK="${SR_MODEL_BULK:-${SR_MODEL:-claude-haiku-5-5}}"                # save.sh summaries + NDC compress (84-126 calls/day, measured 2026-09-25..29 from logs/session-remember.log)
SR_MODEL_CONSOLIDATE="${SR_MODEL_CONSOLIDATE:-$(_sr_table_model session-remember.consolidate)}"
SR_MODEL_CONSOLIDATE="${SR_MODEL_CONSOLIDATE:-${SR_MODEL:-claude-haiku-5-5}}"  # daily rollup + weekly archive: they REWRITE history.md / archive.md
# (the handoff class, SR_MODEL_HANDOFF, is read by precompact-handoff.sh, which does not source this file)
SR_MODEL="${SR_MODEL:-claude-haiku-5-5}" # global override; also the bulk default (a dateless ID is a pinned snapshot since 4.6: bump it per release; Haiku 5.5 since 2026-10-08)

# ── Directory bootstrap ───────────────────────────────────────────────────────
sr_ensure_dirs() {
  mkdir -p "$SESSION_DIR" "$STATE_DIR"
  [[ -f "$STATE_DIR/source-path" ]] || echo "$PROJECT_DIR" > "$STATE_DIR/source-path"
}

# ── Timezone-aware date helpers ───────────────────────────────────────────────
sr_today() { TZ="$SR_TZ" date '+%Y-%m-%d'; }
sr_now()   { TZ="$SR_TZ" date '+%H:%M'; }

# ── Read a field from last-save.json (jq-based, no Python) ───────────────────
sr_last_save_field() {
  local field="$1" default="${2:-}"
  if [[ -f "$SR_LAST_SAVE" ]]; then
    # .[$f] // $d: returns $d for null/missing fields (jq 'empty' exits 0 with no
    # output, so the bash || fallback would never fire for missing-field cases).
    jq -r --arg f "$field" --arg d "$default" '.[$f] // $d' "$SR_LAST_SAVE" 2>/dev/null || echo "$default"
  else
    echo "$default"
  fi
}

# ── Write last-save.json ──────────────────────────────────────────────────────
sr_write_last_save() {
  local session="$1" line="$2"
  # `positions` is a bounded, newest-first history of {session,line,ts}. The top-level
  # session/line stay as they were for back-compatibility, but they are a SINGLE slot:
  # whichever session saved last owns them, so without this history a session's position
  # was lost the moment another session saved, and extract.py:68 then restarted it at
  # line 0. That is what made start.sh's missed-session recovery re-extract the same
  # transcript on every SessionStart. SPEC §6-23.
  local prev='[]'
  if [[ -f "$SR_LAST_SAVE" ]]; then
    prev=$(jq -c '.positions // []' "$SR_LAST_SAVE" 2>/dev/null) || prev='[]'
    [[ -n "$prev" ]] || prev='[]'
  fi
  jq -n \
    --arg  session   "$session" \
    --argjson line   "$line" \
    --argjson ts     "$(date +%s)" \
    --argjson prev   "$prev" \
    '{"session": $session, "line": $line, "timestamp": $ts,
      "positions": ([{session: $session, line: $line, ts: $ts}]
                    + ($prev | map(select(.session != $session))))[0:100]}' \
    > "$SR_LAST_SAVE"
}

# True when <session-id> has a recorded save position — i.e. it has already been captured
# at least once, whether or not it is the most recent save. start.sh's recovery gate needs
# this: comparing against the single top-level `.session` re-fires recovery for the same
# missed session on every SessionStart once the current session has saved anything.
sr_has_saved_session() {
  local sid="$1"
  [[ -n "$sid" && -f "$SR_LAST_SAVE" ]] || return 1
  jq -e --arg s "$sid" \
    '(.session == $s) or ((.positions // []) | any(.session == $s))' \
    "$SR_LAST_SAVE" >/dev/null 2>&1
}

# ── Call Haiku (sandboxed: cwd=~/.claude/llm-sandbox, no tools, max-turns 1) ─────
# Usage: sr_call_haiku <prompt_file> <result_varname> [bulk|consolidate]   (class defaults to bulk; picks the model)
# Returns 0 on success, 1 on failure.
# --no-session-persistence: nothing reads these transcripts (~60 MB/day of them).
# GS_NO_AUTO_HANDOFF=1: the child's own Stop event must not make stop-context-bar.sh
# fire an auto-handoff for the sandbox cwd — a second Haiku call per call (~900 of them
# by 2026-09-27; review-remediation WS6.1). It is the "headless side call" marker for
# three hooks, not one: stop-context-bar.sh (no handoff, silent missing transcript, no
# permission-mode file), session-start-banner.sh (not a main session — the sandbox is inside
# the $HOME repo — and no per-session files or plan pointer) and stop-git-status.sh (no
# refresh, which overwrote the global banner with the sandbox's git view; row 56).
sr_call_haiku() {
  local prompt_file="$1"
  local -n _sr_result_ref="$2"
  local class="${3:-bulk}" model
  case "$class" in consolidate) model="$SR_MODEL_CONSOLIDATE" ;; *) model="$SR_MODEL_BULK" ;; esac

  if [[ ! -f "$prompt_file" ]]; then
    sr_error "prompt file not found: $prompt_file"
    return 1
  fi

  local raw attempt
  for attempt in 1 2 3; do
    raw=$(cd "$HOME/.claude/llm-sandbox" && GS_NO_AUTO_HANDOFF=1 timeout 90 claude -p \
      --model "$model" \
      --max-turns 1 \
      --output-format json \
      --tools "" \
      --no-session-persistence \
      < "$prompt_file" 2>/dev/null) && break
    [[ $attempt -lt 3 ]] && sr_warn "Haiku call failed (attempt ${attempt}/3), retrying in $(( attempt * 2 ))s" && sleep $(( attempt * 2 ))
    [[ $attempt -eq 3 ]] && { sr_error "Haiku call failed after 3 attempts"; return 1; }
  done

  _sr_result_ref=$(echo "$raw" | jq -r '.result // empty' 2>/dev/null | sed '/^[[:space:]]*$/d')
  [[ -n "$_sr_result_ref" ]]
}
