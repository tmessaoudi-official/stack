#!/usr/bin/env bash
# cert-schedule.sh — sourced helper: find a project's certification schedule (CLAUDE.md § Mode).
#
# In autonomous mode the certification tier (advisor / panel / both, and when) is asked ONCE per
# project and stored in ~/.claude/projects/<slug>/certification-schedule (first line = the answer).
# Two consumers must agree on which file that is, or one re-asks what the other already knows:
#   hooks/session-start-banner.sh (prints it at start/compact/resume)
#   bin/project-state.sh          (/next and /progress: identity.certification_schedule)
#
# The bypass that makes a session autonomous is TREE-scoped (recursive rules), so the schedule is
# project-scoped too: the lookup walks UP from cwd to the project root, nearest file wins. An
# exact-cwd lookup re-asked after every compact that followed a `cd` into a subdirectory.
# Safe under `set -euo pipefail` (every test is inside an `if`); defines functions only.

# cert_schedule_root <cwd> → project root. Same clamp as bin/project-state.sh: the git toplevel,
# except that $HOME is itself a repo on this machine, so a toplevel of $HOME means ~/.claude when
# cwd is under it, else cwd.
cert_schedule_root() {
  local cwd="$1" top
  if top=$(git -C "$cwd" rev-parse --show-toplevel 2>/dev/null); then
    if [[ "$top" == "$HOME" ]]; then
      case "$cwd" in "$HOME/.claude"|"$HOME/.claude"/*) printf '%s\n' "$HOME/.claude" ;; *) printf '%s\n' "$cwd" ;; esac
    else
      printf '%s\n' "$top"
    fi
  else
    printf '%s\n' "$cwd"
  fi
}

# cert_schedule_file <dir> → the schedule path for that directory's slug (/ → -, the hooks rule).
cert_schedule_file() { printf '%s/.claude/projects/%s/certification-schedule\n' "$HOME" "${1//\//-}"; }

# cert_schedule_find <cwd> <root> → prints "<value>\t<file>" for the nearest non-empty schedule
# from cwd up to root (inclusive); returns 1 when none. A cwd outside root checks cwd only.
cert_schedule_find() {
  local d="$1" root="$2" f v=""
  while :; do
    f=$(cert_schedule_file "$d")
    # -r: an unreadable file is skipped like an absent one, so the walk still reaches the root's
    # answer (without it, the failed redirect left v unset and set -u aborted the whole lookup)
    if [[ -f "$f" && -r "$f" ]]; then
      IFS= read -r v < "$f" || true   # read returns 1 on a last line without newline; v is still set
      v="${v#"${v%%[![:space:]]*}"}"; v="${v%"${v##*[![:space:]]}"}"
      if [[ -n "$v" ]]; then printf '%s\t%s\n' "$v" "$f"; return 0; fi
    fi
    if [[ "$d" == "$root" || "$d" != "$root"/* ]]; then return 1; fi
    d=$(dirname "$d")
  done
}
