#!/usr/bin/env bash
# stop-failure-notify.sh - StopFailure hook (row 26zp, AGREED 2026-10-16 19:30): say so when a turn dies on an API error.
# Claude Code fires StopFailure INSTEAD of Stop when a turn ends on an API error (after its own retries), so keep-going's Stop
# hook never sees it and an unattended run just sits there. This hook cannot resume the turn: Claude Code ignores its output and
# exit code except `terminalSequence`. It tells the user, through three channels:
#   1. an ERROR line in hooks-errors.log: `stopfailure <type> project=<basename of cwd> sid=<first 8>` (Rule 13)
#   2. a desktop popup (notify-send, when installed; capped at 3 s by timeout) and a terminal notification: {"terminalSequence": OSC 777 notify} -
#      Claude Code writes it only in an interactive session with its interface on screen
#   3. opt-in phone push: CLAUDE_STOPFAILURE_NTFY_URL=https://<host>[:port]/<topic> in Claude Code's environment POSTs
#      "<type> in <project>" to that ntfy topic (curl, 5 s cap). Nothing else is ever sent: never error_details, never the
#      last assistant message. Any other URL shape is refused and logged.
# Values are sanitized: the type must match ^[a-z_]{1,40}$ (else `unknown`), the project keeps [A-Za-z0-9._-] (40 chars), so
# no `;` ESC or BEL reaches the OSC fields. STOPFAILURE_NOTIFY_OFF=1 at launch turns it off. Always exits 0.
# Registered by bin/stop-failure-apply.sh (user-run: settings.json is protected). Tests: hooks/tests/test-stop-failure-notify.sh.
set -uo pipefail
export LC_ALL=C   # byte-wise sanitizers: under a UTF-8 locale [a-z] matches accented letters (milestone panel C-P3-3)
[[ "${STOPFAILURE_NOTIFY_OFF:-}" == 1 ]] && exit 0
source "${BASH_SOURCE[0]%/*}/log-helpers.sh" 2>/dev/null || log_obs() { :; }

IN=$(cat)
field() { jq -r --arg k "$1" '.[$k] // "" | tostring' <<<"$IN" 2>/dev/null; }   # one call per field: an empty or multi-line value never shifts another
if ! err=$(field error) || ! cwd=$(field cwd) || ! sid=$(field session_id); then
  log_obs ERROR stop-failure-notify "unreadable payload (not a JSON object)" 2>/dev/null || true
  exit 0
fi
[[ "$err" =~ ^[a-z_]{1,40}$ ]] || err=unknown
while [[ "$cwd" == */ ]]; do cwd="${cwd%/}"; done
proj=$(printf '%s' "${cwd##*/}" | tr -cd 'A-Za-z0-9._-' | head -c 40)
[[ -n "$proj" ]] || proj=unknown
sid=$(printf '%s' "$sid" | tr -cd 'A-Za-z0-9-' | head -c 8)
body="$err in $proj"
log_obs ERROR stop-failure-notify "stopfailure $err project=$proj sid=$sid" 2>/dev/null || true

# Bounded: the hook has a 10 s budget and a wedged notification daemon must not eat it (curl below has 5 s). No `timeout` on PATH ->
# no popup rather than an unbounded call; the log line and the terminal sequence still go out.
if command -v notify-send >/dev/null 2>&1 && command -v timeout >/dev/null 2>&1; then
  timeout 3 notify-send --urgency=critical "Claude stopped" "$body" >/dev/null 2>&1 || true   # no display (ssh, headless) or cut off: nothing to show
fi

url="${CLAUDE_STOPFAILURE_NTFY_URL:-}"
if [[ -n "$url" ]]; then
  if [[ "$url" =~ ^https://[A-Za-z0-9.-]+(:[0-9]{1,5})?/[A-Za-z0-9_-]{1,64}$ ]]; then
    curl -fsS --max-time 5 -H "Title: Claude stopped" -H "Tags: warning" -d "$body" "$url" >/dev/null 2>&1
    rc=$?
    if (( rc == 0 )); then
      log_obs INFO stop-failure-notify "ntfy push sent ($err)" 2>/dev/null || true
    else
      log_obs ERROR stop-failure-notify "ntfy push failed (curl $rc)" 2>/dev/null || true
    fi
  else
    log_obs ERROR stop-failure-notify "ntfy url refused (want https://<host>[:port]/<topic>)" 2>/dev/null || true
  fi
fi

jq -nc --arg s "$(printf '\033]777;notify;Claude stopped;%s\007' "$body")" '{terminalSequence: $s}'
exit 0
