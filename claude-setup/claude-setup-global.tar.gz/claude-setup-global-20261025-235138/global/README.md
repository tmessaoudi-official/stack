# Claude Code Setup — Replication Guide

This `~/.claude/` directory is structured so that **most of it is portable**. This README
tells you what to copy as-is, what to adapt per machine, and what to strip.

The setup evolved over 10+ sprints and combines: a domain-agnostic reasoning framework,
a custom session-remember pipeline (replaces the broken remember plugin), tiered
permissions with destructive-command protocol, memory kill-switches, and a pattern for
per-project specialist agents.

---

## Quick replication (recommended)

**Trust model**: this machine (`~/.claude/`) is the **origin** — the only place where the
authoring tools live (`claude-export.sh`, `claude-adapt.sh`, `claude-import.sh`). Target machines
and projects are **consumers** — they receive only the installed config, not the authoring tools.
Targets cannot re-export; the bootstrapper self-destructs after install.

### To another project (same or different machine)

```bash
# On origin — create a project seed archive (auto-scrubbed):
~/.claude/bin/claude-export.sh --scope project --target /path/to/new-project

# On target — extract and install:
tar -xzf claude-setup-project-<ts>.tar.gz
cd claude-setup-project-<ts>/
bash ./claude-import.sh --target /path/to/new-project
```

### To another computer (global config + optional project)

```bash
# On origin — bundle global config:
~/.claude/bin/claude-export.sh --scope global

# Both scopes at once (two separate archives):
~/.claude/bin/claude-export.sh --scope all

# On target — extract and run the bootstrapper:
tar -xzf claude-setup-global-<ts>.tar.gz
cd claude-setup-global-<ts>/
bash ./claude-import.sh
```

If `~/.claude/` **already exists** on the target, the importer **refuses to overwrite** — it prints
a detailed manual-merge guide and exits with code 2. Follow the guide to cherry-pick what you want.

After a fresh global install:
```bash
cp ~/.claude/settings.json.template ~/.claude/settings.json   # activate settings (edit to fit)
chmod +x ~/.claude/hooks/*.sh                                 # activate hooks
```
Open a Claude Code session: `/memory-status` (should report "NORMAL"), then `/audit --quick` (verifies command coverage and hook wiring).

**Slash commands** (inside a Claude Code session):
- `/bundle` — bundle config into a portable `.tar.gz`; `--scope project` (default) LLM-generalizes the current project's CLAUDE.md + .claude/ into a rich ADAPT-marker template; `--scope global` exports `~/.claude/` as-is via bash; `--scope all` produces both archives
- `/install` — install a bundle: Phase 0 detects conflicts (asks replace/manual-merge before overwriting); bash installer runs; Phase 5 probes target + fills ADAPT markers in-place
- `/bootstrap` — probe current project + write tailored config (with confirmation)

### Manual replication (alternative)

If you prefer doing it by hand, see the "Adapt per machine" checklist below. The steps
mirror what `claude-adapt.sh` automates — timezone, settings review, first-session verify.

---

## Directory map — what's generic vs specific

### Always generic (copy as-is)

| Path | Purpose |
|---|---|
| `CLAUDE.md` (above "Specific to this computer setup") | Domain-agnostic reasoning framework: task categorization, 33 mental models, 8-phase workflow, memory toggle docs, destructive-command protocol |
| `skills/handoff/SKILL.md` | `/handoff` — write session handoff note |
| `skills/memory-off/SKILL.md` | `/memory-off` — disable memory (load+capture) |
| `skills/memory-on/SKILL.md` | `/memory-on` — re-enable memory |
| `skills/memory-readonly/SKILL.md` | `/memory-readonly` — load context only, no capture |
| `skills/memory-status/SKILL.md` | `/memory-status` — report memory state |
| `skills/bundle/SKILL.md` | `/bundle` — bundle config; `--scope project` LLM-generalizes current project into ADAPT template; `--scope global` exports `~/.claude/` via bash |
| `skills/install/SKILL.md` | `/install` — install bundle; Phase 0 conflict detection; Phase 5 probes + fills ADAPT markers in target project |
| `skills/adapt-project/SKILL.md` | `/adapt-project` — fill ADAPT markers left by `/install`; LLM-driven; project bundle copy self-destructs after all markers filled |
| `skills/bootstrap/SKILL.md` | `/bootstrap` — probe project + write tailored Claude Code config from scratch |
| `skills/repair/SKILL.md` | `/repair` — detect and repair drift in a fully-filled config (no markers) |
| `skills/inspect/SKILL.md` | `/inspect` — project health inspector (10 parallel agents, P0-P3 severity) |
| `hooks/session-remember/` | 7-script pipeline: `start.sh`, `trigger.sh`, `save.sh`, `consolidate.sh`, `common.sh`, plus 3 Haiku prompt files in `prompts/` |
| `hooks/session-remember/DISABLED` | (absent by default) kill switch — touch to silence memory globally |
| `hooks/session-remember/READONLY` | (absent by default) read-only toggle |
| `hooks/session-remember/blacklist` | (optional) per-project opt-out, one slug per line |
| `hooks/ask-bash-firewall.sh` | PreToolUse Bash — **v3 boundary gate** (2026-08-29): resolves every mutate/read/net target of a command and tiers it by blast radius (inside the project root / SAFE zones silent · outside ask · host-critical + credential stores deny · Claude self-mod paths ask). **Needs python3** (fails closed without it). Per-repo overrides: `<root>/.claude/boundary.json`. An fw grant at **level total** (rule `"level":"total"` or sentinel content `total`) makes it never ask — only its deny floor refuses. Suite: `hooks/tests/test-bash-firewall.sh` (934 cases, ~7 min under load) |
| `hooks/ask-human-gate-{arm,block,track}.sh`, `hooks/ask-human-question-guard.sh` | The ask-human gate (one `AskUserQuestion` before tool use on every new prompt) and the end-of-turn free-text-question guard |
| `hooks/advisor-prework-guard.sh`, `hooks/advisor-completion-guard.sh` | Phase 3C / 6C evidence guards (PreToolUse Edit\|Write, Stop) — block implementation without visible 3C evidence and completion claims without an `advisor()` call |
| `hooks/statusline.sh`, `hooks/stop-context-bar.sh`, `hooks/session-start-banner.sh` | Two-line statusline, items separated by ` │ `, fitted to the terminal width (`COLUMNS`): long names are shortened in the middle, then labels, then the right end spills to a `↳` line - nothing is cut. Line 1 = the meters (model + effort, context, usage, cache, cwd + git + `⚠ git-lock`, agent, cost, lines, turns), then the session tail (uptime, Σ lifetime, handoff age, CLAUDE.md/analysis flags); line 2 = warnings, most severe first (`⚠⚠⚠ BYPASS` (bypassPermissions, fed by `run/permission-mode-<sid>`), `⚠⚠⚠ PERM-OPEN`, `⚠⚠ UNATTENDED(<mode>,<time>)`, `AUTO-3C`, the gates group `⚠ bypassed ah fw! (rule) ⏳2h`, `⚠ PERM-PROJ`, `MODELS`, `⚠ ADVISOR(<configured>→<attached|off>)`), then the working state (mode `spec`/`autonomous`[`+cf`], keep-going with `↻n/<cap>` while it is continuing a stop, `advisor <model>[✓|✗code|?]` or `off`, `plan <topic>@<repo|global>`, review, expertise, memory mode). Gate answers are cached per session in `run/statusline-gates-<sid>` (docs/SPEC.md §2.6) |
| `hooks/skill-invocation-log.sh` | PreToolUse `Skill` + UserPromptSubmit — appends one tab-separated line (time, `model` or `typed`, skill name, cwd) to `logs/skill-invocations.log` (never args, prints nothing). Both events needed: a typed `/name` never produces a `Skill` tool_use. The count framework-v2 P4 asked for. Registered by a user-run step. Suite: `hooks/tests/test-skill-invocation-log.sh` (13) |
| `hooks/plan-write-check.sh` | PostToolUse Edit/Write, warn-only — a `*.plan.md` written outside its Rule 17 location, or a NEW Decisions-Log bullet stamped more than 5 min off the clock or below a newer one (a Write flags future stamps only). Reaches Claude via `additionalContext`. Registered by a user-run step (settings.json). Suite: `hooks/tests/test-plan-write-check.sh` (22) |
| `bin/permission-swap.sh`, `bin/permission-swap-project.sh`, `bin/lib/permission-swap-common.sh` | Sentinel-controlled on/off for Claude Code's native `settings.json` permission engine — `on` empties `permissions.ask`/`.deny` (global) or adds a broad `allow` set to the current project's `settings.local.json` (project, convenience-only); `off` restores exactly. Suite: `bin/tests/permission-swap.test.sh` |
| `templates/project-{settings,boundary,progress}.json` | Project-tier templates `/bootstrap` copies into a repo's `.claude/` (bare `Bash` allow; `protected[]`/`trusted_outside[]`; the `/progress` adapter — cursor files, registers, targeted `test_cmd`, `shas_unstable`) |
| `bin/project-state.sh` | Deterministic collector behind `/progress`, `/next`, `/goal-brief` — one JSON document from the plan's `## Status` block, git, session-remember files, registers, TODO markers, test records and the per-repo ledger; read-only except explicit write subcommands. Seven are `flock`-serialized on the per-repo lock (`--persist`, `--record-test`, `--init-block`, `--splice-block`, `--append-ledger`, `--refresh-handoff`, `--write-goal`); `--set-active-plan` deliberately is **not** — it writes `run/active-plan-<session_id>`, which lives outside `PROGRESS_DIR` and is keyed per session, so no two sessions can contend for it and the lock would guard nothing. State lives in `projects/<root-slug>/progress/` (`reports/` + `tests/` gitignored keep-10; `ledger.ndjson` + `goal.md` tracked). Suite: `bin/tests/project-state.test.sh` |
| `progress.json` | Home-repo adapter for `bin/project-state.sh` (machine-local, not bundled; the adapter path rule puts it at the root when the root is `~/.claude` itself) |

> **Origin-only tools** (not included in exported bundles, only on this machine):
> `skills/bundle/SKILL.md`,
> `bin/claude-export.sh` + `bin/lib/claude-export/`,
> `bin/claude-import.sh` + `bin/lib/claude-import/`
>
> Note: `bin/claude-adapt.sh` + `bin/lib/claude-adapt/` **are** included in the global bundle — targets need them to run `/adapt-project`. They self-destruct on the target after all ADAPT markers are resolved.

### Generic structure, machine-specific content

| Path | What to adapt |
|---|---|
| `settings.json` | `enabledPlugins` depends on what you've installed. The `permissions.allow/deny/ask` tiers are designed to be copy-safe (no machine-specific paths), but inspect the MCP tool entries — delete entries for tools you don't have. Model (`opusplan`) is a preference. |

### Specific to this computer setup (strip or adapt)

| Path | What it is | Action when replicating |
|---|---|---|
| `CLAUDE.md` → "Specific to this computer setup" section | Machine-specific notes (currently: timezone + a pointer to per-project routing configs) | **Edit**: update timezone; remove or replace example project paths. Keep the four whole-line `@` includes at its end (`@RTK.md`, `@RTK-local.md`, `@THINKING.md`, `@BLAST-RADIUS.md`): they load those files every session, and `bin/ruling-drift.sh` checks them. |

Note: project-specific agents live with their project (e.g. the reviewer agents in
`/path/to/your/project/.claude/agents/`), not in `~/.claude/agents/`. That's the pattern to prefer —
project-specific agents in the project, global agents here.

### MCP backends — requires local setup

| Path | Purpose |
|---|---|
| `mcp/<mcp-client-1>/docker-compose.yaml` | Jira + Confluence MCP containers (`restart: unless-stopped`) |
| `mcp/<mcp-client-1>/jira.env` | Jira credentials (mode 600) — fill in after install |
| `mcp/<mcp-client-1>/confluence.env` | Confluence credentials (mode 600) — fill in after install |
| `mcp/<mcp-client-1>/gitlab.env` | GitLab token (mode 600) — loaded by `gitlab-mcp-wrapper.sh` at runtime |
| `mcp/<mcp-client-1>/gitlab-mcp-wrapper.sh` | Wrapper that sources `gitlab.env` before starting the stdio MCP |
| `hooks/ensure-mcp-health.sh` | SessionStart hook — warns if Jira/Confluence ports are unreachable **while the ACME compose stack is running**; silent when it is idle (its normal state — the kit is kept for other clients) and in headless side calls |

All `*.env` files are bundled with `CHANGE_ME_*` placeholder values (scrubbed by `sanitize.sh`).
The containers bind only to `127.0.0.1` — not exposed on external interfaces.
MCP files are organized per-client: `mcp/<client>/`. Add a new folder for each project/org.

**After install on a new machine:**
1. Fill in `mcp/<mcp-client-1>/jira.env`, `mcp/<mcp-client-1>/confluence.env`, `mcp/<mcp-client-1>/gitlab.env` with real values
2. `find ~/.claude/mcp -maxdepth 2 -name "*.env" -exec chmod 600 {} +`
3. In `~/.claude.json`, rename MCP server keys (`acme-jira-http` / `acme-confluence-http` / `acme-gitlab-stdio`) to match your org prefix
4. `docker compose -f ~/.claude/mcp/<mcp-client-1>/docker-compose.yaml up -d`
5. Verify: open a new Claude Code session — the SessionStart hook reports status

**MCP server entries in `~/.claude.json` after a fresh install (scrubbed values):**
- `acme-jira-http` → `http://127.0.0.1:8569/mcp` (no secrets — container reads from `mcp/<mcp-client-1>/jira.env`)
- `acme-confluence-http` → `http://127.0.0.1:8570/mcp` (no secrets — container reads from `mcp/<mcp-client-1>/confluence.env`)
- `acme-gitlab-stdio` → `command: ~/.claude/mcp/<mcp-client-1>/gitlab-mcp-wrapper.sh` — GITLAB_API_URL needs your instance URL

### Transient / machine-local (never copy)

| Path | Purpose |
|---|---|
| `projects/` | Per-project memory + session data (auto-generated) |
| `statsig/` | Telemetry cache |
| `cache/`, `shell-snapshots/`, `file-history/`, `paste-cache/` | Internal caches |
| `session-env/`, `sessions/`, `history.jsonl` | Session-local state |
| `ide/`, `chrome/` | IDE/browser integration caches |
| `backups/`, `tasks/`, `agent-memory/`, `plans/`, `teams/` | Ephemeral work state |
| `run/` | Per-session state (`session-cwd-*`, `status-*`, `permission-mode-*`, `active-plan-*`, `session-model-*`, `advisor-last-*`, the keep-going guard's `keep-going-{count,stopask,noask}-*` (all but `active-plan-*` — the banner reaps a dangling one — reaped >24 h by `/cleanup --run-files`; the last three families — the caches — also by the daily `--auto`), and every gate's session-scoped `<family>-bypass-<sid>` — ask-human gate, bash firewall, question guard, completion guard, prework guard, autonomous-3c — and the `<name>-<sid>` files of `expertise-gate-off`, `keep-going` and `confident-pick`, which `--run-files` neither deletes nor reports yet) — self-cleaned by the banner / `claude-cleanup.sh --run-files`; manage with `/gates-bypass`. Also `cleanup-auto.stamp` + `cleanup-auto.lock`, the gate of the daily safe sweep `claude-cleanup.sh --auto` (row 26zc; kept) |
| `state/`, `projects/<slug>/state/` | Machine-local safety state, never bundled, never auto-deleted, three shapes: presence-only guard-bypass sentinels (`<family>-bypass`, across the 6 original gate families, plus `expertise-gate-off` and the enables `keep-going` and `confident-pick` — manage with `/gates-bypass`); `state/gates-bypass-rules.json`, the payload-carrying path rules that give a bypass a recursive scope, an except-list and an expiry; and payload-carrying permission-swap sentinels (`permission-profile-permissive.json`, `permission-profile-project-added.json` — carry the saved rules `off` restores; manage with `/permission-swap` or directly via `permission-swap.sh`/`permission-swap-project.sh status`) |
| `plugins/` | Plugin installs — reinstall from marketplace |
| `policy-limits.json` | Plan/tier limits — regenerated on sign-in |

---

## Adapt per machine (checklist)

- [ ] `settings.json.template` — the installer ships this as `.template` to avoid overwriting. Review it first, then rename: `mv ~/.claude/settings.json.template ~/.claude/settings.json`. If a `settings.json` already exists, diff and cherry-pick instead.
- [ ] `settings.json` — delete `enabledPlugins` entries for plugins you haven't installed.
- [ ] `settings.json` — delete `permissions.allow` MCP tool entries for MCP servers you don't run.
- [ ] `chmod +x ~/.claude/hooks/*.sh` — make hook scripts executable (hooks silently do nothing without this).
- [ ] `CLAUDE.md` — scroll to "Specific to this computer setup". Update or remove /path/to/your/project routing. Change timezone comment if needed.
- [ ] `hooks/session-remember/common.sh` — change `SR_TZ` default if not `{{TZ}}`.
- [ ] `agents/` — check for any project-specific agents; delete or re-scope.
- [ ] Create `~/.claude/projects/` — will auto-populate as sessions run.
- [ ] First session: run `/memory-status` → should report "NORMAL".
- [ ] First session: run `/audit --quick` → verify command coverage and hook wiring.
- [ ] First session: do some work, end with `/handoff` → should write `~/.claude/projects/<slug>/memory/sessions/handoff.md`.
- [ ] `mcp/<mcp-client-1>/jira.env`, `mcp/<mcp-client-1>/confluence.env`, `mcp/<mcp-client-1>/gitlab.env` — replace all `CHANGE_ME_*` values with real credentials.
- [ ] `find ~/.claude/mcp -maxdepth 2 -name "*.env" -exec chmod 600 {} +` — lock down credential files.
- [ ] `~/.claude.json` → rename generic MCP server keys (`acme-jira-http`, `acme-confluence-http`, `acme-gitlab-stdio`) to match your org prefix.
- [ ] `~/.claude.json` → set `GITLAB_API_URL` to your GitLab instance URL (e.g. `https://gitlab.example.com/api/v4`).
- [ ] `docker compose -f ~/.claude/mcp/<mcp-client-1>/docker-compose.yaml up -d` — start Jira/Confluence backends.
- [ ] Confirm the credential-store denies survived your `settings.json` merge: `jq '.permissions.deny[] | select(test("mcp/"))' ~/.claude/settings.json` must list `Read/Edit/Bash` forms of `~/.claude/mcp/*.env` and `~/.claude/mcp/**/*.env` (they ship in the template — do not drop them). The bash firewall (`hooks/ask-bash-firewall.sh`) independently denies reads of credential stores by resolved path.
- [ ] `python3 --version` — the firewall needs it (prefer a real `/usr/bin/python3` over a pyenv shim; see `refs/PREREQUISITES.md`). Smoke: `printf '{"cwd":"/tmp","tool_input":{"command":"ls"}}' | bash ~/.claude/hooks/ask-bash-firewall.sh` must print nothing.

---

## Design principles (why it's structured this way)

1. **Generic reasoning framework lives in `~/.claude/CLAUDE.md`** — not tied to any project. Task categorization, mental models, and the 8-phase workflow apply everywhere.
2. **Specialist agents live with their project** (e.g. `/path/to/your/project/.claude/agents/stack-infra-reviewer.md`), not in `~/.claude/agents/`. Global agents — if any — go in `~/.claude/agents/` and apply everywhere. Routing rules live in each project's `CLAUDE.md`, NOT in the global framework.
3. **Session memory is file-based, not plugin-based** — the official "remember" plugin was failing silently (920 errors in one session). The custom `session-remember/` pipeline uses a 4-tier temporal structure (buffer → today → history → archive), Haiku summarization, and file-presence kill switches.
4. **Permission tier = blast radius; boundary = project root** (2026-08-29, `bash -c`/`sh -c` tier corrected 2026-08-30) — the global `~/.claude/settings.json` carries **host-tier** rules only: `deny` = host escape (sudo, dd/mkfs, pipe-to-shell, `--dangerously-skip-permissions`) + credential stores; `ask` = recoverable-but-loud (git history/force-push, publish, host packages/services/kills, docker prunes, `bash -c`/`sh -c` — moved from deny to ask on 2026-08-30, since the firewall's target-aware one-level unwrap already covers the evasion shape and the flag-anywhere deny still catches `bash -c` combined with `--dangerously-skip-permissions` — the guard-bypass sentinels, `.env` prod/staging). Everything project-local is decided per *resolved path* by the bash firewall boundary gate (`hooks/ask-bash-firewall.sh`): mutates inside the repo silent, outside ask, host-critical deny, Claude self-mod paths ask. A project's `.claude/settings.json` adds only its own footguns (`templates/project-settings.json`) and `.claude/boundary.json` its `protected[]` paths. Never add project-local verb/path rules to the global file. **Superseded 2026-09-30 (permission-engine cutover):** the `ask` and `allow` rules described here now live in the engine's `config/permission-rules.json` (sentinel asks among its `protected` rules); `settings.json` keeps only the backstop denies.
5. **Destructive commands go through a protocol, not just a deny list** — Claude must emit the exact command + backup + rollback plan before presenting (deny) or asking for confirmation (ask). See `CLAUDE.md` → "Destructive & Risky Command Protocol".
6. **Memory has five kill switches** — global `DISABLED` and `DISABLED.lean` (full silence), per-project `blacklist` (full silence), global `READONLY` and per-project `readonly-list` (load-only). Precedence: DISABLED ≡ DISABLED.lean > blacklist > READONLY ≡ readonly-list > normal. Table: `refs/SESSION-REMEMBER.md` § Kill switches.

---

## Troubleshooting

| Symptom | Check |
|---|---|
| Memory doesn't load at session start | `ls -la ~/.claude/hooks/session-remember/DISABLED` → if present, run `/memory-on`. Check `~/.claude/projects/<slug>/memory/sessions/logs/` for errors. |
| Memory loads but doesn't capture | `/memory-status` → if READONLY, run `/memory-on`. Check `SR_DELTA_THRESHOLD=50` — saves only fire after 50 JSONL lines delta. |
| `/memory-*` command fails | Check `~/.claude/settings.json` has the memory toggle Bash allow rules. |
| `/path/to/your/project/projects/` tasks pick up `/path/to/your/project`'s infra rules | Verify `/path/to/your/project/projects/.claude/settings.json` has `"claudeMdExcludes": ["/path/to/your/project/CLAUDE.md"]`. |
| Permission prompts for things that should be allowed | `jq .permissions ~/.claude/settings.json` — scan allow list. Precedence: Deny > Ask > Allow. |
| Claude writes to `~/.claude/settings.json` keep getting blocked | Expected — `settings*.json`, the guard hooks, the firewall itself, `state/**`, `~/.claude.json` and shell rc files are Claude self-mod paths: the firewall's `SELFMOD` tier asks on any Bash mutate, and the built-in classifier blocks `Edit`/`Write`. Apply permission changes manually (Claude hands you a `! bash /tmp/apply-*.sh` script). |
| Every Bash call prompts "python3 is unavailable" | The firewall fails closed without python3. Install it (`/usr/bin/python3` preferred) — `refs/PREREQUISITES.md`. Emergency off-switch: `CLAUDE_BASH_FIREWALL_OFF=1` for one launch — the only one: since 2026-09-23 `/gates-bypass --family=fw` lifts boundary friction only and does NOT skip the python3 check (the badge `FW(g)`/`FW(rule)` on statusline line 2 — remove it when done). A grant at **level total** does: an unclassifiable command is allowed there (user ruling D3, 2026-09-24). |
| Jira/Confluence MCP tools unavailable | Session start prints `[mcp-health]` warning. Start containers: `docker compose -f ~/.claude/mcp/<mcp-client-1>/docker-compose.yaml up -d`. Check `mcp/<mcp-client-1>/*.env` has real values. |
| GitLab MCP auth errors | Verify `~/.claude/mcp/<mcp-client-1>/gitlab.env` has a valid `GITLAB_PERSONAL_ACCESS_TOKEN`. Check `GITLAB_API_URL` in `~/.claude.json`. |

---

## Further reading (inside this directory)

- `~/.claude/CLAUDE.md` — the framework Claude loads on every session
- `/path/to/your/project/.claude/agents/stack-infra-reviewer.md` — example of a project-scoped specialist agent (inline-documented)
- `~/.claude/hooks/session-remember/common.sh` — shared utilities + all toggles/config in one place
- `~/.claude/hooks/session-remember/prompts/` — Haiku prompt templates (summarize, compress, consolidate)
