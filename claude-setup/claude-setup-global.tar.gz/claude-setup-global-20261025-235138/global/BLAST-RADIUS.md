# Blast-Radius Reference

> Consulted at Phase 5 entry for any destructive or risky operation.
> Core insight: blast radius is **state-dependent** — the same command can be trivial
> in one context and unrecoverable in another. Run pre-flight checks first; they cost
> 3 seconds and the consequences of skipping them can be permanent.

---

## Pre-Flight State Checks

Run the applicable checks **before** executing, not after.

### Git state gate
```bash
git status --porcelain                  # uncommitted / untracked changes?
ls .git/MERGE_HEAD 2>/dev/null          # merge in progress?
ls .git/REBASE_HEAD 2>/dev/null         # rebase in progress?
ls .git/CHERRY_PICK_HEAD 2>/dev/null    # cherry-pick in progress?
```
If **any** of those files exist: `git reset`, `git checkout`, `git stash`, `git clean`
all have doubled blast radius — they can abort the in-progress operation silently.

### Docker state gate
```bash
# Before docker compose down: does it carry -v (volumes) or --rmi (images)?
# Before docker volume rm / docker system prune: list what would be removed.
docker volume ls
docker ps -a
```

### Scope / glob gate
Before any glob (`*.sh`, `-r dir/`, `pkill -f pattern`):
```bash
echo rm *.sh          # verify expansion before rm *.sh
pgrep -a pattern      # verify matches before pkill -f pattern
```

### Protected paths — never auto-delete / never bundle
`~/.claude/state/`, `~/.claude/projects/<slug>/state/` **and `~/.claude/run/<family>-bypass-<sid>`**
hold **persistent safety sentinels**. The session scope in `run/` is listed here as of 2026-09-22;
it was documented in `docs/SPEC.md` §2.1 and `README.md` but missing from this file, which is SPEC
register item E — now closed.

`~/.claude/state/gates-bypass-rules.json` belongs to the same protected class: it carries this machine's whole map of bypassed gates, so it is never bundled (export-assertion detail: `~/.claude/.claude/rules/operator-registries.md`).

The protected set is: the bypass toggles (`ask-human-gate-bypass`, `ask-bash-firewall-bypass`,
`ask-human-question-guard-bypass`,
`advisor-completion-guard-bypass`, `advisor-prework-guard-bypass`), the persistent `autonomous-3c-bypass`,
the expertise-gate off-switch and the two enables (`expertise-gate-off`, `keep-going`, `confident-pick`, each also as `run/<name>-<sid>`),
and the payload-carrying permission-swap sentinels (`permission-profile-permissive.json`,
`permission-profile-project-added.json` — carry the saved rules `permission-swap.sh off` /
`permission-swap-project.sh off` restore). They are removed ONLY by deliberate user action. The permission engine's `config/permission-rules.json` holds a protected ask for
any Bash command that names one of them (or `gates-bypass-rules.json`) and is not a plain reader — a redirect, `cp`, `mv`, `tee`, `ln`,
an interpreter, or a heredoc script fed to one, whatever the verb; it survives an `fw` or `perm` grant at level `total` (row 26r) — and for an
Edit/Write-tool write to its path (`settings.json` keeps only the backstop denies since the 2026-09-30 cutover). The firewall also tiers every
modelled Bash mutate as a Claude self-mod path (`ask-bash-firewall.sh` v3 `SELFMOD` list — verb-aware: any mutate asks, reads stay silent), a tier
an `fw` grant at level `total` lifts. Not seen by either: a script FILE that writes one without naming it, and a name built at run time.
A bundle target has no engine: only the firewall tier applies there, for Bash, and an Edit/Write-tool write meets no permission hook (`docs/SPEC.md` §2.19). No cleanup/sweep may delete them (`claude-cleanup.sh` enforces a `*/state/*` guard in
`_cc_act`/`_cc_act_dir`) and no bundle may ship them (the export pipeline never copies `state/` and
asserts against leakage at build time; the coverage caveat is in `~/.claude/.claude/rules/operator-registries.md`).

**One carve-out inside `state/`: `~/.claude/state/model-notice/`** is not a sentinel set: `hooks/skill-model-notice.sh` prunes it itself; never delete its files by hand while a session runs (the user's model override lives there). Detail: `~/.claude/.claude/rules/operator-registries.md`.

---

## Category Reference

### Git — Context-Dependent

| Command | Hidden side effect | Dangerous context |
|---------|--------------------|-------------------|
| `git reset HEAD` / `git reset` | Removes `MERGE_HEAD`/`REBASE_HEAD`/`CHERRY_PICK_HEAD` → silently aborts in-progress op | Any in-progress merge / rebase / cherry-pick |
| `git checkout <branch>` | Silently discards uncommitted changes if conflicting | Dirty working tree |
| `git clean -fd` | Removes untracked source files, not just build artifacts | Any untracked WIP |
| `git commit --amend` | Rewrites commit hash — breaks anyone who already pulled | After `git push` |
| `git add -A` | Stages accidental deletions alongside intentional changes | Dirty tree with inadvertent deletes |
| `git fetch --prune` | Removes remote-tracking refs without warning | Shared branches deleted upstream |
| `git stash drop` | Permanent — no recycle bin | Stash contains unsaved context |

### Docker — Data Destruction

| Command | Hidden side effect | Dangerous context |
|---------|--------------------|-------------------|
| `docker compose down -v` | Destroys **all** named volumes (DBs, uploads, persistent data) — `-v` is the killer flag | Any persistent data present |
| `docker system prune` | Removes **all** unused resources across **all** projects on the host | Other projects share the daemon |
| `docker volume rm` | Permanent, instant, no confirmation | Volume holds database data |
| `docker network rm` | Disconnects **all** containers on that network simultaneously | Running containers depend on it |
| `docker rmi` | Can break containers that aren't running but reference the image | Derived or stopped containers exist |
| `docker compose down` (no `-v`) | Removes containers only — volumes preserved | Safe — kept here for contrast |

### Shell / Filesystem

| Command | Hidden side effect | Dangerous context |
|---------|--------------------|-------------------|
| `rm -rf symlink/` | Trailing `/` → deletes contents of symlink **target**, not the symlink | Target is a shared directory |
| `chmod -R 777 .` | Makes `.git/`, `.env`, SSH keys world-writable | Any secrets or git history in tree |
| `sed -i 's/x/y/g' *.sh` | Glob expands to unexpected files; `-i` has no undo | Pattern matches broadly |
| `mv src dst` | Silently overwrites `dst` — no prompt by default | `dst` already exists |
| `cat > file` | Truncates `file` **immediately** before any data arrives | `file` has content you need |
| `find . -exec rm {} \;` | Executes on every matched file | Condition or path too broad |
| `cp -r src/ dst/` | Behavior differs if `dst/` already exists vs doesn't | Destination state unknown |

### Environment / Shell State

| Command | Hidden side effect | Dangerous context |
|---------|--------------------|-------------------|
| `source script.sh` | Permanently mutates current shell (PATH, functions, traps) — cannot be undone | Script has side effects |
| `ssh-add -D` | Removes **all** keys from agent, not just the intended one | Multiple keys loaded |
| `git config --global` | Affects **all** repos on the machine | Intended change is repo-scoped |
| `export VAR=` | Sets empty string — different from `unset VAR` in many tools | Tool checks `[[ -n "$VAR" ]]` |
| `eval "$(cmd)"` | Code injection if `cmd` output contains shell metacharacters | `cmd` reads external input |

### Process / Signals

| Command | Hidden side effect | Dangerous context |
|---------|--------------------|-------------------|
| `kill -9 PID` | No SIGTERM cleanup — can corrupt files mid-write | Process has open file handles or locks |
| `pkill -f pattern` | Matches full **command line**, not just process name — far broader | Pattern is a common substring |
| `killall name` | Kills **all** processes with that name, all users | Multi-process or multi-user system |
| `nohup cmd &` | Persists after logout with no monitoring or signal handling | One-off commands meant to be temporary |

### Make

| Command | Hidden side effect | Dangerous context |
|---------|--------------------|-------------------|
| `make clean` | `CLEANFILES` may include generated files that are slow to recreate | Generated files aren't in version control |
| `make hard-restart` (/path/to/your/project) | Wipes **all** images + volumes, full rebuild from scratch | Any persistent data or long build cache |

### Databases

| Command | Hidden side effect | Dangerous context |
|---------|--------------------|-------------------|
| `TRUNCATE table` | No `WHERE` possible; resets sequences; faster than `DELETE` but equally unrecoverable | Any data you might want back |
| `UPDATE SET col=val` without `WHERE` | Updates **all** rows — parser never warns | Forgetting the WHERE clause |
| `DELETE FROM table` without `WHERE` | Deletes all rows; transaction-safe only if not yet committed | Same |
| `VACUUM FULL` (Postgres) | Exclusive table lock — blocks **all** reads and writes for duration | Actively queried table |
| `DROP TABLE CASCADE` | Also drops dependent views, foreign keys, sequences | Dependent objects exist |

### Package Managers

| Command | Hidden side effect | Dangerous context |
|---------|--------------------|-------------------|
| `npm install` (no args) | Modifies `package-lock.json` — lock drift in CI | CI expects a pinned lockfile |
| `pip install --upgrade pkg` | Can break pinned transitive deps elsewhere in the env | Complex dependency graph |
| `apt-get upgrade` | Can upgrade kernel, restart services, break running programs | Any non-throwaway system |

### Config Artifact Updates — Manual Registries

New skills, plugins, bin scripts and permission-engine or unattended-window files must be added to manual registries (`bin/lib/claude-export/config/defaults.sh`, the firewall `SELFMOD` list, `config/permission-rules.json`): the table is in `~/.claude/.claude/rules/operator-registries.md`; `/audit` Agent I is the backstop.
