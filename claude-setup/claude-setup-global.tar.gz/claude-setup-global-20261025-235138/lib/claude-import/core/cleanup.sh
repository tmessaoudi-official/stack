#!/usr/bin/env bash
[[ -n "${_CI_CLEANUP_SH_LOADED:-}" ]] && return 0
readonly _CI_CLEANUP_SH_LOADED=1
set -euo pipefail

# The EXIT trap. An `if`, never a bare `[[ ]] && rm`: in-place mode leaves _CI_EXTRACT_DIR empty, and under set -e a
# false test as the trap's last command replaced the script's exit status (success exited 1, "global skipped" exit 2
# exited 1; P1-1, bundle-import.test.sh D1i). A failing rm still reports its own status.
ci_cleanup() {
  if [[ -n "${_CI_EXTRACT_DIR:-}" && -d "$_CI_EXTRACT_DIR" \
    && "$_CI_EXTRACT_DIR" == /tmp/claude-import-* ]]; then
    rm -rf -- "$_CI_EXTRACT_DIR"
  fi
}
