#!/usr/bin/env bash
[[ -n "${_CI_INSTALL_PROJECT_SH_LOADED:-}" ]] && return 0
readonly _CI_INSTALL_PROJECT_SH_LOADED=1
set -euo pipefail

# _ci_store_backup <target> <entry>... — copy each existing top-level <entry> of <target> into
# ~/.claude/backups/install/<epoch>-<target-basename>-XXXX/ (mode 700, never beside the project) and add a
# ledger.tsv row; prints the restore and delete lines (framework-health row 23). Twin: _ca_store_backup in
# claude-adapt/core/merge.sh (both libs ship in bundles); claude-adapt.test.sh covers both.
_ci_store_backup() {
  local target="$1"; shift
  local e present=()
  for e in "$@"; do [[ -e "$target/$e" ]] && present+=("$e"); done
  (( ${#present[@]} )) || return 0
  local store="$HOME/.claude/backups/install" dir
  ( umask 077; mkdir -p "$store" ) && chmod 700 "$store"
  dir=$(mktemp -d "$store/$(date '+%s')-$(basename "$target")-XXXX")
  for e in "${present[@]}"; do cp -a -- "$target/$e" "$dir/"; done
  printf '%s\t%s\t%s\n' "$(date '+%s')" "$target" "$dir" >> "$store/ledger.tsv"
  echo "  backup: $dir (${present[*]})" >&2
  echo "  restore: cp -a '$dir'/. '$target'/   delete once verified: rm -rf -- $dir" >&2
}

# ci_install_project <bundle_dir> <target_dir>
ci_install_project() {
  local bundle_dir="$1"
  local target_dir="$2"
  local project_src="$bundle_dir/project"

  [[ ! -d "$project_src" ]] && return 0

  local mode="merge"

  # --project-mode answers this prompt only: with no existing config there is no question, so the default merge applies
  if [[ ( -d "$target_dir/.claude" || -f "$target_dir/CLAUDE.md" ) && -n "${_CI_PROJECT_MODE:-}" ]]; then
    mode="$_CI_PROJECT_MODE"          # --project-mode: the answer is given, no prompt is read
  elif [[ -d "$target_dir/.claude" || -f "$target_dir/CLAUDE.md" ]]; then
    echo "" >&2
    echo "⚠️  Existing Claude config detected at $target_dir" >&2
    echo "   How to proceed?" >&2
    echo "     1) merge     — keep existing CLAUDE.md, only add missing .claude/ files [default]" >&2
    echo "     2) overwrite — replace existing config completely (backup created)" >&2
    echo "     3) abort     — exit without changes" >&2
    printf "   → choice (Enter for default): " >&2

    local response
    # a read at end of input (stdin /dev/null under Claude Code's Bash tool) is no answer: fail loudly instead of
    # merging silently or, under the entrypoint's set -e, exiting 1 with no message (row 23b)
    read -r response || { echo "" >&2; echo "Error: no answer on stdin: pass --project-mode merge|overwrite" >&2; return 1; }

    case "${response}" in
      ""|1|merge)    mode="merge" ;;
      2|overwrite)   mode="overwrite" ;;
      3|abort)
        echo "Aborted — no changes made." >&2
        return 0
        ;;
      *)
        echo "Unrecognised choice; using default: merge" >&2
        mode="merge"
        ;;
    esac
  fi

  if [[ "$mode" == "overwrite" ]]; then
    # every top-level entry the bundle ships is overwritten by the cp below, so each one that exists is backed up
    local entries=() e
    while IFS= read -r -d '' e; do entries+=("$(basename "$e")"); done < <(find "$project_src" -mindepth 1 -maxdepth 1 -print0)
    _ci_store_backup "$target_dir" "${entries[@]}"
    cp -a "$project_src/." "$target_dir/"
    echo "Project config installed to $target_dir (overwrite)" >&2
    return 0
  fi

  # merge mode: copy only files that do not already exist
  if [[ -d "$project_src/.claude" ]]; then
    mkdir -p "$target_dir/.claude"
    while IFS= read -r -d '' src_file; do
      local rel="${src_file#"$project_src/.claude/"}"
      local dst="$target_dir/.claude/$rel"
      if [[ ! -f "$dst" ]]; then
        mkdir -p "$(dirname "$dst")"
        cp "$src_file" "$dst"
        echo "  added: .claude/$rel" >&2
      else
        echo "  skip (exists): .claude/$rel" >&2
      fi
    done < <(find "$project_src/.claude" -type f -print0)
  fi

  # CLAUDE.md is kept in merge mode
  if [[ -f "$project_src/CLAUDE.md" && ! -f "$target_dir/CLAUDE.md" ]]; then
    cp "$project_src/CLAUDE.md" "$target_dir/CLAUDE.md"
    echo "  added: CLAUDE.md" >&2
  elif [[ -f "$project_src/CLAUDE.md" ]]; then
    echo "  skip (exists): CLAUDE.md" >&2
  fi

  echo "Project config merged into $target_dir" >&2
}
