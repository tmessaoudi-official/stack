#!/usr/bin/env bash
[[ -n "${_CI_PATH_REWRITE_SH_LOADED:-}" ]] && return 0
readonly _CI_PATH_REWRITE_SH_LOADED=1
set -euo pipefail

# ci_path_rewrite <bundle_dir>
# Rewrites /home/<origin-user>/ → /home/<current-user>/ in bundle text files.
# Detects origin user from first /home/<word>/ pattern in bundle content.
# Skips if origin == current user, or if _CI_KEEP_ORIGIN_PATHS=1.
ci_path_rewrite() {
  local bundle_dir="$1"
  local global_dir="${bundle_dir}/global"

  [[ ! -d "$global_dir" ]] && return 0

  # Detect origin user: most frequent /home/<word>/ match across text files
  # (most-frequent avoids false positives from CI or example paths like /home/runner/)
  local origin_user
  origin_user=$(
    find "$global_dir" -type f \( -name "*.sh" -o -name "*.json" -o -name "*.yaml" -o -name "*.yml" -o -name "*.template" \) \
      -not -path "*/projects/*" \
      -not -path "*/hooks/session-remember/*.md" \
      -not -path "$global_dir/bin/*" \
      -exec grep -ohP '/home/\K[a-zA-Z0-9_-]+(?=/)' {} \; 2>/dev/null \
      | sort | uniq -c | sort -rn | awk 'NR==1 {print $2}'
  )

  # A scrubbed bundle names the origin home by placeholder, not by user (/home/user from the text pass; older bundles
  # also /home/CHANGE_ME_HOME from .claude.json). The most frequent user alone picked one and left the other, so every
  # /home/<p> its MANIFEST lists is rewritten too. No MANIFEST: a literal /home/user is a real path and stays.
  local -a origins=()
  [[ -n "$origin_user" ]] && origins+=("$origin_user")
  local p
  if [[ -f "${bundle_dir}/MANIFEST.json" ]] && command -v jq >/dev/null 2>&1; then
    while IFS= read -r p; do
      [[ " ${origins[*]+"${origins[*]}"} " == *" ${p} "* ]] || origins+=("$p")   # +…: empty under set -u, bash < 4.4
    done < <(jq -r '.scrubbed_placeholders // [] | .[] | select(test("^/home/[A-Za-z0-9_-]+$")) | sub("^/home/"; "")' \
               "${bundle_dir}/MANIFEST.json")
  fi

  if (( ${#origins[@]} == 0 )); then
    echo "  [path-rewrite] no /home/<user>/ paths found in bundle — skipping" >&2
    return 0
  fi

  local current_user
  current_user=$(whoami)

  # Warn if .claude.json is present (OAuth tokens are tied to origin account)
  if [[ -f "${global_dir}/.claude.json" && "${origins[0]}" != "$current_user" ]]; then
    echo "  ⚠️  [path-rewrite] .claude.json contains OAuth tokens tied to the origin account — re-auth may be needed on this machine" >&2
  fi

  local count=0 o
  for o in "${origins[@]}"; do
    _ci_path_rewrite_one "$global_dir" "$o" "$current_user"
  done
  echo "  [path-rewrite] done — ${count} file(s) rewritten" >&2
}

# _ci_path_rewrite_one <global_dir> <origin_user> <current_user> — one origin home, path and slug spelling;
# adds to the caller's `count`.
_ci_path_rewrite_one() {
  local global_dir="$1" origin_user="$2" current_user="$3" f

  if [[ "$origin_user" == "$current_user" ]]; then
    echo "  [path-rewrite] same user ($current_user) — no rewrite needed" >&2
    return 0
  fi

  echo "  [path-rewrite] /home/${origin_user}/ → /home/${current_user}/ ..." >&2

  # The same home in its projects/<slug> spelling (every non-alnum → "-"), as session-remember's blacklist and slug
  # comments carry it; bounded like the export scrub's -home-user pass, and run twice for adjacent matches.
  local o_slug n_slug slug_e
  o_slug="$(printf '%s' "/home/${origin_user}" | sed 's/[^A-Za-z0-9]/-/g')"
  n_slug="$(printf '%s' "/home/${current_user}" | sed 's/[^A-Za-z0-9]/-/g')"
  slug_e="s#(^|[^[:alnum:]_]|\\\\[nt])${o_slug}([^[:alnum:]_]|\$)#\\1${n_slug}\\2#g"

  while IFS= read -r -d '' f; do
    local matches
    # grep without trailing slash catches both plain (/home/user/) and quoted forms (\"/home/user\")
    matches=$(grep -c -e "/home/${origin_user}" -e "$o_slug" "$f" 2>/dev/null || true)
    if [[ "$matches" -gt 0 ]]; then
      # \b word boundary replaces both forms: /home/user/path and \"/home/user\" (JSON-escaped quotes)
      sed -i "s|/home/${origin_user}\\b|/home/${current_user}|g" "$f"
      sed -i -E -e "$slug_e" -e "$slug_e" "$f"
      echo "  [path-rewrite] /home/${origin_user} → /home/${current_user} in $(basename "$f") (${matches} matches)" >&2
      ((count++)) || true
    fi
  done < <(find "$global_dir" -type f \( -name "*.sh" -o -name "*.json" -o -name "*.yaml" -o -name "*.yml" -o -name "*.template" -o -name "blacklist" \) \
    -not -path "*/projects/*" \
    -not -path "*/hooks/session-remember/*.md" \
    -not -path "$global_dir/bin/*" \
    -print0)
  # bin/ is the shipped toolchain (CODE, not user config). It carries placeholder/path
  # literals in its own source (sanitize.sh's /home/<user> sed pattern); rewriting them
  # corrupts the toolchain on cross-user import — the WSL self-corruption bug.
}
